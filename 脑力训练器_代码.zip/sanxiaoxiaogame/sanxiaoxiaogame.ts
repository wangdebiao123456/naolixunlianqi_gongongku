import PlatFormMng from "../PlatForm/PlatFormMng"; 
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng"; 
import ComFunc from "../comfuncs/ComFunc";
import BaseUIUtils from "../comfuncs/BaseUIUtils";
import PlatFormType from "../PlatForm/PlatFormType";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import HutuiAppInfoMng from "../PlatForm/HutuiAppInfoMng";
import WMap from "../WDT/WMap";
import ClientLogUtils from "../comfuncs/ClientLogUtils"; 
import ComCodeFuncMng from "../comfuncs/ComCodeFuncMng";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
import Tile from "./Tile";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import { Utils } from "../WDT/Utils";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";

const TILE_W: number = 82;
const TILE_H: number = 82;

const {ccclass, property} = cc._decorator;

@ccclass
export default class game extends cc.Component {
 
    @property(cc.Node)
    tileContainer: cc.Node = null;


    @property(cc.Node)
    targetNode: cc.Node = null;


    @property(cc.Prefab)
    tilePrefab: cc.Prefab = null;

    

    @property(cc.Prefab)
    gamesuccess_new: cc.Prefab = null;



    @property(cc.Prefab)
    game_fuhuo: cc.Prefab = null;



    @property(cc.Prefab)
    game_fail_new: cc.Prefab = null;

    
    @property(cc.Prefab)
    game_end_animate: cc.Prefab = null;

    m_game_finished = false;

    m_last_tuijian_change_tick = 0;
    m_yichu_use_count = 0;

    removeList: Tile[] = []

    tileList: Tile[] = []
    matchList: Tile[] = []
    recordList: Tile[] = []

    yichuList: Tile[] = []
  

    lvData: any = null;
    lock: boolean = false//做动画用防止误点

    txt_title: cc.Label= null;
    txt_undo: cc.Label= null;
    txt_shuffle: cc.Label= null;
    txt_hint: cc.Label = null;

    txt_yichu: cc.Label= null;

    //分数计算
    node_progress: cc.Node= null
    node_star1: cc.Node= null;
    node_star2: cc.Node= null;
    node_star3: cc.Node= null;
    countDown: boolean = false;

    node_warning: cc.Node;

    m_tuijianwe_dest_info_map = new WMap();

    m_top_yichu_offset_x = 0;

    m_last_gezi_change_tick  =0;

    m_cur_level  = 1;

    m_enter_xiaochu_chaonan_moshi=  false;

    node_tuijianyouxi = null;
    m_b_game_started = false;

    m_b_game_ended = false;
    m_game_end_star = 3;

    m_game_banner_arr = [];
    
    onLoad () 
    {
        this.node_warning =  cc.find("downPos/node_warning",this.node);
        this.txt_title =  cc.find("node_top/right/txt_title",this.node).getComponent(cc.Label);

        this.txt_undo =  cc.find("node_item/btn_undo/txt_undo",this.node).getComponent(cc.Label);
       this.txt_shuffle =  cc.find("node_item/btn_shuffle/txt_shuffle",this.node).getComponent(cc.Label);
       this.txt_hint =  cc.find("node_item/btn_hint/txt_hint",this.node).getComponent(cc.Label);
       this.txt_yichu =  cc.find("node_item/btn_yichu/txt_yichu",this.node).getComponent(cc.Label);

       this.node_tuijianyouxi =  cc.find("node_item/tuijianyouxi",this.node);
     
       this.node_tuijianyouxi.on("click",this.OnBtnMoreGame.bind(this));
      

       
       var com_quanping_gezi_show = PlatFormMng.GetInstance().IS_Dating_Game_Quanping_Gezi_Btn_Show();

       if(!com_quanping_gezi_show)
       {
            this.node_tuijianyouxi.active = false;
       }

       this.node_progress =  cc.find("node_top/right/node_progress",this.node);
       this.node_star1 =  cc.find("node_top/right/star_w1/node_star1",this.node);
       this.node_star2 =  cc.find("node_top/right/star_w2/node_star2",this.node);

       this.node_star3 =  cc.find("node_top/right/star_w3/node_star3",this.node);

       
       //判断是不是超难模式
       this.m_enter_xiaochu_chaonan_moshi = GSXC_Game_Mng.GetInstance().m_enter_xiaochu_chaonan_moshi
       this.m_cur_level = GSXC_Game_Mng.GetInstance().selectedLevel;

 
       var tiaozhan_center=  cc.find("tiaozhan_center",this.node);
       if(this.m_enter_xiaochu_chaonan_moshi)
       {
          tiaozhan_center.active = true;
       }else{
            tiaozhan_center.active = false;
       }
   
      
      
       var btn_fx = cc.find("node_top/btn_fx",this.node);
       var btn_xieyi = cc.find("node_top/btn_xieyi",this.node);

       btn_fx.on("click",this.click_dating_fenxiang.bind(this));
       btn_xieyi.on("click",this.click_xieyi.bind(this));


       var btn_help = cc.find("node_top/left/btn_help",this.node);
       btn_help.on("click",this.onBtnHelp.bind(this));



       var btn_undo = cc.find("node_item/btn_undo",this.node);
       btn_undo.on("click",this.click_undo.bind(this));


       var btn_yichu = cc.find("node_item/btn_yichu",this.node);
       btn_yichu.on("click",this.click_yichu.bind(this));

       var btn_hide_yichu=  cc.find("node_item/btn_yichu/btn_hide_yichu",this.node);

       btn_hide_yichu.on("click",this.click_hide_yichu.bind(this));

       var btn_hint=  cc.find("node_item/btn_hint",this.node);

       btn_hint.on("click",this.click_hint.bind(this));


       var btn_shuffle=  cc.find("node_item/btn_shuffle",this.node);

       btn_shuffle.on("click",this.click_shuffle.bind(this));



       var yichumenu_right=  cc.find("yichumenu/right",this.node);
       yichumenu_right.on("click",this.click_Yichu_Menu_Right.bind(this));

       var yichumenu_left=  cc.find("yichumenu/left",this.node);
       yichumenu_left.on("click",this.click_Yichu_Menu_Left.bind(this));


      
       

       var btn_set=  cc.find("node_top/left/btn_set",this.node);

       btn_set.on("click",this.OnBtnSet.bind(this));
 
       btn_fx.active = false;
       btn_xieyi.active = false;
       /*

       if(PlatFormMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_Default
        || PlatFormMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_4399_APP
        || PlatFormMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_Momoyu_Android
    )
       {
            btn_fx.active = false;
            btn_xieyi.active = false;
       }
       else if(PlatFormMng.GetInstance().IS_Fenxiang_Btn_Show())
       {
            btn_fx.active = true;
            btn_xieyi.active = false;
       }else
       {
            btn_fx.active = false;
            btn_xieyi.active = true;
       } 
       */
       
       

       this.scheduleOnce(this.FD_Init.bind(this),0.08);
       
       var ibanner_mng_time = GlobalGameMng.GetInstance().Get_Game_Banner_Mng_Time_Config(this.Get_SubGameType());
  
       this.schedule(this.FD_Banner_Mng_Timer.bind(this),ibanner_mng_time);

      //   this.replay(); 
       PlatFormMng.GetInstance().PreLoad_Jili_Shiping(1);
 
       this.Init_Top_Tuijian_Guangao();
     
          //第一次显示帮助

          var self = this;
          if (GSXC_Game_Mng.GetInstance().showHelp == 1) {
            this.lock = true
            this.scheduleOnce(() => {
                this.lock = false
                GSXC_Game_Mng.GetInstance().showHelp = 0;
                GSXC_Game_Mng.GetInstance().Save_Game_Basic_Info();
                self.onBtnHelp();
           
           
            }, 1)
        };

        var bchaogaoping=  ComFunc.ISChaoGaoPing();
 

        var in_subgame_jiaoti_gezi_arr = [];

        var bannerarr = [];
        if(bchaogaoping)
        {
            var i_need_bannertype = GlobalGameMng.GetInstance().Get_Game_Scence_Next_Bottom_Banner_Type(this.Get_SubGameType());

            if(i_need_bannertype == 1)
            {
                //banner
                bannerarr = [ 151]
            } 
            else if(i_need_bannertype == 2)
            {
                //格子
                bannerarr = [ 152]
            }
            else if(i_need_bannertype == 3)
            {
                //交替出现
                bannerarr = [151, 152];

                in_subgame_jiaoti_gezi_arr =  [151, 152];
            }
            else if(i_need_bannertype == 5)
            {
               // bannerarr = MiddleGamePlatformAction.GetInstance().Get_Game_Bottom_DanGezi_Arr();
            }
            else{

                //格子
                bannerarr = [ 152]
            }
            
        }
  
        this.m_game_banner_arr = bannerarr;


        MiddleGamePlatformAction.GetInstance().Set_In_Subgame_Valid_Gezi_Guangao_Bannerindex_Arr_Info(true,
            this.Get_SubGameType(),this.m_game_banner_arr);
 
     
        
        
        this.Check_Show_Gezi_Guanggao();

        MiddleGamePlatformAction.GetInstance().Set_In_Subgame_Bottom_Jiaoti_Show_Gezi_List(in_subgame_jiaoti_gezi_arr);

        if(this.m_enter_xiaochu_chaonan_moshi)
        {
           

            BackGroundSoundUtils.GetInstance().Play_Music("com/bjyy");


        }else{
            BackGroundSoundUtils.GetInstance().Play_Music("com/bjyy");


        }
        
       


        this.On_Game_Enter();

        this.updateItemView();

        GlobalGameMng.GetInstance().m_dating_last_from_subgame_type =  this.Get_SubGameType();
        GlobalGameMng.GetInstance().m_dating_last_from_subgame_level =  this.Get_Level();


        var isubgametype = this.Get_SubGameType();
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(11000 + isubgametype, "进入游戏子玩法", this.m_cur_level,
             "第"+this.m_cur_level+"关", 0, "", 0, "");

 
    }

    Get_Level()
    {
        return this.m_cur_level;
    }

    On_Game_Enter()
    {
         ComCodeFuncMng.On_Game_Enter(this.Get_SubGameType(),this,this.node);
    }

    Check_Show_Fuli_Or_Quanping_Gezi()
    {
        var self= this;
     

        BannerGuangaoMng.GetInstance().Check_Show_Quanping_Chaiping_Gezi(2,this.Get_SubGameType(),this.m_cur_level)
    }

    FD_Check_Need_Show_Shoukan()
    {
        if(this.m_cur_level <= 2)
        {
            return;
        }

        
        this.Check_Show_Fuli_Or_Quanping_Gezi();
    }
    FD_Init()
    {
        this.Check_Read_Prev_Save_Game_Data();

    }
    OnBtnMoreGame()
    {
        MiddleGamePlatformAction.GetInstance().Show_InGame_MoreGame_Quanping_Gezi(); 
        
      // ComCodeFuncMng.Show_InGame_MoreGame_Quanping_Gezi(this.node);
      
    }

    OnGame_Started()
    {
        var idealysec = GlobalGameMng.GetInstance().Get_GameType_Shouci_Libao_Delay_Pop_Sec(this.Get_SubGameType());

        this.scheduleOnce(this.FD_Check_Need_Show_Shoukan.bind(this),idealysec);

    }
    Check_Read_Prev_Save_Game_Data()
    {
        var prev_game_save_data = GSXC_Game_Mng.GetInstance().Get_Prev_Save_Game_Data();

        if(!prev_game_save_data)
        {

            //没有保存的数据
            this.replay();
        }
        else{
            //弹出弹框让用户选择

            var self = this;
            ComFunc.OpenNewDialog(this.node,"preab/continue_prev_game_confirm","continue_prev_game_confirm", {parentgame:this,
                
                cb:(ijixu)=>
                {
                    self.On_Select_Jixu_Prev_Game(ijixu);
               
               
             }});
    
    
            

        }
    }


    Get_SubGameType()
    {
       
        return 21;
    }
    Check_Show_Gezi_Guanggao()
    {

        
        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
 
        var banerid_map = new WMap();
        banerid_map.putData(151,1);
        banerid_map.putData(152,2); 
        
        var dangezi_arr = MiddleGamePlatformAction.GetInstance().Get_Game_Bottom_DanGezi_Arr();
        for(var hh=0;hh<dangezi_arr.length;hh++)
        {
            var hh_id = dangezi_arr[hh];
            banerid_map.putData(hh_id,2); 
      
        }
   
        for(var ff=0;ff<this.m_game_banner_arr.length;ff++)
        {
            var ff_bannerid = this.m_game_banner_arr[ff];
 
            if(!banerid_map.hasKey(ff_bannerid))
            {

                continue;
            }

            var ibanenrtype = banerid_map.getData(ff_bannerid);


            console.log("Check_Show_Gezi_Guanggao ff_bannerid="+ff_bannerid+",itype="+ibanenrtype);
            MiddleGamePlatformAction.GetInstance().Check_Create_Show_Game_Banner_A(ff_bannerid,ibanenrtype);
     
 
        }
     
 
       
        this.FD_Banner_Mng_Timer();
    }
      
 
    
    FD_Banner_Mng_Timer()
    {

        MiddleGamePlatformAction.GetInstance().FD_Banner_Mng_Timer(this.node);

    
    }
     
    undo() {

        var self = this;
        if (this.recordList.length > 0) {
            let tile = this.recordList.pop()
           // let offset = cc.v2(tile.layer * TILE_W*0.5, -tile.layer * TILE_H*0.5);


           let pos = null;

           if(this.m_enter_xiaochu_chaonan_moshi)
           {
                 pos = this.get_Chaonan_Tile_Pos(tile.row, tile.col)
             
                tile.node.zIndex = this.get_Chaonan_Tile_Zindex(tile.row, tile.col,tile.layer)   ;

           }else{

                var  offset = this.Get_Title_Offset(tile.layer);
                pos = this.getTilePos(tile.row, tile.col, offset)
                tile.node.zIndex = this.getZindex(tile.row, tile.col, tile.layer)

           }

       
            Utils.removeElementFromArray(tile, this.matchList)
            this.tileList.push(tile)

            cc.tween(tile.node).to(0.25, { position: pos }, { easing: 'sineOut' }).call(() => {
                self.checkAllBlock(true)
                self.moveToRightPos()
            }).start();


            this.Save_Chaonan_Ju_Data();
        }
    }

    Clear_ChaonanTiaozhan_Last_Save_Ju(bmustclear)
    {

        if(bmustclear)
        {
            //成功过关了，上次的数据肯定全部清掉
            GSXC_Game_Mng.GetInstance().Clear_ChaonanTiaozhan_Last_Save_Ju( );
        }
        else{

            //不是必须请空模式下，超难模式不清空上次的数据
            if(!this.m_enter_xiaochu_chaonan_moshi )
            {
                //不是超难模式，失败退出，清空数据
                GSXC_Game_Mng.GetInstance().Clear_ChaonanTiaozhan_Last_Save_Ju( );
            }


        }

        
    }
    On_Select_Jixu_Prev_Game(ijixu)
    {
        if(!ijixu)
        {
            var istartnewgk = 0;

            if(!this.m_enter_xiaochu_chaonan_moshi)
            {
                istartnewgk = GSXC_Game_Mng.GetInstance().Get_Max_Can_Enter_GK();
                this.m_cur_level =istartnewgk;
                GSXC_Game_Mng.GetInstance().selectedLevel = istartnewgk;
    
            }

          
            this.replay();
            return;
        }
        
        var prev_game_save_data = GSXC_Game_Mng.GetInstance().Get_Prev_Save_Game_Data();
        if(!prev_game_save_data)
        {
            this.replay();
            return;
        }

        var tiles = prev_game_save_data.tiles;

        if(!tiles || tiles.length == 0)
        {
            this.replay();
            return;
        }

        var igk = prev_game_save_data.igk;

        if(igk > 0)
        {
            this.m_cur_level =igk;
             GSXC_Game_Mng.GetInstance().selectedLevel = igk;

            
        }

        
        this.recycle()
        this.node_warning.active = false;


       // this.unscheduleAllCallbacks();


        this.tileList = []
        this.matchList = []
        this.recordList = []
        this.yichuList = [];
        this.lvData = null
        this.lock = false
        this.countDown = false
        this.m_yichu_use_count = 0;

        this.m_b_game_started = true;
       

        var self = this;
        //恢复上次的数据

        let minX = null;
        let minY = null;
        let maxX = null;
        let maxY = null;

        for(var ff=0;ff<tiles.length;ff++)
        {
            var ff_info = tiles[ff];

            var ff_layer = ff_info.l;
            var ff_row = ff_info.r;
            var ff_col = ff_info.c;
            
            var ff_type = ff_info.t;
            

            let tile = GSXC_Game_Mng.GetInstance().getTile('Tile');
            tile.SetIs_Chaonan(this.m_enter_xiaochu_chaonan_moshi);

            let node = tile.node
            node.parent = this.tileContainer
            node.scale = 1

            this.tileList.push(tile)
           
           
           if(this.m_enter_xiaochu_chaonan_moshi)
           {
                tile.layer = ff_layer;
                tile.row = ff_row;
                tile.col = ff_col;
               // tile.node.zIndex = ff_layer;
                let targetPos = this.get_Chaonan_Tile_Pos(ff_row, ff_col);

                tile.node.zIndex = this.get_Chaonan_Tile_Zindex(tile.row, tile.col,tile.layer)   ;

                node.position = targetPos

           }else{

                var  offset = this.Get_Title_Offset(ff_layer);

                tile.layer = ff_layer;
                tile.row = ff_row;
                tile.col = ff_col;
                tile.node.zIndex = this.getZindex(ff_row, ff_col, tile.layer)

                let targetPos = this.getTilePos(ff_row, ff_col, offset)
                node.position = targetPos
           }

      

            tile.type = ff_type;
            node.off(cc.Node.EventType.TOUCH_START)
            node.on(cc.Node.EventType.TOUCH_START, () => {
                if (!self.lock && !tile.dark) {
                    self.addToMatchList(tile)
                    BackGroundSoundUtils.GetInstance().Play_Effect_Check_Delay('com/clickcube')
                    //有了操作之后，开始倒计时
                    self.countDown = true
                
                }

            })

            if(maxX == null)
                {
                    maxX = node.x
                }else{
                    if (node.x > maxX)
                    {
                        maxX = node.x
                    }
                }
               
                
                
                if(maxY == null)
                {
                    maxY = node.y
                }else{
                    if (node.y > maxY)
                    {
                        maxY = node.y
                    }
                    
                }

             
                if(minX == null)
                {
                    minX = node.x;
                }else{
                    if (node.x < minX)
                    {
                        minX = node.x;
                    }
                }

                
                if(minY == null)
                {
                    minY = node.y
                }else{

                    if (node.y < minY)
                    {
                        minY = node.y
                    }
                }
                  
               
            
        }

        let w = maxX - minX;
        let h = maxY - minY;
        // let t = this.levelData.layouts[maxIndex].alignW == 5 ? 35 : 0
      //  this.tileContainer.x = -w * 0.5 - minX 

       // this.tileContainer.y = this.GetTileContanier_Y(minY,maxY);
     
       var tile_contanier_show_pos:cc.Vec2 = this.Cacuate_Tile_Container_Need_Show_Pos(minX,maxX,minY,maxY);
       this.tileContainer.x = tile_contanier_show_pos.x;
       this.tileContainer.y = tile_contanier_show_pos.y;



        this.checkAllBlock();



        var matchlist = prev_game_save_data.matchlist;

        
        for(var ff=0;ff<matchlist.length;ff++)
        {
            var ff_info = matchlist[ff];

            var ff_layer = ff_info.l;
            var ff_row = ff_info.r;
            var ff_col = ff_info.c;
            var ff_type = ff_info.t;
            

            let tile = GSXC_Game_Mng.GetInstance().getTile('Tile');

            tile.SetIs_Chaonan(this.m_enter_xiaochu_chaonan_moshi);

            let node = tile.node
            node.parent = this.tileContainer
            node.scale = 1

           
           
              
           if(this.m_enter_xiaochu_chaonan_moshi)
           {
                tile.layer = ff_layer;
                tile.row = ff_row;
                tile.col = ff_col;
              //  tile.node.zIndex = ff_layer;
                let targetPos = this.get_Chaonan_Tile_Pos(ff_row, ff_col);
                node.position = targetPos;

                tile.node.zIndex = this.get_Chaonan_Tile_Zindex(tile.row, tile.col,tile.layer)   ;


           }else{

                var  offset = this.Get_Title_Offset(ff_layer);

                tile.layer = ff_layer;
                tile.row = ff_row;
                tile.col = ff_col;
                tile.node.zIndex = this.getZindex(ff_row, ff_col, tile.layer)

                let targetPos = this.getTilePos(ff_row, ff_col, offset)
                node.position = targetPos
           }


       

            tile.type = ff_type;
            node.off(cc.Node.EventType.TOUCH_START)
            node.on(cc.Node.EventType.TOUCH_START, () => {
                if (!self.lock && !tile.dark) {
                    self.addToMatchList(tile)
                    BackGroundSoundUtils.GetInstance().Play_Effect_Check_Delay('com/clickcube')
                    //有了操作之后，开始倒计时
                    self.countDown = true
                
                }

            })

          
            this.matchList.push(tile);
            
        }

        var yichuList = prev_game_save_data.yichuList;


          
        for(var ff=0;ff<yichuList.length;ff++)
        {
            var ff_info = yichuList[ff];

            var ff_layer = ff_info.l;
            var ff_row = ff_info.r;
            var ff_col = ff_info.c;
            var ff_type = ff_info.t;
            

            let tile = GSXC_Game_Mng.GetInstance().getTile('Tile');

            tile.SetIs_Chaonan(this.m_enter_xiaochu_chaonan_moshi);

            let node = tile.node
            node.parent = this.tileContainer
            node.scale = 1

           
           

                
            if(this.m_enter_xiaochu_chaonan_moshi)
            {
                 tile.layer = ff_layer;
                 tile.row = ff_row;
                 tile.col = ff_col;
               //  tile.node.zIndex = ff_layer;
                 let targetPos = this.get_Chaonan_Tile_Pos(ff_row, ff_col)
                 node.position = targetPos;

                 tile.node.zIndex = this.get_Chaonan_Tile_Zindex(tile.row, tile.col,tile.layer)   ;

 
            }else{
 
                 var  offset = this.Get_Title_Offset(ff_layer);
 
                 tile.layer = ff_layer;
                 tile.row = ff_row;
                 tile.col = ff_col;
                 tile.node.zIndex = this.getZindex(ff_row, ff_col, tile.layer)
 
                 let targetPos = this.getTilePos(ff_row, ff_col, offset)
                 node.position = targetPos
            }
 
 
        

            tile.type = ff_type;
            node.off(cc.Node.EventType.TOUCH_START)
            node.on(cc.Node.EventType.TOUCH_START, () => {
                if (!this.lock && !tile.dark) {
                    this.addToMatchList(tile)
                    BackGroundSoundUtils.GetInstance().Play_Effect_Check_Delay('com/clickcube')
                    //有了操作之后，开始倒计时
                    this.countDown = true
                
                }

            })

          
            this.yichuList.push(tile);
            
        }


              
        this.setMatchDepth();
        this.moveToRightPos();
        this.checkRemove();
        this.checkAllBlock(true);
        this.checkWarning();
        this.checkGameResult();
        
        this.Refresh_Yichu_List();
        this.Refresh_Yichu_Menu();

        this.Refresh_Level_Info();

        this.OnGame_Started();

    }
    //保存本局的信息
    Get_Cur_Ju_Current_Save_Data()
    {

        var icurgk = this.m_cur_level;
        if(this.m_enter_xiaochu_chaonan_moshi)
        {
            icurgk = 0;
        }

        var obj = {
            bvalid:1,
            igk:icurgk,
            tiles:[],
            matchlist:[],
            yichuList:[]
        };


        var titles_info = [];


        for(var ff=0;ff<this.tileList.length;ff++)
        {
            var ff_tile:Tile = this.tileList[ff];
 
            var ff_layer=  ff_tile.layer;
            var ff_row =  ff_tile.row;
            var ff_col =  ff_tile.col;
            var ff_type = ff_tile.type;

            var ff_obj = {
                "l":ff_layer,
                "r":ff_row,
                "c":ff_col,
                "t":ff_type
            }

            titles_info.push(ff_obj);
        }
        
        obj.tiles = titles_info;


        var match_obj_list = [];

        for(var ff=0;ff<this.matchList.length;ff++)
        {
            var ff_match_obj:Tile = this.matchList[ff];

            var ff_layer=  ff_match_obj.layer;
            var ff_row =  ff_match_obj.row;
            var ff_col =  ff_match_obj.col;
            var ff_type = ff_match_obj.type;

            var ff_obj = {
                "l":ff_layer,
                "r":ff_row,
                "c":ff_col,
                "t":ff_type
            }

            match_obj_list.push(ff_obj);
            
        }

        obj.matchlist = match_obj_list;



        var yichu_obj_list = [];

        for(var ff=0;ff<this.yichuList.length;ff++)
        {
            var ffyichu_obj:Tile = this.yichuList[ff];

            var ff_layer=  ffyichu_obj.layer;
            var ff_row =  ffyichu_obj.row;
            var ff_col =  ffyichu_obj.col;
            var ff_type = ffyichu_obj.type;

            var ff_obj = {
                "l":ff_layer,
                "r":ff_row,
                "c":ff_col,
                "t":ff_type
            }

            yichu_obj_list.push(ff_obj);
            
        }

        obj.yichuList = yichu_obj_list;

        

        return obj;
    }
    Save_Chaonan_Ju_Data()
    {
         
        if (this.matchList.length >= 7) {
      
            return;
        }
      
        if(this.tileList.length == 0)
        {
            return;
        }
        
        
        var all_ju_save_data = this.Get_Cur_Ju_Current_Save_Data();

        GSXC_Game_Mng.GetInstance().Save_Curju_ChaoNanMoshiData(all_ju_save_data);

    }
    OnBtnSelGK()
    {

        
       // MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);

        var isubgametype = this.Get_SubGameType();
        var igk = this.m_cur_level;

        var imax_can_enter_gk = GSXC_Game_Mng.GetInstance().Get_Max_Can_Enter_GK();

        var self = this;
        ComFunc.OpenNewDialog(this.node,"preab/selectgk","selectgk", { parentgame:this,
            isubgametype:isubgametype,igk:igk,imax_can_enter_gk:imax_can_enter_gk,
            
            cb:(lv)=>
        {
             
            GSXC_Game_Mng.GetInstance().selectedLevel = lv;

                self.Clear_ChaonanTiaozhan_Last_Save_Ju(true);
                self.RealLoadScence();
            //  cc.director.loadScene("game");
            
           // self.OnBtnSelGK();
        },
        close_exit_Callback:()=>
        {
           // MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(11,true);
        }
    
    
        }); 
    }

    OnTiaoguoBenGuang()
    {

        this.On_Game_Success();
    }
    OnBtnSet()
    {
        var isubgametype = this.Get_SubGameType();
        var igk = this.m_cur_level;


        var bshowtiaoguogk = false;

        var hidexuanguang = false;
        if(this.m_enter_xiaochu_chaonan_moshi)
        {
            hidexuanguang = true;
        }
        else{

            //普通模式


            if(this.m_b_game_started && !this.m_b_game_ended)
            {
                bshowtiaoguogk = true;
            }
            

        }


        var self = this;
        ComFunc.OpenNewDialog(this.node,"preab/pausedlg","pausedlg", {isubgametype:isubgametype,igk:igk,
            hidexuanguang:hidexuanguang, parentgame:this,
            bshowtiaoguogk:bshowtiaoguogk,b_hide_shangcheng:true,
            tiaoguo_gk_cb:()=>
            {
                self.OnTiaoguoBenGuang();
            },paihangbang_cb:()=>
            {
                self.OnBtn_PaihangBang();
            },
            cb:()=>
            {

                self.OnBtnSelGK();
            }});
    }
    OnBtn_PaihangBang()
    {

        ComCodeFuncMng.OnBtn_PaihangBang(this,this.node,this.Get_SubGameType())
      
    }
    click_yichu()
    {
        if(this.m_game_finished)
        {
            return;
        }
        if(!this.m_b_game_started)
        {
            return;
        }
        if(this.matchList.length < 3)
        {
            BaseUIUtils.ShowTipTxtDlg('下方列表还没有三个砖块!',this.node);  
            return;
        }


        var self = this;


        if(GSXC_Game_Mng.GetInstance().itemYichu  <= 0)
        {
           // SoundManager.GetInstance().Play_Effect('clickbtn');
    
            /*
            ComFunc.OpenNewDialog(this.node,"preab/Goumai_Daoju","Goumai_Daoju", {itype:2,bshowcancel:false,parentgame:this,
                callback:(bsuc)=>
                {
                    self.updateItemView(); 
                    BaseUIUtils.ShowTipTxtDlg('购买道具成功!',self.node);
                }});



            return;
            */


            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node, 
                ()=>{},
                "三消消使用移除",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
    
    
                self.RealYichuFK();
    
            }, this.Get_SubGameType());


            return;
        }

        GSXC_Game_Mng.GetInstance().itemYichu--;
        self.RealYichuFK();


        

    }

    RealYichuFK()
    {

        this.m_yichu_use_count ++;
        GSXC_Game_Mng.GetInstance().Save_Game_Basic_Info();
        this.updateItemView();
        this.Yichu();

        BaseUIUtils.ShowTipTxtDlg('成功移出三个方块!',this.node);

        

        var isubgametype=  this.Get_SubGameType();
        var idaojutype = 100000 + isubgametype*100 + 2;


        ClientLogUtils.GetInstance().Poset_Server_JS_Log(33, "使用道具", idaojutype,
        "道具:"+idaojutype, isubgametype, "道具:"+idaojutype, this.m_cur_level,  "第"+this.m_cur_level+"关");
    }
    click_hide_yichu()
    {
        BaseUIUtils.ShowTipTxtDlg('每关只能使用一次移出哦!',this.node)
    }
    click_shuffle() {
        if(this.m_game_finished)
        {
            return;
        }
        if(!this.m_b_game_started)
        {
            return;
        }

        var self=  this;
        if(GSXC_Game_Mng.GetInstance().itemShuffle  <= 0)
        {
            BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
    
            ComFunc.OpenNewDialog(this.node,"preab/Goumai_Daoju","Goumai_Daoju", {itype:4,bshowcancel:false,
                igk:this.m_cur_level,
                bchaonan:this.m_enter_xiaochu_chaonan_moshi,
                parentgame:this,
                callback:(bsuc)=>
                {
                    self.updateItemView(); 
                    BaseUIUtils.ShowTipTxtDlg('购买道具成功!',self.node);


          }});



            return;
        }

      

        GSXC_Game_Mng.GetInstance().itemShuffle--;
        GSXC_Game_Mng.GetInstance().Save_Game_Basic_Info();
        this.updateItemView();
        this.shuffle();


        var isubgametype=  this.Get_SubGameType();
        var idaojutype = 100000 + isubgametype*100 + 4;


        ClientLogUtils.GetInstance().Poset_Server_JS_Log(33, "使用道具", idaojutype,
        "道具:"+idaojutype, isubgametype, "道具:"+idaojutype, this.m_cur_level,  "第"+this.m_cur_level+"关");

    }
    swapTile(tileA: Tile, tileB: Tile) {

        let tempRow = tileA.row
        tileA.row = tileB.row
        tileB.row = tempRow

        let tempCol = tileA.col
        tileA.col = tileB.col
        tileB.col = tempCol

        let tempLayer = tileA.layer
        tileA.layer = tileB.layer
        tileB.layer = tempLayer

        let tempZindex = tileA.node.zIndex
        tileA.node.zIndex = tileB.node.zIndex
        tileB.node.zIndex = tempZindex

    }
    shuffle() {
        for (let i = 0; i < 500; i++) {
            let rndA = Math.floor(Math.random() * this.tileList.length)
            let rndB = Math.floor(Math.random() * this.tileList.length)
            if (rndA != rndB) {
                let nodeA = this.tileList[rndA]
                let nodeB = this.tileList[rndB]
                this.swapTile(nodeA, nodeB)
            }
        }
        for (const tile of this.tileList) {
           // let offset = cc.v2(tile.layer * TILE_W*0.5, -tile.layer * TILE_H*0.5);

           let pos = new cc.Vec3(0,0,0);

           if(this.m_enter_xiaochu_chaonan_moshi)
           {
                 pos = this.get_Chaonan_Tile_Pos(tile.row, tile.col)
                //tile.node.position = targetPos;
                tile.node.zIndex = this.get_Chaonan_Tile_Zindex(tile.row, tile.col,tile.layer)   ;


           }else{

                var  offset = this.Get_Title_Offset(tile.layer);

                  pos = this.getTilePos(tile.row, tile.col, offset);

           }





            cc.Tween.stopAllByTarget(tile.node)
            cc.tween(tile.node).to(0.25, { position: pos }).call(() => {
                this.checkAllBlock(true)
            }).start()
        }


        this.Save_Chaonan_Ju_Data();
    }
    click_hint() {
        if(this.m_game_finished)
        {
            return;
        }
        if(!this.m_b_game_started)
        {
            return;
        }
        var self = this;
        if(GSXC_Game_Mng.GetInstance().itemHint  <= 0)
        {
            BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
            ComFunc.OpenNewDialog(this.node,"preab/Goumai_Daoju","Goumai_Daoju",
             {itype:3,bshowcancel:false,parentgame:this, igk:this.m_cur_level,
                callback:(bsuc)=>
                {
                    self.updateItemView(); 
                    BaseUIUtils.ShowTipTxtDlg('购买道具成功!',self.node);
                }});



     


                
            return;
        }

    
        var bsuc = this.searchRemoveable();

     
        if(bsuc)
        {
            GSXC_Game_Mng.GetInstance().itemHint--;
            GSXC_Game_Mng.GetInstance().Save_Game_Basic_Info();
            this.updateItemView();


            

            var isubgametype=  this.Get_SubGameType();
            var idaojutype = 100000 + isubgametype*100 + 3;


            ClientLogUtils.GetInstance().Poset_Server_JS_Log(33, "使用道具", idaojutype,
            "道具:"+idaojutype, isubgametype, "道具:"+idaojutype, this.m_cur_level,  "第"+this.m_cur_level+"关");
        }

    


    }
    searchRemoveable() {
        let arrDark: any = []
        let objLight: any = {}
        for (let i = this.tileList.length - 1; i >= 0; i--) {
            let tile = this.tileList[i]
            if (!tile.dark) {
                objLight[tile.type] = objLight[tile.type] || []
                objLight[tile.type].push(tile)
            } else {
                arrDark.push(tile)
            }

        }

        var bfirst_find = false;

        //底部tiles
        if (this.matchList.length > 0) {
            let bottomObj: any = {}
            for (const bottom of this.matchList) {
                bottomObj[bottom.type] = bottomObj[bottom.type] || []
                bottomObj[bottom.type].push(bottom)
            }
            let bottomArr = []
            for (const key in bottomObj) {
                bottomArr.push({ type: Number(key), tiles: bottomObj[key], count: bottomObj[key].length })
            }
            bottomArr.sort((a, b) => {
                return b.count - a.count
            })







            let first = bottomArr[0]
            let needCount = 3 - first.count
            let needType = first.type;
            for (let i = 0; i < this.tileList.length; i++) {
                if (this.tileList[i].type == needType) {
                    this.addToMatchList(this.tileList[i])
                    needCount--
                    if (needCount == 0)
                    {
                        bfirst_find = true;
                        break;
                    }
                        
                }
            }


            if(!bfirst_find)
            {
                for (let i = 0; i < this.yichuList.length; i++) {
                    if (this.yichuList[i].type == needType) {
                        this.addToMatchList(this.yichuList[i])
                        needCount--
                        if (needCount == 0)
                        {
                            bfirst_find = true;
                            break;
                        }
                            
                    }
                }
            }



        } 
        
        
        if(!bfirst_find)
        {

            let lightArr = []
            for (const key in objLight) {
                lightArr.push({ type: Number(key), tiles: objLight[key], count: objLight[key].length })
            }
            lightArr.sort((a, b) => {
                return b.count - a.count
            })



            let first = lightArr[0]
            let ownCount = Math.min(3, first.tiles.length)
            for (let i = 0; i < ownCount; i++) {
                this.addToMatchList(first.tiles[i])
            }
            let leftCount = Math.max(0, 3 - first.count)
            let needType = first.type
            if (leftCount > 0) {
                for (const temp of arrDark) {
                    if (temp.type == needType) {
                        this.addToMatchList(temp)
                        leftCount--
                        if (leftCount == 0)
                            break
                    }
                }
            }


        }




        return true;
    }
    click_undo() {
        if(this.m_game_finished)
        {
            return;
        }
        if(!this.m_b_game_started)
        {
            return;
        }

        if (this.recordList.length == 0) {
            BaseUIUtils.ShowTipTxtDlg('没有操作的记录!',this.node);
            return
        }

        var self = this;

        if(GSXC_Game_Mng.GetInstance().itemUndo  <= 0)
        {
            BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
            ComFunc.OpenNewDialog(this.node,"preab/Goumai_Daoju","Goumai_Daoju", 
            {itype:1,bshowcancel:false,parentgame:this,
                igk:this.m_cur_level,
                callback:(bsuc)=>
                {
                    self.updateItemView(); 
                    BaseUIUtils.ShowTipTxtDlg('购买道具成功!',self.node);
                }});
            /*
            Core.win.open(GameConst.winPath.Goumai_Daoju,
                {
                    itype:1,
                    callback: () => {
                        this.updateItemView();
                        MsgHints.show('购买道具成功')
        

                    }
                })


*/

            return;
        }else{
            GSXC_Game_Mng.GetInstance().itemUndo--;
            GSXC_Game_Mng.GetInstance().Save_Game_Basic_Info();
            this.updateItemView();
            this.undo();



            var isubgametype=  this.Get_SubGameType();
            var idaojutype = 100000 + isubgametype*100 + 1;
    
    
            ClientLogUtils.GetInstance().Poset_Server_JS_Log(33, "使用道具", idaojutype,
            "道具:"+idaojutype, isubgametype, "道具:"+idaojutype, this.m_cur_level,  "第"+this.m_cur_level+"关");
        }

 
    }
    onBtnHelp()
    {
        ComFunc.OpenNewDialog(this.node,"preab/gamehelp","gamehelp", { },130);
    }

    click_xieyi()
    {
        ComFunc.OpenNewDialog(this.node,"preab/yonghuxieyi","yonghuxieyi", {bshowcancel:false,parentgame:this,
            cb:(bsuc)=>
            {
                
            }});
        //Core.win.open(GameConst.winPath.gamexieyi,{bshowcancel:false,cb:()=>{}})
    }
    click_dating_fenxiang()
    {
        PlatFormMng.GetInstance().Dating_Fenxiang();
    }




    replay() {


        this.m_b_game_started = false;


        this.recycle()
        this.node_warning.active = false;

       // this.unscheduleAllCallbacks();


        this.tileList = [];
        this.matchList = []
        this.recordList = []
        this.yichuList = [];
        this.lvData = null
        this.lock = false
        this.countDown = false
        this.m_yichu_use_count = 0;



        if(this.m_enter_xiaochu_chaonan_moshi)
        {
            this.loadChallengeLevel();
        }else{
            this.loadLevels();
        }

     



        this.Refresh_Yichu_Menu();

        GSXC_Game_Mng.GetInstance().Clear_ChaonanTiaozhan_Last_Save_Ju();
        
       
        MiddleGamePlatformAction.GetInstance().Start_Luping();
        
        this.OnGame_Started();
        
    }
    recycle() {
        for (const temp of this.tileList) {
            temp.recycle()
        }
        for (const temp of this.matchList) {
            temp.recycle()
        }

        for (const temp of this.yichuList) {
            temp.recycle()
        }

    }


    Refresh_Level_Info()
    {

        if(this.m_enter_xiaochu_chaonan_moshi)
        { 
            this.txt_title.string = '挑战模式'
    
        }else{ 
            this.txt_title.string = '第' + this.m_cur_level + '关'
    
        }
    }
    
    get_Chaonan_Tile_Pos(ix,iy)
    {
        
        var x = ix*11  ;
        var y =100-  iy*11;


        return new cc.Vec3(x,y,0);
     
       // node.x = x;
       //   node.y = 100- y;
    }
    loadChallengeLevel()
    {
        let minX = null;
        let minY = null;
        let maxX = null;
        let maxY = null;


       

        let init_chaonan_gk_data =  GSXC_Game_Mng.GetInstance().Get_Init_Chaonan_GK_Data();

    
        var block_count = GSXC_Game_Mng.GetInstance().Get_Init_Chaonan_GK_Block_Type_Count();

        let types = GSXC_Game_Mng.getGSTypes(init_chaonan_gk_data.length, block_count);
        console.log("init_chaonan_gk_data.len="+init_chaonan_gk_data.length+",block_count="+block_count);


        types = Utils.randomArray(types);

        var self = this;

        for (let i = 0; i < init_chaonan_gk_data.length; i++) 
        {
                
            if(i >= types.length)
            {
                break;

            }
            let info = init_chaonan_gk_data[i];

            var ix = info[0];
            var iy = info[1];
            var iz = info[2];


            let tile:Tile = GSXC_Game_Mng.GetInstance().getTile('Tile');

            tile.SetIs_Chaonan(true);

            let node = tile.node
            node.parent = this.tileContainer
            node.scale = 1;


            var x = ix*11  ;
            var y = iy*11;


              
            tile.row = ix;
            tile.col = iy;
            tile.layer =Number(iz);
            let targetPos = this.get_Chaonan_Tile_Pos(ix,iy);

            node.position = targetPos
            tile.node.zIndex = this.get_Chaonan_Tile_Zindex(tile.row, tile.col,tile.layer)   ;

           // node.x = x;
           //   node.y = 100- y;

            

          //  node.x = Number(info[0]);;
          //  node.y = 200-Number(info[1]);



            this.tileList.push(tile)
          
           // tile.node.zIndex = Number(iz);

       
            tile.type = types[i];


            node.off(cc.Node.EventType.TOUCH_START)
            node.on(cc.Node.EventType.TOUCH_START, () => {
                if (!self.lock && !tile.dark) {
                    self.addToMatchList(tile)
                    BackGroundSoundUtils.GetInstance().Play_Effect_Check_Delay('com/clickcube')
                    //有了操作之后，开始倒计时
                    self.countDown = true
                
                }

            })

            if(maxX == null)
            {
                maxX = node.x
            }else{
                if (node.x > maxX)
                {
                    maxX = node.x
                }
            }
           
            
            
            if(maxY == null)
            {
                maxY = node.y
            }else{
                if (node.y > maxY)
                {
                    maxY = node.y
                }
                
            }

         
            if(minX == null)
            {
                minX = node.x;
            }else{
                if (node.x < minX)
                {
                    minX = node.x;
                }
            }

            
            if(minY == null)
            {
                minY = node.y
            }else{

                if (node.y < minY)
                {
                    minY = node.y
                }
            }
        }
        let w = maxX - minX;
        let h = maxY - minY;
        // let t = this.levelData.layouts[maxIndex].alignW == 5 ? 35 : 0


        var tile_contanier_show_pos:cc.Vec2 = this.Cacuate_Tile_Container_Need_Show_Pos(minX,maxX,minY,maxY);
        this.tileContainer.x = tile_contanier_show_pos.x;
        this.tileContainer.y = tile_contanier_show_pos.y;

        /*
        this.tileContainer.x = -w * 0.5 - minX
       // this.tileContainer.y = (h >> 1) - maxY + 124;

        this.tileContainer.y = this.GetTileContanier_Y(minY,maxY);

        */


     
        this.lock = false;
      //  this.m_b_game_started = true;
        this.checkAllBlock();



        let aniPos = [cc.v2(0, 1400), cc.v2(900, 0), cc.v2(0, -1400), cc.v2(-900, 0)]

        var icount_layer = 0;

       
        //做动画
        let all = this.tileContainer.children
        for (const node of all) {
            let tile = node.getComponent(Tile)
            let i = tile.layer;
            let t_row = tile.row;
            let t_col = tile.col;
          
       
            var it = Math.floor(i/10);

            if(it > icount_layer)
            {
                icount_layer = it;
            }

            let targetPos = this.get_Chaonan_Tile_Pos(t_row,t_col);

            node.position = targetPos
            node.position = cc.v3(targetPos.x + aniPos[i % 4].x, targetPos.y + aniPos[i % 4].y)
            cc.tween(node).delay(it * 0.2 + 0.1).call(() => {
                BackGroundSoundUtils.GetInstance().Play_Effect_Check_Delay('com/swtich', 10)
            }).to(0.25, { position: targetPos }, { easing: 'sineOut' }).start()

        }
        


        var iallneedtime = icount_layer * 0.2 + 0.5;

        var self= this;
         
        var lastseq = cc.sequence(cc.delayTime(iallneedtime),cc.callFunc(()=>
        {
            self.m_b_game_started = true;

        }));

        this.node.runAction(lastseq);



        this.updateItemView();
        
        this.Refresh_Level_Info();
    }
    loadLevels() {
        


        if(this.m_enter_xiaochu_chaonan_moshi)
        {
            this.lvData = GSXC_Game_Mng.GetInstance().Get_ChaoNanMoshi_Data();
            this.txt_title.string = '超难模式'
    
        }else{
            this.lvData = GSXC_Game_Mng.GetInstance().readLevelData(this.m_cur_level)
            this.txt_title.string = '第' + this.m_cur_level + '关'
    
        }


        this.node_progress.scaleX = 1
        this.node_star1.active = this.node_star2.active = this.node_star3.active = true
        this.updateItemView()
        this.createTiles()

        this.Refresh_Level_Info();
    }
    updateItemView() {

        var hint_cicle=  cc.find("node_item/btn_hint/circle",this.node);
        hint_cicle.active = GSXC_Game_Mng.GetInstance().itemHint == 0 ? false:true;
   
        this.txt_hint.string = GSXC_Game_Mng.GetInstance().itemHint == 0 ? '' : GSXC_Game_Mng.GetInstance().itemHint + ''


        var txt_yichu =  cc.find("node_item/btn_yichu/txt_yichu",this.node);
      
        var yichu_cicle=  cc.find("node_item/btn_yichu/circle",this.node);
        var btn_hide_yichu=  cc.find("node_item/btn_yichu/btn_hide_yichu",this.node);
        var btn_yichu_shiping =  cc.find("node_item/btn_yichu/sp",this.node);

        var btn_yichu=  cc.find("node_item/btn_yichu",this.node);

        btn_yichu.getComponent(cc.Button).interactable = true;// this.m_yichu_use_count > 0 ? false:true;
        yichu_cicle.active =  GSXC_Game_Mng.GetInstance().itemYichu == 0 ? false:true;
        txt_yichu.active =  GSXC_Game_Mng.GetInstance().itemYichu == 0 ? false:true;

        btn_hide_yichu.active = false;// this.m_yichu_use_count > 0 ? true:false;

   
        this.txt_yichu.string = GSXC_Game_Mng.GetInstance().itemYichu == 0 ? '' : GSXC_Game_Mng.GetInstance().itemYichu + ''



        btn_yichu_shiping.active =   GSXC_Game_Mng.GetInstance().itemYichu == 0 ? true:false;




        var shuffle_cicle=  cc.find("node_item/btn_shuffle/circle",this.node);
        shuffle_cicle.active = GSXC_Game_Mng.GetInstance().itemShuffle == 0 ? false:true;
   
        this.txt_shuffle.string = GSXC_Game_Mng.GetInstance().itemShuffle == 0 ? '' : GSXC_Game_Mng.GetInstance().itemShuffle + ''



        var undo_cicle=  cc.find("node_item/btn_undo/circle",this.node);
        undo_cicle.active = GSXC_Game_Mng.GetInstance().itemUndo == 0 ? false:true;
      
        this.txt_undo.string = GSXC_Game_Mng.GetInstance().itemUndo == 0 ? '' : GSXC_Game_Mng.GetInstance().itemUndo + ''
    }
    getTilePos(row: number, col: number, offset: cc.Vec2) 
    {

        if(ComFunc.ISChaoGaoPing())
        {
         //   return cc.v3(col * TILE_W + offset.x, -row * TILE_H + offset.y +10  , 0);
        }

        return cc.v3(col * TILE_W + offset.x, -row * TILE_H + offset.y - 15, 0);
    }
    checkAllBlock(ani: boolean = false) {
        for (const tile of this.tileList) {
            if (this.hasBlock(tile)) {
                tile.setDark(true, ani)
            } else {
                tile.setDark(false, ani)
            }
        }
    }
    hasBlock(tile: Tile) {
        let tileRec = tile.node.getBoundingBox()
       
        for (const tempTile of this.tileList) {
            if (tempTile == tile) continue
            if (tempTile.layer > tile.layer) {                
                if (tempTile.node.getBoundingBox().intersects(tileRec)) {
                    return true
                }
            }
        }
        return false
    }


    Get_Title_Offset(tileindex)
    {
       // let offset = cc.v2(TILE_W*0.5 * tileindex, -TILE_H*0.5 * tileindex);

        var chaonanoffset_x = TILE_W*0.5 * tileindex;
        var chaonanoffset_y =  -TILE_H*0.5 * tileindex;


        //超难模式
        if(this.m_enter_xiaochu_chaonan_moshi)
        {
            var i_xiuzheng = Math.floor(tileindex%2);

              chaonanoffset_x = TILE_W*0.5 * i_xiuzheng;
              chaonanoffset_y =  -TILE_H*0.5 * i_xiuzheng;


        }
        var offset = new cc.Vec2(chaonanoffset_x,chaonanoffset_y);
        return offset;
    }
    GetTileContanier_Y(minY,maxY)
    {
   

        let h = maxY - minY
      
        // var y = (h >> 1) - maxY + 224;


        //普通居中
         var y = (maxY - minY)/2 - maxY + 224;
     

         var imaxheight = 450;



         



         if(this.m_enter_xiaochu_chaonan_moshi)
         {
              imaxheight = 450;

         }else{
             //普通模式下
            if(ComFunc.ISChaoGaoPing())
            {
               imaxheight = 450 + 100;
            }
         }





         //如果高度超过450,贴着下面
        if(h > imaxheight)
        {
             y =  -120- minY;


             console.log("GetTileContanier_Y h="+h);
        }
     
        // miny + y


         return y;
    }
    createTiles() {
        this.tileContainer.destroyAllChildren()
        let aniPos = [cc.v2(0, 1400), cc.v2(900, 0), cc.v2(0, -1400), cc.v2(-900, 0)]

        if(this.lvData.typeCount > 41)
        {
            this.lvData.typeCount = 41;
        }
        var self = this;

        let types = GSXC_Game_Mng.getGSTypes(this.lvData.count, this.lvData.typeCount)
        types = Utils.randomArray(types)
        let c = 0;
        let minX = null;
        let minY = null;
        let maxX = null;
        let maxY = null;
        for (let i = 0; i < this.lvData.floorIds.length; i++) 
        {
            
            let floorData = GSXC_Game_Mng.GetInstance().get_Level_FloorData(Number(this.lvData.floorIds[i]))
            let tiles = floorData.layouts;
            
            if(c >= types.length)
            {
                break;

            }

            for (const info of tiles) 
            {
                if(c >= types.length)
                {
                    break;

                }


                let pos = info.split(',')
                let row = Number(pos[0])
                let col = Number(pos[1])
                // let node = cc.instantiate(this.tilePrefab)
                //  node.parent = this.tileContainer
                // let tile = node.getComponent(Tile)
                let tile = GSXC_Game_Mng.GetInstance().getTile('Tile')
                let node = tile.node
                node.parent = this.tileContainer
                node.scale = 1

                this.tileList.push(tile)
               
               
               

               var  offset = this.Get_Title_Offset(i);


               
                tile.layer = i;
                tile.row = row;
                tile.col = col;
                tile.node.zIndex = this.getZindex(row, col, tile.layer)

                let targetPos = this.getTilePos(row, col, offset)
                node.position = targetPos

                tile.type = types[c];
                node.off(cc.Node.EventType.TOUCH_START)
                node.on(cc.Node.EventType.TOUCH_START, () => {
                    if (!self.lock && !tile.dark) {
                        self.addToMatchList(tile)
                        BackGroundSoundUtils.GetInstance().Play_Effect_Check_Delay('com/clickcube')
                        //有了操作之后，开始倒计时
                        self.countDown = true
                    
                    }

                })


                if(maxX == null)
                {
                    maxX = node.x
                }else{
                    if (node.x > maxX)
                    {
                        maxX = node.x
                    }
                }
               
                
                
                if(maxY == null)
                {
                    maxY = node.y
                }else{
                    if (node.y > maxY)
                    {
                        maxY = node.y
                    }
                    
                }

             
                if(minX == null)
                {
                    minX = node.x;
                }else{
                    if (node.x < minX)
                    {
                        minX = node.x;
                    }
                }

                
                if(minY == null)
                {
                    minY = node.y
                }else{

                    if (node.y < minY)
                    {
                        minY = node.y
                    }
                }
                  
               
                 

                c++;


            }
           
        }

        let w = maxX - minX
        let h = maxY - minY
        // let t = this.levelData.layouts[maxIndex].alignW == 5 ? 35 : 0
       // this.tileContainer.x = -w * 0.5 - minX
      //  this.tileContainer.y = (h >> 1) - maxY + 224
       
       // this.tileContainer.y = this.GetTileContanier_Y(minY,maxY);
       

     
        var tile_contanier_show_pos:cc.Vec2 = this.Cacuate_Tile_Container_Need_Show_Pos(minX,maxX,minY,maxY);
        this.tileContainer.x = tile_contanier_show_pos.x;
        this.tileContainer.y = tile_contanier_show_pos.y;

        


        this.checkAllBlock();



        var icount_layer = 0;

        //做动画
        let all = this.tileContainer.children
        for (const node of all) {
            let tile = node.getComponent(Tile)
            let i = tile.layer;
           
         
            var  offset = this.Get_Title_Offset(i);


            if(icount_layer < i)
            {
                icount_layer=  i;
            }

            let targetPos = this.getTilePos(tile.row, tile.col, offset)
            node.position = targetPos
            node.position = cc.v3(targetPos.x + aniPos[i % 4].x, targetPos.y + aniPos[i % 4].y)
            cc.tween(node).delay(i * 0.2 + 0.1).call(() => {
                BackGroundSoundUtils.GetInstance().Play_Effect_Check_Delay('com/swtich', 10)
            }).to(0.25, { position: targetPos }, { easing: 'sineOut' }).start()

        }


        var iallneedtime = icount_layer * 0.2 + 0.5;

        var self= this;
         
        var lastseq = cc.sequence(cc.delayTime(iallneedtime),cc.callFunc(()=>
        {
            self.m_b_game_started = true;

        }));

        this.node.runAction(lastseq);
 
        //第一次显示帮助
        if (GSXC_Game_Mng.GetInstance().showHelp == 1) {
            this.lock = true
            this.scheduleOnce(() => {
                this.lock = false
                GSXC_Game_Mng.GetInstance().showHelp = 0;

                GSXC_Game_Mng.GetInstance().Save_Game_Basic_Info();
               // Model.save()
               // Core.win.open(GameConst.winPath.HelpWin)
           
           
           
            }, 1)
        }
    }

    getZindex(row, col, layer) {
        return row * 20 + col + layer * 200
    }
    get_Chaonan_Tile_Zindex(ix,iy,iz)
    {
        return  ix + iy + iz * 200
 
    }
     //添加到列表
     addToMatchList(tile: Tile,bneedsave = true) {

        if(!this.m_b_game_started)
        {
            return;
        }
        if(this.m_b_game_ended )
        {
            return;
        }


        if (this.tileList.length == 0) {


            this.On_Game_Success();
 
          
        }
        else if (this.matchList.length < 7) {
            if (this.matchList.indexOf(tile) != -1) return


            tile.setDark(false, false);
 
            var binyichu  =  Utils.IsElementInArray(tile, this.yichuList);


            Utils.removeElementFromArray(tile, this.tileList);
            Utils.removeElementFromArray(tile, this.yichuList);
           

            if(binyichu && this.yichuList.length <= 9)
            {
                this.m_top_yichu_offset_x = 0;
            }
            this.Refresh_Yichu_List();

            this.recordList.push(tile)

            tile.node.zIndex = 999
            let bol = false
            for (let i = this.matchList.length - 1; i >= 0; i--) {
                if (this.matchList[i].type == tile.type) {
                    bol = true
                    this.matchList.splice(i + 1, 0, tile)
                    break
                }
            }
            if (!bol)
            {
                this.matchList.push(tile);
            }
            
                
            this.setMatchDepth();
            this.moveToRightPos();
            this.checkRemove();
            this.checkAllBlock(true);
            this.checkWarning();
            this.checkGameResult();
            
            this.Refresh_Yichu_Menu();


            this.Save_Chaonan_Ju_Data();
        }else{
             
        }

    }
    Yichu()
    {
        
        var yichu_list = this.matchList.slice(0,3);

        for(var ff=0;ff<yichu_list.length;ff++)
        {
            var ff_title = yichu_list[ff];
            Utils.removeElementFromArray(ff_title, this.recordList);
            Utils.removeElementFromArray(ff_title, this.matchList);

            this.yichuList.push(ff_title);
        }


        this.m_top_yichu_offset_x = 0;
             
        this.moveToRightPos();

        this.Refresh_Yichu_List();

        this.Refresh_Yichu_Menu();

        
        this.Save_Chaonan_Ju_Data();
    }

    Init_Top_Tuijian_Guangao()
    { 
         
        var othergame_node = cc.find("node_other_tuijian2/othergame",this.node);

        var pos1 = this.Get_SubGameType() + 51000 ; 
        var pos2 = this.Get_SubGameType() + 52000 ; 


        var pos_arr = [pos1,pos2];
        ComCodeFuncMng.Init_Com_Two_Guangao(this,this.node,othergame_node,pos_arr);
 


    }
    Refresh_Yichu_Menu()
    {
        var yichumenu=  cc.find("yichumenu",this.node);
        if(this.yichuList.length <= 9)
        {
            yichumenu.active = false;
          
        }else{
            yichumenu.active = true;
        }

    }

    RealLoadScence()
    {
       // ComFunc.RealLoadScence("game",this.Get_SubGameType(),1);
    
       cc.director.loadScene("sanxiaoxiaoGame");
    }
    RestartNewGame()
    {
        this.RealLoadScence();
       // cc.director.loadScene("game")
    }
    OnGameFail()
    {
        var isubgametype = this.Get_SubGameType();
        var icutgk = this.m_cur_level;

        var strtip = "挑战失败";
        if(this.m_enter_xiaochu_chaonan_moshi)
        {
            strtip = "挑战失败";
        }else{
            strtip = "第"+icutgk+"关闯关失败";
        }


        this.Clear_ChaonanTiaozhan_Last_Save_Ju(true);

        BackGroundSoundUtils.GetInstance().Play_Effect("com/failed");

        var self = this;
      
        ComFunc.Real_OpenNewDialog(this.game_fail_new,this.node,"preab/game_fail_new","game_fail_new", {parentgame:this,
            isubgametype:isubgametype, igk:icutgk,strtip:strtip,
            cb:(val)=>
            {
                self.RestartNewGame();
           
            }});


    }
    checkGameResult() {

        if(this.m_b_game_ended )
        {
            return;
        }

        var self = this;
        
        if (this.matchList.length >= 7) {
            this.lock = true

            this.m_b_game_ended = true;
          


            
        BackGroundSoundUtils.GetInstance().Play_Effect("com/gameover_sound");

            
            ComFunc.Real_OpenNewDialog(this.game_fuhuo, this.node,"preab/game_fuhuo","game_fuhuo", {bshowcancel:false,
                bchaonan:this.m_enter_xiaochu_chaonan_moshi,
                parentgame:this,
                cb:(val)=>
                {
 
                  


                    if (val == 1) {
                        self.lock = false;
                        self.m_b_game_ended = false;
                        //撤销3个
                       //// this.undo()
                       // this.undo()
                       // this.undo()

                       self.Yichu();
                       self.moveToRightPos();

                       BaseUIUtils.ShowTipTxtDlg('复活成功!',this.node);  
     
                    } else {
                        //移除所有的,重新开始
                        self.OnGameFail();
                       // self.replay()
                    }


                    ClientLogUtils.GetInstance().Poset_Server_JS_Log(13, "消除复活", self.m_cur_level,
                    "第"+self.m_cur_level+"关复活选择", val, "选择:"+val, 0, "");
                }});

 
            


        } else if (this.tileList.length == 0) {


            this.On_Game_Success();

            

          
        }else{
        }
    }


    On_Game_Success()
    {


        this.On_Game_Success_Real();


    }
    On_Game_Success_Real()
    {
        let hasAward = false;
        if ( this.m_cur_level % 4 == 0)
        {
            hasAward = true
        }


        this.lock = true;
        this.m_b_game_ended = true;
        let star = 0;
        var self=  this;

       



        if (this.m_cur_level == GSXC_Game_Mng.GetInstance().level && !this.m_enter_xiaochu_chaonan_moshi) 
        {

           
            GSXC_Game_Mng.GetInstance().level++
         
        }

            

       
        {
            
            if (this.node_progress.scaleX >= 0.8)
            {
                star = 3
            }
            else if (this.node_progress.scaleX >= 0.5)
            {
                star = 2
            }
            else if (this.node_progress.scaleX > 0.1)
            {
                star = 1
            }
                
                
            GSXC_Game_Mng.GetInstance().levelstar[this.m_cur_level] = star;
        }

        GSXC_Game_Mng.GetInstance().Save_Game_Basic_Info();



        var isubgametype = this.Get_SubGameType();
        if(this.m_enter_xiaochu_chaonan_moshi)
        {
            GSXC_Game_Mng.GetInstance().Add_ChaonanMode_Guoguang_Cishu();
          //  GlobalGameMng.GetInstance().Send_Server_GameType_Paihangbang(isubgametype,GSXC_Game_Mng.GetInstance().m_chaonan_mode_wined_cishu)


        }else{
           // GlobalGameMng.GetInstance().Send_Server_GameType_Paihangbang(isubgametype,this.m_cur_level)

        }

        this.Clear_ChaonanTiaozhan_Last_Save_Ju(true);

        

        this.m_game_end_star = star;
        this.OnGame_End();
      
       
           
    }
    FD_Pop_GameEnd_Animate()
    {
        var pnode = cc.instantiate(this.game_end_animate);
        this.node.addChild(pnode,70);
        
        BackGroundSoundUtils.GetInstance().Play_Effect("com/game_win_effect")
   
    }
    OnGame_End()
    {
            var isubgametype = this.Get_SubGameType();
            var isec = GlobalGameMng.GetInstance().GameEnd_Pop_SuccessDlg_Delay_Sec(isubgametype);
    
            if(GlobalGameMng.GetInstance().IS_GameEnd_Need_Pop_Animate(isubgametype))
            {
                //this.Pop_Win_Qiu_Anim();
                var game_end_animate_d_sec = GlobalGameMng.GetInstance().Get_Game_End_Aniamte_Dealy_Sec();
                this.scheduleOnce(this.FD_Pop_GameEnd_Animate.bind(this),game_end_animate_d_sec)
    
               // var pnode = cc.instantiate(this.game_end_animate);
                //this.node.addChild(pnode,70);
                
    
            }else{
    
            }
    
            this.m_game_finished = true;
            
            this.scheduleOnce(this.On_Game_Success_Dlg.bind(this),isec);
            //BackGroundSoundUtils.GetInstance().Play_Effect("com/game_win_effect")
    }
    On_Game_Success_Dlg()
    {
        var self = this;
        ComFunc.Real_OpenNewDialog(this.gamesuccess_new, this.node,"preab/gamesuccess_new","gamesuccess_new",
         {parentgame:this,star:this.m_game_end_star,
            isubgametype:this.Get_SubGameType(),ilevel:this.m_cur_level,
            cb:(iret)=>
            {

                if(GSXC_Game_Mng.GetInstance().m_enter_xiaochu_chaonan_moshi)
                {
                    self.RealLoadScence();
                    //cc.director.loadScene("game");
                    return;
                }
               

                GSXC_Game_Mng.GetInstance().selectedLevel++;
                 GSXC_Game_Mng.GetInstance().Save_Game_Basic_Info();
                 self.RealLoadScence();
                // cc.director.loadScene("game");
                
                
            
        }});


    }
    checkWarning() {
        if (this.matchList.length < 5) {
            cc.Tween.stopAllByTarget(this.node_warning)
            this.node_warning.active = false
        } else {
            this.node_warning.active = true
            cc.Tween.stopAllByTarget(this.node_warning)
            cc.tween(this.node_warning).to(1, { opacity: 0 }).to(1, { opacity: 255 }).union().repeatForever().start()
        }
    }

    checkRemove() {
        let obj: any = {}
        for (const tile of this.matchList) {
            obj[tile.type] = obj[tile.type] || 0
            obj[tile.type]++
        }

        for (const key in obj) {
            if (obj[key] >= 3) {
                for (let i = 0; i < this.matchList.length; i++) {
                    let tile = this.matchList[i]
                    if (tile.type == Number(key)) {
                        Utils.removeElementFromArray(tile, this.recordList)
                        tile.remove = true

                        this.matchList.splice(i, 1)
                        i--
                    }
                }
                break
            }
        }
    }


    Get_Match_Pos( parentpos, i)
    {
        let targetX = i * 85 + parentpos.x - 256;
        let targetY = parentpos.y + 2;

        if(this.m_enter_xiaochu_chaonan_moshi)
        {
            targetY -= 10;
        }

        return new cc.Vec2(targetX,targetY);
    }

    Cacuate_Tile_Container_Need_Show_Pos(minX,maxX,minY,maxY):cc.Vec2
    {

        console.log("Cacuate_Tile_Container_Need_Show_Pos miny="+minY+",maxy="+maxY);

        var newx =  0;
        var newy = 0 ;

        var tuijianyouxi = cc.find("node_item/tuijianyouxi",this.node);
        var btn_top_pos = cc.find("node_item/toppos",this.node);


        var srccontain = cc.find("titleparent/srccontain",this.node);

        
        let pos1 = Utils.convetOtherNodeSpaceAR(tuijianyouxi, srccontain);
        let pos2 = Utils.convetOtherNodeSpaceAR(btn_top_pos, srccontain);
     

        let w = maxX - minX;
        let h = maxY - minY;

      
        newx = -0.5*minX - 0.5*maxX;

        var py_max = pos2.y;
        var py_min = pos1.y + 80;

       // var max_jianju = Math.abs(py_max - py_min);


       var node_center_y = (minY+maxY)/2;

        var center_need_y = py_min + (py_max-py_min)/2;
        newy = center_need_y - node_center_y;

        if(this.m_enter_xiaochu_chaonan_moshi)
        {
            newy -= 40;
        }

       // newy = (2*center_need_y - minY - maxY)/2;
      //  2*center_need_y = minY + maxY + 2*newy;

     //  ( (minY + newy)  +   (maxY + newy))/2 = center_need_y




        // let t = this.levelData.layouts[maxIndex].alignW == 5 ? 35 : 0


       // var tile_contanier_show_pos:cc.Vec2 = this.Cacuate_Tile_Container_Need_Show_Pos(minX,maxX,minY,maxY);
     //   this.tileContainer.x = tile_contanier_show_pos.x;
      //  this.tileContainer.y = tile_contanier_show_pos.y;

       // -0.5*maxX + 0.5*minX - minX
        /*
        this.tileContainer.x = -w * 0.5 - minX
        */
        
        return new cc.Vec2(newx,newy);
    }
    moveToRightPos() {
        let pos = Utils.convetOtherNodeSpaceAR(this.targetNode, this.tileContainer)
       

        var self = this;

        for (let i = 0; i < this.matchList.length; i++) 
        {
           
            var i_pos = this.Get_Match_Pos( pos, i);

            cc.Tween.stopAllByTarget(this.matchList[i].node)
            cc.tween(this.matchList[i].node).to(0.3, { x: i_pos.x, y: i_pos.y }, { easing: 'sineOut' }).call((targetNode: cc.Node) => {

                let targetTile = targetNode.getComponent(Tile)
                if (targetTile.remove) {
                    targetTile.recycle(true)
                    //targetNode.destroy()
                    self.moveToRightPos()
                    self.checkGameResult()
                    BackGroundSoundUtils.GetInstance().Play_Effect_Check_Delay('com/tileclean')
                    self.updateProgress(0.01)
                }
            }).start()
        }

    }
    setMatchDepth() {
        for (let i = this.matchList.length - 1; i >= 0; i--) {
            this.matchList[i].node.zIndex = i + 999
        }
    }


    click_Yichu_Menu_Right()
    {
        var ilen = this.yichuList.length*82;
        var idayu = ilen - 700;

        if(idayu <= 0)
        {
            idayu = 0;
        }


        this.m_top_yichu_offset_x -= 360;
        
        if(this.m_top_yichu_offset_x <= -1*idayu)
        {
            this.m_top_yichu_offset_x = -1*idayu;
        }

        this.Refresh_Yichu_List();
    }

    click_Yichu_Menu_Left()
    {
        var ilen = this.yichuList.length*82;
        var idayu = ilen - 700;

        if(idayu <= 0)
        {
            idayu = 0;
        }


        this.m_top_yichu_offset_x += 360;
        
        if(this.m_top_yichu_offset_x >= 1*idayu)
        {
            this.m_top_yichu_offset_x = 1*idayu;
        }

        this.Refresh_Yichu_List();
    }
    Refresh_Yichu_List()
    {
          

        if(this.yichuList.length == 0)
        {
            return;
        }
        for (let i = this.yichuList.length - 1; i >= 0; i--) {
            this.yichuList[i].node.zIndex = i + 999
        }

        var startx = -1* Math.floor(this.yichuList.length/2*82) ;
        let pos = Utils.convetOtherNodeSpaceAR(this.targetNode, this.tileContainer)
          
        for (let i = 0; i < this.yichuList.length; i++) {
             let targetX = i * 82 + startx + pos.x + this.m_top_yichu_offset_x;
            let targetY = pos.y + 120;
            cc.Tween.stopAllByTarget(this.yichuList[i].node);


            cc.tween(this.yichuList[i].node).to(0.3, { x: targetX, y: targetY }, { easing: 'sineOut' }).call((targetNode: cc.Node) => {

               
            }).start()
        } 
    }

    updateProgress(offset: number) {
        this.node_progress.scaleX += offset
        if (this.node_progress.scaleX <= 0)
            this.node_progress.scaleX = 0
        else if (this.node_progress.scaleX > 1)
            this.node_progress.scaleX = 1

        this.node_star1.active = this.node_progress.scaleX >= 0.1
        this.node_star2.active = this.node_progress.scaleX >= 0.5
        this.node_star3.active = this.node_progress.scaleX >= 0.8
    }
 
    update(dt: number): void {
        this.Update_Choujiang_Dt(dt);

        if (this.lock) return;
        if (this.countDown) {

           // this.updateProgress(-dt * 0.05)


           this.updateProgress(-dt * 0.005);
        }
    }

    
    Update_Choujiang_Dt(dt: number) 
    {
        if(dt > 1)
        {
            return;
        }
        
        ComCodeFuncMng.On_Choujiang_Update_Dt(dt);
    }
}
