import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng";
import PlatFormMng from "../PlatForm/PlatFormMng";
import PlatFormType from "../PlatForm/PlatFormType";
import ComFunc from "../comfuncs/ComFunc";

 

const { ccclass, property } = cc._decorator;

@ccclass
export default class Tile extends cc.Component {

    @property(cc.Sprite)
    sp_icon: cc.Sprite = null;


    @property(cc.Node)
    tileBg: cc.Node = null;

    @property(cc.Node)
    tileBg_chaonan: cc.Node = null;

    remove: boolean = false
    private _type: number;

    row: number
    col: number
    layer: number
    aniObj = { c: 0 }

    m_bj_node = null;

    m_bchaonan = false;
    SetIs_Chaonan(b)
    {
        
        this.m_bchaonan = b;

        if(b)
        {
            this.m_bj_node=  this.tileBg_chaonan;

            this.tileBg_chaonan.active = true;
            this.tileBg.active  = false;
           
        }else
        {
            this.m_bj_node=  this.tileBg;

            this.tileBg_chaonan.active = false;
            this.tileBg.active  = true;
        }
      
    }

    public get type(): number {
        return this._type;
    }
    public set type(itype: number) {
        this._type = itype;


         

        if(!itype && itype != 0)
        {  
             console.log("itype="+itype)

        }

        var self = this;

        ComFunc.CheckFind_Name_Resource2('tiles/' + itype,cc.Texture2D,(bsuc,texture)=>
                {
                    if(!bsuc)
                    {
                        console.log("加载title error");
                        return;
                    }

                    let sp = new cc.SpriteFrame(texture)
                    self.sp_icon.spriteFrame = sp;

                    if(self.m_bchaonan)
                    {
                        self.sp_icon.node.scale  = 0.64;
                    }else{
                        self.sp_icon.node.scale  = 0.72;
                    }
                }
         );

        /*
        cc.resources.load('tiles/' + itype,   cc.Texture2D, (err, texture: cc.Texture2D) => {
            if(err)
            {
                console.log("err="+err)
            }
            let sp = new cc.SpriteFrame(texture)
            self.sp_icon.spriteFrame = sp;

            if(self.m_bchaonan)
            {
                self.sp_icon.node.scale  = 0.64;
            }else{
                self.sp_icon.node.scale  = 0.72;
            }
           
        })
        */
    }

    start() {
        if(!this.m_bj_node)
        {
            this.m_bj_node = this.tileBg;
        }

    }
    private _dark: boolean = false;
    public get dark(): boolean {
        return this._dark;
    }
    public set dark(value: boolean) {
        this._dark = value;

    }
    setDark(value: boolean, ani: boolean = false) {
        if (this._dark != value) {
            this._dark = value
            if (ani) {
                let start = 80
                let end = 255
                if (value) {
                    start = 255
                    end = 120
                }
                this.aniObj.c = start
                cc.Tween.stopAllByTarget(this.aniObj)
                cc.tween(this.aniObj).to(0.5, { c: end }, {
                    progress: (start, end, current, radio) => {
                        let tempColor = start + (end - start) * radio
                        this.sp_icon.node.color = cc.color(tempColor, tempColor, tempColor)
                        this.m_bj_node.color = cc.color(tempColor, tempColor, tempColor)
                        
                    }
                }).start()

            } else {
                this.sp_icon.node.color = value ? cc.color(120, 120, 120) : cc.color(255, 255, 255)
                this.m_bj_node.color = value ? cc.color(120, 120, 120) : cc.color(255, 255, 255)
            }
        }

    }
    recycle(ani: boolean = false) {
        this.remove = false
        this._dark = false
        cc.Tween.stopAllByTarget(this.aniObj)
        cc.Tween.stopAllByTarget(this.node)
        this.sp_icon.node.color = cc.color(255, 255, 255)
        this.m_bj_node.color = cc.color(255, 255, 255)
       
        if (ani) {
            cc.tween(this.node).delay(0.06).to(0.2, { scale: 0 }).call(() => {
                GSXC_Game_Mng.GetInstance().recover('Tile', this.node)
            }).start()
        } else {
            GSXC_Game_Mng.GetInstance().recover('Tile', this.node)
        }



    }


    // update (dt) {}
}
