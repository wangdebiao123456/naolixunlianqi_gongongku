 
import BaseUIUtils from "../../comfuncs/BaseUIUtils"; 
import Start_Game_InfoMng from "../../manager/Start_Game_InfoMng";
import PlatFormMng from "../../PlatForm/PlatFormMng";
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import NodeComPoolUtils from "../../WDT/NodeComPoolUtils";
import juba_Config_Mng from "../mng/juba_Config_Mng"; 
import juba_Game_Mng from "../mng/juba_Game_Mng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class guaishou_new_jiubei_show_dlg extends cc.Component {

    m_cb  =  null;

    m_share_money  =  0;

    m_drink_id  =  0;
    m_top3_pos_index  =  0;

    m_b_has_lingqued = 0;
    m_lingqucb = null;
    
    onLoad () 
    {
 

        var guang = cc.find("panel/guang",this.node);
        var fengxiangbtn = cc.find("panel/fengxiangbtn",this.node);

        var exitbtn = cc.find("panel/exitbtn",this.node);


        exitbtn.on("click",this.OnBtnExit.bind(this))
 

        fengxiangbtn.on("click",this.OnBtnShare.bind(this))

        var pseq =  cc.rotateBy(0.3,5 );
        guang.runAction(cc.repeatForever(pseq))

     //   var tankuang = this.node.getComponent("tankuang");
      //  tankuang.Set_Close_Lisnter(this);
 

        BackGroundSoundUtils.GetInstance().Play_Effect("com/snd_warning",1.5)
     }
   
     On_Tankuang_Real_Exit()
     {
         this.OnBtnExit();
     }
     OnBtnExit()
     {
         this.node.destroy();
        
         if(this.m_cb)
         {
            this.m_cb();
         }

         Start_Game_InfoMng.GetIns().m_b_in_share_msg=  0;
   
         Start_Game_InfoMng.GetIns().Remove_WX_Show_Hide_Event_Lisnter(this)

     }
    SetInfo(paradata)
    {
        this.m_cb=  paradata.cb;

        this.m_lingqucb=  paradata.lingqucb;

        
        this.m_share_money=  paradata.share_money;
        this.m_drink_id=  paradata.drink_id;
        this.m_top3_pos_index=  paradata.top3_pos_index;
 
        var fenxiangc_label =  cc.find("panel/fengxiangbtn/c",this.node)
        fenxiangc_label.getComponent(cc.Label).string = "x" + this.m_share_money;


        
        var ff_preab_name = "guaishou_jiubei_Preab_"+this.m_drink_id;
        var ff_preab = juba_Game_Mng.GetInstance().Get_Preab_By_Name(ff_preab_name)
        var wuping_node =  cc.find("panel/wuping/gs",this.node)
    

        var ff_ndoe = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node(ff_preab_name,ff_preab);
        if(ff_ndoe)
        {
            wuping_node.addChild(ff_ndoe,20);
            ff_ndoe.active = true;
    
            var w_node = cc.find("w",ff_ndoe)
            if(w_node)
            {
                var sanimname = juba_Config_Mng.GetInstance().Get_Guaishou_Type_Anim_Name(this.m_drink_id,1);
                var sp_com = w_node.getComponent(sp.Skeleton);
    
                if(sp_com)
                {
                    sp_com.timeScale = 0.5;
                    sp_com.setAnimation(0,sanimname,true)
    
                }
             
            }
        }
       

      //  var wuping_icon_node =  cc.find("panel/wuping/icon",this.node)
    
    //    BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("jiubei_xunlian",wuping_icon_node,"drink/"+this.m_drink_id,{width:150,height:150})

        
     //   var drinkinfo = juba_Config_Mng.GetInstance().Find_Drink_Info_By_ID(this.m_drink_id);

         var sname =   juba_Config_Mng.GetInstance().Get_Guaishou_Type_Name(this.m_drink_id)
  
        var wuping_name_node =  cc.find("panel/wuping/name",this.node)
    
        wuping_name_node.getComponent(cc.Label).string = "" + sname;
    }
    Notify_WX_Show_Hide_Event(bshow)
    {
        if(!Start_Game_InfoMng.GetIns().m_b_in_share_msg)
        {
            return;
        }

        if(this.m_b_has_lingqued)
        {
            return;
        }

        Start_Game_InfoMng.GetIns().m_b_in_share_msg = 0;

        this.m_b_has_lingqued = 1;
 
         if(this.m_lingqucb)
         {
            this.m_lingqucb(this.m_share_money);
         }
       
        BaseUIUtils.ShowTipTxtDlg("获得奖励成功",this.node)

    }
    OnBtnShare()
    {
        Start_Game_InfoMng.GetIns().m_b_in_share_msg=  1;

        Start_Game_InfoMng.GetIns().Add_WX_Show_Hide_Event_Lisnter(this)
        PlatFormMng.GetInstance().Share_Msg("怪兽训练","怪兽集合训练增加训练了，超好玩的游戏");

    }
}
