 
import ClientLogUtils from "../../comfuncs/ClientLogUtils"; 
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";

 

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class game_fail_dlg extends cc.Component {

    
    m_cb = null;
    m_igk = 1;
    m_igamemode = 1;

    onLoad () {

        var backbtn = cc.find("panel/backbtn",this.node)
        backbtn.on("click",this.OnBtnBackHall.bind(this));


        var retrybtn = cc.find("panel/retrybtn",this.node)
        retrybtn.on("click",this.OnBtnRetry.bind(this));


        BannerGuangaoMng.GetInstance().CheckShowChaiping();
   
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(108, "酒杯怪兽失败", this.m_igk,
        "第"+this.m_igk+"关", 0, "", 0, "");

        BackGroundSoundUtils.GetInstance().Play_Effect("jiubei/sound_lose")
    }

    OnBtnBackHall()
    {

        cc.director.loadScene("dating");

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(106, "离开酒杯怪兽游戏场", this.m_igk,
        "第"+this.m_igk+"关", 0, "", 0, "");
       
    }
   SetInfo(paradata)
    {
        this.m_cb=  paradata.cb;
        this.m_igk = paradata.igk;
        this.m_igamemode = paradata.igamemode;

        this.Refresh_Info();
    }
    Refresh_Info()
    {
        var gk_label = cc.find("panel/gk",this.node)
   
     
        if(this.m_igamemode == 5)
        {
            gk_label.getComponent(cc.Label).string = "麻将聚会";

        }
        else if(this.m_igamemode == 63)
        {
            gk_label.getComponent(cc.Label).string = "第"+this.m_igk+"关";

        }
        else if(this.m_igamemode == 2)
        {
            gk_label.getComponent(cc.Label).string = "每日挑战";

        }else{
            gk_label.getComponent(cc.Label).string = "第"+this.m_igk+"天";

        }
    }

    OnBtnRetry()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(1)
        }
    }
}
