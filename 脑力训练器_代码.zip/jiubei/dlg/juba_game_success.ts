 
import BundleLoadUtils from "../../comfuncs/BundleLoadUtils";
import ClientLogUtils from "../../comfuncs/ClientLogUtils";
import ComFunc from "../../comfuncs/ComFunc"; 
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";

 
 
const {ccclass, property} = cc._decorator;

@ccclass
export default class juba_game_success extends cc.Component {
 
    m_cb=  null;
    m_igk = 1;
    m_game_suc_jinbi = 0;


    m_jl_reward = [];

    onLoad () 
    {
        var nextbtn = cc.find("panel/nextbtn",this.node)
        nextbtn.on("click",this.OnBtOK.bind(this))


        var backbtn = cc.find("panel/backbtn",this.node)
        backbtn.on("click",this.OnBtnBackHall.bind(this));
        BannerGuangaoMng.GetInstance().CheckShowChaiping();
   

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(107, "酒杯怪兽胜利", this.m_igk,
        "第"+this.m_igk+"关", 0, "", 0, "");

        BackGroundSoundUtils.GetInstance().Play_Effect("jiubei/gamewin")
    }
    OnBtnBackHall()
    {
        cc.director.loadScene("dating");

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(106, "离开酒杯怪兽游戏场", this.m_igk,
        "第"+this.m_igk+"关", 0, "", 0, "");
    }
    OnBtOK()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(1)
        }
    }
    SetInfo(paradata)
    {
        this.m_cb=  paradata.cb;
        this.m_igk=  paradata.igk;
        this.m_game_suc_jinbi=  paradata.game_suc_jinbi;
        this.m_jl_reward = paradata.jl_reward;
       
        var gk_label = cc.find("panel/gk",this.node)
   
        gk_label.getComponent(cc.Label).string = "第"+this.m_igk+"天"

     //   var reward_c_label = cc.find("panel/reward/c",this.node)
   
      //  reward_c_label.getComponent(cc.Label).string = "+"+ ComFunc.Format_Number(this.m_game_suc_jinbi)  

        for(var ff=1;ff<=3;ff++)
        {
            var ff_wp_ndoe  = cc.find("panel/wuping/"+ff+"",this.node);
            ff_wp_ndoe.active = false;
        }

        var awrd_list= this.m_jl_reward;

        for(var ff=1;ff<=awrd_list.length;ff++)
        {

            var ff_awrd = awrd_list[ff-1];
            var ff_wp_ndoe  = cc.find("panel/wuping/"+ff+"",this.node);
            ff_wp_ndoe.active = true;

            ff_wp_ndoe.setPosition(this.Get_Item_Pos(ff,awrd_list.length))

            var ff_icon_ndoe  = cc.find("panel/wuping/"+ff+"/icon",this.node);
            var ff_reward_ndoe  = cc.find("panel/wuping/"+ff+"/c",this.node);
            ff_reward_ndoe.getComponent(cc.Label).string = "x"+ComFunc.Format_Number(ff_awrd.c);

            BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",ff_icon_ndoe,"daoju/com/"+ff_awrd.t,{width:55,height:55})
        }
    }
    Get_Item_Pos(ff,iallne)
    {
        if(iallne == 1)
        {
            return new cc.Vec2(0,0)
        }
        if(iallne == 2)
        {
            if(ff == 1)
            {
                return new cc.Vec2(-100,0)
            }
            return new cc.Vec2(100,0)
        }

        if(iallne == 3)
        {
            if(ff == 1)
            {
                return new cc.Vec2(-140,0)
            }
            if(ff == 2)
            {
                return new cc.Vec2( 0,0)
            }
            return new cc.Vec2(140,0)
        }

        return new cc.Vec2(0,0)

    }
}
