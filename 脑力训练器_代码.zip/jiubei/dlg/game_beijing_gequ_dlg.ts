 
import BaseUIUtils from "../../comfuncs/BaseUIUtils"; 
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";
import juba_Config_Mng from "../mng/juba_Config_Mng";
import juba_Game_Mng from "../mng/juba_Game_Mng";
import Juba_Beijing_Gedan_Mng from "../utils/Juba_Beijing_Gedan_Mng"; 
 

const {ccclass, property} = cc._decorator;

@ccclass
export default class game_beijing_gequ_dlg extends cc.Component 
{

    m_cb = null;



  
    @property(cc.Prefab)
    per_beijing_music_item: cc.Prefab = null;
    

    m_all_item_node_list = [];
    

    onLoad () 
    {
        var bjyyuebtn = cc.find("panel/top/bjyyuebtn",this.node);
        bjyyuebtn.runAction(cc.repeatForever(cc.rotateBy(0.1,6)))

        var mode = cc.find("panel/top/mode",this.node);
        mode.on("click",this.OnChangeMode.bind(this))

        BannerGuangaoMng.GetInstance().CheckShowChaiping();
   
    }

    Refresh_Info()
    {
        var pro_C_label = cc.find("panel/top/pro/c",this.node);
        var  cur_jiesuo_music_played_count = Juba_Beijing_Gedan_Mng.GetInstance().m_cur_jiesuo_music_played_count;
        var jiesuo_need_c = Juba_Beijing_Gedan_Mng.GetInstance().Get_Next_Need_Jiesuo_Music_Need_Finish_Order_Count();

        var iprogress = cur_jiesuo_music_played_count/jiesuo_need_c;

        var ipc = Math.floor(iprogress*100);
        pro_C_label.getComponent(cc.Label).string = cur_jiesuo_music_played_count+ "/"+jiesuo_need_c;

        var pro_bar = cc.find("panel/top/pro/bar",this.node);
      
        pro_bar.getComponent(cc.Sprite).fillRange = iprogress;
        

        var music_mode = Juba_Beijing_Gedan_Mng.GetInstance().m_play_music_mode;

        for(var ff=0;ff<=2;ff++)
        {
            var ff_mode_ndoe = cc.find("panel/top/mode/"+ff,this.node);

            if(music_mode == ff)
            {
                ff_mode_ndoe.active  = true;
            }else{
                ff_mode_ndoe.active  = false;
            }
        }


        this.Refresh_SC();
    }
    SetInfo(paradata)
    {
        this.m_cb = paradata.cb;
  
   
        this.Refresh_Info();

    }

    Real_Jiesuo(musicindex)
    {
        Juba_Beijing_Gedan_Mng.GetInstance().Unlock_Music_Index(musicindex);
        Juba_Beijing_Gedan_Mng.GetInstance().Start_Play_BJ_Music(musicindex);
        this.Refresh_Info();

        BackGroundSoundUtils.GetInstance().Play_Effect("com/huode")
    }
    OnBtnClick(musicindex)
    {
        if(juba_Game_Mng.GetInstance().m_enter_game_mode <= 2)
        {

            BaseUIUtils.ShowTipTxtDlg("酒吧训练中才可以使用",this.node)
            return;
        }


        var ff_uncloked = Juba_Beijing_Gedan_Mng.GetInstance().IS_Music_Index_Unlocked(musicindex);
        if(ff_uncloked)
        {
            Juba_Beijing_Gedan_Mng.GetInstance().Start_Play_BJ_Music(musicindex);
            this.Refresh_Info();
            this.scheduleOnce(this.Refresh_Info.bind(this),0.5)
            return;
        }


        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "酒杯歌单",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.Real_Jiesuo(musicindex);

        });
 
    }

    OnChangeMode()
    {
        Juba_Beijing_Gedan_Mng.GetInstance().Change_Music_Play_Mode();

        this.Refresh_Info();

        var musicmode=  Juba_Beijing_Gedan_Mng.GetInstance().m_play_music_mode;
        var strmodename=  "";
        if(musicmode == 0)
        {
            strmodename=  "列表循环";
        } 
        else if(musicmode == 1)
        {
            strmodename=  "单曲循环";
        }else if(musicmode == 2)
        {
            strmodename=  "随机播放";
        }

        BaseUIUtils.ShowTipTxtDlg(strmodename,this.node)
    }
    Refresh_SC()
    {
        var content = cc.find("panel/bottom/pv/view/content",this.node)

        
        for(var ff=1;ff<=50;ff++)
        {
            var ipage = Math.floor((ff-1)/10);

            var sgae= ipage+1;
            var page_node = content.getChildByName(""+sgae);

            if(!page_node)
            {
                continue;
            }

            var ff_ndoe:cc.Node = this.m_all_item_node_list[ff];
            if(!ff_ndoe)
            {
                ff_ndoe = cc.instantiate(this.per_beijing_music_item);
                page_node.addChild(ff_ndoe,10);
                this.m_all_item_node_list[ff] = ff_ndoe;
            }

          


            var page_sub_index = ff-  ipage*10;


            var iy = Math.floor((page_sub_index-1)/5);
            var ix = page_sub_index - iy*5-1;

            var showx =   -260 + 130*ix  ;
            var showy =  75 -iy*150 ;

            ff_ndoe.setPosition(showx,showy);

            var name_node = cc.find("name",ff_ndoe);
            var lock_node  = cc.find("lock",ff_ndoe);
            var btn_node = cc.find("btn",ff_ndoe);
            btn_node.off("click");
            btn_node.on("click",this.OnBtnClick.bind(this,ff))
          
            var ff_name = juba_Config_Mng.GetInstance().Find_Beijing_Music_Index_Name(ff);
            name_node.getComponent(cc.Label).string = ff_name;

            var ff_uncloked = Juba_Beijing_Gedan_Mng.GetInstance().IS_Music_Index_Unlocked(ff);

            if(ff_uncloked)
            {
                lock_node.active = false;
            }else{
                lock_node.active = true;
            }

            var play_music_index = Juba_Beijing_Gedan_Mng.GetInstance().m_last_play_music_index;

            if(play_music_index == ff)
            {
                btn_node.scale = 1.3;
               
            }else{
                btn_node.scale = 1;
                
            }


        }

        content.width  = 700*5
    }


}
    


