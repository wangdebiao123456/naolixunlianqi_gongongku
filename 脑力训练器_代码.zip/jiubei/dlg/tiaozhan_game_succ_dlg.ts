 
import BundleLoadUtils from "../../comfuncs/BundleLoadUtils";
import ComFunc from "../../comfuncs/ComFunc"; 
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";
import juba_Game_Mng from "../mng/juba_Game_Mng"; 



const {ccclass, property} = cc._decorator;

@ccclass
export default class tiaozhan_game_succ_dlg extends cc.Component {

    
    m_cb = null;
    m_game_suc_jinbi = 0;
    m_jl_reward = [];


    onLoad () {
        
        var backbtn = cc.find("panel/backbtn",this.node)
        backbtn.on("click",this.OnBtnBackHall.bind(this));


        BannerGuangaoMng.GetInstance().CheckShowChaiping();
   
        BackGroundSoundUtils.GetInstance().Play_Effect("jiubei/gamewin")
    }

    
    OnBtnBackHall()
    {
        cc.director.loadScene("dating");
    }
    Get_Item_Pos(ff,iallne)
    {
        if(iallne == 1)
        {
            return new cc.Vec2(0,0)
        }
        if(iallne == 2)
        {
            if(ff == 1)
            {
                return new cc.Vec2(-100,0)
            }
            return new cc.Vec2(100,0)
        }

        if(iallne == 3)
        {
            if(ff == 1)
            {
                return new cc.Vec2(-140,0)
            }
            if(ff == 2)
            {
                return new cc.Vec2( 0,0)
            }
            return new cc.Vec2(140,0)
        }


        if(iallne == 4)
        {
            if(ff == 1)
            {
                return new cc.Vec2(-180,0)
            }
            if(ff == 2)
            {
                return new cc.Vec2( -60,0)
            }

            if(ff == 3)
            {
                return new cc.Vec2( 60,0)
            }
            return new cc.Vec2(180,0)
        }
        if(iallne == 5)
        {
            if(ff == 1)
            {
                return new cc.Vec2(-220,0)
            }
            if(ff == 2)
            {
                return new cc.Vec2( -110,0)
            }

            if(ff == 3)
            {
                return new cc.Vec2( 0,0)
            }

            if(ff == 4)
            {
                return new cc.Vec2( 110,0)
            }
            if(ff == 5)
            {
                return new cc.Vec2( 220,0)
            }


            return new cc.Vec2(0,0)
        }
        return new cc.Vec2(0,0)

    }

    SetInfo(paradata)
    {
        this.m_cb=  paradata.cb;
        this.m_jl_reward = paradata.jl_reward;
       

        for(var ff=1;ff<=5;ff++)
        {
            var ff_wp_ndoe  = cc.find("panel/wuping/"+ff+"",this.node);
            ff_wp_ndoe.active = false;
        }

        var awrd_list= this.m_jl_reward;

        for(var ff=1;ff<=awrd_list.length;ff++)
        {

            var ff_awrd = awrd_list[ff-1];
            var ff_wp_ndoe  = cc.find("panel/wuping/"+ff+"",this.node);
            ff_wp_ndoe.active = true;

            ff_wp_ndoe.setPosition(this.Get_Item_Pos(ff,awrd_list.length))

            var ff_icon_ndoe  = cc.find("panel/wuping/"+ff+"/icon",this.node);
            var ff_reward_ndoe  = cc.find("panel/wuping/"+ff+"/c",this.node);
            ff_reward_ndoe.getComponent(cc.Label).string = "x"+ComFunc.Format_Number(ff_awrd.c);

            BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",ff_icon_ndoe,"daoju/com/"+ff_awrd.t,{width:55,height:55})
        }

     //   this.m_game_suc_jinbi =  paradata.game_suc_jinbi;

       
 /*
        var awrd_list = juba_Game_Mng.GetInstance().Get_Tiaozhan_Game_Award();
        
        for(var ff=1;ff<=5;ff++)
        {
            var ff_icon_ndoe  = cc.find("panel/wuping/"+ff+"/zs",this.node);
            var ff_reward_ndoe  = cc.find("panel/wuping/"+ff+"/reward",this.node);
            var ff_awrd = awrd_list[ff-1];
            ff_reward_ndoe.getComponent(cc.Label).string = "x"+ComFunc.Format_Number(ff_awrd.c);

            BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",ff_icon_ndoe,"game/daoju/"+ff_awrd.t,{width:60,height:60})
        }
        */


    }


}
