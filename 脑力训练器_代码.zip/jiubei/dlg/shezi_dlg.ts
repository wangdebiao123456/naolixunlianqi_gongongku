 
import ClientLogUtils from "../../comfuncs/ClientLogUtils"; 
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";
import juba_Game_Mng from "../mng/juba_Game_Mng";
import Juba_Beijing_Gedan_Mng from "../utils/Juba_Beijing_Gedan_Mng";
 

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class shezi_dlg extends cc.Component {

    m_byd_finished = 0;
    m_cb = null;
    m_chongxin_tiaozhan_cb = null;
    m_ifromgametype = 1;

    onLoad () {

        var backbtn = cc.find("panel/backbtn",this.node)
        backbtn.on("click",this.OnBtnBackHall.bind(this));
        
        var chongxintzbtn = cc.find("panel/chongxintzbtn",this.node)
        chongxintzbtn.on("click",this.OnBtnChongxinTiaozhan.bind(this));


        var exitbtn = cc.find("panel/exit",this.node)
        exitbtn.on("click",this.OnBtnExit.bind(this));


        

        var slider_sound = cc.find("panel/yy/slidereffect",this.node);
        slider_sound.on('slide', this.OnSliderSound.bind(this), this); 


         

        var slider_music = cc.find("panel/yy/slidermusic",this.node);
        slider_music.on('slide', this.OnSliderMusic.bind(this), this); 
 

        BannerGuangaoMng.GetInstance().CheckShowChaiping();
   
    }
    OnSliderMusic(tg){
        //this.pro_music.progress = tg.progress;
      //  this.m_SoundMgr.SetBackGroundMusicVolum(tg.progress);

        var iprogress = Number(tg.progress);
        var prig = cc.find("panel/yy/slidermusic/progress",this.node);
        prig.getComponent(cc.Sprite).fillRange = iprogress;
        
        BackGroundSoundUtils.GetInstance().SetBackGroundMusicVolum(iprogress);
        Juba_Beijing_Gedan_Mng.GetInstance().SetBackGroundMusicVolum(iprogress);
    }
    OnSliderSound(tg)
    {
       // this.pro_sound.progress = tg.progress;
        //this.m_SoundMgr.SetEffectSoundVolum(tg.progress);
            var iprogress = Number(tg.progress);
            var prig = cc.find("panel/yy/slidereffect/progress",this.node);
            prig.getComponent(cc.Sprite).fillRange = iprogress;
            
            BackGroundSoundUtils.GetInstance().SetEffectSoundVolum(iprogress);

    }
    OnBtnJixu()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb();
        }
    }
    OnBtnChongxinTiaozhan()
    {
        if(this.m_chongxin_tiaozhan_cb)
        {
            this.m_chongxin_tiaozhan_cb();
        }
        this.node.destroy();
    }
    OnBtnExit()
    {
        this.node.destroy();
    }
    OnBtnBackHall()
    {
        cc.director.loadScene("dating");
        var igk = juba_Game_Mng.GetInstance().Get_Cur_Enter_Day_GK();

        if(this.m_ifromgametype == 4)
        {
            ClientLogUtils.GetInstance().Poset_Server_JS_Log(116, "离开排序怪兽游戏场", igk,
            "第"+igk+"关", 0, "", 0, "");
        }else
        {
            ClientLogUtils.GetInstance().Poset_Server_JS_Log(106, "离开酒杯怪兽游戏场", igk,
            "第"+igk+"关", 0, "", 0, "");
        }
       
    }
    SetInfo(paradata)
    {
        this.m_cb=  paradata.cb; 
        this.m_chongxin_tiaozhan_cb=  paradata.chongxin_tiaozhan_cb; 

        this.m_byd_finished =  paradata.byd_finished; 

        this.m_ifromgametype = paradata.ifromgametype;

        this.Refresh_Info();
    }
    Refresh_Info()
    {
        var slider_sound = cc.find("panel/yy/slidereffect",this.node);
        slider_sound.getComponent(cc.Slider).progress = BackGroundSoundUtils.GetInstance().GetEffectSoundVolum();

        

        var slider_sound_progress = cc.find("panel/yy/slidereffect/progress",this.node); 
        slider_sound_progress.getComponent(cc.Sprite).fillRange = BackGroundSoundUtils.GetInstance().GetEffectSoundVolum();
    

        var slider_music = cc.find("panel/yy/slidermusic",this.node); 
        slider_music.getComponent(cc.Slider).progress = BackGroundSoundUtils.GetInstance().GetBackGroundMusicVolum();


        var slider_music_progress = cc.find("panel/yy/slidermusic/progress",this.node); 
        slider_music_progress.getComponent(cc.Sprite).fillRange = BackGroundSoundUtils.GetInstance().GetBackGroundMusicVolum();
        

        var backbtn = cc.find("panel/backbtn",this.node)
        var chongxintzbtn = cc.find("panel/chongxintzbtn",this.node)
       
        var exitbtn = cc.find("panel/exit",this.node)
   
        if(this.m_byd_finished)
        {
            backbtn.active = true;
            chongxintzbtn.active = true;
            chongxintzbtn.x = 120;

            exitbtn.active = true;

        }else{
            backbtn.active = false;
            chongxintzbtn.active = false;
            chongxintzbtn.x = 0;

            exitbtn.active = true;
        }

        if(this.m_ifromgametype == 36 || this.m_ifromgametype == 61)
        {
            backbtn.active = true;
            chongxintzbtn.active = false;
            backbtn.x = 0;

        }
    }

    
}
