 
import BaseUIUtils from "../../comfuncs/BaseUIUtils";
import BundleLoadUtils from "../../comfuncs/BundleLoadUtils";
import Start_Game_InfoMng from "../../manager/Start_Game_InfoMng";
import PlatFormMng from "../../PlatForm/PlatFormMng";
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";
import juba_Config_Mng from "../mng/juba_Config_Mng"; 
 

const {ccclass, property} = cc._decorator;

@ccclass
export default class new_jiubei_show_dlg extends cc.Component {

    m_cb  =  null;

    m_share_money  =  0;

    m_drink_id  =  0;
    m_top3_pos_index  =  0;

    m_b_has_lingqued = 0;
    m_lingqucb = null;
    
    onLoad () 
    {
 

        var guang = cc.find("panel/guang",this.node);
        var fengxiangbtn = cc.find("panel/fengxiangbtn",this.node);

        fengxiangbtn.on("click",this.OnBtnShare.bind(this))

        var pseq =  cc.rotateBy(0.3,5 );
        guang.runAction(cc.repeatForever(pseq))

        var tankuang = this.node.getComponent("tankuang");
        tankuang.Set_Close_Lisnter(this);
 
        BannerGuangaoMng.GetInstance().CheckShowChaiping();
   
        BackGroundSoundUtils.GetInstance().Play_Effect("com/new_jiubei_show",1.5)
     }
   
     On_Tankuang_Real_Exit()
     {
         this.OnBtnExit();
     }
     OnBtnExit()
     {
         this.node.destroy();
        
         if(this.m_cb)
         {
            this.m_cb();
         }

         Start_Game_InfoMng.GetIns().m_b_in_share_msg=  0;
   
         Start_Game_InfoMng.GetIns().Remove_WX_Show_Hide_Event_Lisnter(this)

     }
    SetInfo(paradata)
    {
        this.m_cb=  paradata.cb;

        this.m_lingqucb=  paradata.lingqucb;

        
        this.m_share_money=  paradata.share_money;
        this.m_drink_id=  paradata.drink_id;
        this.m_top3_pos_index=  paradata.top3_pos_index;
 
        var fenxiangc_label =  cc.find("panel/fengxiangbtn/c",this.node)
        fenxiangc_label.getComponent(cc.Label).string = "x" + this.m_share_money;


        
        var wuping_icon_node =  cc.find("panel/wuping/icon",this.node)
    
        BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("jiubei_xunlian",wuping_icon_node,"drink/"+this.m_drink_id,{width:150,height:150})

        
        var drinkinfo = juba_Config_Mng.GetInstance().Find_Drink_Info_By_ID(this.m_drink_id);


  
        var wuping_name_node =  cc.find("panel/wuping/name",this.node)
    
        wuping_name_node.getComponent(cc.Label).string = "" + drinkinfo.n;
    }
    Notify_WX_Show_Hide_Event(bshow)
    {
        if(!Start_Game_InfoMng.GetIns().m_b_in_share_msg)
        {
            return;
        }

        if(this.m_b_has_lingqued)
        {
            return;
        }

        Start_Game_InfoMng.GetIns().m_b_in_share_msg = 0;

        this.m_b_has_lingqued = 1;
 
         if(this.m_lingqucb)
         {
            this.m_lingqucb(this.m_share_money);
         }
       
        BaseUIUtils.ShowTipTxtDlg("获得奖励成功",this.node)

    }
    OnBtnShare()
    {
        Start_Game_InfoMng.GetIns().m_b_in_share_msg=  1;

        Start_Game_InfoMng.GetIns().Add_WX_Show_Hide_Event_Lisnter(this)
        PlatFormMng.GetInstance().Share_Msg("脑力训练器","获得新酒杯啦，超好玩的游戏");

    }
}
