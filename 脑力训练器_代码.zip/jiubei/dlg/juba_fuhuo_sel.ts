 
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import MiddleGamePlatformAction from "../../PlatForm/MiddleGamePlatformAction";
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class juba_fuhuo_sel extends cc.Component {
 
    m_cb=  null;

    m_cancel_step1 = 1;

    m_game_mode = 0;
    
    onLoad () 
    {
        var fuhuobtn = cc.find("panel/fuhuobtn",this.node)
        fuhuobtn.on("click",this.OnBtnFuhuo.bind(this))
        
        var exitbtn = cc.find("panel/exitbtn",this.node)
        exitbtn.on("click",this.OnBtnExit.bind(this))
      
        BannerGuangaoMng.GetInstance().CheckShowChaiping();
   
        BackGroundSoundUtils.GetInstance().Play_Effect("com/died1")
    }

    OnBtnExit()
    {
        if(this.m_cancel_step1 >= 2)
        {
            MiddleGamePlatformAction.GetInstance().Show_Refuhuo_Banners(false);
            MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,false);
       
            this.node.destroy();

            if(this.m_cb)
            {
                this.m_cb(0);
            }
        }
        else{
            this.m_cancel_step1 = 2;
            this.Refresh_Info();

            var panel_node = cc.find("panel",this.node)
            panel_node.scale = 0.01;
            const action = cc.scaleTo(0.2, 1);
            panel_node.runAction(action);


        }
    }

    OnBtnFuhuo()
    {
             
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "酒杯复活",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.Real_Fuhuo();

        });

      
    }
    Real_Fuhuo()
    {
        MiddleGamePlatformAction.GetInstance().Show_Refuhuo_Banners(false);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,false);
   
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(1);
        }
    }
    SetInfo(paradata)
    {
        this.m_cb=  paradata.cb;
        this.m_game_mode=  paradata.igamemode

        this.Refresh_Info();

        MiddleGamePlatformAction.GetInstance().Show_Refuhuo_Banners(true);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,true);
   
    }
    Refresh_Info()
    {
        var p1 = cc.find("panel/1",this.node)
        var p2 = cc.find("panel/2",this.node)

        if(this.m_cancel_step1 == 2)
        {
            p2.active = true;
            p1.active = false;
        }else{
            p2.active = false;
            p1.active = true;
        }


        
        var pinfo_t_label = cc.find("panel/1/t",this.node)

        if(this.m_game_mode == 5)
        {
            pinfo_t_label.getComponent(cc.Label).string = "复活并清空上方条中麻将";
        }
      
        if(this.m_game_mode == 63)
        {
            pinfo_t_label.getComponent(cc.Label).string = "复活游戏,清空所有钉子";
        }
         
    }
}
