

import BundleLoadUtils from "../../comfuncs/BundleLoadUtils";
import tankuang from "../../dlg/tankuang";
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";
import juba_Config_Mng from "../mng/juba_Config_Mng";
import juba_Game_Mng from "../mng/juba_Game_Mng"; 
 

const {ccclass, property} = cc._decorator;

@ccclass
export default class jiesuo_new_juese_dlg extends cc.Component {

  
    m_cb=  null;

    m_guimi_id= 0;
    
    onLoad () 
    {

        var tankuang:tankuang = this.node.getComponent("tankuang");
        tankuang.Set_Close_Lisnter(this);
        tankuang.Set_Pingbi_Close_Event(true);

        this.scheduleOnce(this.FD_Int.bind(this),1)

        BackGroundSoundUtils.GetInstance().Play_Effect("com/jiesuo_user")
        BannerGuangaoMng.GetInstance().CheckShowChaiping();
   
     }
     FD_Int()
     {
        
        var tankuang:tankuang = this.node.getComponent("tankuang");
    
        tankuang.Set_Pingbi_Close_Event(false);

     }
     On_Tankuang_Real_Exit()
     {
         this.OnBtnExit();
     }
     OnBtnExit()
     {
         this.node.destroy();
        
         if(this.m_cb)
         {
            this.m_cb();
         }
     }


    SetInfo(paradata)
    {
        this.m_cb=  paradata.cb;
        this.m_guimi_id = paradata.guimid;

        this.Refresh_Info();
    }
    Refresh_Info()
    {
        var guimiinfo = juba_Config_Mng.GetInstance().Find_Model_Info_By_ID(this.m_guimi_id);

        var name_ndoe = cc.find("panel/userinfo/name",this.node)
        name_ndoe.getComponent(cc.Label).string = guimiinfo.name;


        var age_lable = cc.find("panel/userinfo/age",this.node);
        age_lable.getComponent(cc.Label).string = ""+guimiinfo.age;

        

        var zhiye_lable = cc.find("panel/userinfo/zhiye",this.node);
        zhiye_lable.getComponent(cc.Label).string = ""+guimiinfo.job;

        
        var shengri_lable = cc.find("panel/userinfo/shengri",this.node);
        shengri_lable.getComponent(cc.Label).string = ""+guimiinfo.shengri;

  
        var aihao_lable = cc.find("panel/userinfo/aihao",this.node);
        aihao_lable.getComponent(cc.Label).string = ""+guimiinfo.aihao;
   
        var ren_icon_node = cc.find("panel/ren",this.node);
      
        var sfilename = juba_Game_Mng.GetInstance().Get_Guimi_ID_Touxiang(this.m_guimi_id);
       

        BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("guimi",ren_icon_node,sfilename,{width:465,height:465})
    
   
    }

    

}
