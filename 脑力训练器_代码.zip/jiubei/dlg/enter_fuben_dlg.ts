import XJS_GameInfoManager from "../../manager/XJS_GameInfoManager";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class enter_fuben_dlg extends cc.Component {

  
    m_cb = null;
    m_ifubentype = 0;

    m_enter_lv= 0;

    onLoad () 
    {
        var exitbtn = cc.find("panel/exitbtn",this.node)
        exitbtn.on("click",this.OnBtnExit.bind(this))

        var startbtn = cc.find("panel/startbtn",this.node)
        startbtn.on("click",this.OnBtnStartGame.bind(this))

 
    }
    OnBtnStartGame()
    {
        XJS_GameInfoManager.GetInstance().m_i_current_enter_gk = this.m_enter_lv;

        XJS_GameInfoManager.GetInstance().m_i_enter_game_mode = this.m_ifubentype;

 

        XJS_GameInfoManager.GetInstance().Set_Fuben_Type_Entered(this.m_ifubentype)
        XJS_GameInfoManager.GetInstance().On_User_New_EnterGame();

    }
    SetInfo(paradata)
    {
        this.m_cb =  paradata.cb;
        this.m_ifubentype = paradata.ifubentype;

        var maxwinnedgk = XJS_GameInfoManager.GetInstance().Get_Fuben_Type_Max_Winned_GK(this.m_ifubentype);
    
        this.m_enter_lv = maxwinnedgk+1;



        var gk_label = cc.find("panel/tongyongk/gk",this.node);

        var fubenname = XJS_GameInfoManager.GetInstance().Get_Fubentype_Name(this.m_ifubentype);
        gk_label.getComponent(cc.Label).string = fubenname +"-第"+this.m_enter_lv+"回"
        
        var hongdian_node = cc.find("panel/startbtn/hongdian",this.node);
        var fuben_entered = XJS_GameInfoManager.GetInstance().Get_Fuben_Type_Entered(this.m_ifubentype);
        
        if(fuben_entered)
        {
            hongdian_node.active = false;
        }else{
            hongdian_node.active = true;
        }
    }
    OnBtnExit()
    {
        this.node.destroy();
        if(this.m_cb)
        {
            this.m_cb();
        }
    }

}
