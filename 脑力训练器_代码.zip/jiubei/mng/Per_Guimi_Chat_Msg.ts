import ComFunc from "../../comfuncs/ComFunc";

 
 
 
 export class Per_Chat_Info
 {
        Get_Desc()
        {
            if(this.m_msg_type == 1)
            {
                return this.m_msg_content;
            }

            if(this.m_msg_type == 2)
            {
                return "[转账]";
            }
            if(this.m_msg_type == 3)
            {
                return "[礼物]";
            }
            if(this.m_msg_type == 4)
            {
                return "[语音]";
            }

            return "";
        }

        Init_Info(bself,msg_type,smsg,msg_addtion_data)
        {
            this.m_b_self = bself;
            this.m_msg_type=  msg_type;
            this.m_msg_content = smsg;
            this.m_addtion_msg_data = msg_addtion_data;
            this.m_chat_msg_tick = Date.now();


            this.m_chat_day_union = ComFunc.GetCurDayUnion();

            let date = new Date();
            let h = date.getHours();
            let m = date.getMinutes() ;
            

            this.m_chat_date_hour = h;
            this.m_chat_date_min = m;


        }

        static Serial_From_Save_OBJ(pobj)
        {
            if(!pobj)
            {
                return null;
            }

            var chatinfo = new Per_Chat_Info();

            chatinfo.m_b_self = ComFunc.Check_Read_Number(pobj.m_b_self);
            chatinfo.m_msg_type = ComFunc.Check_Read_Number(pobj.m_msg_type);
            chatinfo.m_msg_content =  pobj.m_msg_content;
            chatinfo.m_chat_msg_tick = ComFunc.Check_Read_Number(pobj.m_chat_msg_tick);
            
            chatinfo.m_chat_day_union = ComFunc.Check_Read_Number(pobj.m_chat_day_union);
            chatinfo.m_chat_date_hour = ComFunc.Check_Read_Number(pobj.m_chat_date_hour);
            chatinfo.m_chat_date_min = ComFunc.Check_Read_Number(pobj.m_chat_date_min);
         
            chatinfo.m_zhuanzhang_recved = ComFunc.Check_Read_Number(pobj.m_zhuanzhang_recved);
            chatinfo.m_b_readed = ComFunc.Check_Read_Number(pobj.m_b_readed);
        
            
            var addtiondata = pobj.addtiondata;
            chatinfo.m_addtion_msg_data = addtiondata;

            return chatinfo;
        }

        SetReaded(breaded)
        {
            this.m_b_readed = breaded;

        }
        Get_Saved_OBJ()
        {
            var addtiondata=  this.m_addtion_msg_data;
            if(!addtiondata)
            {
                addtiondata =  {};
            }

            var obj  = {
                m_b_self:this.m_b_self,
                m_msg_type:this.m_msg_type,
                m_msg_content:this.m_msg_content,
                m_chat_msg_tick:this.m_chat_msg_tick,
                addtiondata:addtiondata,
                m_chat_day_union:this.m_chat_day_union,
                m_chat_date_hour:this.m_chat_date_hour,
                m_chat_date_min:this.m_chat_date_min,
                m_zhuanzhang_recved:this.m_zhuanzhang_recved,
                m_b_readed:this.m_b_readed
            };

            return obj;
        }
        m_b_self = 0;
        m_msg_type=  1;
        m_msg_content = "";
        m_addtion_msg_data = null;
        m_chat_msg_tick = 0;
        m_chat_day_union = 0;
        m_chat_date_hour = 0;
        m_chat_date_min = 0;
        m_zhuanzhang_recved = 0;
        m_b_readed = 0;

 }
 
 export default  class Per_Guimi_Chat_Msg 
 {
    m_guimi_id = 0;
    m_b_first_chat_finished = 0; 


    m_chat_msg_info_list:Per_Chat_Info[] = [];

    m_last_start_chat_msg_orignal_index = 0;

    m_last_dealed_start_chat_msg_orignal_index = 0;

    m_last_chat_tick = 0;
    
    Add_Chat_Msg(bself,msg_type,smsg,msg_addtion_data)
    {
        if(!bself)
        {
            bself = 0;
        }

        if(this.m_chat_msg_info_list.length > 0 && msg_type == 3)
        {
            var last_msg :Per_Chat_Info= this.m_chat_msg_info_list[this.m_chat_msg_info_list.length-1];
            if(last_msg.m_msg_type == 3)
            {
                var last_t = last_msg.m_addtion_msg_data.t;
                var last_c = last_msg.m_addtion_msg_data.c;

                var cur_t=  msg_addtion_data.t;
                var cur_c=  msg_addtion_data.c;
                if(cur_t == last_t)
                {
                    last_c += cur_c;
                    last_msg.m_addtion_msg_data.c = last_c;
                    return;
                }
              
            }
        }


        var perchat = new Per_Chat_Info();
        perchat.Init_Info(bself,msg_type,smsg,msg_addtion_data);


        this.m_chat_msg_info_list.push(perchat);

        this.m_last_chat_tick = Date.now();
    }

    
    static Serial_From_Saved_OBJ(savedobj)
    {
        if(!savedobj)
        {
            return null;
        }
 
        var pmsg = new Per_Guimi_Chat_Msg();
        pmsg.m_guimi_id = ComFunc.Check_Read_Number(savedobj.m_guimi_id) ; 
        pmsg.m_last_start_chat_msg_orignal_index = ComFunc.Check_Read_Number(savedobj.m_last_start_chat_msg_orignal_index) ;
        pmsg.m_last_dealed_start_chat_msg_orignal_index = ComFunc.Check_Read_Number(savedobj.m_last_dealed_start_chat_msg_orignal_index) ;

        var chat_info_list = savedobj.chat_info_list;
        if(!chat_info_list)
        {
            chat_info_list = [];
        }

        var all_chat_list = [];

        for(var tt=0;tt<chat_info_list.length;tt++)
        {
            var tt_info = chat_info_list[tt];
            var tt_perchat = Per_Chat_Info.Serial_From_Save_OBJ(tt_info);

            if(tt_perchat)
            {
                all_chat_list.push(tt_perchat)
            }
            
        }

        pmsg.m_chat_msg_info_list = all_chat_list;
        return pmsg;
    }
    Get_Saved_OBJ()
    {
        var chat_info_list = [];

        for(var ff=0;ff<this.m_chat_msg_info_list.length;ff++)
        {
            var ff_info:Per_Chat_Info  = this.m_chat_msg_info_list[ff];
            var ff_obk = ff_info.Get_Saved_OBJ();
            chat_info_list.push(ff_obk);
        }


        var obj = {
            m_guimi_id:this.m_guimi_id,
      
            m_last_start_chat_msg_orignal_index :this.m_last_start_chat_msg_orignal_index ,
            m_last_dealed_start_chat_msg_orignal_index:this.m_last_dealed_start_chat_msg_orignal_index,
            chat_info_list:chat_info_list
        }


        return obj;
    }

    Set_Last_Dealed_Start_Msg_Index(index)
    {

        this.m_last_dealed_start_chat_msg_orignal_index = index;
        
    }

    Set_Last_Start_Msg_Chat_Original_Msg_Index( index)
    {

        this.m_last_start_chat_msg_orignal_index= index;
    }
    Get_UnReaded_Msg_Count()
    {
        var unread_msg = 0;

        for(var ff=0;ff<this.m_chat_msg_info_list.length;ff++)
        {
            var ff_msg:Per_Chat_Info = this.m_chat_msg_info_list[ff];
            if(!ff_msg.m_b_readed)
            {
                unread_msg++;
            }
        }
        return unread_msg;
    }
    
    Get_Last_Msg()
    {
        if(this.m_chat_msg_info_list.length == 0)
        {
            return "";
        }

        var last_msg:Per_Chat_Info = this.m_chat_msg_info_list[this.m_chat_msg_info_list.length-1];
        return last_msg.Get_Desc();


    }

    Get_Last_Chat_Info()
    {
        if(this.m_chat_msg_info_list.length == 0)
        {
            return  null;
        }

        var last_msg:Per_Chat_Info = this.m_chat_msg_info_list[this.m_chat_msg_info_list.length-1];
        return last_msg;


    }

 }