
export default class juba_Game_Event_Type{


    public static juba_Game_Event_Type_Money_Res_Change = 1; //无 
    public static juba_Game_Event_Type_Yaoqiangshu_Zhanshi_Change = 2; //无 
  
    public static juba_Game_Event_Type_Dianyuan_Shangzhen_Capter = 3; //无 
 
    
}

 