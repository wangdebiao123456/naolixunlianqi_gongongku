import WMap from "../../WDT/WMap";

 
 
 export default  class juba_Game_Event_Mng 
 {
    public static  m_ins:juba_Game_Event_Mng = null;

    public static GetInstance()
    {
        if(juba_Game_Event_Mng.m_ins == null)
        {
            juba_Game_Event_Mng.m_ins  =  new juba_Game_Event_Mng();
        }

        return juba_Game_Event_Mng.m_ins;
    }


    m_event_lisnter_map = new  WMap();

    constructor()
    {

    }
    RegLisnter(pp)
    {
        this.m_event_lisnter_map.putData(pp,1);
    }
    UnRegLisnter(pp)
    {
        this.m_event_lisnter_map.RemoveKey(pp);
    }


    Notify_Event(itype,pdata = null)
    {
        var pmap = this.m_event_lisnter_map.Copy();


        for(var ff=0;ff<pmap.size();ff++)
        {
            var ff_k = pmap.GetKeyByIndex(ff)
            ff_k.Notify_Event(itype,pdata)
        }
    }

}