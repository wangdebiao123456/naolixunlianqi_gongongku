import BundleLoadUtils from "../../comfuncs/BundleLoadUtils";

 

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class yingdao_mote_duihua_dlg extends cc.Component {

   
    m_cb = null;

    m_people_id = 0;
    m_top_pos_index = 0;
    m_msg_list = [];
    m_cur_chat_msg_index = 0;
    m_cur_chat_msg_tick = 0;
    m_cur_show_msg_info  =null;
    m_cur_show_chat_msg_info = null;


    m_btiaozhan = 0;
    onLoad () 
    {

        for(var ff=1;ff<=2;ff++)
        {
            var ff_chat_btn = cc.find("panel/self/"+ff+"/btn",this.node)
            ff_chat_btn.on("click",this.OnBtnSelfchat.bind(this,ff))
     
        }


       
    }
    Real_Success_Exit()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(1);
        }
         
    }
    OnBtnSelfchat(iindex)
    {
        if(!this.m_cur_show_msg_info)
        {
            return;
        }

        var n1 = this.m_cur_show_msg_info.n1;
        var n2 = this.m_cur_show_msg_info.n2;
        var bend = this.m_cur_show_msg_info.bend;


        
        var new_index=  n1;
        if(iindex == 2)
        {
            new_index=  n2;
        }

        if(!new_index || bend)
        {
            var self_msg_node = cc.find("panel/self",this.node)
            self_msg_node.active = false;
       
            this.scheduleOnce(this.Real_Success_Exit.bind(this),1)

            return;
        }


        if(new_index == this.m_cur_chat_msg_index)
        {
            return;
        }

        this.Show_Chat_Msg_Index( new_index ) 
    
    }
    SetInfo(paradata)
    {
        this.m_cb = paradata.cb;

        this.m_people_id = paradata.people_id;
        this.m_top_pos_index = paradata.top_pos_index;
        this.m_msg_list = paradata.msg_list;

        this.m_btiaozhan = paradata.btiaozhan;

        
         
        this.On_Start_Chat();
        this.Refresh_Info()

   

    }
    On_Start_Chat()
    {
        var first_msg = this.m_msg_list[0];
        this.m_cur_chat_msg_index = first_msg.i;


        this.Show_Chat_Msg_Index(this.m_cur_chat_msg_index );


    }
    OnBtnExit()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(0);
        }
 
        
    }

    protected update(dt: number): void {
        if(!this.m_cur_show_chat_msg_info)
        {
            return;
        }

        var ineed_sec = 0.5;


        var stip = this.m_cur_show_chat_msg_info[0];
        var eplasesec = this.m_cur_show_chat_msg_info[1];

        eplasesec += dt;
        this.m_cur_show_chat_msg_info[1] =eplasesec;
        var tip_node = cc.find("panel/pmsg/bk/msg",this.node);

        if(this.m_btiaozhan)
        {
            tip_node = cc.find("panel/tiaozhan/pmsg/bk/msg",this.node);

            
        }
      
        if(eplasesec > ineed_sec)
        {
            tip_node.getComponent(cc.Label).string = stip;
            this.m_cur_show_chat_msg_info = null;
        }else{
            var showlen = Math.floor(stip.length*(eplasesec/ineed_sec));

            var deststr = stip.substring(0,showlen);
 
 
            tip_node.getComponent(cc.Label).string = ""+deststr;
       

        }

    }
    Show_Chat_Msg_Index( chat_msg_index )
    {
        var msg = null;

        for(var ff=0;ff<this.m_msg_list.length;ff++)
        {

            var ff_info = this.m_msg_list[ff];
            if(ff_info.i == chat_msg_index)
            {
                msg= ff_info;
                break;
            }
        }


        if(!msg)
        {
            var self_msg_node = cc.find("panel/self",this.node)
            self_msg_node.active = false;

            this.scheduleOnce(this.OnBtnExit.bind(this),0.3)
            return;
        }


        this.m_cur_chat_msg_index  = chat_msg_index
        this.m_cur_show_msg_info = msg;
        this.m_cur_chat_msg_tick = Date.now();

        var stip = msg.m;

        var tip_node = cc.find("panel/pmsg/bk/msg",this.node)
        tip_node.getComponent(cc.Label).string = stip;

        this.m_cur_show_chat_msg_info = [stip,0]


        
        var self_msg_node = cc.find("panel/self",this.node)
        self_msg_node.active = false;


        var msg_1_t_label = cc.find("panel/self/1/btn/msg",this.node)
        var msg_2_t_label = cc.find("panel/self/2/btn/msg",this.node)
        var msg_2_node = cc.find("panel/self/2",this.node)
     
        

        var bend= msg.bend;
        var st1 = msg.t1;
        var st2 = msg.t2;


        if(bend && (st1 == "" || st1 == "0" || !st1))
        {
            var self_msg_node = cc.find("panel/self",this.node)
            self_msg_node.active = false;

            this.scheduleOnce(this.Real_Success_Exit.bind(this),1)

            return;
        }
      
      

        var n2 = msg.n2;

        if(!n2)
        {
            st2 = "";
        }


        msg_1_t_label.getComponent(cc.Label).string = st1;

        if(st2)
        {
            msg_2_node.active = true;
            msg_2_t_label.getComponent(cc.Label).string = st2;
        }else{
            msg_2_node.active = false;
        }

        var self = this;
        var pseq = cc.sequence(cc.delayTime(1.5),cc.callFunc(()=>
        {
            self.Show_Self_Msg_Node(msg);
        }));

        this.node.runAction(pseq);



        
    }
    Show_Self_Msg_Node(msg)
    {
        
        var msg_1_t_label = cc.find("panel/self/1/t",this.node)
        var msg_2_t_label = cc.find("panel/self/2/t",this.node)
        var msg_2_node = cc.find("panel/self/2",this.node)
        var msg_1_node = cc.find("panel/self/1",this.node)
     
        
        var self_msg_node = cc.find("panel/self",this.node)
        self_msg_node.active = true;
      
        msg_1_node.stopAllActions();
        msg_1_node.scale = 0.001;
        var pscale = cc.scaleTo(0.1,1);
        msg_1_node.runAction(pscale);


        if(msg_2_node.active)
        {
            msg_2_node.stopAllActions();
            msg_2_node.scale =0.001;
            var pscale2 = cc.scaleTo(0.1,1);
            msg_2_node.runAction(cc.sequence(cc.delayTime(0.2),pscale2));
    
             
        }


    }
    Refresh_Tiaozhan_Info()
    {
        var ren_node=  cc.find("panel/tiaozhan/tiaozhan_ren/1/ren",this.node)

        BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("guimi",ren_node,"touxiang/"+this.m_people_id,{width:200,height:200})
           
        
    }
    Refresh_Info()
    {
        var renwu_ndoe = cc.find("panel/renwu",this.node);
        var pmsg_ndoe = cc.find("panel/pmsg",this.node);
        var tiaozhan_ndoe = cc.find("panel/tiaozhan",this.node);

        if(this.m_btiaozhan)
        {
            tiaozhan_ndoe.active = true;
            pmsg_ndoe.active = false;
            renwu_ndoe.active = false;
        }else{
            tiaozhan_ndoe.active = false;
            pmsg_ndoe.active = true;
            renwu_ndoe.active = true;
        }


        if(this.m_btiaozhan)
        {

            this.Refresh_Tiaozhan_Info();
            return;
        }

        for(var ff=1;ff<=3;ff++)
        {
            var ff_ndoe = cc.find("panel/renwu/"+ff,this.node);

            if(ff  != this.m_top_pos_index)
            {
                ff_ndoe.active = false;
            }else{
                ff_ndoe.active = true;

                var id_label = cc.find("id",ff_ndoe)
                var ren_node = cc.find("ren",ff_ndoe)
               
                var ff_guiestid = this.m_people_id;

                if(ff_guiestid > 0)
                {
                    id_label.getComponent(cc.Label).string = ""+ff_guiestid;
                    BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("guimi",ren_node,"touxiang/"+ff_guiestid,{width:200,height:200})
                    
                }
            }

        }

      
        if(this.m_top_pos_index == 1)
        {
            pmsg_ndoe.x=  -130;
        }
        else if(this.m_top_pos_index == 3)
        {
            pmsg_ndoe.x=  130;
        }else{
            pmsg_ndoe.x=  0;
        }
        
    }

}
