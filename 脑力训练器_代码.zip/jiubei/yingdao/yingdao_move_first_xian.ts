 

const {ccclass, property} = cc._decorator;

@ccclass
export default class yingdao_move_first_xian extends cc.Component {


    m_cb = null;

    m_startpos = new cc.Vec2(0,0)
    m_endpos = new cc.Vec2(0,0)

    m_cur_step1 = 1;
    m_update_start_dt = 0;

    m_mask_height = 1;
    
    onLoad () 
    {

        this.Refresh_Info();

    }

    

    SetInfo(paradata)
    {
        this.m_cb = paradata.cb;
        this.m_startpos = paradata.startpos;
        this.m_endpos = paradata.endpos;
    

    }
    Refresh_Info()
    {
        var xd = Math.abs(this.m_endpos.x - this.m_startpos.x)
        var yd = Math.abs(this.m_endpos.y - this.m_startpos.y)

        if(yd <= 1)
        {
            yd = 1;
        }

        var yd_mask_node = cc.find("mask",this.node)
        yd_mask_node.setPosition(this.m_startpos);


        yd_mask_node.width = xd;
        yd_mask_node.height = yd;
        
        var yd_xian_node = cc.find("mask/yd_xian",this.node)
        yd_xian_node.width = xd;
        yd_xian_node.height = yd;
       
        this.m_mask_height = yd;

        yd_mask_node.height   = 0;

        var shouzhi_node = cc.find("shouzhi",this.node)
        shouzhi_node.active = false;
        
    }


    protected update(dt: number): void {

        this.m_update_start_dt += dt;
        var yd_mask_node = cc.find("mask",this.node)
        var shouzhi_node = cc.find("shouzhi",this.node)
        shouzhi_node.active = false;


        if(this.m_cur_step1 == 2)
        {

            yd_mask_node.height = this.m_mask_height ;
            
            if(this.m_update_start_dt >= 1)
            {
                this.m_update_start_dt=  0;
                yd_mask_node.height =  0;
                this.m_cur_step1 = 1;
            }
            return;
        }

        var show_need_sec= 1;
      
        if(this.m_update_start_dt >= show_need_sec)
        {
            this.m_update_start_dt = 0;
            yd_mask_node.height = this.m_mask_height ;
            this.m_cur_step1 = 2;

            return;
        }


        shouzhi_node.active = true;
     
        yd_mask_node.height = this.m_mask_height * this.m_update_start_dt/show_need_sec;

        var shouzhiy =  yd_mask_node.y+ yd_mask_node.height;
        shouzhi_node.y = shouzhiy;



        var startx = yd_mask_node.x + 30;
        var endx  = this.m_endpos.x + 40;

        var icurx = startx  + (endx - startx)*this.m_update_start_dt/show_need_sec;

        shouzhi_node.x=  icurx;
    }

}
