import WMap from "../../WDT/WMap";

 

 
export   class Seed_Random 
{

    
    m_Seed1 = -1;
    m_Seed2 = -1;
    CheckInitSeed()
    {
        if(this.m_Seed1 == -1 || this.m_Seed2 == -1)
        {
            this.m_Seed1 = Math.floor(Math.random()*65535);
            this.m_Seed2 = Math.floor(Math.random()*65535);
        }
    }
    GetNextRealRandom()
    {
        this.CheckInitSeed();


         let rand_data = Seed_Random.GetNextRandom(this.m_Seed1,this.m_Seed2);
        let irand = rand_data[0];
        this.m_Seed1 = rand_data[1];
        this.m_Seed2 = rand_data[2];
        return irand;
    }
    static MathImul(x, y)
    {
      return  x*y;
    }
    static GetNextRandom(iseed1,iseed2)
    {
        
         var rngstate = [];  // Initialized to a Uint32Array during genesis.
         rngstate[0] = iseed1;
         rngstate[1] = iseed2;
 
         var r0 = (Seed_Random.MathImul(18030, rngstate[0] & 0xFFFF) + (rngstate[0] >>> 16)) | 0;
         rngstate[0] = r0;
         var r1 = (Seed_Random.MathImul(36969, rngstate[1] & 0xFFFF) + (rngstate[1] >>> 16)) | 0;
         rngstate[1] = r1;
         var x = ((r0 << 16) + (r1 & 0xFFFF)) | 0;
         // Division by 0x100000000 through multiplication by reciprocal.
 
        let irand = (x < 0 ? (x + 0x100000000) : x) * 2.3283064365386962890625e-10;
        let inew_data = [irand,rngstate[0],rngstate[1]];
        //console.log("GetNextRandom = "+inew_data);
        return inew_data;
     }
    
}

export default class Juba_Rand_Seed_Mng 
{
    static _instance:Juba_Rand_Seed_Mng = null;
   

    static GetInstance() 
    {
        if (!Juba_Rand_Seed_Mng._instance) {
            // doSomething
            Juba_Rand_Seed_Mng._instance = new Juba_Rand_Seed_Mng();
             
        }
        return Juba_Rand_Seed_Mng._instance;
    }

    m_index_seed_map = new WMap();

    constructor()
    {

    }
    Get_Next_Rand_V_By_Gailv_Map(gailv_map,randindex)
    {
        var key_arr = [];
        var gailv_arr = [];

        var all_Gailv = 0;
        for(var ff=0;ff<gailv_map.size();ff++)
        {
            var ff_key = gailv_map.GetKeyByIndex(ff);
            var ff_v = gailv_map.GetEntryByIndex(ff);
            key_arr.push(ff_key);
            gailv_arr.push(ff_v);
            all_Gailv += ff_v;
        }


        if(all_Gailv == 0)
        {
            return gailv_map.GetKeyByIndex(0);
        }

        for(var ff=0;ff<gailv_arr.length;ff++)
        {
            var ff_gailv = gailv_arr[ff];
            var ff_newgailv = ff_gailv/all_Gailv;
            gailv_arr[ff] = ff_newgailv;
        }

        var irand1 = Juba_Rand_Seed_Mng.GetInstance().Get_Seed_Index_Next_Random(randindex);
     

        var find_idnex= 0;
        var addg = 0;
        for(var ff=0;ff<gailv_arr.length;ff++)
        {
            var ff_g = gailv_arr[ff];
            addg+=ff_g;
            if(addg > irand1)
            {
                find_idnex = ff;
                break;
            }
        }
        var find_k = key_arr[find_idnex];

        return find_k;

        
    }
    Get_Seed_Index_Next_Random(iseedindex)
    {
        if(!this.m_index_seed_map.hasKey(iseedindex))
        {
            var prasnd = new Seed_Random();
            this.m_index_seed_map.putData(iseedindex,prasnd)
        }

        var oldrand:Seed_Random = this.m_index_seed_map.getData(iseedindex);
        return oldrand.GetNextRealRandom();
    }

}