 
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import juba_Config_Mng from "../mng/juba_Config_Mng";
import juba_Game_Mng from "../mng/juba_Game_Mng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class loadingto_juba_game extends cc.Component {

    
    @property(cc.Asset)
    model_info: cc.Asset = null;


    @property(cc.JsonAsset)
    chat_info: cc.JsonAsset = null;

    
    @property(cc.JsonAsset)
    gameinfo: cc.JsonAsset = null;

      
    @property(cc.JsonAsset)
    game_yd_info_config: cc.JsonAsset = null;

    m_b_in_progress = false;
  
    m_progress_start_tick = 0;
    m_prog=  null;
    m_b_inited = 0;

    onLoad () 
    {

        this.m_b_in_progress = true;
        this.m_progress_start_tick = Date.now();
        this.m_prog=  cc.find("bottom/progress",this.node);
        this.m_b_inited = 1;

        cc.director.preloadScene("jiubagame");

        var kaishiyingye_node  = cc.find("kaishiyingye",this.node);
        var tiaozhanmoshi_node  = cc.find("tiaozhanmoshi",this.node);

        var imode = juba_Game_Mng.GetInstance().m_enter_game_mode ;
 
        juba_Config_Mng.GetInstance().Set_Model_Info_Config(this.model_info)
       
        juba_Config_Mng.GetInstance().Set_Chat_Config(this.chat_info.json)
       
        juba_Config_Mng.GetInstance().Set_GameInfo_Config(this.gameinfo.json)
        juba_Config_Mng.GetInstance().Set_Game_Yingdao_Info_Config(this.game_yd_info_config.json)
    
        if(imode == 1 || imode == 3)
        {
            kaishiyingye_node.active = true;
            tiaozhanmoshi_node.active = false;


            var tianshu_label  = cc.find("kaishiyingye/tianshu",this.node);

            var curentergk = juba_Game_Mng.GetInstance().Get_Cur_Enter_Day_GK();

            if(imode == 1)
            {
                curentergk = juba_Game_Mng.GetInstance().Get_Cur_Guaishou_Enter_Day_GK();

            }

            tianshu_label.getComponent(cc.Label).string = ""+curentergk+"";
    
            var kaishiyingye  = cc.find("kaishiyingye",this.node);
    
            kaishiyingye.opacity = 1;
    
            var pseq  = cc.fadeIn(0.5);
            kaishiyingye.runAction(pseq)
        }else{
          
            kaishiyingye_node.active = false;
            tiaozhanmoshi_node.active = true;
            tiaozhanmoshi_node.opacity = 1;
    
            var pseq  = cc.fadeIn(0.5);
            tiaozhanmoshi_node.runAction(pseq)

        }
       
        if(imode == 1 || imode == 2)
        {
            BackGroundSoundUtils.GetInstance().Play_Effect("com/snd_talk_gogo")
        }
       
        this.scheduleOnce(this.FD_Change_To_Game.bind(this),1)
    }

    FD_Change_To_Game()
    {
        var imode = juba_Game_Mng.GetInstance().m_enter_game_mode ;

        if(imode == 3 || imode== 4)
        {

            cc.director.loadScene("jiubagame")
        }else{

            cc.director.loadScene("guaishoujubagame")
        }

    }
    update()
    {
 
        if(!this.m_b_inited)
        {
            return;
        }


    

        var self = this;
        
 
        if(this.m_b_in_progress){
            var ieplasetick = Date.now() - this.m_progress_start_tick ;
            var iprogress = Math.min(ieplasetick/30000,1);
            if(ieplasetick > 30000)
            {
                 this.m_progress_start_tick =  Date.now();
            }

            if(iprogress >= 0.95)
            {
             //   iprogress = 0.95;
            }
            this.m_prog.getComponent(cc.ProgressBar).progress  = iprogress;


            var prolb = cc.find("bottom/prolb",this.node);

            prolb.getComponent(cc.Label).string = "正在加载进入游戏场资源..";

           
        }
    }
}
