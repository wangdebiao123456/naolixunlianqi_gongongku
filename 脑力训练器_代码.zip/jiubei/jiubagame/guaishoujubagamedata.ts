import BaseUIUtils from "../../comfuncs/BaseUIUtils";
import BundleLoadUtils from "../../comfuncs/BundleLoadUtils";
import ComFunc from "../../comfuncs/ComFunc"; 
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import MyLocalStorge from "../../WDT/MyLocalStorge";
import NodeComPoolUtils from "../../WDT/NodeComPoolUtils";
import WMap from "../../WDT/WMap";
import juba_Config_Mng from "../mng/juba_Config_Mng";
import juba_Game_Mng from "../mng/juba_Game_Mng";
import Juba_Beijing_Gedan_Mng from "../utils/Juba_Beijing_Gedan_Mng";
import Juba_Rand_Seed_Mng from "../utils/RandomSeedMng";
import game_spceial_item from "./game_spceial_item";
import guaishou_banzi from "./guaishou_banzi"; 
import guaishou_juba_Banzi_Info from "./guaishou_juba_Banzi_Info";
 
import MoveLogicMng, { juba_PerMoveInfo } from "./MoveLogicMng";

 


export class Juba_Game_Spcieal_Pos_Info
{
    //0:为空,1:视频解锁，2：盒子，3：金币
    itype = 0;

    //type 2:剩余几个,3：金币解锁数
    icount = 0;


}


class Per_Tiaozhan_Top_Drink_Info
{
    m_cur_index= 0;
    m_drink_id = 0;
    m_existed = 0;

    m_node:cc.Node = null;

    static From_SaveInfo(saveinfo)
    {
        var pinfo  =new Per_Tiaozhan_Top_Drink_Info();
        pinfo.m_cur_index = ComFunc.Check_Read_Number(saveinfo.m_cur_index);
        pinfo.m_drink_id = ComFunc.Check_Read_Number(saveinfo.m_drink_id);
        pinfo.m_existed = ComFunc.Check_Read_Number(saveinfo.m_existed);

        return pinfo;
    }
    Get_SavedInfo()
    {
        var pinfo={
            m_cur_index:this.m_cur_index,
            m_drink_id:this.m_drink_id,
            m_existed:this.m_existed
        }
        return pinfo;
    }
    SetPosition(tt_pos)
    {
        if(this.m_node)
        {
            this.m_node.setPosition(tt_pos)
        }
    }

    Set_Existed(bexisted)
    {
        this.m_existed = bexisted;
        if(!this.m_node)
        {
            return
        }

        var jiubei_gou_ndoe = this.m_node.getChildByName("gou")
        jiubei_gou_ndoe.active = this.m_existed ? true :false;
        var jiubei_icon_ndoe = this.m_node.getChildByName("icon")
        
        if(this.m_existed )
        {
            jiubei_icon_ndoe.opacity = 255;
        }else{
            jiubei_icon_ndoe.opacity = 130;
        }
    }
}


export default class guaishoujubagamedata
{
    m_parent_game = null;
    m_parent_game_node:cc.Node = null;




    m_b_inited = 0;

    m_tiaozhan_total_finished_jiubei_count = 0;
    m_tiaozhan_total_need_finished_jiubei_count = 58;
    m_cur_tiaozhan_wav = 1;
    m_cur_tiaozhan_wav_need_finished_count = 0;
    m_cur_tiaozhan_wav_has_finished_count = 0;
    m_cur_tiaozhan_all_valid_drinkid_list = [];

    m_tiaozhan_cur_use_chat_id = 0;
    m_tiaozhan_mode_guest_id = 0;

    m_tiaozhan_top_drink_info_list:Per_Tiaozhan_Top_Drink_Info[] = [];



    m_bottom_pos_banzi_info_map = new WMap();
  

    m_center_pos_banzi_info_map = new WMap();

    m_jiba_lv=  0;
    m_cur_lv_wave = 1;


    m_last_show_game_guest_id = 0;
    m_last_show_game_guest_valid_index = 0;

    m_top_guest_id_exist_count_map = new WMap();

    m_cur_lv_all_valid_guest_id_list =[];
    m_cur_lv_wave_valid_guest_id_list = [];


    m_lv_valid_jiubei_type_list = [];

    m_center_all_displayed_bk_pos_list =[];
    m_center_valid_bk_pos_list =[];
    m_b_in_dealing_animate = 0;

    m_b_in_banzi_Del_status = 0;

    m_b_in_first_gk_yd = 0;

    m_cur_game_jinbi = 0;

    m_center_logic_pos_bk_select_color_node_map = new WMap();

    m_select_show_gezi_bk_green_node:cc.Node   = null;

    m_move_cell_hit_center_bk_pos = null;

    m_b_game_ended = 0;
    m_b_game_end_success = 0;

    m_drage_jiubei_info:guaishou_juba_Banzi_Info =  null;

    m_b_drage_type = 0;
    m_bottom_selected_drage_index=  0;
    m_drag_move_cell_node:cc.Node = null;
    m_drag_move_cell_touch_start_pos=   new cc.Vec2(0,0);

    m_rand_mng:Juba_Rand_Seed_Mng = new Juba_Rand_Seed_Mng();
    
    m_b_touchued = false;
    m_touch_start_pt = new cc.Vec2(0,0);

    m_last_move_pt = new cc.Vec2(0,0);


    m_gk_finished_guest_jiubei_count=  0;

    m_gk_pos_index_speical_init_box_info_map = new WMap();
    m_gk_pos_index_speical_cur_box_info_map = new WMap();

    m_gk_pos_game_spcial_item_node_map = new WMap();

    //用于临时显示最新饮品的
    m_b_show_new_drink_id_top_index = 0;

    m_top3_pos_w_node_map = new WMap();
    m_top3_pos_w_prev_type_map = new WMap();
  

    m_top3_pos_unlocked_map = new WMap();
    m_top3_pos_guest_id_map = new WMap();
    //位置剩余完成几次饮料，一个位置可能有几个
    m_top3_pos_left_need_finish_drink_count_map = new WMap();
    m_top3_pos_need_finish_drink_id_map = new WMap();

    //当前波次能出的饮料id
    m_gk_cur_wave_can_show_drink_id_map = new WMap();
    //当前波次各个能出的饮料id已经出的数目 -上方3个
    m_gk_cur_wave_existed_top3_drink_id_count_map = new WMap();
     //当前波次各个能出的饮料id已经出的数目 -下方盘子数目
    m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map = new WMap();

    m_cur_gk_show_new_drinkid_map = new WMap();

    
    //下方盘子里面有1，2,3，个酒杯数目的次数
    m_bottom_panzi_perci_shumu_count_map = new WMap();


    //本波次需要完成的酒杯数目和已经完成的酒杯数目
    m_gk_cur_wave_Need_Finished_drink_count = 0;
    m_gk_cur_wave_has_Finished_drink_count = 0;


    m_gk_cur_wave_diaoluoed_jinbi_count = 0;


    m_center_logic_pos_has_diaoluo_jinbi_map = new WMap();
    m_center_logic_pos_diaoluo_xianjing_node_map = new WMap();


    m_yd_move_logic_pos_list = [];
    m_yd_move_logcic_pos_bk_node_map = new WMap();

    m_cur_gk_has_showed_chat_guest_id_map = new WMap();
    m_cur_top_finish_order_need_show_chat_guestid = 0;

    m_cur_gk_all_can_show_game_chat_guest_id_list =[];
    
    m_enter_game_mode = 1;


    constructor(parentgame,parentgamenode,enter_game_mode )
    {
        this.m_parent_game = parentgame;
        this.m_parent_game_node = parentgamenode;

        this.m_enter_game_mode = enter_game_mode ;
       
    }

    Parse_GK_Box_Data(src_box)
    {

        var box_arr = src_box.split("|");
        var src_box_d_arr = [];
        for(var tt=0;tt<box_arr.length;tt++)
        {
            var tt_d = Math.floor( ComFunc.Check_Read_Number(box_arr[tt]));
            var newd =tt_d;
            
            src_box_d_arr[tt] =  newd;
        }

        return src_box_d_arr;
    }
    Translate_Cell_Index_To_Logic_Pos(cellindex)
    {
        var iy = Math.floor(cellindex/4);

        var ix = cellindex - 4*iy;

        var logicx = ix +1;
        var logicy = 6- iy;

        return [logicx,logicy]
    }
    Translate_Logic_Pos_To_Cell_Index(logic_pos)
    {
        var logix = logic_pos[0];
        var logiy = logic_pos[1];

        var iy1 = 6-logiy;

        var cellindex = logix - 1 +  iy1*4;

        return cellindex;
    }
    Get_Game_Jinbi()
    {
        return this.m_cur_game_jinbi;
    }
    Notify_Jinbi_Jiesuo_Cell( cell_index,icount)
    {
        this.m_cur_game_jinbi -= icount;;
        this.Notify_Jiesuo_Cell_Index(cell_index);
        this.m_parent_game.Refresh_Info();
    }

    Notify_Jiesuo_Cell_Index( cell_index)
    {
        this.m_gk_pos_index_speical_cur_box_info_map.RemoveKey(cell_index);

        var logicc_pos = this.Translate_Cell_Index_To_Logic_Pos(cell_index);


        var find_eisst = false;
        for(var tt=0;tt<this.m_center_valid_bk_pos_list.length;tt++)
        {
            var tt_pos = this.m_center_valid_bk_pos_list[tt];
            if(tt_pos[0] == logicc_pos[0] && tt_pos[1] == logicc_pos[1])
            {
                find_eisst = true;
            }
        }

        if(!find_eisst)
        {
            this.m_center_valid_bk_pos_list.push(logicc_pos);

        }
      
      //  this.Refresh_Special_Node_Item_Node();

        this.Refresh_Info();
        this.Refresh_Top_Guest_Info()
        this.Save_Cur_Gk_Info()

    }
    Refresh_Special_Node_Item_Node()
    {
        var spciealgezi_node = cc.find("wuping/speicalitem",this.m_parent_game_node);

        var need_remove_index_map = new WMap();

        for(var ff=0;ff<this.m_gk_pos_game_spcial_item_node_map.size();ff++)
        {
            var ff_pos_idnex= this.m_gk_pos_game_spcial_item_node_map.GetKeyByIndex(ff);

            var ff_spciel_item_node:cc.Node = this.m_gk_pos_game_spcial_item_node_map.GetEntryByIndex(ff);

            if(!this.m_gk_pos_index_speical_cur_box_info_map.hasKey(ff_pos_idnex))
            {
                need_remove_index_map.putData(ff_pos_idnex,1)
            }
        }

        for(var tt=0;tt<need_remove_index_map.size();tt++)
        {
            var tt_index=  need_remove_index_map.GetKeyByIndex(tt);
            var tt_node:cc.Node = this.m_gk_pos_game_spcial_item_node_map.getData(tt_index);

            NodeComPoolUtils.GetInstance().putANode("game_spceial_item",tt_node)
        }

        var game_spceial_item_preab =  this.m_parent_game.game_spceial_item;

        for(var ff=0;ff<this.m_gk_pos_index_speical_cur_box_info_map.size();ff++)
        {
            var ff_index = this.m_gk_pos_index_speical_cur_box_info_map.GetKeyByIndex(ff);
            var ff_boxingfo:Juba_Game_Spcieal_Pos_Info = this.m_gk_pos_index_speical_cur_box_info_map.GetEntryByIndex(ff);

            if(!this.m_gk_pos_game_spcial_item_node_map.hasKey(ff_index))
            {
                var ff_node = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("game_spceial_item",game_spceial_item_preab)
                spciealgezi_node.addChild(ff_node,10);
                this.m_gk_pos_game_spcial_item_node_map.putData(ff_index,ff_node)
            }

            var ff_old_ndoe:cc.Node = this.m_gk_pos_game_spcial_item_node_map.getData(ff_index);

            var ff_cell_pos = this.Translate_Cell_Index_To_Logic_Pos(ff_index);

            var ff_realpos=  this.Get_Logic_Pos_Center_Real_World_Pos(ff_cell_pos[0],ff_cell_pos[1]);

            ff_old_ndoe.setPosition(ff_realpos);

            var game_spceial_item:game_spceial_item  = ff_old_ndoe.getComponent("game_spceial_item");
            game_spceial_item.SetInfo(
                {
                    cell_index:ff_index,
                    gamejinbi:this.m_cur_game_jinbi,
                    boxinfo:ff_boxingfo
                    ,plisnter:this
                }
            )
        }
    }

    Find_Next_Show_Guest_ID(itop_pos)
    {
        var guest_find_start_index = 0;
        if(this.m_last_show_game_guest_id == 0)
        {
            guest_find_start_index = 0;
        }else{
            guest_find_start_index = this.m_last_show_game_guest_valid_index+1;
        }

        var top_exist_id_pos_map = new WMap();
        for(var tt=0;tt<this.m_top3_pos_guest_id_map.size();tt++)
        {
            var tt_pos  = this.m_top3_pos_guest_id_map.GetKeyByIndex(tt);
            var tt_gid = this.m_top3_pos_guest_id_map.GetEntryByIndex(tt);
            top_exist_id_pos_map.putData(tt_gid,tt_pos);
        }

        var find_index=  0;
        var find_guest_id = 0;
        for(var ff=guest_find_start_index;ff<this.m_cur_lv_all_valid_guest_id_list.length;ff++)
        {
            var ff_guest_id = this.m_cur_lv_all_valid_guest_id_list[ff];

            if(!ComFunc.arrayShuzuContain(this.m_cur_lv_wave_valid_guest_id_list,ff_guest_id))
            {
                continue;
            }

            if(top_exist_id_pos_map.hasKey(ff_guest_id))
            {
                continue;
            }

            find_index = ff;
            find_guest_id=  ff_guest_id;
            break;

        }


        if(!find_guest_id)
        {
            for(var ff=0;ff<this.m_cur_lv_all_valid_guest_id_list.length;ff++)
            {
                var ff_guest_id = this.m_cur_lv_all_valid_guest_id_list[ff];
    
                if(!ComFunc.arrayShuzuContain(this.m_cur_lv_wave_valid_guest_id_list,ff_guest_id))
                {
                    continue;
                }

                if(top_exist_id_pos_map.hasKey(ff_guest_id))
                {
                    continue;
                }
    
    
                find_index = ff;
                find_guest_id=  ff_guest_id;
                break;
    
            }
        }



        if(!find_guest_id)
        {
            for(var ff=0;ff<this.m_cur_lv_all_valid_guest_id_list.length;ff++)
            {
                var ff_guest_id = this.m_cur_lv_all_valid_guest_id_list[ff];
    
                if(!ComFunc.arrayShuzuContain(this.m_cur_lv_wave_valid_guest_id_list,ff_guest_id))
                {
                    continue;
                }

                if(top_exist_id_pos_map.hasKey(ff_guest_id))
                {
                    var prev_pos = top_exist_id_pos_map.getData(ff_guest_id);
                    if(prev_pos != itop_pos)
                    {
                        continue;
                    }
                  
                }
     
                find_index = ff;
                find_guest_id=  ff_guest_id;
                break;
    
            }
        }



        if(!find_guest_id)
        {
            console.log("出错了 !find_guest_id")
            find_guest_id = this.m_cur_lv_wave_valid_guest_id_list[0];
            find_index = 0;
        }

        var cur_wave_jiesuo_guestid = juba_Config_Mng.GetInstance().Get_GK_Wave_Jiesuo_GuestID(this.m_jiba_lv,this.m_cur_lv_wave);

        if(cur_wave_jiesuo_guestid > 0 && ComFunc.arrayShuzuContain(this.m_cur_lv_wave_valid_guest_id_list,cur_wave_jiesuo_guestid))
        {
            if(!this.m_top_guest_id_exist_count_map.hasKey(cur_wave_jiesuo_guestid))
            {
                find_guest_id = cur_wave_jiesuo_guestid;
                this.m_top_guest_id_exist_count_map.putData(find_guest_id,1);
                        
                return cur_wave_jiesuo_guestid;
            }
        }

        this.m_last_show_game_guest_id = find_guest_id;
        this.m_last_show_game_guest_valid_index = find_index;

        if(!this.m_top_guest_id_exist_count_map.hasKey(find_guest_id))
        {
            this.m_top_guest_id_exist_count_map.putData(find_guest_id,1);
        }else{
            var prevc  = this.m_top_guest_id_exist_count_map.getData(find_guest_id);
            this.m_top_guest_id_exist_count_map.putData(find_guest_id, 1+ prevc);
        }
    
        return find_guest_id;

    }

    Get_Next_Top3_Show_Drink_ID(itop_pos)
    {
        if(this.m_b_in_first_gk_yd)
        {
            return 1;
        }

        var exist_other_pos_drink_id_map = new WMap();
        var exist_other_pos_drink_id_all_map = new WMap();

        for(var tt=0;tt<this.m_top3_pos_need_finish_drink_id_map.size();tt++)
        {
            var tt_pos = this.m_top3_pos_need_finish_drink_id_map.GetKeyByIndex(tt);
            var tt_id  = this.m_top3_pos_need_finish_drink_id_map.GetEntryByIndex(tt);

            if(tt_pos != itop_pos)
            {
                exist_other_pos_drink_id_map.putData(tt_id,1)
            }

            exist_other_pos_drink_id_all_map.putData(tt_id,1)
        }
        
        var left_drink_id_map = new WMap();

        for(var ff=0;ff<this.m_gk_cur_wave_can_show_drink_id_map.size();ff++)
        {
            var ff_drink_id = this.m_gk_cur_wave_can_show_drink_id_map.GetKeyByIndex(ff);

            if(!exist_other_pos_drink_id_map.hasKey(ff_drink_id) && !exist_other_pos_drink_id_all_map.hasKey(ff_drink_id))
            {
                left_drink_id_map.putData(ff_drink_id,1);
            }
  
        }
        
        if(left_drink_id_map.size() == 0)
        {
            for(var ff=0;ff<this.m_gk_cur_wave_can_show_drink_id_map.size();ff++)
            {
                var ff_drink_id = this.m_gk_cur_wave_can_show_drink_id_map.GetKeyByIndex(ff);
    
                if(!exist_other_pos_drink_id_map.hasKey(ff_drink_id))
                {
                    left_drink_id_map.putData(ff_drink_id,1);
                } 
            }
            
        }
        if(left_drink_id_map.size() == 0)
        {
            left_drink_id_map = this.m_gk_cur_wave_can_show_drink_id_map.Copy();
        }

        //可用的这些drinkid里面选择最低数目出现次数的几个
        var min_chuxian_cishu = 0;
        var min_chuxian_drinkid=  0;

        for(var tt=0;tt<left_drink_id_map.size();tt++)
        {
            var tt_drinkid = left_drink_id_map.GetKeyByIndex(tt);

            var tt_chuxian_c = 0;
            if(this.m_gk_cur_wave_existed_top3_drink_id_count_map.hasKey(tt_drinkid))
            {
                tt_chuxian_c = this.m_gk_cur_wave_existed_top3_drink_id_count_map.getData(tt_drinkid);
            }

            if(min_chuxian_drinkid == 0)
            {
                min_chuxian_drinkid = tt_drinkid;
                min_chuxian_cishu = tt_chuxian_c;
            }else{
                if(tt_chuxian_c < min_chuxian_cishu)
                {
                    min_chuxian_drinkid = tt_drinkid;
                    min_chuxian_cishu = tt_chuxian_c;
                }
            }
        }


        var min_cishu_or_jia1_drinkid_map = new WMap();
        
        for(var tt=0;tt<left_drink_id_map.size();tt++)
        {
            var tt_drinkid = left_drink_id_map.GetKeyByIndex(tt);

            var tt_chuxian_c = 0;
            if(this.m_gk_cur_wave_existed_top3_drink_id_count_map.hasKey(tt_drinkid))
            {
                tt_chuxian_c = this.m_gk_cur_wave_existed_top3_drink_id_count_map.getData(tt_drinkid);
            }

            if(tt_chuxian_c <= 1 + min_chuxian_cishu)
            {
                min_cishu_or_jia1_drinkid_map.putData(tt_drinkid,1)
            }
        }


        //第一步，首先判断本关卡本波次解锁了哪个drinkid?
        var cur_wave_jiesuo_drinkid = this.Get_GK_Wave_Jiesuo_DrinkID(this.m_jiba_lv,this.m_cur_lv_wave)

        if(cur_wave_jiesuo_drinkid > 0 && this.m_gk_cur_wave_can_show_drink_id_map.hasKey(cur_wave_jiesuo_drinkid))
        {
            if(!this.m_gk_cur_wave_existed_top3_drink_id_count_map.hasKey(cur_wave_jiesuo_drinkid))
            {
                this.m_gk_cur_wave_existed_top3_drink_id_count_map.putData(cur_wave_jiesuo_drinkid,1);
                return cur_wave_jiesuo_drinkid;
            }
        }

        if(min_cishu_or_jia1_drinkid_map.size() == 0)
        {
            min_cishu_or_jia1_drinkid_map = left_drink_id_map;
        }

        var irand1  = Math.floor(min_cishu_or_jia1_drinkid_map.size() * this.m_rand_mng.Get_Seed_Index_Next_Random(3));
        var idrinktype = min_cishu_or_jia1_drinkid_map.GetKeyByIndex(irand1);


        if(!this.m_gk_cur_wave_existed_top3_drink_id_count_map.hasKey(idrinktype))
        {
            this.m_gk_cur_wave_existed_top3_drink_id_count_map.putData(idrinktype,1);
        }else{
            var prevc = this.m_gk_cur_wave_existed_top3_drink_id_count_map.getData(idrinktype);

            this.m_gk_cur_wave_existed_top3_drink_id_count_map.putData(idrinktype,1 + prevc);
        }
        

        return idrinktype;
    }
    
    Real_Jiesuo_Top3_Pos(itop_pos)
    {      
        this.m_top3_pos_unlocked_map.putData(itop_pos,1)
        var show_guest_id  = this.Find_Next_Show_Guest_ID(itop_pos);
        this.m_top3_pos_guest_id_map.putData(itop_pos,show_guest_id);

        var nex_show_drink_id_type =  this.Get_Next_Top3_Show_Drink_ID(itop_pos);

        var lv_wave_info_arr = juba_Config_Mng.GetInstance().Fing_GK_Wave_Info(this.m_jiba_lv,this.m_cur_lv_wave);
        var wave_need_finish_drink_c = lv_wave_info_arr[3];
        if(!wave_need_finish_drink_c)
        {
            wave_need_finish_drink_c = 1;
        }

        this.m_top3_pos_need_finish_drink_id_map.putData(itop_pos,nex_show_drink_id_type)
        this.m_top3_pos_left_need_finish_drink_count_map.putData(itop_pos,wave_need_finish_drink_c);

 
        this.Refresh_Top_Guest_Info();
        this.Refresh_Info();
        this.Refresh_Special_Node_Item_Node();

        this.Save_Cur_Gk_Info();

    }
    Refresh_Info()
    {
        this.m_parent_game.Refresh_Info();
    }
    Get_Cur_Wave_Can_Show_Drink_ID_Map()
    {
        var lv_wave_info_arr = juba_Config_Mng.GetInstance().Fing_GK_Wave_Info(this.m_jiba_lv,this.m_cur_lv_wave);
        var cur_wave_drink_count = ComFunc.Check_Read_Number(lv_wave_info_arr[2]);
        var all_in_gk_can_show_jiubei_type_list = juba_Config_Mng.GetInstance().Guaishou_Get_GK_Seq_Show_Drink_Id_List(this.m_jiba_lv)

        if(cur_wave_drink_count > all_in_gk_can_show_jiubei_type_list.length)
        {
            cur_wave_drink_count = all_in_gk_can_show_jiubei_type_list.length
        }

        var all_need_show_drink_map = new WMap();
        for(var ff=0;ff<cur_wave_drink_count;ff++)
        {
            var ff_id = all_in_gk_can_show_jiubei_type_list[ff];
            all_need_show_drink_map.putData(ff_id,1);
        }

        return all_need_show_drink_map;
    }
    On_Change_To_GK_Next_Wave()
    {
        if(this.m_enter_game_mode == 2)
        {
            return;
        }

        var curgk=  this.m_jiba_lv ;

        this.m_cur_lv_wave++;
        this.m_cur_lv_wave_valid_guest_id_list = juba_Config_Mng.GetInstance().Get_All_Can_Show_Guest_ID_List_In_GK_Wave(curgk,this.m_cur_lv_wave);

        var lv_wave_info_arr = juba_Config_Mng.GetInstance().Fing_GK_Wave_Info(this.m_jiba_lv,this.m_cur_lv_wave);
        var wave_need_finish_drink_c = lv_wave_info_arr[3];
        if(!wave_need_finish_drink_c)
        {
            wave_need_finish_drink_c = 1;
        }
 //得到当前波次出现的饮料

        //当前波次能出的饮料id
 
        //var prev_gk_jiesuo_drinkid_map = juba_Config_Mng.GetInstance().Get_Prev_GK_Jiesuo_Drink_Id_Map(curgk)

       // var cur_gk_wave_has_jiesuo_drinkid_map = juba_Config_Mng.GetInstance().Get_In_GK_Wave_Has_Jiesuo_Drink_Id_Map(curgk,this.m_cur_lv_wave)
       
       

        
        this.m_gk_cur_wave_Need_Finished_drink_count = ComFunc.Check_Read_Number(lv_wave_info_arr[1]);
        this.m_gk_cur_wave_has_Finished_drink_count = 0;
        this.m_gk_cur_wave_diaoluoed_jinbi_count = 0;

        //这个波次能显示的dreink数目
        var cur_wave_drink_count = ComFunc.Check_Read_Number(lv_wave_info_arr[2]);
      
        


        this.m_gk_cur_wave_can_show_drink_id_map = this.Get_Cur_Wave_Can_Show_Drink_ID_Map();
        /*
        var show_drink_id_map = cur_gk_wave_has_jiesuo_drinkid_map.Copy();
        var left_need_add_drink_id_count = cur_wave_drink_count - show_drink_id_map.size();
        this.m_gk_cur_wave_can_show_drink_id_map.clear();

        if(left_need_add_drink_id_count > 0)
        {
            var add_cc = 0;
            for(var tt=prev_gk_jiesuo_drinkid_map.size()-1;tt>=0;tt--)
            {
                var tt_id = prev_gk_jiesuo_drinkid_map.GetKeyByIndex(tt);
                add_cc++;
                show_drink_id_map.putData(tt_id,1);

                if(add_cc >= left_need_add_drink_id_count)
                {
                    break;
                }
            }
        }
        this.m_gk_cur_wave_can_show_drink_id_map = show_drink_id_map;
        */

       

        //当前波次各个能出的饮料id已经出的数目
        this.m_gk_cur_wave_existed_top3_drink_id_count_map.clear();
        this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.clear();

 
   
   
    }
    Init_GK1_First_Center_Wuping_Step2()
    {
        var ff_bottom_cell_types = [1,1]

        this.ReShow_Bottom_Pos_Panzi_Types(2,ff_bottom_cell_types);
        var addc = 150;

        for(var ff=0;ff<this.m_bottom_pos_banzi_info_map.size();ff++)
        {
            var ff_iindex:guaishou_juba_Banzi_Info = this.m_bottom_pos_banzi_info_map.GetKeyByIndex(ff);
         
            var ff_bottom_banzi:guaishou_juba_Banzi_Info = this.m_bottom_pos_banzi_info_map.GetEntryByIndex(ff);
            var ff_node = ff_bottom_banzi.m_node;


            var ff_bottom_pos = this.Get_Bottom_Banzi_Pos_By_Index(ff_iindex);

            ff_node.setPosition(ff_bottom_pos.x + addc,ff_bottom_pos.y);

            var pmove = cc.moveTo(0.1,ff_bottom_pos)
            ff_node.runAction(pmove);
        }
    }
    Init_GK1_First_Center_Wuping_Step1()
    {
        this.Set_Logic_Pos_Jiubei_Type_List([2,3],[1,1])
        this.Set_Logic_Pos_Jiubei_Type_List([3,2],[1]);

        var ff_bottom_cell_types = [1]

        this.ReShow_Bottom_Pos_Panzi_Types(2,ff_bottom_cell_types);

        var addc = 150;

        for(var ff=0;ff<this.m_bottom_pos_banzi_info_map.size();ff++)
        {
            var ff_iindex:guaishou_juba_Banzi_Info = this.m_bottom_pos_banzi_info_map.GetKeyByIndex(ff);
         
            var ff_bottom_banzi:guaishou_juba_Banzi_Info = this.m_bottom_pos_banzi_info_map.GetEntryByIndex(ff);
            var ff_node = ff_bottom_banzi.m_node;


            var ff_bottom_pos = this.Get_Bottom_Banzi_Pos_By_Index(ff_iindex);

            ff_node.setPosition(ff_bottom_pos.x + addc,ff_bottom_pos.y);

            var pmove = cc.moveTo(0.1,ff_bottom_pos)
            ff_node.runAction(pmove);
        }

    }
    Check_Init_Or_Read_Prev_Tiaozhan_mode(out_prev_has_arr)
    {
        this.m_tiaozhan_mode_guest_id = this.m_parent_game.m_tiaozhan_mode_guest_id;

     //   var ren_node = cc.find("tiaozhan_mode/renwu/1/ren",this.m_parent_game_node)
     //   BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("jiubei_xunlian",ren_node,"touxiang/"+this.m_tiaozhan_mode_guest_id,{width:200,height:200})
     out_prev_has_arr[0] = 0;

        var sfilename = this.Get_Save_Game_Ju_Filename();
        var scontent = MyLocalStorge.getItem(sfilename);

        var pobj = null;

        try{
            pobj = JSON.parse(scontent);
        }catch(e)
        {

        }

        if(!pobj)
        {
            this.Init_Tiaozhan()
            return;
        }

        /*
        var tiaozhan_guest_id = pobj.tiaozhan_guest_id;

        if(tiaozhan_guest_id != this.m_tiaozhan_mode_guest_id)
        {
            this.Init_Tiaozhan()
            return;
        }
        */

        out_prev_has_arr[0] = 1;


        this.m_tiaozhan_cur_use_chat_id = ComFunc.Check_Read_Number(pobj.m_tiaozhan_cur_use_chat_id)
        this.m_cur_tiaozhan_wav = ComFunc.Check_Read_Number(pobj.m_cur_tiaozhan_wav)
        this.m_cur_game_jinbi = ComFunc.Check_Read_Number(pobj.m_cur_game_jinbi)
 
        this.m_tiaozhan_total_finished_jiubei_count = ComFunc.Check_Read_Number(pobj.m_tiaozhan_total_finished_jiubei_count)
        this.m_tiaozhan_total_need_finished_jiubei_count = ComFunc.Check_Read_Number(pobj.m_tiaozhan_total_need_finished_jiubei_count)
        this.m_cur_tiaozhan_wav_need_finished_count = ComFunc.Check_Read_Number(pobj.m_cur_tiaozhan_wav_need_finished_count)
        this.m_cur_tiaozhan_wav_has_finished_count = ComFunc.Check_Read_Number(pobj.m_cur_tiaozhan_wav_has_finished_count)
 
        
        this.m_cur_tiaozhan_all_valid_drinkid_list =  pobj.m_cur_tiaozhan_all_valid_drinkid_list;

 
 
        this.Check_Init_GK_Jiubei_Type_Node_Pool(this.m_cur_tiaozhan_all_valid_drinkid_list);

          
        this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map = ComFunc.Serize_Saved_OBJ_Map(pobj.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map)
 
        this.m_bottom_panzi_perci_shumu_count_map = ComFunc.Serize_Saved_OBJ_Map(pobj.m_bottom_panzi_perci_shumu_count_map)
 
       
        var speical_cur_box_info_list = pobj.speical_cur_box_info_list;


        for(var ff=0;ff<speical_cur_box_info_list.length;ff++)
        {
            var jj_info  = speical_cur_box_info_list[ff];


            var jj_cellindex =  jj_info.cellindex;
            var jj_itype =  jj_info.itype;
            var jj_icount =  jj_info.ic;



            var perinfo  =new Juba_Game_Spcieal_Pos_Info();
            perinfo.itype = jj_itype;
            perinfo.icount = jj_icount;

        
            this.m_gk_pos_index_speical_cur_box_info_map.putData(jj_cellindex,perinfo)
        }


        var bottom_banzi_info_list = pobj.bottom_banzi_info_list;



        for(var ff=0;ff<bottom_banzi_info_list.length;ff++)
        {
            var  kk_info  = bottom_banzi_info_list[ff];

            var  kk_pos  = kk_info.pos;
            var  kk_jiubei_list = kk_info.jiubei_list;


            if(kk_pos < 1 || kk_pos > 3)
            {
                continue;
            }

            if(!kk_jiubei_list || !kk_jiubei_list.length)
            {
                continue;
            }

            this.ReShow_Bottom_Pos_Panzi_Types(kk_pos,kk_jiubei_list);

        }
 
 
  
        this.m_gk_cur_wave_can_show_drink_id_map = ComFunc.Serize_Saved_OBJ_Map(pobj.m_gk_cur_wave_can_show_drink_id_map)
 
 
      
     
  


        var all_valid_bk_pos_list = [];
        var all_display_bk_pos_list = [];

        for(var x =1;x<=4;x++)
        {
            for(var y =1;y<=6;y++)
            {
              
                all_display_bk_pos_list.push( [x,y]);

                var ff_cell_pos = [x,y];
                var icellindex = this.Translate_Logic_Pos_To_Cell_Index(ff_cell_pos);

                if(this.m_gk_pos_index_speical_cur_box_info_map.hasKey(icellindex))
                {

                }else{
                    all_valid_bk_pos_list.push(ff_cell_pos);
                }
                
            }
        }

        this.m_center_all_displayed_bk_pos_list = all_display_bk_pos_list;
        this.m_center_valid_bk_pos_list = all_valid_bk_pos_list;

        
        var center_banzi_info_list = pobj.center_banzi_info_list;

        for(var ff=0;ff<center_banzi_info_list.length;ff++)
        {
            var hh_info  = center_banzi_info_list[ff];

        
            var hh_src_logicpos = hh_info.logicpos;
            var hh_jiubei_list = hh_info.jiubei_list;

            var hh_src_logic_x = ComFunc.Check_Read_Number(hh_src_logicpos[0])
            var hh_src_logic_y = ComFunc.Check_Read_Number(hh_src_logicpos[1])


            var center_logic_pos = [hh_src_logic_x,hh_src_logic_y]
            
        
            this.Set_Logic_Pos_Jiubei_Type_List(center_logic_pos,hh_jiubei_list)
        }
    
      

        if(this.m_bottom_pos_banzi_info_map.size() == 0)
        {
            this.Recreate_Bottom_Pabzi();
        }
         

 

        var select_bk_color = this.m_parent_game.select_bk_color;

        var selectbk_node = cc.find("center/selectbk",this.m_parent_game_node)
        

        var pnode = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("select_bk_color",select_bk_color)
         selectbk_node.addChild(pnode,20);


         this.m_select_show_gezi_bk_green_node = selectbk_node;
         selectbk_node.active = false;

        
         var top_drink_info_node_preab = this.m_parent_game.top_drink_info_node_preab;
         var info_ndoe = cc.find("tiaozhan_mode/wuping/info",this.m_parent_game_node)

         var tiaozhan_top_drink_info_list = pobj.tiaozhan_top_drink_info_list;

         if(tiaozhan_top_drink_info_list.length == 0)
         {

            this.Recreate_Tiaozhan_Top_Drink_Info_On_Change_Wave();
         }
         else{
            for(var ff=0;ff<this.m_tiaozhan_top_drink_info_list.length;ff++)
            {
                var ff_info1:Per_Tiaozhan_Top_Drink_Info =  this.m_tiaozhan_top_drink_info_list[ff];
                var pndoe1 = ff_info1.m_node;
    
                if(pndoe1)
                {
                    NodeComPoolUtils.GetInstance().putANode("top_drink_info_node",pndoe1)
                }
            }
            this.m_tiaozhan_top_drink_info_list = [];


            for(var ff=0;ff< tiaozhan_top_drink_info_list.length;ff++)
            {
                var ff_info  = tiaozhan_top_drink_info_list[ff];
                if(!ff_info)
                {
                    continue;
                }
                var ff_per_tiaozhan_drin_data = Per_Tiaozhan_Top_Drink_Info.From_SaveInfo(ff_info);


                var ff_drinkid = ff_per_tiaozhan_drin_data.m_drink_id;
                var ff_exist = ff_per_tiaozhan_drin_data.m_existed;

                var pndoe2 = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("top_drink_info_node",top_drink_info_node_preab)
                info_ndoe.addChild(pndoe2,20);
               

                var jiubei_wuping_ndoe = pndoe2.getChildByName("wuping");

                var  gs_pre_v_info2 = (jiubei_wuping_ndoe as any).guaishou_node_info ;
    
                if(gs_pre_v_info2 && gs_pre_v_info2.length)
                {
                    var gs_prev_ndoe2 = gs_pre_v_info2[0];
                    var gs_prev_type2 = gs_pre_v_info2[1];
                    NodeComPoolUtils.GetInstance().putANode("guaishou_jiubei_Preab_"+gs_prev_type2,gs_prev_ndoe2);
                    (jiubei_wuping_ndoe as any).guaishou_node_info = null;
                }
    
    
                var ff_preab_name = "guaishou_jiubei_Preab_"+ff_drinkid;
                var ff_preab = juba_Game_Mng.GetInstance().Get_Preab_By_Name(ff_preab_name)
                var ff_ndoe = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node(ff_preab_name,ff_preab);
                jiubei_wuping_ndoe.addChild(ff_ndoe,10);
                ff_ndoe.active = true;
                ff_ndoe.scale = 1;
             

    
                (jiubei_wuping_ndoe as any).guaishou_node_info = [ff_ndoe,ff_drinkid];
    
                var w_node = ff_ndoe.getChildByName("w");
    
                    if(w_node)
                    {
                        var sanimname = juba_Config_Mng.GetInstance().Get_Guaishou_Type_Anim_Name(ff_drinkid,1);
                        var sp_com = w_node.getComponent(sp.Skeleton);
            
                        if(sp_com)
                        {
                            sp_com.timeScale = 0.5;
                            sp_com.setAnimation(0,sanimname,true)
            
                        }
                     
                    }
             
    
    
             //   var jiubei_icon_ndoe = pndoe2.getChildByName("icon")
              //  BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("jiubei_xunlian",jiubei_icon_ndoe,"drink/"+ff_drinkid,{width:60,height:60})
               
              
                var jiubei_gou_ndoe = pndoe2.getChildByName("gou") 
                ff_per_tiaozhan_drin_data.m_node = pndoe2;
                ff_per_tiaozhan_drin_data.Set_Existed(ff_exist);
                this.m_tiaozhan_top_drink_info_list.push(ff_per_tiaozhan_drin_data);
            }

            var iline = 1;
            if(this.m_tiaozhan_top_drink_info_list.length > 8)
            {
                iline = 2;
            }
    
            var wuping_bk_ndoe = cc.find("tiaozhan_mode/wuping/bk",this.m_parent_game_node)
    
            if(iline == 2)
            {
                wuping_bk_ndoe.height = 170;
            }else
            {
                wuping_bk_ndoe.height = 110;
            }
    
    
            for(var tt=0;tt<this.m_tiaozhan_top_drink_info_list.length;tt++)
            {
                var tt_pos =  this.Get_Top_Drink_Node_Pos(tt,this.m_tiaozhan_top_drink_info_list.length);
                var pdrininfo:Per_Tiaozhan_Top_Drink_Info =  this.m_tiaozhan_top_drink_info_list[tt];
    
                var tt_exist_pos = new cc.Vec2(tt_pos.x+1000,tt_pos.y);
                pdrininfo.SetPosition(tt_exist_pos);
    
    
                var tt_node = pdrininfo.m_node;
    
                if(tt_node)
                {
                    var paction = cc.moveTo(0.2,tt_pos);
                    tt_node.runAction(paction);
                }
               
            }
   
            
         }


       
 
        
        this.Refresh_Special_Node_Item_Node();
  

        this.m_b_inited = 1;
     
       
        
        
    }
    Check_Init_Or_Read_Prev(curgk)
    {
        var sfilename = this.Get_Save_Game_Ju_Filename();
        var scontent = MyLocalStorge.getItem(sfilename);

        var pobj = null;

        try{
            pobj = JSON.parse(scontent);
        }catch(e)
        {

        }

        if(!pobj)
        {
            this.Init(curgk)
            return;
        }

        var igk = pobj.igk;

        if(igk != curgk)
        {
            this.Init(curgk)
            return;
        }

        //读取之前的数据
        this.m_jiba_lv = curgk;
        this.m_cur_lv_wave = ComFunc.Check_Read_Number(pobj.m_cur_lv_wave);
 
        this.m_cur_gk_all_can_show_game_chat_guest_id_list = juba_Game_Mng.GetInstance().Get_Gk_Cur_Can_Show_Game_Chat_Guest_ID_List(curgk)
        var max_need_c = juba_Config_Mng.GetInstance().Get_Gk_Finish_Need_Jiubei( this.m_jiba_lv)

        var guest_id_list = juba_Config_Mng.GetInstance().Get_All_Can_Show_Guest_ID_List_In_GK(curgk);
        this.m_cur_lv_all_valid_guest_id_list = guest_id_list;
        this.m_cur_lv_wave_valid_guest_id_list = juba_Config_Mng.GetInstance().Get_All_Can_Show_Guest_ID_List_In_GK_Wave(curgk,this.m_cur_lv_wave);

        this.m_cur_lv_all_valid_guest_id_list.sort((a,b)=>
        {
            return Math.random()-0.5;

        })


        this.m_last_show_game_guest_id = ComFunc.Check_Read_Number(pobj.m_last_show_game_guest_id);
        this.m_last_show_game_guest_valid_index = ComFunc.Check_Read_Number(pobj.m_last_show_game_guest_valid_index);
 

        this.m_top3_pos_unlocked_map = ComFunc.Serize_Saved_OBJ_Map(pobj.m_top3_pos_unlocked_map)
        this.m_top3_pos_guest_id_map = ComFunc.Serize_Saved_OBJ_Map(pobj.m_top3_pos_guest_id_map)

        this.m_top3_pos_left_need_finish_drink_count_map = ComFunc.Serize_Saved_OBJ_Map(pobj.m_top3_pos_left_need_finish_drink_count_map)
        this.m_top3_pos_need_finish_drink_id_map = ComFunc.Serize_Saved_OBJ_Map(pobj.m_top3_pos_need_finish_drink_id_map)
        this.m_top_guest_id_exist_count_map = ComFunc.Serize_Saved_OBJ_Map(pobj.m_top_guest_id_exist_count_map)
 

        this.m_gk_finished_guest_jiubei_count = ComFunc.Check_Read_Number(pobj.m_gk_finished_guest_jiubei_count);
        this.m_cur_game_jinbi = ComFunc.Check_Read_Number(pobj.m_cur_game_jinbi);
  
 
        this.m_gk_cur_wave_existed_top3_drink_id_count_map = ComFunc.Serize_Saved_OBJ_Map(pobj.m_gk_cur_wave_existed_top3_drink_id_count_map)
        this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map = ComFunc.Serize_Saved_OBJ_Map(pobj.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map)
 
        this.m_cur_gk_show_new_drinkid_map = ComFunc.Serize_Saved_OBJ_Map(pobj.m_cur_gk_show_new_drinkid_map)
     
         

        this.m_bottom_panzi_perci_shumu_count_map = ComFunc.Serize_Saved_OBJ_Map(pobj.m_bottom_panzi_perci_shumu_count_map)
 
        
        var center_logic_pos_has_diaoluo_jinbi_list = pobj.center_logic_pos_has_diaoluo_jinbi_list;

        for(var ff=0;ff<center_logic_pos_has_diaoluo_jinbi_list.length;ff++)
        {
            var ff_info  = center_logic_pos_has_diaoluo_jinbi_list[ff];

            var ff_x = ff_info.x;
            var ff_y = ff_info.y;

            var ff_logic_pos=  [ff_x,ff_y];
            this.m_center_logic_pos_has_diaoluo_jinbi_map.putData(ff_logic_pos,1)
            
        }
        
        var speical_cur_box_info_list = pobj.speical_cur_box_info_list;


        for(var ff=0;ff<speical_cur_box_info_list.length;ff++)
        {
            var jj_info  = speical_cur_box_info_list[ff];


            var jj_cellindex =  jj_info.cellindex;
            var jj_itype =  jj_info.itype;
            var jj_icount =  jj_info.ic;



            var perinfo  =new Juba_Game_Spcieal_Pos_Info();
            perinfo.itype = jj_itype;
            perinfo.icount = jj_icount;

        
            this.m_gk_pos_index_speical_cur_box_info_map.putData(jj_cellindex,perinfo)
        }


        var bottom_banzi_info_list = pobj.bottom_banzi_info_list;



        for(var ff=0;ff<bottom_banzi_info_list.length;ff++)
        {
            var  kk_info  = bottom_banzi_info_list[ff];

            var  kk_pos  = kk_info.pos;
            var  kk_jiubei_list = kk_info.jiubei_list;


            if(kk_pos < 1 || kk_pos > 3)
            {
                continue;
            }

            if(!kk_jiubei_list || !kk_jiubei_list.length)
            {
                continue;
            }

            this.ReShow_Bottom_Pos_Panzi_Types(kk_pos,kk_jiubei_list);

        }
 


  

        var lv_wave_info_arr = juba_Config_Mng.GetInstance().Fing_GK_Wave_Info(this.m_jiba_lv,this.m_cur_lv_wave);
        var wave_need_finish_drink_c = lv_wave_info_arr[3];
        if(!wave_need_finish_drink_c)
        {
            wave_need_finish_drink_c = 1;
        }

      
        //得到当前波次出现的饮料

        //当前波次能出的饮料id
 
      //  var prev_gk_jiesuo_drinkid_map = juba_Config_Mng.GetInstance().Get_Prev_GK_Jiesuo_Drink_Id_Map(curgk)

       // var cur_gk_wave_has_jiesuo_drinkid_map = juba_Config_Mng.GetInstance().Get_In_GK_Wave_Has_Jiesuo_Drink_Id_Map(curgk,this.m_cur_lv_wave)
       
      
        this.m_gk_cur_wave_Need_Finished_drink_count = ComFunc.Check_Read_Number(lv_wave_info_arr[1]);
        this.m_gk_cur_wave_has_Finished_drink_count =  ComFunc.Check_Read_Number(pobj.m_gk_cur_wave_has_Finished_drink_count);
        this.m_gk_cur_wave_diaoluoed_jinbi_count = ComFunc.Check_Read_Number(pobj.m_gk_cur_wave_diaoluoed_jinbi_count);

        var cur_wave_drink_count = ComFunc.Check_Read_Number(lv_wave_info_arr[2]);
      
      
        /*
        var show_drink_id_map = cur_gk_wave_has_jiesuo_drinkid_map.Copy();
        var left_need_add_drink_id_count = cur_wave_drink_count - show_drink_id_map.size();

        this.m_gk_cur_wave_can_show_drink_id_map.clear();
 
        if(left_need_add_drink_id_count > 0)
        {
            var add_cc = 0;
            for(var tt=prev_gk_jiesuo_drinkid_map.size()-1;tt>=0;tt--)
            {
                var tt_id = prev_gk_jiesuo_drinkid_map.GetKeyByIndex(tt);
                add_cc++;
                show_drink_id_map.putData(tt_id,1);

                if(add_cc >= left_need_add_drink_id_count)
                {
                    break;
                }
            }
        }
 
        this.m_gk_cur_wave_can_show_drink_id_map = show_drink_id_map;

        */


        this.m_gk_cur_wave_can_show_drink_id_map = this.Get_Cur_Wave_Can_Show_Drink_ID_Map();

     
        var all_in_gk_can_show_jiubei_type_list = juba_Config_Mng.GetInstance().Guaishou_Get_GK_Seq_Show_Drink_Id_List(this.m_jiba_lv)

        /*
        for(var ff=0;ff<cur_gk_wave_has_jiesuo_drinkid_map.size();ff++)
        {
            var ff_drinkid = cur_gk_wave_has_jiesuo_drinkid_map.GetKeyByIndex(ff);
            all_in_gk_can_show_jiubei_type_list.push(ff_drinkid);
        }

        var iaddcc2 = 6 - all_in_gk_can_show_jiubei_type_list.length;
        for(var tt=prev_gk_jiesuo_drinkid_map.size()-1;tt>=0;tt--)
        {
            var tt_id = prev_gk_jiesuo_drinkid_map.GetKeyByIndex(tt);
            if(all_in_gk_can_show_jiubei_type_list.length >= 6)
            {
                break;
            }
            all_in_gk_can_show_jiubei_type_list.push(tt_id)
        }
        */
 
        this.Check_Init_GK_Jiubei_Type_Node_Pool(all_in_gk_can_show_jiubei_type_list);
      
     
  


        var all_valid_bk_pos_list = [];
        var all_display_bk_pos_list = [];

        for(var x =1;x<=4;x++)
        {
            for(var y =1;y<=6;y++)
            {
              
                all_display_bk_pos_list.push( [x,y]);

                var ff_cell_pos = [x,y];
                var icellindex = this.Translate_Logic_Pos_To_Cell_Index(ff_cell_pos);

                if(this.m_gk_pos_index_speical_cur_box_info_map.hasKey(icellindex))
                {

                }else{
                    all_valid_bk_pos_list.push(ff_cell_pos);
                }
                
            }
        }

        this.m_center_all_displayed_bk_pos_list = all_display_bk_pos_list;
        this.m_center_valid_bk_pos_list = all_valid_bk_pos_list;

        
        var center_banzi_info_list = pobj.center_banzi_info_list;

        for(var ff=0;ff<center_banzi_info_list.length;ff++)
        {
            var hh_info  = center_banzi_info_list[ff];

        
            var hh_src_logicpos = hh_info.logicpos;
            var hh_jiubei_list = hh_info.jiubei_list;

            var hh_src_logic_x = ComFunc.Check_Read_Number(hh_src_logicpos[0])
            var hh_src_logic_y = ComFunc.Check_Read_Number(hh_src_logicpos[1])


            var center_logic_pos = [hh_src_logic_x,hh_src_logic_y]
            
        
            this.Set_Logic_Pos_Jiubei_Type_List(center_logic_pos,hh_jiubei_list)
        }
    
      

        if(this.m_bottom_pos_banzi_info_map.size() == 0)
        {
            this.Recreate_Bottom_Pabzi();
        }
         

 

        var select_bk_color = this.m_parent_game.select_bk_color;

        var selectbk_node = cc.find("center/selectbk",this.m_parent_game_node)
        

        var pnode = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("select_bk_color",select_bk_color)
         selectbk_node.addChild(pnode,20);


         this.m_select_show_gezi_bk_green_node = selectbk_node;
         selectbk_node.active = false;

        

        this.Refresh_Logci_Pos_Diaoluo_Xianjing_Node();
        this.Refresh_Special_Node_Item_Node();

        this.Refresh_Top_Guest_Info();


       

        this.m_b_inited = 1;
    }

    Get_GK_Wave_Jiesuo_DrinkID( jiba_lv, cur_lv_wave)
    {
  
        var all_in_gk_can_show_jiubei_type_list = juba_Config_Mng.GetInstance().Guaishou_Get_GK_Seq_Show_Drink_Id_List(this.m_jiba_lv)
        var lv_wave_info_arr = juba_Config_Mng.GetInstance().Fing_GK_Wave_Info(jiba_lv, cur_lv_wave);
        var cur_wave_drink_count = ComFunc.Check_Read_Number(lv_wave_info_arr[2]);
      
        if(cur_wave_drink_count <= 3)
        {
            return 0;
        }
        if(cur_wave_drink_count > all_in_gk_can_show_jiubei_type_list.length)
        {
            return 0;
        }

        var last_drinkid = all_in_gk_can_show_jiubei_type_list[cur_wave_drink_count-1]

        return last_drinkid;
        
       // var cur_wave_jiesuo_drinkid = juba_Config_Mng.GetInstance().Get_GK_Wave_Jiesuo_DrinkID(jiba_lv, cur_lv_wave)

       // return cur_wave_jiesuo_drinkid;
    }
    Get_Tiaozhan_Wave_Show_Drink_Count( tiaozhan_wav)
    {
        if(tiaozhan_wav == 1)
        {
            return 3;
        }

        if(tiaozhan_wav == 2)
        {
            return 4;
        }

        if(tiaozhan_wav == 3)
        {
            return 5;
        }

        return 6;

    }

    Guaishou_Get_Random_Tiaozhan_DrinkID_List()
    {

        return juba_Config_Mng.GetInstance().Guaishou_Get_Random_Tiaozhan_DrinkID_List()

        /*
        var irandgk = 2 + Math.floor(Math.random()*8);

 
        var prev_gk_jiesuo_drinkid_map = juba_Config_Mng.GetInstance().Get_Prev_GK_Jiesuo_Drink_Id_Map(irandgk);
        if(prev_gk_jiesuo_drinkid_map.size() < 6)
        {
            prev_gk_jiesuo_drinkid_map = juba_Config_Mng.GetInstance().Get_Prev_GK_Jiesuo_Drink_Id_Map(10);
        }

        var startindex=  prev_gk_jiesuo_drinkid_map.size()-6;

        var valid_drinkid_list = [];
        for(var ff= startindex;ff<prev_gk_jiesuo_drinkid_map.size();ff++)
        {
            var ff_deinkid = prev_gk_jiesuo_drinkid_map.GetKeyByIndex(ff);
            valid_drinkid_list.push(ff_deinkid);
        }

        return valid_drinkid_list;
        */
    }
    Get_Tiaozhan_Wav_Need_Finished_Jiubei_Count(itiaozhan_wav)
    { 
         


        if(itiaozhan_wav == 1)
        {
            return 6;
        }

        if(itiaozhan_wav == 2)
        {
            return 8;
        }
        if(itiaozhan_wav == 3)
        {
            return 12;
        }
        return 16;
    }
    Generate_Tiaozhan_Top_DrinkID_List(show_drink_id_map, cur_tiaozhan_wav_need_finished_count )
    {
        var all_drink_id_list =[];

        var left_c = cur_tiaozhan_wav_need_finished_count;

        while(left_c > 0)
        {
            if(left_c >= show_drink_id_map.size())
            {
                left_c -= show_drink_id_map.size();

                for(var tt=0;tt<show_drink_id_map.size();tt++)
                {
                    var tt_drinkid =  show_drink_id_map.GetKeyByIndex(tt);
                    all_drink_id_list.push(tt_drinkid);
                }
            }
            else{

                var irand1 = Math.floor(Math.random()*show_drink_id_map.size());
                var rand_drinkid = show_drink_id_map.GetKeyByIndex(irand1);
                all_drink_id_list.push(rand_drinkid);
                left_c--;
            }
        }

        all_drink_id_list.sort((a,b)=>
        {
            return 0.5 - Math.random();
        })

        return all_drink_id_list;

    }
    On_Tioazhan_Wave_Change()
    {
        this.m_cur_tiaozhan_wav_need_finished_count = this.Get_Tiaozhan_Wav_Need_Finished_Jiubei_Count(this.m_cur_tiaozhan_wav);
        this.m_cur_tiaozhan_wav_has_finished_count = 0;
        this.m_gk_cur_wave_can_show_drink_id_map.clear();

        this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.clear();

        var cur_wave_drink_count = this.Get_Tiaozhan_Wave_Show_Drink_Count(this.m_cur_tiaozhan_wav);
      
        var show_drink_id_list = this.m_cur_tiaozhan_all_valid_drinkid_list.slice(0,cur_wave_drink_count)

        var show_drink_id_map = new WMap();
 
        for(var ff=0;ff<show_drink_id_list.length;ff++)
        {
            var ff_drinkid = show_drink_id_list[ff];
            show_drink_id_map.putData(ff_drinkid,1)   
        }

         
        this.m_gk_cur_wave_can_show_drink_id_map = show_drink_id_map;


        this.Refresh_Special_Node_Item_Node();
 
    }

    Check_Init_GK_Jiubei_Type_Node_Pool( valid_drinkid_list)
    {

        /*
        var jiubei_preab = juba_Game_Mng.GetInstance().m_jiubei_preab ;
        for(var ff=0;ff<valid_drinkid_list.length;ff++)
        {
            var ff_drink_type = valid_drinkid_list[ff];
 
            for(var tt=0;tt<6;tt++)
            {
                var pnode=  cc.instantiate(jiubei_preab);
                NodeComPoolUtils.GetInstance().putANode("jiubei_preab_"+ff_drink_type,pnode)
            }
            
        }
        */
    }
    Init_Tiaozhan()
    {
        this.m_b_inited = 1;

        this.m_tiaozhan_total_finished_jiubei_count = 0;
        this.m_tiaozhan_total_need_finished_jiubei_count = 58;
        this.m_cur_tiaozhan_wav = 1;
        this.m_cur_tiaozhan_wav_need_finished_count = this.Get_Tiaozhan_Wav_Need_Finished_Jiubei_Count(this.m_cur_tiaozhan_wav);
        this.m_cur_tiaozhan_wav_has_finished_count = 0;

        this.m_tiaozhan_cur_use_chat_id = juba_Config_Mng.GetInstance().Get_Tiaozhan_Cur_Chat_ID();
  

        

        this.m_cur_tiaozhan_all_valid_drinkid_list = this.Guaishou_Get_Random_Tiaozhan_DrinkID_List();

        this.Check_Init_GK_Jiubei_Type_Node_Pool(this.m_cur_tiaozhan_all_valid_drinkid_list);
      
        //得到当前波次出现的饮料

        //当前波次能出的饮料id
 
      //  var curgk = 10;
      //  var prev_gk_jiesuo_drinkid_map = juba_Config_Mng.GetInstance().Get_Prev_GK_Jiesuo_Drink_Id_Map(curgk)

        
        this.m_gk_cur_wave_can_show_drink_id_map.clear();

  

        var cur_wave_drink_count = this.Get_Tiaozhan_Wave_Show_Drink_Count(this.m_cur_tiaozhan_wav);
      
        var show_drink_id_list = this.m_cur_tiaozhan_all_valid_drinkid_list.slice(0,cur_wave_drink_count)

        var show_drink_id_map = new WMap();
 
        for(var ff=0;ff<show_drink_id_list.length;ff++)
        {
            var ff_drinkid = show_drink_id_list[ff];
            show_drink_id_map.putData(ff_drinkid,1)   
        }

         
        this.m_gk_cur_wave_can_show_drink_id_map = show_drink_id_map;


     
        

        //当前波次各个能出的饮料id已经出的数目 
        this.m_gk_cur_wave_existed_top3_drink_id_count_map.clear();
        this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.clear();


        this.m_bottom_panzi_perci_shumu_count_map.clear();
 

 
        var gk_box_orignal_data = juba_Config_Mng.GetInstance().Get_Tiaozhan_Mode_Rand_Box_Data();
        var gk_box_data = this.Parse_GK_Box_Data(gk_box_orignal_data)

        this.m_gk_pos_index_speical_init_box_info_map.clear();
        this.m_gk_pos_index_speical_cur_box_info_map.clear();

        for(var ff=0;ff<gk_box_data.length;ff++)
        {
            var ff_d = gk_box_data[ff];
            this.m_gk_pos_index_speical_init_box_info_map.putData(ff,ff_d);

            if(ff_d == 0)
            {
                continue;
            }

            if(ff_d == -1)
            {
                var perinfo  =new Juba_Game_Spcieal_Pos_Info();
                perinfo.itype = 1;
                perinfo.icount = 1;

               this.m_gk_pos_index_speical_cur_box_info_map.putData(ff,perinfo)
            }
            else if(ff_d  > 0)
            {
                var perinfo  =new Juba_Game_Spcieal_Pos_Info();
                perinfo.itype = 3;
                perinfo.icount = ff_d;

               this.m_gk_pos_index_speical_cur_box_info_map.putData(ff,perinfo)
            }   
            else if(ff_d   < -1 && ff_d >= -4)
            {
                var perinfo  =new Juba_Game_Spcieal_Pos_Info();
                perinfo.itype = 2;
                perinfo.icount = Math.abs(ff_d);

               this.m_gk_pos_index_speical_cur_box_info_map.putData(ff,perinfo)
            }
        }
    
 



        var all_valid_bk_pos_list = [];
        var all_display_bk_pos_list = [];

        for(var x =1;x<=4;x++)
        {
            for(var y =1;y<=6;y++)
            {
              
                all_display_bk_pos_list.push( [x,y]);

                var ff_cell_pos = [x,y];
                var icellindex = this.Translate_Logic_Pos_To_Cell_Index(ff_cell_pos);

                if(this.m_gk_pos_index_speical_cur_box_info_map.hasKey(icellindex))
                {

                }else{
                    all_valid_bk_pos_list.push(ff_cell_pos);
                }
                
            }
        }

        this.m_center_all_displayed_bk_pos_list = all_display_bk_pos_list;
        this.m_center_valid_bk_pos_list = all_valid_bk_pos_list;


        /*
        if(this.m_b_in_first_gk_yd)
        {

        }else{
            this.Recreate_Bottom_Pabzi();
        }
        */
   

        var select_bk_color = this.m_parent_game.select_bk_color;

        var selectbk_node = cc.find("center/selectbk",this.m_parent_game_node)
        

        var pnode = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("select_bk_color",select_bk_color)
         selectbk_node.addChild(pnode,20);


         this.m_select_show_gezi_bk_green_node = selectbk_node;
         selectbk_node.active = false;

        for(var ff=0;ff<all_valid_bk_pos_list.length;ff++)
        {
            var ff_cellpos=  all_valid_bk_pos_list[ff];

          //  var pnode = Node_Pool_Utils.GetInstance().Get_Prab_Name_Node("select_bk_color",select_bk_color)
           //  selectbk_node.addChild(pnode,20);

          //  var ff_center_real_pos = this.Get_Logic_Pos_Center_Real_World_Pos(ff_logicx,ff_logicy);
          //  pnode.setPosition(ff_center_real_pos)
        }


        
       

        this.Refresh_Special_Node_Item_Node();

        this.Refresh_Top_Guest_Info();

        this.On_Tiaozhan_New_Wave_Start_Chat();
    }

    On_Tioazhan_Wave_End(cb)
    {
    
        var cur_wave = this.m_cur_tiaozhan_wav + 1;
      
        var tiaozhan_msg_list = juba_Config_Mng.GetInstance().Get_Tiaozhan_Wave_Start_Chat_Msg(this.m_tiaozhan_cur_use_chat_id,cur_wave);

        var self = this;
        if(tiaozhan_msg_list && tiaozhan_msg_list.length)
        {
         
            this.m_parent_game.Show_Tiaozhan_New_Wave_Chat(tiaozhan_msg_list, ()=>
            {
                cb();
            
            })
        }else{
            cb();
        }

 

    }
    On_Tiaozhan_New_Wave_Chat_End()
    {
        this.Recreate_Tiaozhan_Top_Drink_Info_On_Change_Wave();
        this.Recreate_Bottom_Pabzi();
    }
    On_Tiaozhan_New_Wave_Start_Chat()
    {
        var icurwave=  this.m_cur_tiaozhan_wav;
        var tiaozhan_msg_list = juba_Config_Mng.GetInstance().Get_Tiaozhan_Wave_Start_Chat_Msg(this.m_tiaozhan_cur_use_chat_id,icurwave);

        if(!tiaozhan_msg_list)
        {
            this.On_Tiaozhan_New_Wave_Chat_End()
            return;
        }


        if(!tiaozhan_msg_list.length)
        {
            this.On_Tiaozhan_New_Wave_Chat_End()
            return;
        }

        var self = this;
        this.m_parent_game.Show_Tiaozhan_New_Wave_Chat(tiaozhan_msg_list, ()=>
        {
            self.On_Tiaozhan_New_Wave_Chat_End()
        
        })
    }
    Get_Top_Drink_Node_Pos(tt,iallcount)
    {
        var iline = 1;
        if(iallcount > 8)
        {
            iline = 2;
        }

        var perlincoutn = Math.ceil(iallcount/2);

        if(iline == 1)
        {
            var ileft_startx = -1*((iallcount-1)/2)*70;

            var ix = ileft_startx + 70*tt;

            return new cc.Vec2(ix,-31);
        }

        var ix2 = tt;
        var iy2 = 0;

        if(tt >= perlincoutn)
        {
              ix2 = tt - perlincoutn;
              iy2 = 1;
        }

        var ileft_startx = -1*((perlincoutn-1)/2)*70;

        var ix = ileft_startx + 70*ix2;

        return new cc.Vec2(ix,-70 + 80*iy2 + 10);


    }
    Recreate_Tiaozhan_Top_Drink_Info_On_Change_Wave()
    {
        for(var ff=0;ff<this.m_tiaozhan_top_drink_info_list.length;ff++)
        {
            var ff_info:Per_Tiaozhan_Top_Drink_Info =  this.m_tiaozhan_top_drink_info_list[ff];
            var pndoe = ff_info.m_node;

            if(pndoe)
            {
                var jiubei_wuping_ndoe1 = pndoe.getChildByName("wuping");
                var  gs_pre_v_info = (jiubei_wuping_ndoe1 as any).guaishou_node_info ;

                if(gs_pre_v_info && gs_pre_v_info.length)
                {
                    var gs_prev_ndoe = gs_pre_v_info[0];
                    var gs_prev_type = gs_pre_v_info[1];
                    NodeComPoolUtils.GetInstance().putANode("guaishou_jiubei_Preab_"+gs_prev_type,gs_prev_ndoe);
                    (jiubei_wuping_ndoe1 as any).guaishou_node_info = null;
                }

                NodeComPoolUtils.GetInstance().putANode("top_drink_info_node",pndoe)
            }
            
        }

        this.m_tiaozhan_top_drink_info_list = [];

        var top_drink_info_node_preab = this.m_parent_game.top_drink_info_node_preab;

        var all_need_drink_id_list = this.Generate_Tiaozhan_Top_DrinkID_List(this.m_gk_cur_wave_can_show_drink_id_map,this.m_cur_tiaozhan_wav_need_finished_count );

        var info_ndoe = cc.find("tiaozhan_mode/wuping/info",this.m_parent_game_node)

        
        for(var ff=0;ff<all_need_drink_id_list.length;ff++)
        {
            var ff_drinkid = all_need_drink_id_list[ff];

            var pdrininfo =  new Per_Tiaozhan_Top_Drink_Info();
            pdrininfo.m_drink_id = ff_drinkid;
         
            pdrininfo.m_cur_index = ff+1;

            var pndoe2 = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("top_drink_info_node",top_drink_info_node_preab)
            info_ndoe.addChild(pndoe2,20);


          //  var jiubei_icon_ndoe = pndoe2.getChildByName("icon")
         //   BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("jiubei_xunlian",jiubei_icon_ndoe,"drink/"+ff_drinkid,{width:60,height:60})
            var jiubei_wuping_ndoe = pndoe2.getChildByName("wuping");

            var  gs_pre_v_info2 = (jiubei_wuping_ndoe as any).guaishou_node_info ;

            if(gs_pre_v_info2 && gs_pre_v_info2.length)
            {
                var gs_prev_ndoe2 = gs_pre_v_info2[0];
                var gs_prev_type2 = gs_pre_v_info2[1];
                NodeComPoolUtils.GetInstance().putANode("guaishou_jiubei_Preab_"+gs_prev_type2,gs_prev_ndoe2);
                (jiubei_wuping_ndoe as any).guaishou_node_info = null;
            }


            var ff_preab_name = "guaishou_jiubei_Preab_"+ff_drinkid;
            var ff_preab = juba_Game_Mng.GetInstance().Get_Preab_By_Name(ff_preab_name)
            var ff_ndoe = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node(ff_preab_name,ff_preab);
            jiubei_wuping_ndoe.addChild(ff_ndoe,10);
            ff_ndoe.active = true; 
            ff_ndoe.scale = 1;
         

            ff_ndoe.setPosition(0,0);
            (jiubei_wuping_ndoe as any).guaishou_node_info = [ff_ndoe,ff_drinkid];

            var w_node = ff_ndoe.getChildByName("w");

                if(w_node)
                {
                    var sanimname = juba_Config_Mng.GetInstance().Get_Guaishou_Type_Anim_Name(ff_drinkid,1);
                    var sp_com = w_node.getComponent(sp.Skeleton);
        
                    if(sp_com)
                    {
                        sp_com.timeScale = 0.5;
                        sp_com.setAnimation(0,sanimname,true)
        
                    }
                 
                }
         
            var jiubei_gou_ndoe = pndoe2.getChildByName("gou")
            jiubei_gou_ndoe.active = pdrininfo.m_existed ? true :false;
            pdrininfo.m_node = pndoe2;
            pdrininfo.Set_Existed(0);
            this.m_tiaozhan_top_drink_info_list.push(pdrininfo);
        }

        var iline = 1;
        if(all_need_drink_id_list.length > 8)
        {
            iline = 2;
        }

        var wuping_bk_ndoe = cc.find("tiaozhan_mode/wuping/bk",this.m_parent_game_node)

        if(iline == 2)
        {
            wuping_bk_ndoe.height = 170;
        }else
        {
            wuping_bk_ndoe.height = 110;
        }


        for(var tt=0;tt<this.m_tiaozhan_top_drink_info_list.length;tt++)
        {
            var tt_pos =  this.Get_Top_Drink_Node_Pos(tt,this.m_tiaozhan_top_drink_info_list.length);
            var pdrininfo:Per_Tiaozhan_Top_Drink_Info =  this.m_tiaozhan_top_drink_info_list[tt];

            var tt_exist_pos = new cc.Vec2(tt_pos.x+1000,tt_pos.y);
            pdrininfo.SetPosition(tt_exist_pos);


            var tt_node = pdrininfo.m_node;

            if(tt_node)
            {
                var paction = cc.moveTo(0.2,tt_pos);
                tt_node.runAction(paction);
            }
          
        }
        
    }
    Init(  curgk)
    {
        this.m_jiba_lv = curgk;
        this.m_cur_lv_wave = 1;

        this.m_b_inited = 1;

        this.m_cur_gk_all_can_show_game_chat_guest_id_list = juba_Game_Mng.GetInstance().Get_Gk_Cur_Can_Show_Game_Chat_Guest_ID_List(curgk)
        var max_need_c = juba_Config_Mng.GetInstance().Get_Gk_Finish_Need_Jiubei( this.m_jiba_lv)

        var guest_id_list = juba_Config_Mng.GetInstance().Get_All_Can_Show_Guest_ID_List_In_GK(curgk);
        this.m_cur_lv_all_valid_guest_id_list = guest_id_list;
        this.m_cur_lv_wave_valid_guest_id_list = juba_Config_Mng.GetInstance().Get_All_Can_Show_Guest_ID_List_In_GK_Wave(curgk,this.m_cur_lv_wave);

        this.m_cur_lv_all_valid_guest_id_list.sort((a,b)=>
        {
            return Math.random()-0.5;

        })



        this.m_last_show_game_guest_id = 0;
        this.m_last_show_game_guest_valid_index = 0;

       
        var itop_pos = 1;

        if(curgk == 1)
        {
            this.m_top3_pos_unlocked_map.putData(2,1)
            itop_pos = 2;
    //m_top3_pos_unlocked_map = new juba_WMap();
   // m_top3_pos_guest_id_map = new juba_WMap();

        }else{
            this.m_top3_pos_unlocked_map.putData(1,1)
            itop_pos = 1;
        }


        var first_guest_id  = 0;//this.Find_Next_Show_Guest_ID(itop_pos);

        if(this.m_b_in_first_gk_yd)
        {
            first_guest_id = 108;
        }
        else{
            first_guest_id  = this.Find_Next_Show_Guest_ID(itop_pos);
        }


        this.m_top3_pos_guest_id_map.putData(itop_pos,first_guest_id);

        var lv_wave_info_arr = juba_Config_Mng.GetInstance().Fing_GK_Wave_Info(this.m_jiba_lv,this.m_cur_lv_wave);
        var wave_need_finish_drink_c = lv_wave_info_arr[3];
        if(!wave_need_finish_drink_c)
        {
            wave_need_finish_drink_c = 1;
        }

      
        //得到当前波次出现的饮料

        //当前波次能出的饮料id
 
     //   var prev_gk_jiesuo_drinkid_map = juba_Config_Mng.GetInstance().Get_Prev_GK_Jiesuo_Drink_Id_Map(curgk)

     //   var cur_gk_wave_has_jiesuo_drinkid_map = juba_Config_Mng.GetInstance().Get_In_GK_Wave_Has_Jiesuo_Drink_Id_Map(curgk,this.m_cur_lv_wave)
       
        //this.m_gk_cur_wave_can_show_drink_id_map.clear();


        
        this.m_gk_cur_wave_Need_Finished_drink_count = ComFunc.Check_Read_Number(lv_wave_info_arr[1]);
        this.m_gk_cur_wave_has_Finished_drink_count = 0;
        this.m_gk_cur_wave_diaoluoed_jinbi_count = 0;

        var cur_wave_drink_count = ComFunc.Check_Read_Number(lv_wave_info_arr[2]);
      
        /*
        var show_drink_id_map = cur_gk_wave_has_jiesuo_drinkid_map.Copy();
        var left_need_add_drink_id_count = cur_wave_drink_count - show_drink_id_map.size();

        if(left_need_add_drink_id_count > 0)
        {
            var add_cc = 0;
            for(var tt=prev_gk_jiesuo_drinkid_map.size()-1;tt>=0;tt--)
            {
                var tt_id = prev_gk_jiesuo_drinkid_map.GetKeyByIndex(tt);
                add_cc++;
                show_drink_id_map.putData(tt_id,1);

                if(add_cc >= left_need_add_drink_id_count)
                {
                    break;
                }
            }
        }


         
        this.m_gk_cur_wave_can_show_drink_id_map = show_drink_id_map;
        */

        this.m_gk_cur_wave_can_show_drink_id_map = this.Get_Cur_Wave_Can_Show_Drink_ID_Map();
        var all_in_gk_can_show_jiubei_type_list = juba_Config_Mng.GetInstance().Guaishou_Get_GK_Seq_Show_Drink_Id_List(this.m_jiba_lv)

     

        /*

        var all_in_gk_can_show_jiubei_type_list = [];
        for(var ff=0;ff<cur_gk_wave_has_jiesuo_drinkid_map.size();ff++)
        {
            var ff_drinkid = cur_gk_wave_has_jiesuo_drinkid_map.GetKeyByIndex(ff);
            all_in_gk_can_show_jiubei_type_list.push(ff_drinkid);
        }

        var iaddcc2 = 6 - all_in_gk_can_show_jiubei_type_list.length;
        for(var tt=prev_gk_jiesuo_drinkid_map.size()-1;tt>=0;tt--)
        {
            var tt_id = prev_gk_jiesuo_drinkid_map.GetKeyByIndex(tt);
            if(all_in_gk_can_show_jiubei_type_list.length >= 6)
            {
                break;
            }
            all_in_gk_can_show_jiubei_type_list.push(tt_id)
        }
        */
 
        this.Check_Init_GK_Jiubei_Type_Node_Pool(all_in_gk_can_show_jiubei_type_list);

        //当前波次各个能出的饮料id已经出的数目 
        this.m_gk_cur_wave_existed_top3_drink_id_count_map.clear();
        this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.clear();


        this.m_bottom_panzi_perci_shumu_count_map.clear();

        var nex_show_drink_id_type =  this.Get_Next_Top3_Show_Drink_ID(itop_pos);

        this.m_top3_pos_need_finish_drink_id_map.putData(itop_pos,nex_show_drink_id_type)
        this.m_top3_pos_left_need_finish_drink_count_map.putData(itop_pos,wave_need_finish_drink_c);




        var gk_basicinfo = juba_Config_Mng.GetInstance().Find_GK_Basci_Info(curgk);
        var gk_box_data = this.Parse_GK_Box_Data(gk_basicinfo.box)

        this.m_gk_pos_index_speical_init_box_info_map.clear();
        this.m_gk_pos_index_speical_cur_box_info_map.clear();

        for(var ff=0;ff<gk_box_data.length;ff++)
        {
            var ff_d = gk_box_data[ff];
            this.m_gk_pos_index_speical_init_box_info_map.putData(ff,ff_d);

            if(ff_d == 0)
            {
                continue;
            }

            if(ff_d == -1)
            {
                var perinfo  =new Juba_Game_Spcieal_Pos_Info();
                perinfo.itype = 1;
                perinfo.icount = 1;

               this.m_gk_pos_index_speical_cur_box_info_map.putData(ff,perinfo)
            }
            else if(ff_d  > 0)
            {
                var perinfo  =new Juba_Game_Spcieal_Pos_Info();
                perinfo.itype = 3;
                perinfo.icount = ff_d;

               this.m_gk_pos_index_speical_cur_box_info_map.putData(ff,perinfo)
            }   
            else if(ff_d   < -1 && ff_d >= -4)
            {
                var perinfo  =new Juba_Game_Spcieal_Pos_Info();
                perinfo.itype = 2;
                perinfo.icount = Math.abs(ff_d);

               this.m_gk_pos_index_speical_cur_box_info_map.putData(ff,perinfo)
            }
        }
    
 



        var all_valid_bk_pos_list = [];
        var all_display_bk_pos_list = [];

        for(var x =1;x<=4;x++)
        {
            for(var y =1;y<=6;y++)
            {
              
                all_display_bk_pos_list.push( [x,y]);

                var ff_cell_pos = [x,y];
                var icellindex = this.Translate_Logic_Pos_To_Cell_Index(ff_cell_pos);

                if(this.m_gk_pos_index_speical_cur_box_info_map.hasKey(icellindex))
                {

                }else{
                    all_valid_bk_pos_list.push(ff_cell_pos);
                }
                
            }
        }

        this.m_center_all_displayed_bk_pos_list = all_display_bk_pos_list;
        this.m_center_valid_bk_pos_list = all_valid_bk_pos_list;


        if(this.m_b_in_first_gk_yd)
        {

        }else{
            this.Recreate_Bottom_Pabzi();
        }
   

        var select_bk_color = this.m_parent_game.select_bk_color;

        var selectbk_node = cc.find("center/selectbk",this.m_parent_game_node)
        

        var pnode = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("select_bk_color",select_bk_color)
         selectbk_node.addChild(pnode,20);


         this.m_select_show_gezi_bk_green_node = selectbk_node;
         selectbk_node.active = false;

        for(var ff=0;ff<all_valid_bk_pos_list.length;ff++)
        {
            var ff_cellpos=  all_valid_bk_pos_list[ff];

          //  var pnode = Node_Pool_Utils.GetInstance().Get_Prab_Name_Node("select_bk_color",select_bk_color)
           //  selectbk_node.addChild(pnode,20);

          //  var ff_center_real_pos = this.Get_Logic_Pos_Center_Real_World_Pos(ff_logicx,ff_logicy);
          //  pnode.setPosition(ff_center_real_pos)
        }

        this.Refresh_Special_Node_Item_Node();

        this.Refresh_Top_Guest_Info();

    }
    OnBtn_Goumai_Top3_Pos(itop_pos)
    {
        var ijieso_need_game_jinbi = juba_Config_Mng.GetInstance().Get_Top3_Unlock_Need_Game_Jinbi(this.m_jiba_lv);

        if(ijieso_need_game_jinbi > this.m_cur_game_jinbi)
        {
            return;
        }

        this.m_cur_game_jinbi -= ijieso_need_game_jinbi;
        this.Real_Jiesuo_Top3_Pos(itop_pos)
              
    }

    Refresh_Top_Guest_Info_Index(top3_pos_index)
    {
        var ff= top3_pos_index;
        var ff_renwu_node = cc.find("common_mode/renwu/"+ff,this.m_parent_game_node);

        if(this.m_top3_pos_unlocked_map.hasKey(ff))
        {
            ff_renwu_node.active = true;

            var id_label  = cc.find("id",ff_renwu_node);
            var ren_node  = cc.find("ren",ff_renwu_node);
            
          
            var ff_guiestid = this.m_top3_pos_guest_id_map.getData(ff);

            if(ff_guiestid > 0)
            {
              //  id_label.getComponent(cc.Label).string = ""+ff_guiestid;
              //  BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("jiubei_xunlian",ren_node,"touxiang/"+ff_guiestid,{width:200,height:200})
                 
            }
        }
        else{
            ff_renwu_node.active = false;
        }


        var ff_lock_node = cc.find("common_mode/topbar/"+ff+"/lock",this.m_parent_game_node)
            var ff_com_node = cc.find("common_mode/topbar/"+ff+"/com",this.m_parent_game_node)
            var ff_goumai_node = cc.find("common_mode/topbar/"+ff+"/goumai",this.m_parent_game_node);
            ff_com_node.active = false;
            ff_lock_node.active  = false;
            ff_goumai_node.active = false;


            if(this.m_top3_pos_unlocked_map.hasKey(ff))
            {
                ff_com_node.active = true;
                ff_lock_node.active  = false;
                ff_goumai_node.active = false;


                var leftc = this.m_top3_pos_left_need_finish_drink_count_map.getData(ff);
                var idrinkid = this.m_top3_pos_need_finish_drink_id_map.getData(ff);


                var old_node = null;
                var old_type = 0;
                if(this.m_top3_pos_w_node_map.hasKey(ff))
                {
                    old_node = this.m_top3_pos_w_node_map.getData(ff);
                }

                if(this.m_top3_pos_w_prev_type_map.hasKey(ff))
                {
                    old_type = this.m_top3_pos_w_prev_type_map.getData(ff);
                }
                 
                var bneed_del = false;
                if(old_type != idrinkid || !old_node)
                {
                    bneed_del = true;
                }

                if(bneed_del)
                {
                    if(old_node)
                    {
                        var  old_preab_name = "guaishou_jiubei_Preab_"+old_type;
    
                        NodeComPoolUtils.GetInstance().putANode(old_preab_name,old_node)
                    }
                    this.m_top3_pos_w_prev_type_map.RemoveKey(ff)
                    this.m_top3_pos_w_node_map.RemoveKey(ff)
                }


                var prev_old_node:cc.Node = null;
                if(this.m_top3_pos_w_node_map.hasKey(ff))
                {
                    prev_old_node = this.m_top3_pos_w_node_map.getData(ff);
                }

                if(!prev_old_node)
                {
                    
                    var ff_preab_name = "guaishou_jiubei_Preab_"+idrinkid;
                    var ff_preab = juba_Game_Mng.GetInstance().Get_Preab_By_Name(ff_preab_name)
                    var ff_ndoe = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node(ff_preab_name,ff_preab);

                    ff_ndoe.scale = 1;
                    ff_ndoe.active = true;

                    ff_com_node.addChild(ff_ndoe,10)
                    prev_old_node = ff_ndoe;
                }

                this.m_top3_pos_w_prev_type_map.putData(ff,idrinkid)
                this.m_top3_pos_w_node_map.putData(ff,prev_old_node);
                prev_old_node.active =  true;
                var w_node = prev_old_node.getChildByName("w");

                if(w_node)
                {
                    var sanimname = juba_Config_Mng.GetInstance().Get_Guaishou_Type_Anim_Name(idrinkid,1);
                    var sp_com = w_node.getComponent(sp.Skeleton);
        
                    if(sp_com)
                    {
                        sp_com.timeScale = 0.5;
                        sp_com.setAnimation(0,sanimname,true)
        
                    }
                 
                }


                prev_old_node.setPosition(-60,-26)
              //  var ff_icon_node = cc.find("icon",ff_com_node);

             //   BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("jiubei_xunlian",ff_icon_node,"drink/"+idrinkid,{width:70,height:70})

                var ff_name_node = cc.find("name",ff_com_node);
                var ff_c_node = cc.find("c",ff_com_node);


                var guaishouname = juba_Config_Mng.GetInstance().Get_Guaishou_Type_Name(idrinkid);
                ff_name_node.getComponent(cc.Label).string = guaishouname ;

                ff_c_node.getComponent(cc.Label).string =  "x"+leftc;

             //   var lv_wave_info_arr = juba_Config_Mng.GetInstance(). Fing_GK_Wave_Info(this.m_jiba_lv,this.m_cur_lv_wave);


                if(this.m_b_show_new_drink_id_top_index == ff)
                {
                    ff_com_node.active = false;
         
                }else{
                    ff_com_node.active = true;
         
                }
       


            }else{
                if(ff == 3)
                {
                    ff_lock_node.active  = true;
                }else{
                    ff_goumai_node.active = true;

                    var jiesuo_c_label  = cc.find("jiesuobtn/c",ff_goumai_node);
                    var jiesuo_invalid_c_label  = cc.find("jiesuo_invalid/c",ff_goumai_node);

                    var ijieso_need_game_jinbi = juba_Config_Mng.GetInstance().Get_Top3_Unlock_Need_Game_Jinbi(this.m_jiba_lv);
                    jiesuo_c_label.getComponent(cc.Label).string = ""+ijieso_need_game_jinbi;
                    jiesuo_invalid_c_label.getComponent(cc.Label).string = ""+ijieso_need_game_jinbi;

                    var jiesuobtn_node  = cc.find("jiesuobtn",ff_goumai_node);
                    var jiesuo_invalid_node  = cc.find("jiesuo_invalid",ff_goumai_node);

                    if(ijieso_need_game_jinbi <= this.m_cur_game_jinbi)
                    {
                        jiesuobtn_node.active = true;
                        jiesuo_invalid_node.active = false;
                    }else{
                        jiesuobtn_node.active = false;
                        jiesuo_invalid_node.active = true;
                    }


                }
            }
    }
    Refresh_Top_Guest_Info()
    {
        if(this.m_enter_game_mode == 2)
        {
            // 挑战模式
            return;
        }

 
        for(var ff=1;ff<=3;ff++)
        { 
         
            this.Refresh_Top_Guest_Info_Index(ff);
            
        }
       
        for(var ff=1;ff<=3;ff++)
        { 
            
        }
    }
    Get_Logic_Pos_Center_Real_World_Pos(ff_logicx,ff_logicy)
    {
           
        var middlegezi_node = cc.find("center/dige",this.m_parent_game_node);

        var middle_node_center_pos=  ComFunc.NodeWorldPos(middlegezi_node);


        var x = middle_node_center_pos.x + ( -2.5)*180 + 195 + 170*(ff_logicx-1);
        var y = middle_node_center_pos.y   -300 -11+90 + 88*(ff_logicy-1);

        return new cc.Vec2(x,y)
     
    }
    On_Change_Pifu(pifuindex)
    {
        for(var ff=0;ff<this.m_bottom_pos_banzi_info_map.size();ff++)
        {
            var ff_banzi:guaishou_juba_Banzi_Info  =  this.m_bottom_pos_banzi_info_map.GetEntryByIndex(ff);
            ff_banzi.On_Change_Pifu(pifuindex);
        }


        for(var ff=0;ff<this.m_center_pos_banzi_info_map.size();ff++)
        {
            var ff_banzi:guaishou_juba_Banzi_Info  =  this.m_center_pos_banzi_info_map.GetEntryByIndex(ff);
            ff_banzi.On_Change_Pifu(pifuindex);
        }


        for(var ff=0;ff<this.m_gk_pos_game_spcial_item_node_map.size();ff++)
        {
            var ff_pos_idnex= this.m_gk_pos_game_spcial_item_node_map.GetKeyByIndex(ff);

            var ff_spciel_item_node:cc.Node = this.m_gk_pos_game_spcial_item_node_map.GetEntryByIndex(ff);
            if(!ff_spciel_item_node)
            {
                continue;
            }
            var game_spceial_item:game_spceial_item  = ff_spciel_item_node.getComponent("game_spceial_item");
            game_spceial_item.On_Change_Pifu(pifuindex);

        }
        
    }
    Sort_JiubeiType_List(all_type_d)
    {
        var sorted_type_list = [];


        var ff_map = new WMap();
        for(var ff=0;ff<all_type_d.length;ff++)
        {
            var ff_d=  all_type_d[ff];

            if(!ff_map.hasKey(ff_d))
            {
                ff_map.putData(ff_d,1);
            }
            else{
                var ff_prevc = ff_map.getData(ff_d);
                ff_map.putData(ff_d,1+ff_prevc);
            }
        }


        for(var tt=0;tt<ff_map.size();tt++)
        {
            var tt_typer = ff_map.GetKeyByIndex(tt);
            var tt_C = ff_map.GetEntryByIndex(tt);

            for(var hh=0;hh<tt_C;hh++)
            {
                sorted_type_list.push(tt_typer); 
            }
        }

        return sorted_type_list;
    }


    Create_A_Bottom_Jiubei_Types()
    {

        this.m_lv_valid_jiubei_type_list = [];

        

        for(var tt=0;tt<this.m_gk_cur_wave_can_show_drink_id_map.size();tt++)
        {
            var tt_id = this.m_gk_cur_wave_can_show_drink_id_map.GetKeyByIndex(tt);
            this.m_lv_valid_jiubei_type_list.push(tt_id);
        }

       // m_bottom_panzi_perci_shumu_count_map


      //  var icount = Math.floor(Math.random()*2.9)+1;
        var icount = this.Get_Next_Bottom_Panzi_Jiubei_Count();

        if(!this.m_bottom_panzi_perci_shumu_count_map.hasKey(icount))
        {
            this.m_bottom_panzi_perci_shumu_count_map.putData(icount,1);
        }else{
            var prevc1 = this.m_bottom_panzi_perci_shumu_count_map.getData(icount);
            this.m_bottom_panzi_perci_shumu_count_map.putData(icount,1 + prevc1);
        }



        var all_type_d = [];
        for(var ff=0;ff<icount;ff++)
        {
            var ff_tytpe = this.Get_Next_Bottom_Panzi_Jiubei_Type();

            if(!this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.hasKey(ff_tytpe))
            {
                this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.putData(ff_tytpe,1)
            }else{
                var ff_prevc = this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.getData(ff_tytpe);
                this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.putData(ff_tytpe,1 + ff_prevc)
            }

            all_type_d.push(ff_tytpe);
        }
        /*
        var left_valid_list = this.m_lv_valid_jiubei_type_list.slice(0);
        for(var ff=0;ff<icount;ff++)
        {
            var ff_rand = Math.floor(Math.random()*left_valid_list.length);

            var ff_tytpe = left_valid_list[ff_rand];
 
            all_type_d.push(ff_tytpe);
        }
        */





        var sorted_list = this.Sort_JiubeiType_List(all_type_d);

        return sorted_list;
          
    }


    Get_Tiaozhan_mode_Next_Bottom_Panzi_Jiubei_Type()
    { 
        var cur_valid_jiubei_type_list = [];

        for(var ff=0;ff<this.m_lv_valid_jiubei_type_list.length;ff++)
        {
            var ff_jiubei_type=  this.m_lv_valid_jiubei_type_list[ff];
           
            cur_valid_jiubei_type_list.push(ff_jiubei_type);
           
        }

        var next_jiubei_Type = this.Get_Valid_Jiubei_Type_Rand_Type(cur_valid_jiubei_type_list);
        return next_jiubei_Type;

    }

   
    //获得下一个底部盘子的饮料类型
    Get_Next_Bottom_Panzi_Jiubei_Type()
    { 
        if(this.m_enter_game_mode == 2)
        {
            return this.Get_Tiaozhan_mode_Next_Bottom_Panzi_Jiubei_Type();
        }

        //第一步，首先判断本关卡本波次解锁了哪个drinkid?
        var cur_wave_jiesuo_drinkid = this.Get_GK_Wave_Jiesuo_DrinkID(this.m_jiba_lv,this.m_cur_lv_wave)

        if(cur_wave_jiesuo_drinkid > 0 && this.m_gk_cur_wave_can_show_drink_id_map.hasKey(cur_wave_jiesuo_drinkid))
        {
            if(!this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.hasKey(cur_wave_jiesuo_drinkid))
            { 
                return cur_wave_jiesuo_drinkid;
            }
        }

        var min_jiubeitype   = 0;
        var min_jiubeitype_count   = 0;
        
        for(var ff=0;ff<this.m_lv_valid_jiubei_type_list.length;ff++)
        {
            var ff_jiubei_type=  this.m_lv_valid_jiubei_type_list[ff];
            var ff_exist_c=  0;
            if(this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.hasKey(ff_jiubei_type))
            {
                ff_exist_c = this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.getData(ff_jiubei_type);
            }

            if(min_jiubeitype == 0)
            {
                min_jiubeitype = ff_jiubei_type;
                min_jiubeitype_count = ff_exist_c;
            }else{

                if(ff_exist_c < min_jiubeitype_count)
                {
                    min_jiubeitype = ff_jiubei_type;
                    min_jiubeitype_count = ff_exist_c;
                }

            }

        }
 


        var cur_valid_jiubei_type_list = [];

        for(var ff=0;ff<this.m_lv_valid_jiubei_type_list.length;ff++)
        {
            var ff_jiubei_type=  this.m_lv_valid_jiubei_type_list[ff];
            var ff_exist_c=  0;
            if(this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.hasKey(ff_jiubei_type))
            {
                ff_exist_c = this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map.getData(ff_jiubei_type);
            }

       

           if(this.m_jiba_lv == 1)
           {
                if(ff_exist_c  <= min_jiubeitype_count+1 )
                {
                    cur_valid_jiubei_type_list.push(ff_jiubei_type);
                }
           }else{

                if(ff_exist_c  <= min_jiubeitype_count+6 )
                {
                  //  cur_valid_jiubei_type_list.push(ff_jiubei_type);
                }
               
                
                cur_valid_jiubei_type_list.push(ff_jiubei_type);

           }
         
           

        }

        if(this.m_jiba_lv == 1)
        {
           
            var irand1_lv = Math.floor(this.m_rand_mng.Get_Seed_Index_Next_Random(1)*cur_valid_jiubei_type_list.length);
            var next_jiubei_Type1 = cur_valid_jiubei_type_list[irand1_lv];
    
            return next_jiubei_Type1;
        }
        

        var next_jiubei_Type = this.Get_Valid_Jiubei_Type_Rand_Type(cur_valid_jiubei_type_list);
        return next_jiubei_Type;
    }

    Get_Valid_Jiubei_Type_Rand_Type(cur_valid_jiubei_type_list)
    {
        var pmap = new WMap();

        var all_gailv = 0;

        for(var ff=0;ff<cur_valid_jiubei_type_list.length;ff++)
        {
            var ff_type = cur_valid_jiubei_type_list[ff];
            var ff_gailv = 1;
            //这里我们调整下，概率不一样

            if(ff >= 3)
            {
                
            }
            ff_gailv  = ff*0.05+1;
            pmap.putData(ff_type,ff_gailv);
            all_gailv+=ff_gailv;
        }

        var fugai_gailv = 0;
        var all_type_gailv_list = [];
        for(var ff=0;ff<cur_valid_jiubei_type_list.length;ff++)
        {
            var ff_type = cur_valid_jiubei_type_list[ff];
            var ff_gailv2 = pmap.getData(ff_type);

            var ff_real_gailv = ff_gailv2/all_gailv;

            fugai_gailv += ff_real_gailv;
            all_type_gailv_list.push([ff_type,ff_real_gailv,fugai_gailv]);
        }
      
        var irand1 = this.m_rand_mng.Get_Seed_Index_Next_Random(1)
        for(var tt=0;tt<all_type_gailv_list.length;tt++)
        {
            var tt_arr = all_type_gailv_list[tt];
    
            var tt_type = tt_arr[0];
            var tt_gailv = tt_arr[1];
            var tt_fugai_gailv = tt_arr[2];

            if(irand1 <= tt_fugai_gailv)
            {

                return tt_type;
            }

        }

        var firsttype = cur_valid_jiubei_type_list[0];
        return firsttype;

    }


    Get_Next_Bottom_Panzi_Jiubei_Count()
    {
        var min_panzi_shumu = 0;
        var min_panzishumu_count = 0;

        for(var ff=1;ff<=3;ff++)
        {
            var ff_count  = 0 ;
            if(this.m_bottom_panzi_perci_shumu_count_map.hasKey(ff))
            {
                ff_count = this.m_bottom_panzi_perci_shumu_count_map.getData(ff);
            }

            if(min_panzi_shumu == 0)
            {
                min_panzi_shumu=  ff;
                min_panzishumu_count = ff_count;
            }else{

                if(ff_count < min_panzishumu_count)
                {
                    min_panzi_shumu=  ff;
                    min_panzishumu_count = ff_count;
                }
            }

        }


        
        var cur_wave = this.m_cur_lv_wave;
        if(this.m_enter_game_mode == 2)
        {
            cur_wave = this.m_cur_tiaozhan_wav;
        }

        var valid_c_list = [];

        for(var ff=1;ff<=3;ff++)
        {
            var ff_count  = 0 ;
            if(this.m_bottom_panzi_perci_shumu_count_map.hasKey(ff))
            {
                ff_count = this.m_bottom_panzi_perci_shumu_count_map.getData(ff);
            }

            //ff_count <=  min_panzishumu_count + 1,这里调整为+10

            var bcandd = true;

            //前面三波需要确定不能往一个太多，后面波次不需要管了
            if(cur_wave <= 2)
            {
                if( ff_count <=  min_panzishumu_count + 2 )
                {
                    bcandd = true;
                }else{
                    bcandd = false;
                }
            }
            else if(cur_wave == 3)
            {
                if( ff_count <=  min_panzishumu_count + 10 )
                {
                    bcandd = true; 
                }else{
                    bcandd = false;
                }
            }else{
                bcandd = true;
                
            }

            if(bcandd)
            {
                valid_c_list.push(ff);
            }
        }





        //给每个数字加上权重
        var valid_c_quanzhong_map= new WMap();
        for(var ff=0;ff<valid_c_list.length;ff++)
        {
            var ff_c=  valid_c_list[ff];

            var iquanzhong = 100;
          
            if(cur_wave <= 2)
            {
                iquanzhong = 100;
            } 
            else if(cur_wave <= 3)
            {
                if(ff_c == 3)
                {
                    iquanzhong = 40;
                }else{
                    iquanzhong = 30;
                }
                
            }else{
                if(ff_c == 3)
                {
                    iquanzhong = 50;
                }
                else if(ff_c == 2)
                {
                    iquanzhong = 30;
                }else{
                    iquanzhong = 20;
                }
            }


            valid_c_quanzhong_map.putData(ff_c,iquanzhong);
        }


        var irand1 = this.m_rand_mng.Get_Seed_Index_Next_Random(2);

        var inextc =   this.Get_Next_Quanzhong_C_Rand_Value(valid_c_quanzhong_map,irand1);


     //   var irn1 = Math.floor(this.m_rand_mng.Get_Seed_Index_Next_Random(2)*valid_c_list.length);
      //  var inextc = valid_c_list[irn1];

        return inextc;

    }


    Get_Next_Quanzhong_C_Rand_Value(valid_c_quanzhong_map,irand1)
    {
        if(valid_c_quanzhong_map.size() == 0)
        {
            return 1;
        }
        //只有一个选择，那直接就
        if(valid_c_quanzhong_map.size() == 1)
        {
            var validc = valid_c_quanzhong_map.GetKeyByIndex(0);
            return validc;
        }


        var valid_c_arr = [];
        var valid_c_quanzhong_arr = [];

        var iall_quanz = 0;
        for(var tt=0;tt<valid_c_quanzhong_map.size();tt++)
        {
            var tt_c  = valid_c_quanzhong_map.GetKeyByIndex(tt);
            var tt_qz = valid_c_quanzhong_map.GetEntryByIndex(tt);
            iall_quanz += tt_qz;
 
        }


        for(var tt=0;tt<valid_c_quanzhong_map.size();tt++)
        {
            var tt_c  = valid_c_quanzhong_map.GetKeyByIndex(tt);
            var tt_qz = valid_c_quanzhong_map.GetEntryByIndex(tt);
            valid_c_arr[tt] = tt_c;
            valid_c_quanzhong_arr[tt] = tt_qz/iall_quanz;
        }



        var all_add_lv = 0;

        for(var gg=0;gg<valid_c_quanzhong_arr.length;gg++)
        {
            var gg_gl = valid_c_quanzhong_arr[gg];
            var gg_c = valid_c_arr[gg];

            all_add_lv += gg_gl;


            if(all_add_lv >= irand1)
            {

                return gg_c;
            }
        }


        var firstd = valid_c_arr[0];

        return firstd;
    }


    Get_Bottom_Panzi_Pos(iindex)
    {
        var bottm_bk_node = cc.find("bottom/com/"+iindex+"/bk",this.m_parent_game_node)
        
        var worl_pos = ComFunc.NodeWorldPos(bottm_bk_node);

        return worl_pos;
    }

    Get_Bottom_Banzi_Pos_By_Index(iindex)
    {

        return new cc.Vec2(-230 + 230*(iindex-1),-430);
    }
    ReShow_Bottom_Pos_Panzi_Types(iindex, pos_bottom_jiubei_types)
    {
        var prevbanziinfo:guaishou_juba_Banzi_Info = null;

        if(this.m_bottom_pos_banzi_info_map.hasKey(iindex))
        {
            prevbanziinfo = this.m_bottom_pos_banzi_info_map.getData(iindex);
        }

        if(prevbanziinfo)
        {
            prevbanziinfo.Del_Info();
        }
        this.m_bottom_pos_banzi_info_map.RemoveKey(iindex);


        var bottom_wuping_node = cc.find("bottom/com/bottom_wuping",this.m_parent_game_node)
         
        var guaishou_banzi_preab = this.m_parent_game.guaishou_banzi;

        var panzi_ndoe =  NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("guaishou_banzi",guaishou_banzi_preab)

        var btm_pos = this.Get_Bottom_Banzi_Pos_By_Index(iindex);

        bottom_wuping_node.addChild(panzi_ndoe,10);
        panzi_ndoe.setPosition(btm_pos);


        var guaishou_banzi:guaishou_banzi = panzi_ndoe.getComponent("guaishou_banzi");
      
        guaishou_banzi.Init_Jiubei_Types(pos_bottom_jiubei_types);


        var new_banzi_info = new guaishou_juba_Banzi_Info();
        new_banzi_info.Init(iindex,panzi_ndoe)

        this.m_bottom_pos_banzi_info_map.putData(iindex,new_banzi_info);


    }



    Real_Sel_Fuhuo()
    {

        var ilineindex = 2;
        if(Math.random() > 0.5)
        {
            ilineindex = 3;
        }
        this.Delete_Line_Banzi(ilineindex);

        this.m_b_game_ended = 0;
     
        this.Save_Cur_Gk_Info()
    }
 
    Delete_Line_Banzi(iline)
    {
        var logic_list = [];
        var  banzi_list = [];
        for(var ff=0;ff<this.m_center_pos_banzi_info_map.size();ff++)
        {
            var ff_lofgic_pos = this.m_center_pos_banzi_info_map.GetKeyByIndex(ff);
            var fF_banzi_info =  this.m_center_pos_banzi_info_map.GetEntryByIndex(ff);
            if(ff_lofgic_pos[0] == iline)
            {
                logic_list.push(ff_lofgic_pos);
                banzi_list.push(fF_banzi_info);
            }
        }


        for(var ff=0;ff<banzi_list.length;ff++)
        {
            var ff_banzi:guaishou_juba_Banzi_Info = banzi_list[ff];
            ff_banzi.Del_Info();
        }


        for(var ff=0;ff<logic_list.length;ff++)
        {
         
            var ff_pos = logic_list[ff];
            
            var real_pos = this.Get_Logic_Pos_Center_Real_World_Pos(ff_pos[0],ff_pos[1])

            this.m_parent_game.Add_Suikai_Anim(real_pos);
    
            this.m_center_pos_banzi_info_map.Remove_By_Logic_Pos(ff_pos);
        }


        BackGroundSoundUtils.GetInstance().Play_Effect("com/yichu")
    }
    Notify_Select_Delete_Banzi( logic_pos)
    {
        if(!this.m_b_in_banzi_Del_status)
        {
            return;
        }

        if(!this.m_center_pos_banzi_info_map.has_key_By_Logic_Pos(logic_pos))
        {
            return;
        }

        var banzi:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.get_Data_By_Logic_Pos(logic_pos);
        banzi.Del_Info();
        this.m_center_pos_banzi_info_map.Remove_By_Logic_Pos(logic_pos);

        var real_pos = this.Get_Logic_Pos_Center_Real_World_Pos(logic_pos[0],logic_pos[1])

        this.m_parent_game.Notify_Select_Delete_Banzi(real_pos);


        BackGroundSoundUtils.GetInstance().Play_Effect("com/yichu")
    }
    Show_All_Banzi_Del_State(bshow)
    {
        this.m_b_in_banzi_Del_status = bshow;

        for(var ff=0;ff<this.m_center_pos_banzi_info_map.size();ff++)
        {
            var ff_banzi:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.GetEntryByIndex(ff);
            ff_banzi.Show_Delete_Status(bshow)
        }
    }
    Find_Line_Banzi_List(iline)
    {

        var banzi_list = [];
        for(var ff=0;ff<this.m_center_pos_banzi_info_map.size();ff++)
        {
            var ff_lofgic_pos = this.m_center_pos_banzi_info_map.GetKeyByIndex(ff);
            var fF_banzi_info =  this.m_center_pos_banzi_info_map.GetEntryByIndex(ff);
            if(ff_lofgic_pos[0] == iline)
            {
                banzi_list.push(fF_banzi_info);
            }
        }

        return banzi_list;
    }
    Check_Can_Del_One_Line_Now()
    {
        if(this.m_b_in_dealing_animate)
        {
            return false;
        }

        if(this.m_b_game_ended)
        {
            return false;
        }

        if(this.m_center_pos_banzi_info_map.size() == 0)
        {
            BaseUIUtils.ShowTipTxtDlg("没有可删除的",this.m_parent_game_node)
            return false;
        }
        return true;
    }
    Check_Can_Del_One_Now()
    {
        if(this.m_b_in_dealing_animate)
        {
            return false;
        }

        if(this.m_b_game_ended)
        {
            return false;
        }

        if(this.m_center_pos_banzi_info_map.size() == 0)
        {
            BaseUIUtils.ShowTipTxtDlg("没有可删除的",this.m_parent_game_node)
            return false;
        }
        return true;
    }
    OnBtnChongxinFasong()
    {
        if(this.m_b_in_dealing_animate)
        {
            return;
        }

        if(this.m_b_game_ended)
        {
            return;
        }

        this.Recreate_Bottom_Pabzi();

    }
    Recreate_Bottom_Pabzi()
    {

        if(this.m_b_in_first_gk_yd)
        {
            this.m_parent_game.Notify_YD_Bottom_Panzi_Empty();
            return;
        }

        for(var ff=1;ff<=3;ff++)
        {
            var ff_bottom_cell_types = this.Create_A_Bottom_Jiubei_Types();

            this.ReShow_Bottom_Pos_Panzi_Types(ff,ff_bottom_cell_types);
        }




        var addc = 150;

        for(var ff=0;ff<this.m_bottom_pos_banzi_info_map.size();ff++)
        {
            var ff_iindex:guaishou_juba_Banzi_Info = this.m_bottom_pos_banzi_info_map.GetKeyByIndex(ff);
         
            var ff_bottom_banzi:guaishou_juba_Banzi_Info = this.m_bottom_pos_banzi_info_map.GetEntryByIndex(ff);
            var ff_node = ff_bottom_banzi.m_node;


            var ff_bottom_pos = this.Get_Bottom_Banzi_Pos_By_Index(ff_iindex);

            ff_node.setPosition(ff_bottom_pos.x + addc,ff_bottom_pos.y);

            var pmove = cc.moveTo(0.1,ff_bottom_pos)
            ff_node.runAction(pmove);
        }

        

        BackGroundSoundUtils.GetInstance().Play_Effect("com/feiru_3")
    }

    Clear_All_Drage_Jiubei_Node()
    {
        if(this.m_drage_jiubei_info)
        {
            this.m_drage_jiubei_info.Del_Info();
            this.m_drage_jiubei_info = null;
        }
        for(var ff=1;ff<=3;ff++)
        {
            var ff_banzi_info:guaishou_juba_Banzi_Info  = null;

            if(this.m_bottom_pos_banzi_info_map.hasKey(ff))
            {
                ff_banzi_info = this.m_bottom_pos_banzi_info_map.getData(ff);
         
            }

            if(ff_banzi_info)
            {
                ff_banzi_info.SetVisible(true)
            }
        }

        this.m_move_cell_hit_center_bk_pos=  null;
    }

    Check_Touch_Bottom_Panzi_Pos(iindex,pos)
    {
        var center_pos = this.Get_Bottom_Panzi_Pos(iindex);

        var absx = Math.abs(pos.x - center_pos.x);
        var absy = Math.abs(pos.y - center_pos.y);
        
        if(absx < 84 && absy < 42)
        {
            return true;
        }

        return false;
    }
    onTouchStart(pos) {
        this.Clear_All_Drage_Jiubei_Node();
 
        this.m_b_drage_type = 0;
        this.m_bottom_selected_drage_index = 0; 
        this.m_b_touchued = false;
        this.m_touch_start_pt = pos; 
 
    
        this.m_last_move_pt = pos;

        var i_sel_bottom_index=  0;

        this.Change_Show_Center_Hit_Select_Status();

        if(this.m_b_in_dealing_animate)
        {
            return;
        }

        if(this.m_b_game_ended)
        {
            return;
        }


        this.m_b_touchued = true;
      
        for(var ff=1;ff<=3;ff++)
        {
            var ff_banzi_info:guaishou_juba_Banzi_Info  = null;

            if(this.m_bottom_pos_banzi_info_map.hasKey(ff))
            {
                ff_banzi_info = this.m_bottom_pos_banzi_info_map.getData(ff);
         
            }

            if(!ff_banzi_info)
            {
                continue;
            }
             
            var bcheck = this.Check_Touch_Bottom_Panzi_Pos(ff,pos);
            if(bcheck)
            {
                i_sel_bottom_index = ff;
                break;
            }

            
        }

        if(i_sel_bottom_index > 0)
        {
            this.On_TouchStart_Sel_Bottom_Index(i_sel_bottom_index,pos);
            this.m_b_drage_type = 1;
            this.m_bottom_selected_drage_index = i_sel_bottom_index;

         
     
            BackGroundSoundUtils.GetInstance().Play_Effect("jiubei/sel_start");
        }
        else{

            var ff_click_xianjin_logic_pos=  null;
            for(var ff=0;ff<this.m_center_logic_pos_diaoluo_xianjing_node_map.size();ff++)
            {
                var ff_logic_pos = this.m_center_logic_pos_diaoluo_xianjing_node_map.GetKeyByIndex(ff);
                var ff_real_pos=  this.Get_Logic_Pos_Center_Real_World_Pos(ff_logic_pos[0],ff_logic_pos[1]);

                if(Math.abs(ff_real_pos.x - pos.x) < 30 && Math.abs(ff_real_pos.y - pos.y) < 30 )
                {
                    ff_click_xianjin_logic_pos = ff_logic_pos;
                }
            }

            if(ff_click_xianjin_logic_pos)
            {
                this.Shiqu_Logic_Pos_Xianjin(ff_click_xianjin_logic_pos);
            }

        }
    }

    //掉落现金拾取
    Check_Has_And_Shiqu_Logic_Pos_Xianjin( logic_pos)
    {
        if(!logic_pos)
        {
            return;
        }

        if(!this.m_center_logic_pos_diaoluo_xianjing_node_map.has_key_By_Logic_Pos(logic_pos))
        {
            return;
        }

        this.Shiqu_Logic_Pos_Xianjin(logic_pos)
    }

    Shiqu_Logic_Pos_Xianjin(ff_click_xianjin_logic_pos)
    {
        var ff_xianjin_ndoe = this.m_center_logic_pos_diaoluo_xianjing_node_map.get_Data_By_Logic_Pos(ff_click_xianjin_logic_pos);
    
        this.m_center_logic_pos_has_diaoluo_jinbi_map.Remove_By_Logic_Pos(ff_click_xianjin_logic_pos);
        this.m_center_logic_pos_diaoluo_xianjing_node_map.Remove_By_Logic_Pos(ff_click_xianjin_logic_pos);


        if(!ff_xianjin_ndoe)
        {
            return;
        }

        var real_pos = this.Get_Logic_Pos_Center_Real_World_Pos(ff_click_xianjin_logic_pos[0],ff_click_xianjin_logic_pos[1]);
       
        NodeComPoolUtils.GetInstance().putANode("move_xianjin_preab",ff_xianjin_ndoe);

        this.Show_Huode_Xianjin_Moveto_JinbiLan_Anim(real_pos);

        var gk_basicinfo = juba_Config_Mng.GetInstance().Find_GK_Basci_Info(this.m_jiba_lv);
        var jm = gk_basicinfo.jm;

        var add_jinbi = Math.floor(jm/5);
        this.m_cur_game_jinbi += add_jinbi;

        var self = this;
        var pseq = cc.sequence(cc.delayTime(1),
        cc.callFunc(()=>
        {
            self.Refresh_Info();
        }))
     
        this.m_parent_game_node.runAction(pseq);

    }
    On_TouchStart_Sel_Bottom_Index(i_sel_bottom_index,pos)
    {

        var moveinfo_node = cc.find("wuping/moveinfo",this.m_parent_game_node)
        

        if(!this.m_drag_move_cell_node)
        {
            this.m_drag_move_cell_node = new cc.Node();
            moveinfo_node.addChild(this.m_drag_move_cell_node ,10)
        }
        this.m_drag_move_cell_node.active = true;

        var sel_banzi_info:guaishou_juba_Banzi_Info  = null;

        if(this.m_bottom_pos_banzi_info_map.hasKey(i_sel_bottom_index))
        {
            sel_banzi_info = this.m_bottom_pos_banzi_info_map.getData(i_sel_bottom_index);
     
        }

        sel_banzi_info.SetVisible(false);

        var panzi_jiubei_list = sel_banzi_info.Get_Left_Jubei_Type_List();

         
        var panzi_preab = this.m_parent_game.guaishou_banzi;

        var panzi_ndoe =  NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("guaishou_banzi",panzi_preab)
        panzi_ndoe.setPosition(0,0)
        this.m_drag_move_cell_node.addChild(panzi_ndoe,10);
     
        var bottom_pos=  this.Get_Bottom_Panzi_Pos(i_sel_bottom_index);
      //  panzi_ndoe.setPosition(bottom_pos);


        this.m_drag_move_cell_touch_start_pos = new cc.Vec2(bottom_pos.x,bottom_pos.y + 100);
        this.m_drag_move_cell_node.setPosition(this.m_drag_move_cell_touch_start_pos);
 

        var jiuba_panzi_preab:guaishou_banzi = panzi_ndoe.getComponent("guaishou_banzi");
        
        jiuba_panzi_preab.Init_Jiubei_Types(panzi_jiubei_list);


        var new_banzi_info = new guaishou_juba_Banzi_Info();
        new_banzi_info.Init(i_sel_bottom_index,panzi_ndoe)


        this.m_drage_jiubei_info = new_banzi_info;

    }

     
    onTouchMove(pos) {
       
        if(!this.m_b_touchued)
        {
            return;
        }
 
        if(this.m_b_drage_type == 0)
        {
            return;
        }

        if(this.m_b_in_dealing_animate)
        {
            return;
        }

        var offsetptx = pos.x- this.m_touch_start_pt.x;
        var offsetpty = pos.y- this.m_touch_start_pt.y;
        

        var newx = this.m_drag_move_cell_touch_start_pos.x + offsetptx;
        var newy = this.m_drag_move_cell_touch_start_pos.y + offsetpty;

        var move_pos=  new cc.Vec2(newx,newy)
        this.m_drag_move_cell_node.setPosition(move_pos);


        var find_exist_pos = this.Find_Move_Pos_Inter_Center_Cell_Logic_Pos(move_pos);
        
      

        var can_fz_pos = null;

        if(!find_exist_pos)
        {

            can_fz_pos = null;
        }else{

            var center_banzi = this.Find_Center_Pos_Banzi_Info(find_exist_pos)

            if(!center_banzi)
            {
                can_fz_pos = find_exist_pos;
            }else{
                can_fz_pos = null;
            }
        }

        this.m_move_cell_hit_center_bk_pos = can_fz_pos;

        if(can_fz_pos)
        {
            this.Check_Has_And_Shiqu_Logic_Pos_Xianjin( can_fz_pos)
        }
   
        this.Change_Show_Center_Hit_Select_Status();

    }
    Refresh_YD_Move_Logic_Pos_Node()
    {

        var yd_move_bk_color_preab = this.m_parent_game.yd_move_bk_color_preab;

        var need_remove_logci_pos_node_map = new WMap();

        for(var tt=0;tt<this.m_yd_move_logcic_pos_bk_node_map.size();tt++)
        {
            var tt_pos = this.m_yd_move_logcic_pos_bk_node_map.GetKeyByIndex(tt);

            var tt_exist = false;
            for(var gg=0;gg<this.m_yd_move_logic_pos_list.length;gg++)
            {
                var gg_pos = this.m_yd_move_logic_pos_list[gg];

                if(this.IsSameLogicPos(tt_pos,gg_pos))
                {
                    tt_exist = true;
                }

            }

            if(!tt_exist)
            {
                need_remove_logci_pos_node_map.putData(tt_pos,1);
            }
        }

        for(var yy=0;yy<need_remove_logci_pos_node_map.size();yy++)
        {
            var yy_pos = need_remove_logci_pos_node_map.GetKeyByIndex(yy);
            var yy_ndoe = this.m_yd_move_logcic_pos_bk_node_map.get_Data_By_Logic_Pos(yy_pos);

            if(yy_ndoe)
            {
                NodeComPoolUtils.GetInstance().putANode("yd_move_bk_color_preab",yy_ndoe)
            }
            this.m_yd_move_logcic_pos_bk_node_map.Remove_By_Logic_Pos(yy_pos);
        }
        var yd_move_bk_node = cc.find("center/yd_move_bk",this.m_parent_game_node)
      
        for(var gg=0;gg<this.m_yd_move_logic_pos_list.length;gg++)
        {
            var gg_pos = this.m_yd_move_logic_pos_list[gg];


            if(!this.m_yd_move_logcic_pos_bk_node_map.has_key_By_Logic_Pos(gg_pos))
            {
                var gg_ndoe = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("yd_move_bk_color_preab",yd_move_bk_color_preab);
                yd_move_bk_node.addChild(gg_ndoe,10);
                this.m_yd_move_logcic_pos_bk_node_map.putData(gg_pos,gg_ndoe)
            }

          
            var gg_old_node=  this.m_yd_move_logcic_pos_bk_node_map.get_Data_By_Logic_Pos(gg_pos);
            var gg_real_pos=  this.Get_Logic_Pos_Center_Real_World_Pos(gg_pos[0],gg_pos[1])
            gg_old_node.setPosition(gg_real_pos);

            gg_old_node.active = true;
        }

        
    }
    Set_Yingdao_Move_Logic_Pos(yd_move_logic_pos_list)
    {
        this.m_yd_move_logic_pos_list = yd_move_logic_pos_list;
        this.Refresh_YD_Move_Logic_Pos_Node();
    }
    Change_Show_Center_Hit_Select_Status()
    {
        if(this.m_move_cell_hit_center_bk_pos)
        {
            var lx = this.m_move_cell_hit_center_bk_pos[0];
            var ly = this.m_move_cell_hit_center_bk_pos[1];

              
            this.m_select_show_gezi_bk_green_node.active = true;

            var real_pos=  this.Get_Logic_Pos_Center_Real_World_Pos(lx,ly);

            this.m_select_show_gezi_bk_green_node.setPosition(real_pos)
        }
        else{

            this.m_select_show_gezi_bk_green_node.active = false;
        }

    }
    Find_Center_Pos_Banzi_Info(find_exist_pos)
    {
        for(var ff=0;ff<this.m_center_pos_banzi_info_map.size();ff++)
        {
            var ff_logicjpos = this.m_center_pos_banzi_info_map.GetKeyByIndex(ff);
            var ff_banziinfo = this.m_center_pos_banzi_info_map.GetEntryByIndex(ff);
            
            if(ff_logicjpos[0] == find_exist_pos[0] && ff_logicjpos[1] == find_exist_pos[1])
            {
                return ff_banziinfo;
            }
        }

        return null;
    }

    

    Find_Move_Pos_Inter_Center_Cell_Logic_Pos(move_pos)
    { 
        
        for(var ff=0;ff<this.m_center_valid_bk_pos_list.length;ff++)
        {
            var ff_valid_pos = this.m_center_valid_bk_pos_list[ff];

            var ff_logicx = ff_valid_pos[0];
            var ff_logicy = ff_valid_pos[1];

            var ff_world_pos = this.Get_Logic_Pos_Center_Real_World_Pos(ff_logicx,ff_logicy);

            if(Math.abs(move_pos.x - ff_world_pos.x) < 80  && Math.abs(move_pos.y - ff_world_pos.y) < 40)
            {
                return [ff_logicx,ff_logicy]
            }
        }

        if(this.m_move_cell_hit_center_bk_pos)
        {
            var ff_world_pos = this.Get_Logic_Pos_Center_Real_World_Pos(this.m_move_cell_hit_center_bk_pos[0],this.m_move_cell_hit_center_bk_pos[1]);

            
            if(Math.abs(move_pos.x - ff_world_pos.x) < 100  && Math.abs(move_pos.y - ff_world_pos.y) < 50)
            {
                return this.m_move_cell_hit_center_bk_pos
            }

        }

        return null;
    }
    onTouchCancel()
    {
         
        this.Clear_All_Drage_Jiubei_Node();
 
        this.m_b_drage_type = 0;
        this.m_bottom_selected_drage_index = 0; 
        this.m_b_touchued = false;
     
     

        this.Change_Show_Center_Hit_Select_Status();
    }
    onTouchEnd(pos) {

        var bottom_selected_index_fzed_index = 0;

        BackGroundSoundUtils.GetInstance().Play_Effect("jiubei/sel_start");

        if(this.m_b_drage_type == 1 && this.m_b_touchued)
        {
            if(this.m_move_cell_hit_center_bk_pos && this.m_bottom_selected_drage_index > 0)
            {
                this.Check_Has_And_Shiqu_Logic_Pos_Xianjin( this.m_move_cell_hit_center_bk_pos)
                bottom_selected_index_fzed_index = this.m_bottom_selected_drage_index ;

                var b_valid_can_fangzho  = true;

                if(this.m_b_in_first_gk_yd )
                {
                    var b_yingdao_waitfor_user_fangzhi = this.m_parent_game.m_b_yingdao_waitfor_user_fangzhi;

                    var waitfor_fanagzhipos = this.m_parent_game.m_b_yingdao_waitfor_user_fangzhi_pos;

                    if(!b_yingdao_waitfor_user_fangzhi)
                    {
                        b_valid_can_fangzho = false;
                    }else{

                        if(!waitfor_fanagzhipos)
                        {
                            b_valid_can_fangzho = false;
                        }
                        else{

                            if(waitfor_fanagzhipos[0] != this.m_move_cell_hit_center_bk_pos[0] || this.m_move_cell_hit_center_bk_pos[1] != waitfor_fanagzhipos[1])
                            {
                                b_valid_can_fangzho = false;
                            }
                        }

                    }

                }


                if(b_valid_can_fangzho)
                {
                    this.On_Move_Bottom_Index_Cell_To_Center(this.m_bottom_selected_drage_index,this.m_move_cell_hit_center_bk_pos);
                }
                
            }
        }



        this.Clear_All_Drage_Jiubei_Node();
 
        this.m_b_drage_type = 0;
        this.m_bottom_selected_drage_index = 0; 
        this.m_b_touchued = false;
        this.m_touch_start_pt = pos; 
 
    
        this.m_last_move_pt = pos;


        this.Change_Show_Center_Hit_Select_Status();

       
    }

    Set_Logic_Pos_Jiubei_Type_List(center_logic_pos,jiubei_type_list)
    {
        if(this.m_center_pos_banzi_info_map.has_key_By_Logic_Pos(center_logic_pos))
        {
            var banzi:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.get_Data_By_Logic_Pos(center_logic_pos);
            banzi.Del_Info();
            this.m_center_pos_banzi_info_map.Remove_By_Logic_Pos(center_logic_pos);
        }
        
        var center_wuping_node = cc.find("wuping/center",this.m_parent_game_node)
         
        var panzi_preab = this.m_parent_game.guaishou_banzi;

        var panzi_ndoe =  NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("guaishou_banzi",panzi_preab)

        center_wuping_node.addChild(panzi_ndoe,10 + 20 - center_logic_pos[1]);

        var center_real_pos = this.Get_Logic_Pos_Center_Real_World_Pos(center_logic_pos[0],center_logic_pos[1])

        panzi_ndoe.setPosition(center_real_pos);


        var jiuba_panzi_preab:guaishou_banzi = panzi_ndoe.getComponent("guaishou_banzi");
      
        jiuba_panzi_preab.Init_Jiubei_Types(jiubei_type_list);


        var new_banzi_info = new guaishou_juba_Banzi_Info();
        new_banzi_info.Init_Center(center_logic_pos,panzi_ndoe)
        new_banzi_info.Set_Notifyer(this);

        this.m_center_pos_banzi_info_map.putData(center_logic_pos,new_banzi_info);

    }

    On_Move_Bottom_Index_Cell_To_Center( i_sel_bottom_index, center_logic_pos)
    {

        var prevbanziinfo:guaishou_juba_Banzi_Info = null;
 
        if(this.m_bottom_pos_banzi_info_map.hasKey(i_sel_bottom_index))
        {
            prevbanziinfo = this.m_bottom_pos_banzi_info_map.getData(i_sel_bottom_index);
        }
        this.m_bottom_pos_banzi_info_map.RemoveKey(i_sel_bottom_index);

        var old_jiubei_type_list = prevbanziinfo.Get_Left_Jubei_Type_List();


        var center_wuping_node = cc.find("wuping/center",this.m_parent_game_node)
         
        var panzi_preab = this.m_parent_game.guaishou_banzi;

        var panzi_ndoe =  NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("guaishou_banzi",panzi_preab)

        center_wuping_node.addChild(panzi_ndoe,10 + 20 - center_logic_pos[1]);

        var center_real_pos = this.Get_Logic_Pos_Center_Real_World_Pos(center_logic_pos[0],center_logic_pos[1])

        panzi_ndoe.setPosition(center_real_pos);


        var jiuba_panzi_preab:guaishou_banzi = panzi_ndoe.getComponent("guaishou_banzi");
      
        jiuba_panzi_preab.Init_Jiubei_Types(old_jiubei_type_list);


        var new_banzi_info = new guaishou_juba_Banzi_Info();
        new_banzi_info.Init_Center(center_logic_pos,panzi_ndoe)
        new_banzi_info.Set_Notifyer(this);

        this.m_center_pos_banzi_info_map.putData(center_logic_pos,new_banzi_info);

        this.Touchu_End_Deal(center_logic_pos);

    }
    On_Move_End_Deal_Finished()
    {
        this.m_b_in_dealing_animate = 0; 

        //判断是否结束了

        var ball_full = true;

        for(var ff=0;ff<this.m_center_valid_bk_pos_list.length;ff++)
        {
            var ff_valid_pos = this.m_center_valid_bk_pos_list[ff];

            if(!this.m_center_pos_banzi_info_map.has_key_By_Logic_Pos(ff_valid_pos))
            {
                ball_full = false;
            }
        }

        if(ball_full)
        {
            this.m_b_game_ended = 1;
            this.m_b_game_end_success = 0;

            this.m_parent_game.Notify_Game_Fail_End();

            this.Remove_Gk_Save_File();
        }


        this.Save_Cur_Gk_Info();
    }
    Notify_Game_Success()
    {
        this.m_b_game_ended = 1;
        this.m_b_game_end_success = 1;

        this.m_parent_game.Notify_Game_Success();

        this.Remove_Gk_Save_File();
    }

    Get_Save_Game_Ju_Filename()
    {
        if(this.m_enter_game_mode == 2)
        {
            return "guaishou_jugame_game_last_tiaozhan_data";
        }
        return "guaishou_jugame_game_last_ju_gk_data";
    }
    Remove_Gk_Save_File()
    {
        var sfilename = this.Get_Save_Game_Ju_Filename();

        MyLocalStorge.removeItem(sfilename);
    }
    Save_Cur_Gk_Info()
    {

        if(this.m_enter_game_mode == 2)
        {
            this.Save_Cur_Gk_Info_Tiaozhan()
        }
        else{
            this.Save_Cur_Gk_Info_Common()
        }

    }
    Save_Cur_Gk_Info_Tiaozhan()
    {
        if(this.m_b_game_ended)
        {
            return;
        }
     

        if(!this.m_b_inited)
        {
            return;
        }

       

        var bottom_banzi_info_list = [];

        for(var gg=0;gg<this.m_bottom_pos_banzi_info_map.size();gg++)
        {
            var gg_poos_index = this.m_bottom_pos_banzi_info_map.GetKeyByIndex(gg);
            var ff_bottom_banzi:guaishou_juba_Banzi_Info = this.m_bottom_pos_banzi_info_map.GetEntryByIndex(gg);
            var ff_left_jiubei_type_list = ff_bottom_banzi.Get_Left_Jubei_Type_List();

            bottom_banzi_info_list.push(
                {
                    pos:gg_poos_index,
                    jiubei_list:ff_left_jiubei_type_list
                }
            )
        }

        
        var center_banzi_info_list = [];

        for(var ff=0;ff<this.m_center_pos_banzi_info_map.size();ff++)
        {
            var ff_center_pos = this.m_center_pos_banzi_info_map.GetKeyByIndex(ff);
            var ff_banziinfo :guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.GetEntryByIndex(ff);
            var ff_left_type_list = ff_banziinfo.Get_Left_Jubei_Type_List();


            center_banzi_info_list.push(
                {
                    logicpos:[ff_center_pos[0],ff_center_pos[1]],
                    jiubei_list:ff_left_type_list
                }
            )
        }


        var speical_cur_box_info_list = [];

        for(var jj=0;jj<this.m_gk_pos_index_speical_cur_box_info_map.size();jj++)
        {
            var jj_cellindex =  this.m_gk_pos_index_speical_cur_box_info_map.GetKeyByIndex(jj);
            var jj_boxinfo:Juba_Game_Spcieal_Pos_Info = this.m_gk_pos_index_speical_cur_box_info_map.GetEntryByIndex(jj);

            var jj_type = jj_boxinfo.itype;
            var jj_icount = jj_boxinfo.icount;

            var per_speicalitem = {
                "cellindex":jj_cellindex,
                "itype":jj_type,
                "ic":jj_icount
            }
            speical_cur_box_info_list.push(per_speicalitem);
        }

        var tiaozhan_top_drink_info_list = [];
        for(var jj=0;jj<this.m_tiaozhan_top_drink_info_list.length;jj++)
        {
            var jj_drinkinfo:Per_Tiaozhan_Top_Drink_Info =  this.m_tiaozhan_top_drink_info_list[jj];

            var jj_save_info =  jj_drinkinfo.Get_SavedInfo();
            tiaozhan_top_drink_info_list.push(jj_save_info);
 
        }
    
       

        var pobj  = 
        {
            "tiaozhan_guest_id":this.m_tiaozhan_mode_guest_id,
            "m_tiaozhan_cur_use_chat_id":this.m_tiaozhan_cur_use_chat_id,
       
            "m_cur_tiaozhan_wav":this.m_cur_tiaozhan_wav,
          
            "m_cur_game_jinbi":this.m_cur_game_jinbi,
       
            
            "m_tiaozhan_total_finished_jiubei_count":this.m_tiaozhan_total_finished_jiubei_count,
            "m_tiaozhan_total_need_finished_jiubei_count":this.m_tiaozhan_total_need_finished_jiubei_count,
            "m_cur_tiaozhan_wav_need_finished_count":this.m_cur_tiaozhan_wav_need_finished_count,
            "m_cur_tiaozhan_wav_has_finished_count":this.m_cur_tiaozhan_wav_has_finished_count,

            "m_cur_tiaozhan_all_valid_drinkid_list":this.m_cur_tiaozhan_all_valid_drinkid_list,

            "tiaozhan_top_drink_info_list":tiaozhan_top_drink_info_list,

            
            
            "bottom_banzi_info_list":bottom_banzi_info_list,
            "center_banzi_info_list":center_banzi_info_list,
            "speical_cur_box_info_list":speical_cur_box_info_list,

            "m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map":ComFunc.Format_Save_OBJ_Map(this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map),
      
            "m_bottom_panzi_perci_shumu_count_map":ComFunc.Format_Save_OBJ_Map(this.m_bottom_panzi_perci_shumu_count_map),
      
            "m_gk_cur_wave_can_show_drink_id_map":ComFunc.Format_Save_OBJ_Map(this.m_gk_cur_wave_can_show_drink_id_map)
       

            
    
        }
 
  
       
    
      
    

        var sfilename = this.Get_Save_Game_Ju_Filename();

        MyLocalStorge.setItem(sfilename,JSON.stringify(pobj));
    }
    Save_Cur_Gk_Info_Common()
    {



        if(this.m_b_game_ended)
        {
            return;
        }
        if(this.m_jiba_lv <= 1)
        {
            return;
        }

        if(!this.m_b_inited)
        {
            return;
        }

        var center_logic_pos_has_diaoluo_jinbi_list = [];

        for(var tt=0;tt<this.m_center_logic_pos_has_diaoluo_jinbi_map.size();tt++)
        {
            var tt_logic_pos=  this.m_center_logic_pos_has_diaoluo_jinbi_map.GetKeyByIndex(tt);
            center_logic_pos_has_diaoluo_jinbi_list.push(
                {
                    x:tt_logic_pos[0],
                    y:tt_logic_pos[1]
                }
            )

        }

        var bottom_banzi_info_list = [];

        for(var gg=0;gg<this.m_bottom_pos_banzi_info_map.size();gg++)
        {
            var gg_poos_index = this.m_bottom_pos_banzi_info_map.GetKeyByIndex(gg);
            var ff_bottom_banzi:guaishou_juba_Banzi_Info = this.m_bottom_pos_banzi_info_map.GetEntryByIndex(gg);
            var ff_left_jiubei_type_list = ff_bottom_banzi.Get_Left_Jubei_Type_List();

            bottom_banzi_info_list.push(
                {
                    pos:gg_poos_index,
                    jiubei_list:ff_left_jiubei_type_list
                }
            )
        }

        
        var center_banzi_info_list = [];

        for(var ff=0;ff<this.m_center_pos_banzi_info_map.size();ff++)
        {
            var ff_center_pos = this.m_center_pos_banzi_info_map.GetKeyByIndex(ff);
            var ff_banziinfo :guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.GetEntryByIndex(ff);
            var ff_left_type_list = ff_banziinfo.Get_Left_Jubei_Type_List();


            center_banzi_info_list.push(
                {
                    logicpos:[ff_center_pos[0],ff_center_pos[1]],
                    jiubei_list:ff_left_type_list
                }
            )
        }


        var speical_cur_box_info_list = [];

        for(var jj=0;jj<this.m_gk_pos_index_speical_cur_box_info_map.size();jj++)
        {
            var jj_cellindex =  this.m_gk_pos_index_speical_cur_box_info_map.GetKeyByIndex(jj);
            var jj_boxinfo:Juba_Game_Spcieal_Pos_Info = this.m_gk_pos_index_speical_cur_box_info_map.GetEntryByIndex(jj);

            var jj_type = jj_boxinfo.itype;
            var jj_icount = jj_boxinfo.icount;

            var per_speicalitem = {
                "cellindex":jj_cellindex,
                "itype":jj_type,
                "ic":jj_icount
            }
            speical_cur_box_info_list.push(per_speicalitem);
        }


        var pobj  = 
        {
            "igk":this.m_jiba_lv,
            "m_cur_lv_wave":this.m_cur_lv_wave,
            "m_top3_pos_unlocked_map":ComFunc.Format_Save_OBJ_Map(this.m_top3_pos_unlocked_map),
            "m_top3_pos_guest_id_map":ComFunc.Format_Save_OBJ_Map(this.m_top3_pos_guest_id_map),
            "m_top3_pos_left_need_finish_drink_count_map":ComFunc.Format_Save_OBJ_Map(this.m_top3_pos_left_need_finish_drink_count_map),
            "m_top3_pos_need_finish_drink_id_map":ComFunc.Format_Save_OBJ_Map(this.m_top3_pos_need_finish_drink_id_map),
            "m_top_guest_id_exist_count_map":ComFunc.Format_Save_OBJ_Map(this.m_top_guest_id_exist_count_map),
      
            "m_gk_finished_guest_jiubei_count":this.m_gk_finished_guest_jiubei_count,

            "m_cur_game_jinbi":this.m_cur_game_jinbi,
            "m_last_show_game_guest_id":this.m_last_show_game_guest_id,
            "m_last_show_game_guest_valid_index":this.m_last_show_game_guest_valid_index,

            "m_gk_cur_wave_has_Finished_drink_count":this.m_gk_cur_wave_has_Finished_drink_count,
            "m_gk_cur_wave_diaoluoed_jinbi_count":this.m_gk_cur_wave_diaoluoed_jinbi_count,
            "center_logic_pos_has_diaoluo_jinbi_list":center_logic_pos_has_diaoluo_jinbi_list,
            "bottom_banzi_info_list":bottom_banzi_info_list,
            "center_banzi_info_list":center_banzi_info_list,
            "speical_cur_box_info_list":speical_cur_box_info_list,

            "m_cur_gk_show_new_drinkid_map":ComFunc.Format_Save_OBJ_Map(this.m_cur_gk_show_new_drinkid_map),
          
            "m_gk_cur_wave_existed_top3_drink_id_count_map":ComFunc.Format_Save_OBJ_Map(this.m_gk_cur_wave_existed_top3_drink_id_count_map),
            "m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map":ComFunc.Format_Save_OBJ_Map(this.m_gk_cur_wave_existed_bottom_panzi_drink_id_count_map),
      
            "m_bottom_panzi_perci_shumu_count_map":ComFunc.Format_Save_OBJ_Map(this.m_bottom_panzi_perci_shumu_count_map)
      
            

    
        }
        var sfilename = this.Get_Save_Game_Ju_Filename();

        MyLocalStorge.setItem(sfilename,JSON.stringify(pobj));
    }
   
    Check_Bottom_Empty()
    {
        this.m_b_in_dealing_animate = 0; 

        if(this.m_bottom_pos_banzi_info_map.size() > 0)
        {
            this.On_Move_End_Deal_Finished();
            return;
        }
        var self=  this;
        var pseq = cc.sequence(cc.delayTime(0.5),cc.callFunc(()=>
        {
            self.Recreate_Bottom_Pabzi();

            self.On_Move_End_Deal_Finished();

        }));
      
        this.m_parent_game_node.runAction(pseq);

        
        
    }
    IS_TiaozhanMode_Cur_Wave_End()
    {
        for(var ff=0;ff<this.m_tiaozhan_top_drink_info_list.length;ff++)
        {
            var ff_drinkinfo = this.m_tiaozhan_top_drink_info_list[ff];
            if(!ff_drinkinfo.m_existed)
            {
                return 0;
            }
        }
        return 1;
    }
    On_Deal_With_Moveing_Center_Cell_End()
    {
        var self = this;
  
        if(this.m_enter_game_mode == 2)
        {
            //挑战模式
            var bcur_wave_end = this.IS_TiaozhanMode_Cur_Wave_End();

            if(bcur_wave_end)
            {
                //
               
                this.On_Tioazhan_Wave_End(()=>
                {
 

                    if(self.m_cur_tiaozhan_wav >= 5)
                    {
                        self.Notify_Game_Success();
                        return;
                    }
                    else{

                        self.m_cur_tiaozhan_wav++;
                        self.On_Tioazhan_Wave_Change();

                        self.Recreate_Tiaozhan_Top_Drink_Info_On_Change_Wave();
                        self.Check_Bottom_Empty();
                    }

                    
                })

            }
            else{
                this.Check_Bottom_Empty();
            }

        }else{
            this.Check_Bottom_Empty();
        }
    }
    Touchu_End_Deal(last_move_to_center_logic_pos)
    {
        this.m_b_in_dealing_animate = 1;

        this.m_parent_game.Notify_Touch_End_Deal_Start(last_move_to_center_logic_pos);

        var self = this;
        //判断是否结束了 
        this.Deal_With_Moveing_Center_Near_Cell(last_move_to_center_logic_pos,()=>
        {
            self.On_Deal_With_Moveing_Center_Cell_End();

            
        })
    }

    //获得logic_pos这个位置的酒杯类型列表
    Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(logic_pos,all_logic_has_jiubei_type_map)
    {
        for(var ff=0;ff<all_logic_has_jiubei_type_map.size();ff++)
        {
            var ff_logic = all_logic_has_jiubei_type_map.GetKeyByIndex(ff);
            var ff_jibeitypelist = all_logic_has_jiubei_type_map.GetEntryByIndex(ff);

            if(ff_logic[0] == logic_pos[0] && ff_logic[1] == logic_pos[1])
            {
                return ff_jibeitypelist;
            }
        }

        return [];
    }


    Is_LogicPos_In_Logic_Pos_List(logicpos_list,logicpos)
    {
        for(var ff=0;ff<logicpos_list.length;ff++)
        {
            var ff_logic_pso = logicpos_list[ff];

            if(ff_logic_pso[0] == logicpos[0] && ff_logic_pso[1] == logicpos[1])
            {
                return true;
            }
        }

        return false;
    }

     
    
    Get_Logic_Pos_Xianglian_Same_Jiubei_Type_Logic_Pos_List(src_logic_x,src_logic_y,ijiubei_type,all_logic_has_jiubei_type_map)
    {
        var direct_xianglian_pos_lsit = this.Get_Logic_Pos_Direct_Line_Xianglian_Same_Jiubei_Type_Logic_Pos_List(src_logic_x,src_logic_y,ijiubei_type,all_logic_has_jiubei_type_map);

        //只有1个，说明周边直接相邻的都没有，肯定也不会有二次扩展的
        if(direct_xianglian_pos_lsit.length <= 1)
        {
            return direct_xianglian_pos_lsit;
        }
        // /再加个判断有没有其他位置和这个直接相连的位置相连的二次扩展查找

        for(var ff=0;ff<this.m_center_pos_banzi_info_map.size();ff++)
        {
            var ff_logic_pos = this.m_center_pos_banzi_info_map.GetKeyByIndex(ff);

            //已经在列表里面了
            if(this.Is_LogicPos_In_Logic_Pos_List(direct_xianglian_pos_lsit,ff_logic_pos))
            {
                continue;
            }
            var ff_logic_pos_jiubei_klist = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(ff_logic_pos,all_logic_has_jiubei_type_map);

            //没有这个酒杯类型
            if(!ComFunc.arrayShuzuContain(ff_logic_pos_jiubei_klist,ijiubei_type))
            {
                continue;
            }

            //判断是否与上面
            var bxiangliaN = MoveLogicMng.Is_LogicPos_XiangLing_With_Logic_Pos_List(ff_logic_pos,ff_logic_pos_jiubei_klist)

            if(bxiangliaN)
            {
                direct_xianglian_pos_lsit.push(ff_logic_pos);
            }
        }


        return direct_xianglian_pos_lsit;
    }

    //与src_logic_x,src_logic_y这个点相同的x,y两条线上，有ijiubei_type这个酒杯类型直接相连的位置列表
    Get_Logic_Pos_Direct_Line_Xianglian_Same_Jiubei_Type_Logic_Pos_List(src_logic_x,src_logic_y,ijiubei_type,all_logic_has_jiubei_type_map)
    {
        var same_xianglian_pos_list = [];
        same_xianglian_pos_list.push([src_logic_x,src_logic_y]);


        for(var ff=1;ff<=6;ff++)
        {
            var new_x = src_logic_x + ff;
            var newy = src_logic_y;

            if(new_x > 4)
            {
                break;
            }

            var ff_pos1 = [new_x,newy]
            var src_touch_end_pos_jiubei_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(ff_pos1,all_logic_has_jiubei_type_map);

            if(src_touch_end_pos_jiubei_type_list.length == 0)
            {
                break;
            }

            if(!ComFunc.arrayShuzuContain(src_touch_end_pos_jiubei_type_list,ijiubei_type))
            {
                break;
            }
            same_xianglian_pos_list.push(ff_pos1);
        }



        for(var ff=1;ff<=6;ff++)
        {
            var new_x2 = src_logic_x - ff;
            var newy = src_logic_y;

            if(new_x2 <= 0)
            {
                break;
            }

            var ff_pos1 = [new_x2,newy]
            var src_touch_end_pos_jiubei_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(ff_pos1,all_logic_has_jiubei_type_map);

            if(src_touch_end_pos_jiubei_type_list.length == 0)
            {
                break;
            }

            if(!ComFunc.arrayShuzuContain(src_touch_end_pos_jiubei_type_list,ijiubei_type))
            {
                break;
            }
            same_xianglian_pos_list.push(ff_pos1);
        }




        for(var ff=1;ff<=6;ff++)
        {
            var new_x3 = src_logic_x  ;
            var newy1 = src_logic_y - ff;

            if(newy1  <= 0)
            {
                break;
            }

            var ff_pos3 = [new_x3,newy1]
            var src_touch_end_pos_jiubei_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(ff_pos3,all_logic_has_jiubei_type_map);

            if(src_touch_end_pos_jiubei_type_list.length == 0)
            {
                break;
            }

            if(!ComFunc.arrayShuzuContain(src_touch_end_pos_jiubei_type_list,ijiubei_type))
            {
                break;
            }
            same_xianglian_pos_list.push(ff_pos3);
        }


        for(var ff=1;ff<=6;ff++)
        {
            var new_x3 = src_logic_x  ;
            var newy2 = src_logic_y + ff;

            if(newy2 > 6)
            {
                break;
            }

            var ff_pos3 = [new_x3,newy2]
            var src_touch_end_pos_jiubei_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(ff_pos3,all_logic_has_jiubei_type_map);

            if(src_touch_end_pos_jiubei_type_list.length == 0)
            {
                break;
            }

            //没有这个酒杯，断开了
            if(!ComFunc.arrayShuzuContain(src_touch_end_pos_jiubei_type_list,ijiubei_type))
            {
                break;
            }
            same_xianglian_pos_list.push(ff_pos3);
        }


       

        return same_xianglian_pos_list;
    }
    Get_Logic_Pos_List_Jiubei_Type_List(tt_same_logic_pos_list,tt_jiubeitype,all_logic_has_jiubei_type_map)
    {
        var all_count=  0;
        for(var tt=0;tt<tt_same_logic_pos_list.length;tt++)
        {
            var tt_pos = tt_same_logic_pos_list[tt];

            var  tt_jiubei_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(tt_pos,all_logic_has_jiubei_type_map);

            var tt_coutn  = 0;
            for(var gg=0;gg<tt_jiubei_type_list.length;gg++)
            {
                var gg_jiubeitype = tt_jiubei_type_list[gg];
                if(gg_jiubeitype == tt_jiubeitype)
                {
                    tt_coutn++;
                }
            }
            all_count += tt_coutn;

        }

        return all_count;
    }
    Cacute_Moved_New_Jiubei_Info_Map_Step1(last_move_to_center_logic_pos,all_logic_has_jiubei_type_map)
    {
        var new_map = new WMap();

        //首先，得到所有的能连在一起
        var src_touch_end_pos_jiubei_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(last_move_to_center_logic_pos,all_logic_has_jiubei_type_map);

        //放置上去的这个位置的所有存在的酒杯类型
        var src_exost_jiubei_type_map = new WMap();
         
        for(var ff=0;ff<src_touch_end_pos_jiubei_type_list.length;ff++)
        {
            var ff_jiubei_type = src_touch_end_pos_jiubei_type_list[ff];
            src_exost_jiubei_type_map.putData(ff_jiubei_type,1)
        }


        var jiubei_type_has_same_xianglian_logicpos_list_map = new WMap();


        var src_logic_x = last_move_to_center_logic_pos[0];
        var src_logic_y = last_move_to_center_logic_pos[1];


        for(var tt=0;tt<src_exost_jiubei_type_map.size();tt++)
        {
            var tt_jiubei_type = src_exost_jiubei_type_map.GetKeyByIndex(tt);

            //得到从last_move_to_center_logic_pos扩展开，上下直线左右相连的位置.最后再扩展周边一个位置

            var xianglian_has_same_jiubeitype_pos_list = this.Get_Logic_Pos_Xianglian_Same_Jiubei_Type_Logic_Pos_List(src_logic_x,src_logic_y,tt_jiubei_type,all_logic_has_jiubei_type_map);

            if(xianglian_has_same_jiubeitype_pos_list.length > 1)
            {
                jiubei_type_has_same_xianglian_logicpos_list_map.putData(tt_jiubei_type,xianglian_has_same_jiubeitype_pos_list)
            }
        }

        if(jiubei_type_has_same_xianglian_logicpos_list_map.size() == 0)
        {
            return all_logic_has_jiubei_type_map;
        }

        //排序下,优先处理数目最多的
        var jiubeitype_count_map = new WMap();
        var jiubeitype_count_dest_jiubeitype_list_map = new WMap();
        
        for(var tt=0;tt<jiubei_type_has_same_xianglian_logicpos_list_map.size();tt++)
        {
            var tt_jiubeitype = jiubei_type_has_same_xianglian_logicpos_list_map.GetKeyByIndex(tt);
            var tt_same_logic_pos_list = jiubei_type_has_same_xianglian_logicpos_list_map.GetEntryByIndex(tt);

          
            var tt_jiubei_type_count = this.Get_Logic_Pos_List_Jiubei_Type_List(tt_same_logic_pos_list,tt_jiubeitype,all_logic_has_jiubei_type_map);
            jiubeitype_count_map.putData(tt_jiubeitype,tt_jiubei_type_count);

            if(!jiubeitype_count_dest_jiubeitype_list_map.hasKey(tt_jiubei_type_count))
            {
                jiubeitype_count_dest_jiubeitype_list_map.putData(tt_jiubei_type_count,[])
            }

            var oldarr = jiubeitype_count_dest_jiubeitype_list_map.getData(tt_jiubei_type_count);
            oldarr.push(tt_jiubeitype);
            jiubeitype_count_dest_jiubeitype_list_map.putData(tt_jiubei_type_count,oldarr)
        }


        var all_ordered_jiubeitype_list = [];
        var finded_count_map = new WMap();
        while(true)
        {
            var find_max_count = 0;


            for(var ff=0;ff<jiubeitype_count_dest_jiubeitype_list_map.size();ff++)
            {
                var ff_count = jiubeitype_count_dest_jiubeitype_list_map.GetKeyByIndex(ff);
                if(finded_count_map.hasKey(ff_count))
                {
                    continue;
                }

                if(ff_count > find_max_count)
                {
                    find_max_count = ff_count;
                }
            }

            if(find_max_count == 0)
            {
                break;
            }

            finded_count_map.putData(find_max_count,1)
            var dest_jiubei_type_list = jiubeitype_count_dest_jiubeitype_list_map.getData(find_max_count);
            all_ordered_jiubeitype_list = all_ordered_jiubeitype_list.concat(dest_jiubei_type_list);
        }


        var ordered_jiubeitype_has_same_lianxian_logic_pos_map = new WMap();

        for(var hh=0;hh<all_ordered_jiubeitype_list.length;hh++)
        {
            var hh_jiubeitype  =  all_ordered_jiubeitype_list[hh];
            var hh_same_logic_pos_list = jiubei_type_has_same_xianglian_logicpos_list_map.getData(hh_jiubeitype);
            ordered_jiubeitype_has_same_lianxian_logic_pos_map.putData(hh_jiubeitype,hh_same_logic_pos_list)
        }
      

        //接下来，处理

        var all_move_step_info_list = [];

        for(var tt=0;tt<all_logic_has_jiubei_type_map.size();tt++)
        {
            var tt_pos1 = all_logic_has_jiubei_type_map.GetKeyByIndex(tt);
            var tt_jiubei_type_list = all_logic_has_jiubei_type_map.GetEntryByIndex(tt);

            var newspos = [tt_pos1[0],tt_pos1[1]];
            var news_jibei_type_list = tt_jiubei_type_list.slice(0);

            new_map.putData(newspos,news_jibei_type_list)
        }

        //第一步，先把所有相同的类型放到一起去
        for(var tt=0;tt<ordered_jiubeitype_has_same_lianxian_logic_pos_map.size();tt++)
        {
            var tt_jiubeitype = ordered_jiubeitype_has_same_lianxian_logic_pos_map.GetKeyByIndex(tt);
            var tt_same_logic_pos_list = ordered_jiubeitype_has_same_lianxian_logic_pos_map.GetEntryByIndex(tt);

            this.Deal_Move_Same_Type_Jiubei_To_Same_Beizi(tt_jiubeitype,tt_same_logic_pos_list,new_map,all_move_step_info_list,last_move_to_center_logic_pos);
        }

  

        //第二步，检查放好的有没有超过6个的，需不需要放到空的位置回去

        var destpos_min_count_srcpos_map = new WMap();

        for(var ff=0;ff<all_move_step_info_list.length;ff++)
        {
            var ff_info = all_move_step_info_list[ff];
            var ff_src_pos = ff_info[0];
            var ff_dest_pos = ff_info[1];

            
            var ff_src_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(ff_src_pos,new_map);
            var ff_dest_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(ff_dest_pos,new_map);

            if(destpos_min_count_srcpos_map.has_key_By_Logic_Pos(ff_dest_pos))
            {
                 var dest_pos_min_src_pos = destpos_min_count_srcpos_map.get_Data_By_Logic_Pos(ff_dest_pos);
                 var ff_min_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(dest_pos_min_src_pos,new_map);
         
                 if(ff_min_type_list.length > ff_src_type_list.length)
                 {
                    destpos_min_count_srcpos_map.putData(ff_dest_pos,ff_src_pos);
                 }
          
            }else{
                destpos_min_count_srcpos_map.putData(ff_dest_pos,ff_src_pos);
            }

        }


        

        for(var ff=0;ff<all_move_step_info_list.length;ff++)
        {
            var ff_info = all_move_step_info_list[ff];
            var ff_src_pos = ff_info[0];
            var ff_dest_pos = ff_info[1];
            var ff_move_type = ff_info[2];

            var dest_pos_min_src_pos = destpos_min_count_srcpos_map.get_Data_By_Logic_Pos(ff_dest_pos);

            if(dest_pos_min_src_pos[0] != ff_src_pos[0]  ||  ff_src_pos[1] != dest_pos_min_src_pos[1])
            {
                continue;
            }
              

            var ff_src_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(ff_src_pos,new_map);
            var ff_dest_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(ff_dest_pos,new_map);

            if(ff_src_type_list.length > 0 && ff_dest_type_list.length <= 6)
            {
                continue;
            }

            var ff_dest_not_move_type_list = [];
            var ff_same_count = 0;

            for(var gg=0;gg<ff_dest_type_list.length;gg++)
            {
                var gg_type = ff_dest_type_list[gg];
                if(gg_type != ff_move_type)
                {
                    ff_dest_not_move_type_list.push(gg_type);
                }else{
                    ff_same_count++;
                }
            }

            if(ff_dest_not_move_type_list.length == 0  )
            {
                continue;
            }

            var need_move_count = ff_dest_not_move_type_list.length;
            if(need_move_count + ff_src_type_list.length  > 6)
            {
                need_move_count = 6- ff_src_type_list.length ;
            }

            var gg_remove_c = 0;
            var gg_remove_list = [];
            var gg_left_list = [];

            for(var gg=0;gg<ff_dest_type_list.length;gg++)
            {
                var gg_type = ff_dest_type_list[gg];

                if(gg_remove_c >= need_move_count)
                {
                    gg_left_list.push(gg_type);
                }else{
                    if(gg_type != ff_move_type)
                    {
                    
                        gg_remove_c++;
                        gg_remove_list.push(gg_type);
                    }else{
                        gg_left_list.push(gg_type);
                    }
                }
            }


            var new_dest_type_list = this.Sort_JiubeiType_List(gg_left_list);

            var new_src_type_list = ff_src_type_list.concat(gg_remove_list) ;
            new_src_type_list = this.Sort_JiubeiType_List(new_src_type_list);
             

            this.Set_Pos_Jiubei_Type_List(new_map,ff_src_pos,new_src_type_list)
            this.Set_Pos_Jiubei_Type_List(new_map,ff_dest_pos,new_dest_type_list)
        }

        //再做一遍确认没有超过6个的

        for(var ff=0;ff<all_move_step_info_list.length;ff++)
        {
            var ff_info = all_move_step_info_list[ff];
            var ff_src_pos = ff_info[0];
            var ff_dest_pos = ff_info[1];
            var ff_move_type = ff_info[2];

            var ff_src_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(ff_src_pos,new_map);
            var ff_dest_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(ff_dest_pos,new_map);

            if(ff_dest_type_list.length <= 6)
            {

                continue;
            }

            var ff_dest_not_move_type_list = [];
            var ff_same_count = 0;

            for(var gg=0;gg<ff_dest_type_list.length;gg++)
            {
                var gg_type = ff_dest_type_list[gg];
                if(gg_type != ff_move_type)
                {
                    ff_dest_not_move_type_list.push(gg_type);
                }else{
                    ff_same_count++;
                }
            }

            if(ff_dest_not_move_type_list.length == 0  )
            {
                continue;
            }

            var need_move_count = ff_dest_not_move_type_list.length;
            if(need_move_count + ff_src_type_list.length  > 6)
            {
                need_move_count = 6- ff_src_type_list.length ;
            }

            var gg_remove_c = 0;
            var gg_remove_list = [];
            var gg_left_list = [];

            for(var gg=0;gg<ff_dest_type_list.length;gg++)
            {
                var gg_type = ff_dest_type_list[gg];

                if(gg_remove_c >= need_move_count)
                {
                    gg_left_list.push(gg_type);
                }else{
                    if(gg_type != ff_move_type)
                    {
                    
                        gg_remove_c++;
                        gg_remove_list.push(gg_type);
                    }else{
                        gg_left_list.push(gg_type);
                    }
                }
            }


            var new_dest_type_list = this.Sort_JiubeiType_List(gg_left_list);

            var new_src_type_list = ff_src_type_list.concat(gg_remove_list) ;
            new_src_type_list = this.Sort_JiubeiType_List(new_src_type_list);
             

            this.Set_Pos_Jiubei_Type_List(new_map,ff_src_pos,new_src_type_list)
            this.Set_Pos_Jiubei_Type_List(new_map,ff_dest_pos,new_dest_type_list)

        }





        return new_map;
    }

    Deal_Move_Same_Type_Jiubei_To_Same_Beizi(tt_jiubeitype,tt_same_logic_pos_list,new_map,all_move_step_info_list,last_move_to_center_logic_pos)
    {
        while(true)
        {
            var tt_all_c = 0;
            var tt_max_logic_pos_c =  0;
            var tt_max_logic_pos = null;

            var tt_max_logic_pos_c_Expcet_cur_fz_pos =  0;
            var tt_max_logic_pos_Expcet_cur_fz_pos = null;



            var tt_max_only_cur_type_logic_pos_c =  0;
            var tt_max_only_cur_type__logic_pos = null;


            for(var hh=0;hh<tt_same_logic_pos_list.length;hh++)
            {
                var hh_logic_pos = tt_same_logic_pos_list[hh];
                var hh_jiubeitype_pos_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(hh_logic_pos,new_map);

                var hh_has_type_c = 0;

                for(var jj=0;jj<hh_jiubeitype_pos_list.length;jj++)
                {
                    var jj_type=  hh_jiubeitype_pos_list[jj];
                    if(jj_type == tt_jiubeitype)
                    {
                        hh_has_type_c++;
                    }
                }
                tt_all_c += hh_has_type_c;

                if(hh_has_type_c >= 6)//已经全部是同一个类型了
                {
                    continue;
                }

                //满了
                if(hh_jiubeitype_pos_list.length >= 6)
                {
                    continue;
                }

                if(hh_has_type_c > tt_max_logic_pos_c )
                {
                    tt_max_logic_pos_c=  hh_has_type_c;
                    tt_max_logic_pos = hh_logic_pos;
                }


                //不是放置的最大数目的酒杯位置
                if(hh_has_type_c > tt_max_logic_pos_c_Expcet_cur_fz_pos  && !this.IsSameLogicPos(last_move_to_center_logic_pos,hh_logic_pos) )
                {
                    tt_max_logic_pos_c_Expcet_cur_fz_pos=  hh_has_type_c;
                    tt_max_logic_pos_Expcet_cur_fz_pos = hh_logic_pos;
                }
                

                if(hh_has_type_c == hh_jiubeitype_pos_list.length)
                {
                    //只有这一种类型
                    if(hh_has_type_c > tt_max_only_cur_type_logic_pos_c && !this.IsSameLogicPos(last_move_to_center_logic_pos,hh_logic_pos))
                    {
                        tt_max_only_cur_type_logic_pos_c = hh_has_type_c;
                        tt_max_only_cur_type__logic_pos = hh_logic_pos;
                    }
                }
            }

            if(!tt_max_logic_pos)
            {
                break;
            }
 
           // var tt_max_count_logic_pos = jiubei_type_in_max_count_logic_pos_map.getData(tt_jiubeitype);
          //  var tt_max_only_cur_type_count_logic_pos = jiubei_type_in_max_count_only_cur_type_logic_pos_map.getData(tt_jiubeitype);

            var tt_moveto_pos = tt_max_logic_pos_Expcet_cur_fz_pos;
            if(tt_max_only_cur_type__logic_pos)
            {
                tt_moveto_pos = tt_max_only_cur_type__logic_pos;
            }

            if(!tt_moveto_pos)
            {
                tt_moveto_pos =  tt_max_logic_pos;
            }


            var dealed_pos_list = [];
            dealed_pos_list.push(tt_moveto_pos);

            var bhasmoved  = false;

            for(var uu=0;uu<tt_same_logic_pos_list.length;uu++)
            {
                var uu_pos  = tt_same_logic_pos_list[uu];
                if(this.IsSameLogicPos(uu_pos,tt_moveto_pos))
                {
                    continue;
                }


                var uu_moed = this.Move_JiubeiType_To_Step1(tt_jiubeitype,uu_pos,tt_moveto_pos,new_map,all_move_step_info_list)

                if(uu_moed)
                {
                    bhasmoved = true;
                }
            }

            if(!bhasmoved)
            {
                break;
            }
        }
    }
    Move_JiubeiType_To_Step1(ijiubeitype,src_pos,destpos,new_map,all_move_step_info_list)
    {

        var dest_jiubei_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(destpos,new_map);
       var dest_same_count = 0;
       for(var ff=0;ff<dest_jiubei_type_list.length;ff++)
       {
            var ff_type = dest_jiubei_type_list[ff];
            if(ff_type == ijiubeitype)
            {
                dest_same_count++;
            }
       } 

       if(dest_same_count >= 6)
       {
            return false;
       }
       if(dest_same_count  == 0)
       {
            return false;
       }

       var src_jiubei_type_list = this.Find_Jiubeitype_list_From_Logic_Pos_JiubeiType_Map(src_pos,new_map);
    
       var src_same_count = 0;
       for(var ff=0;ff<src_jiubei_type_list.length;ff++)
       {
            var ff_type = src_jiubei_type_list[ff];
            if(ff_type == ijiubeitype)
            {
                src_same_count++;
            }
       } 

       if(src_same_count == 0)
       {
            return false;
       }
       if(src_same_count == 6)//已经满了，还移动啥
       {
            return false;
       }
       var need_move_count = src_same_count;
       if(need_move_count + dest_same_count > 6)
       {
            need_move_count = 6-dest_same_count;
       }

       var reomoeved_c = 0;
       var src_new_type_list = [];

       for(var ff=0;ff<src_jiubei_type_list.length;ff++)
       {
            var ff_type = src_jiubei_type_list[ff];
            if(ff_type == ijiubeitype)
            {
                 if(reomoeved_c >= need_move_count)
                 {
                    src_new_type_list.push(ff_type)
                 }else{
                    reomoeved_c++;
                 }
            }else{
                src_new_type_list.push(ff_type)
            }
       } 

       var front_arr = [];
       for(var tt=0;tt<reomoeved_c;tt++)
       {
            front_arr.push(ijiubeitype);
       }

       var new_dest_type_list = front_arr.concat(dest_jiubei_type_list);

       src_new_type_list = this.Sort_JiubeiType_List(src_new_type_list);
       new_dest_type_list = this.Sort_JiubeiType_List(new_dest_type_list);

       this.Set_Pos_Jiubei_Type_List(new_map,src_pos,src_new_type_list)
       this.Set_Pos_Jiubei_Type_List(new_map,destpos,new_dest_type_list)

       //第一次移动，将所有相同的移动到相应位置去，先不管超过或者空位的
       all_move_step_info_list.push([src_pos,destpos,ijiubeitype,reomoeved_c])


        return true;
    }

    Set_Pos_Jiubei_Type_List(new_map:WMap,destpos,new_dest_type_list)
    {
        var exist_one = false;
        for(var ff=0;ff<new_map.size();ff++)
        {
            var ff_pos = new_map.GetKeyByIndex(ff);

            if(ff_pos[0] == destpos[0] &&  ff_pos[1] == destpos[1])
            {
                new_map.DeleteFromArrayByIndex(ff);
                exist_one=  true;
                break;
            }
        }

        new_map.putData(destpos,new_dest_type_list)
    }
    IsSameLogicPos(pos1,pos2)
    {

        if(pos1[0] == pos2 [0 ]  && pos1[1] == pos2[1])
        {
            return true;
        }

        return false;
    }
    Get_In_Bar_SubIndex_Pos(ipos)
    {
        if(ipos == 1)
        {
            return new cc.Vec2(-51,13);
        }

        if(ipos == 2)
        {
            return new cc.Vec2(0,13);
        }
        if(ipos == 3)
        {
            return new cc.Vec2(55,13);
        }
        if(ipos == 4)
        {
            return new cc.Vec2(-51,-27);
        }

        if(ipos == 5)
        {
            return new cc.Vec2(0,-27);
        }
        if(ipos == 6)
        {
            return new cc.Vec2(55,-27);
        }


        return new cc.Vec2(0,0)
    }
    Get_Logic_Pos_SubIndex_Real_Pos(logicpos,isubindex)
    {
        var center_pos = this.Get_Logic_Pos_Center_Real_World_Pos(logicpos[0],logicpos[1]);
        var ipos = isubindex+1;

        var subpos = this.Get_In_Bar_SubIndex_Pos(ipos);

        var ix = center_pos.x + subpos.x;
        var iy = center_pos.y + subpos.y;

        return new cc.Vec2(ix,iy)
    }

    Add_Per_Move_Info_Anim(ff_info:juba_PerMoveInfo )
    {
        var center_wuping_node = cc.find("wuping/moveinfo",this.m_parent_game_node)

       

    //    var jiubei_preab = juba_Game_Mng.GetInstance().m_jiubei_preab ;
        var ff_start_logic_pos = ff_info.start_move_pos;
        var ff_start_index = ff_info.start_move_index;
        var ff_jiubei_type = ff_info.move_value;

        var ff_preab_name = "guaishou_jiubei_Preab_"+ff_jiubei_type;
        var ff_preab = juba_Game_Mng.GetInstance().Get_Preab_By_Name(ff_preab_name)
      
        var ff_banziinfo:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.get_Data_By_Logic_Pos(ff_start_logic_pos);
        ff_banziinfo.Show_Hide_Index_Jiubei(ff_start_index,false);


        
        var ff_dest_logic_pos = ff_info.dest_move_pos;
        var ff_dest_index = ff_info.dest_move_index;

        var ff_banziinfo2:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.get_Data_By_Logic_Pos(ff_dest_logic_pos);
        ff_banziinfo2.Show_Hide_Index_Jiubei(ff_dest_index,false);


        var ff_ndoe = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node(ff_preab_name,ff_preab);
        ff_ndoe.active = true;
        ff_ndoe.scale = 1;
     
        
        center_wuping_node.addChild(ff_ndoe,50);

      //  var jiubei_preab:jiubei_preab = ff_ndoe.getComponent("jiubei_preab")
    
    //  var jiubei_icon_node:cc.Node = cc.find("w",ff_ndoe);
    //  BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("jiubei_xunlian",jiubei_icon_node,"drink/"+ff_jiubei_type,{width:70,height:70})



        /*
        for(var tt=1;tt<=7;tt++)
        {
            var tt_node = cc.find(""+tt,ff_ndoe);
            tt_node.active = false;

            if(tt == ff_jiubei_type)
            {
                tt_node.active = false;
            }
        }
        */


        var startpso =  this.Get_Logic_Pos_SubIndex_Real_Pos(ff_start_logic_pos,ff_start_index)
        ff_ndoe.setPosition(startpso);


  
        var destpos =  this.Get_Logic_Pos_SubIndex_Real_Pos(ff_dest_logic_pos,ff_dest_index);

        var pmoveto =  cc.moveTo(0.2,destpos);

        var pseq =  cc.sequence(cc.targetedAction(ff_ndoe,pmoveto),cc.callFunc(()=>
        {
            NodeComPoolUtils.GetInstance().putANode(ff_preab_name,ff_ndoe)
            //ff_ndoe.destroy();
        }));

        this.m_parent_game_node.runAction(pseq);
     
    }
    Do_Move_Jiubei_Anim(move_pos_info_list)
    {
       
        for(var ff=0;ff<move_pos_info_list.length;ff++)
        {
            var ff_info:juba_PerMoveInfo = move_pos_info_list[ff];

            this.Add_Per_Move_Info_Anim(ff_info );
        }






    }
    Deal_With_Moveing_Center_Near_Cell(last_move_to_center_logic_pos,callback)
    {

        var all_logic_has_jiubei_type_map = new WMap();

        for(var ff=0;ff<this.m_center_pos_banzi_info_map.size();ff++)
        {
            var ff_logic_pos = this.m_center_pos_banzi_info_map.GetKeyByIndex(ff);
            var ff_banzi :guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.GetEntryByIndex(ff);
            var jiubei_type_list = ff_banzi.Get_Left_Jubei_Type_List();

            if(jiubei_type_list.length > 0)
            {
                all_logic_has_jiubei_type_map.putData(ff_logic_pos,jiubei_type_list);
            }
        }



         var new_map1:WMap = this.Cacute_Moved_New_Jiubei_Info_Map_Step1(last_move_to_center_logic_pos,all_logic_has_jiubei_type_map)

         var new_map:WMap = MoveLogicMng.Deal_Move_Xiangling_Logic_Pos_Same_Jiubei(new_map1);

         var changed_pos_map = new WMap();


         for(var ff=0;ff<all_logic_has_jiubei_type_map.size();ff++)
         {
            var ff_pos = all_logic_has_jiubei_type_map.GetKeyByIndex(ff);
            var ff_jiuba_type_list  = all_logic_has_jiubei_type_map.GetEntryByIndex(ff);

            var ff_new_jiubei_Type_list = new_map.get_Data_By_Logic_Pos(ff_pos);

            var ff_bsame = this.IS_Same_Jiubei_Type_List(ff_jiuba_type_list,ff_new_jiubei_Type_list);

            if(!ff_bsame)
            {
                changed_pos_map.putData(ff_pos,[ff_jiuba_type_list.slice(0),ff_new_jiubei_Type_list.slice(0)])
            }
         }



         var move_pos_info_list =  MoveLogicMng.Cacualte_Move_Pos_Info_List(changed_pos_map);



         var self = this;
    
         if(move_pos_info_list.length== 0)
         {
            var pseq = cc.sequence(cc.delayTime(0.2),cc.callFunc(()=>
            {

                self.ReGenerate_Center_Pos_Banzi_Info(new_map);


             


                self.Check_Remove_Full_And_empty_Pos(()=>
                {
                   callback();
                });
            }));


            this.m_parent_game_node.runAction(pseq);
         }
         else{

            var pseq = cc.sequence(cc.delayTime(0.2),
            cc.callFunc(()=>
            {

                self.Do_Move_Jiubei_Anim(move_pos_info_list);

                
                if(move_pos_info_list.length >= 3)
                {
                    BackGroundSoundUtils.GetInstance().Play_Effect("jiubei/kuaisi_mv",1);
                }
                else if(move_pos_info_list.length == 2)
                {
                    BackGroundSoundUtils.GetInstance().Play_Effect("jiubei/kuaisi_mv",1);
                }else  if(move_pos_info_list.length == 1) 
                {
                    BackGroundSoundUtils.GetInstance().Play_Effect("jiubei/kuaisi_mv",1);
                }
        
            }),
            cc.delayTime(0.2),
             cc.callFunc(()=>
            {

                self.ReGenerate_Center_Pos_Banzi_Info(new_map);



 

                self.Check_Remove_Full_And_empty_Pos(()=>
                {
                   callback();
                });
            }));


            this.m_parent_game_node.runAction(pseq);
         }

    

         //callback();
    }
    IS_Same_Jiubei_Type_List(srcjiuba_type_list, new_jiubei_Type_list)
    {

        if(srcjiuba_type_list.length != new_jiubei_Type_list.length)
        {
            return false;
        }

        for(var tt=0;tt<srcjiuba_type_list.length;tt++)
        {
            var ff_D1 = srcjiuba_type_list[tt];
            var ff_D2 = new_jiubei_Type_list[tt];

            if(ff_D1 !=  ff_D2)
            {
                return false;
            }
        }

        return true;
    }

    Check_Remove_Full_And_empty_Pos_Tiaozhan_Mode(cb)
    {

        var self = this;
        var need_remove_logic_pos_list_empty = [];
        var need_remove_logic_pos_list_full = [];



        for(var ff=0;ff<this.m_center_pos_banzi_info_map.size();ff++)
        {
            var ff_center_pos = this.m_center_pos_banzi_info_map.GetKeyByIndex(ff);
            var ff_banziinfo :guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.GetEntryByIndex(ff);
            var ff_left_type_list = ff_banziinfo.Get_Left_Jubei_Type_List();

            if(ff_left_type_list.length == 0)
            {
                need_remove_logic_pos_list_empty.push(ff_center_pos);
            }

            
            if(ff_left_type_list.length == 6)
            {
                var bsame_count = 1;
                var first_c = ff_left_type_list[0];

                for(var jj=0;jj<ff_left_type_list.length;jj++)
                {
                    var jj_v=  ff_left_type_list[jj];
                    if(jj_v != first_c)
                    {

                        bsame_count = 0;
                    }
                }

                if(bsame_count)
                {
                    need_remove_logic_pos_list_full.push(ff_center_pos);
                }
            }
        }


        for(var ff=0;ff<need_remove_logic_pos_list_empty.length;ff++)
        {
            var ff_pos = need_remove_logic_pos_list_empty[ff];
            var ff_banziinfo:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.get_Data_By_Logic_Pos(ff_pos);
            ff_banziinfo.Del_Info();
            this.m_center_pos_banzi_info_map.Remove_By_Logic_Pos(ff_pos);
        }



        if(need_remove_logic_pos_list_full.length == 0)
        {
            var left_empty_kongwei_couint = this.Get_Left_Kongwei_Count();
            if(left_empty_kongwei_couint == 1)
            {
                BaseUIUtils.ShowTipTxtDlg("只有一个空位了",this.m_parent_game_node)
            }

            cb();
            return;
        }


        var remove_logic_pos_jiubeitype_map = new WMap()
        var removed_jiubei_type_count_map = new WMap();

        var remove_pos_dest_to_top_drink_info_map = new WMap();

        var tiaozhan_top_drink_index_used_map =  new WMap();

        var del_top3_c = 0;

        

        for(var ff=0;ff<need_remove_logic_pos_list_full.length;ff++)
        {
            var ff_pos = need_remove_logic_pos_list_full[ff];
            var ff_banziinfo:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.get_Data_By_Logic_Pos(ff_pos);
            var ff_left_type_list = ff_banziinfo.Get_Left_Jubei_Type_List();

            var first_c = ff_left_type_list[0];

            remove_logic_pos_jiubeitype_map.putData(ff_pos,first_c)

            if(!removed_jiubei_type_count_map.hasKey(first_c))
            {
                removed_jiubei_type_count_map.putData(first_c,1)

            }else{
                var ff_prevc = removed_jiubei_type_count_map.getData(first_c);
                removed_jiubei_type_count_map.putData(first_c,1+ff_prevc)
            }

            var find_jiubei_type_to_top_drink_info:Per_Tiaozhan_Top_Drink_Info = null;

            for(var tt=0;tt<this.m_tiaozhan_top_drink_info_list.length;tt++)
            {
                var tt_drinkinfo:Per_Tiaozhan_Top_Drink_Info  = this.m_tiaozhan_top_drink_info_list[tt];
                if(tt_drinkinfo.m_existed)
                {
                    continue;
                }
                var tt_idnex = tt_drinkinfo.m_cur_index;

                if(tiaozhan_top_drink_index_used_map.hasKey(tt_idnex))
                {
                    continue;
                }
                var tt_id = tt_drinkinfo.m_drink_id;


                if(tt_id != first_c)
                {
                    //酒杯类型不同
                    continue;
                }
                find_jiubei_type_to_top_drink_info = tt_drinkinfo;
                break;
            }


            if(find_jiubei_type_to_top_drink_info)
            {
                 var find_idnesx = find_jiubei_type_to_top_drink_info.m_cur_index;
                 tiaozhan_top_drink_index_used_map.putData(find_idnesx,1);

                 remove_pos_dest_to_top_drink_info_map.putData(ff_pos,find_jiubei_type_to_top_drink_info);
                 del_top3_c++;
            }else{
                remove_pos_dest_to_top_drink_info_map.putData(ff_pos,null)
            }

            /*
            var dest_to_top_pos=  0;
            if(top3_jiubeitype_pos_map.hasKey(first_c))
            {
                dest_to_top_pos = top3_jiubeitype_pos_map.getData(first_c);
                del_top3_c++;
            }

            remove_pos_dest_to_top3_pos_map.putData(ff_pos,dest_to_top_pos);
            */
        }

        this.m_tiaozhan_total_finished_jiubei_count += del_top3_c;


        var last_delytime = 0.5;
        if(del_top3_c > 0)
        {
            last_delytime =1.8;
        }

        if(this.m_enter_game_mode == 2)
        {
            last_delytime = 0.3;
        }
   
        var pseq = cc.sequence(cc.delayTime(0.3),
        cc.callFunc(()=>
        {
            for(var ff=0;ff<need_remove_logic_pos_list_full.length;ff++)
            {
                var ff_pos = need_remove_logic_pos_list_full[ff];
                var ff_banziinfo:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.get_Data_By_Logic_Pos(ff_pos);
                var ff_node = ff_banziinfo.m_node;
                ff_node.angle = 0;
                var pseq = cc.sequence(cc.rotateBy(0.1,10),cc.rotateBy(0.2,-20),cc.rotateBy(0.2,20),cc.rotateBy(0.1,-10));

                self.m_parent_game_node.runAction(cc.targetedAction(ff_node,pseq))

            }
        }),cc.callFunc(()=>
        {
            BackGroundSoundUtils.GetInstance().Play_Effect("jiubei/huanhu");
 
        }),cc.delayTime(0.7),
        cc.callFunc(()=>
        {
            var cell_index_removed_map = new WMap();

           
            for(var ff=0;ff<need_remove_logic_pos_list_full.length;ff++)
            {
                var ff_pos = need_remove_logic_pos_list_full[ff];
                var ff_cellindex = self.Translate_Logic_Pos_To_Cell_Index(ff_pos);
                cell_index_removed_map.putData(ff_cellindex,1)
                var ff_banziinfo:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.get_Data_By_Logic_Pos(ff_pos);
                ff_banziinfo.Del_Info();
                this.m_center_pos_banzi_info_map.Remove_By_Logic_Pos(ff_pos);
            }


    
          
        

            //删除周边的盒子
            self.Check_Remove_Full_Cell_Index_Zhoubian_Box(cell_index_removed_map);
    
           
            //增加移动粒子效果，以及掉落现金
            for(var ff=0;ff<remove_pos_dest_to_top_drink_info_map.size();ff++)
            {
                var ff_logic_pos = remove_pos_dest_to_top_drink_info_map.GetKeyByIndex(ff);

                var ff_tiaozhan_drink_infoL:Per_Tiaozhan_Top_Drink_Info  = remove_pos_dest_to_top_drink_info_map.GetEntryByIndex(ff);

                if(!ff_tiaozhan_drink_infoL)
                {
                    self.Add_MoveLizi_From_Center_To_Top(ff_logic_pos,0);
                }
                else{
                    self.Add_Move_Lizi_From_Center_To_Top_Drink_Info(ff_logic_pos,ff_tiaozhan_drink_infoL);
                }
              
 
            }
            
        }),
        cc.delayTime(0.2),
        cc.callFunc(()=>
        {
            BackGroundSoundUtils.GetInstance().Play_Effect("jiubei/finished_p");
         
        }),
        cc.delayTime(0.3),
        cc.callFunc(()=>
        {
            
         
            //解锁歌单一个进度
            for(var ff=0;ff<remove_pos_dest_to_top_drink_info_map.size();ff++)
            {
                var ff_logic_pos = remove_pos_dest_to_top_drink_info_map.GetKeyByIndex(ff);

                var ff_tiaozhan_drink_infoL:Per_Tiaozhan_Top_Drink_Info  = remove_pos_dest_to_top_drink_info_map.GetEntryByIndex(ff);

                if(!ff_tiaozhan_drink_infoL)
                {
                    Juba_Beijing_Gedan_Mng.GetInstance().On_Jiesuo_Add_One_Order();
                }

            }

            self.m_parent_game.Refresh_GeDan_Jindu();
        }),
        cc.delayTime(last_delytime),
         
        cc.callFunc(()=>
            {
                    
                self.Refresh_Top_Guest_Info();
                self.m_parent_game.Refresh_Info();
                cb();
            }
        )
        
        
        );

        this.m_parent_game_node.runAction(pseq);
    }
    Check_Remove_Full_And_empty_Pos(cb)
    {
        if(this.m_enter_game_mode == 2)
        {

            this.Check_Remove_Full_And_empty_Pos_Tiaozhan_Mode(cb)
            return;
        }
        

        var self = this;
        var need_remove_logic_pos_list_empty = [];
        var need_remove_logic_pos_list_full = [];



        for(var ff=0;ff<this.m_center_pos_banzi_info_map.size();ff++)
        {
            var ff_center_pos = this.m_center_pos_banzi_info_map.GetKeyByIndex(ff);
            var ff_banziinfo :guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.GetEntryByIndex(ff);
            var ff_left_type_list = ff_banziinfo.Get_Left_Jubei_Type_List();

            if(ff_left_type_list.length == 0)
            {
                need_remove_logic_pos_list_empty.push(ff_center_pos);
            }

            
            if(ff_left_type_list.length == 6)
            {
                var bsame_count = 1;
                var first_c = ff_left_type_list[0];

                for(var jj=0;jj<ff_left_type_list.length;jj++)
                {
                    var jj_v=  ff_left_type_list[jj];
                    if(jj_v != first_c)
                    {

                        bsame_count = 0;
                    }
                }

                if(bsame_count)
                {
                    need_remove_logic_pos_list_full.push(ff_center_pos);
                }
            }
        }


        for(var ff=0;ff<need_remove_logic_pos_list_empty.length;ff++)
        {
            var ff_pos = need_remove_logic_pos_list_empty[ff];
            var ff_banziinfo:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.get_Data_By_Logic_Pos(ff_pos);
            ff_banziinfo.Del_Info();
            this.m_center_pos_banzi_info_map.Remove_By_Logic_Pos(ff_pos);
        }



        if(need_remove_logic_pos_list_full.length == 0)
        {
            var left_empty_kongwei_couint = this.Get_Left_Kongwei_Count();
            if(left_empty_kongwei_couint == 1)
            {
                BaseUIUtils.ShowTipTxtDlg("只有一个空位了",this.m_parent_game_node)
            }

            cb();
            return;
        }


        var remove_logic_pos_jiubeitype_map = new WMap()
        var removed_jiubei_type_count_map = new WMap();

        var remove_pos_dest_to_top3_pos_map = new WMap();

        var top3_jiubeitype_pos_map =  new WMap();

        var del_top3_c = 0;

        for(var ff=0;ff<this.m_top3_pos_need_finish_drink_id_map.size();ff++)
        {
            var ff_top_pos = this.m_top3_pos_need_finish_drink_id_map.GetKeyByIndex(ff);
            var ff_drinkid = this.m_top3_pos_need_finish_drink_id_map.GetEntryByIndex(ff);
            top3_jiubeitype_pos_map.putData(ff_drinkid,ff_top_pos)
        }

        for(var ff=0;ff<need_remove_logic_pos_list_full.length;ff++)
        {
            var ff_pos = need_remove_logic_pos_list_full[ff];
            var ff_banziinfo:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.get_Data_By_Logic_Pos(ff_pos);
            var ff_left_type_list = ff_banziinfo.Get_Left_Jubei_Type_List();

            var first_c = ff_left_type_list[0];

            remove_logic_pos_jiubeitype_map.putData(ff_pos,first_c)

            if(!removed_jiubei_type_count_map.hasKey(first_c))
            {
                removed_jiubei_type_count_map.putData(first_c,1)

            }else{
                var ff_prevc = removed_jiubei_type_count_map.getData(first_c);
                removed_jiubei_type_count_map.putData(first_c,1+ff_prevc)
            }

            var dest_to_top_pos=  0;
            if(top3_jiubeitype_pos_map.hasKey(first_c))
            {
                dest_to_top_pos = top3_jiubeitype_pos_map.getData(first_c);
                del_top3_c++;
            }

            remove_pos_dest_to_top3_pos_map.putData(ff_pos,dest_to_top_pos);
        }


        var last_delytime = 0.5;
        if(del_top3_c > 0)
        {
            last_delytime =1.8;
        }
   
        var pseq = cc.sequence(cc.delayTime(0.3),
        cc.callFunc(()=>
        {
            for(var ff=0;ff<need_remove_logic_pos_list_full.length;ff++)
            {
                var ff_pos = need_remove_logic_pos_list_full[ff];
                var ff_banziinfo:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.get_Data_By_Logic_Pos(ff_pos);
                var ff_node = ff_banziinfo.m_node;
                ff_node.angle = 0;
                var pseq = cc.sequence(cc.rotateBy(0.1,10),cc.rotateBy(0.2,-20),cc.rotateBy(0.2,20),cc.rotateBy(0.1,-10));

                self.m_parent_game_node.runAction(cc.targetedAction(ff_node,pseq))

            }
        }),cc.callFunc(()=>
        {
            BackGroundSoundUtils.GetInstance().Play_Effect("jiubei/huanhu");
 
        }),cc.delayTime(0.7),
        cc.callFunc(()=>
        {
            
            var cell_index_removed_map = new WMap();

           
            for(var ff=0;ff<need_remove_logic_pos_list_full.length;ff++)
            {
                var ff_pos = need_remove_logic_pos_list_full[ff];
                var ff_cellindex = self.Translate_Logic_Pos_To_Cell_Index(ff_pos);
                cell_index_removed_map.putData(ff_cellindex,1)
                var ff_banziinfo:guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.get_Data_By_Logic_Pos(ff_pos);
                ff_banziinfo.Del_Info();
                this.m_center_pos_banzi_info_map.Remove_By_Logic_Pos(ff_pos);
            }


    
           

        

            //删除周边的盒子
            self.Check_Remove_Full_Cell_Index_Zhoubian_Box(cell_index_removed_map);
    
           
            //增加移动粒子效果，以及掉落现金
            for(var ff=0;ff<remove_pos_dest_to_top3_pos_map.size();ff++)
            {
                var ff_logic_pos = remove_pos_dest_to_top3_pos_map.GetKeyByIndex(ff);

                var fF_top3_index  = remove_pos_dest_to_top3_pos_map.GetEntryByIndex(ff);

                self.Add_MoveLizi_From_Center_To_Top(ff_logic_pos,fF_top3_index);

                self.Check_Add_Del_Logic_Pos_Diaoluo_Jinbi(ff_logic_pos,fF_top3_index);
            }
            
        }),

        cc.delayTime(0.2),
        cc.callFunc(()=>
        {
            BackGroundSoundUtils.GetInstance().Play_Effect("jiubei/finished_p");
         
        }),
        cc.delayTime(0.3),
        cc.callFunc(()=>
        {
            // /移动删除上方的三个酒杯
            self.Chec_Remove_Full_Cell_Top3_Jiubei(removed_jiubei_type_count_map,remove_logic_pos_jiubeitype_map);
    
         
            //解锁歌单一个进度
            for(var ff=0;ff<remove_pos_dest_to_top3_pos_map.size();ff++)
            {
                var ff_logic_pos = remove_pos_dest_to_top3_pos_map.GetKeyByIndex(ff);

                var fF_top3_index  = remove_pos_dest_to_top3_pos_map.GetEntryByIndex(ff);

                if(fF_top3_index == 0)
                {
                    Juba_Beijing_Gedan_Mng.GetInstance().On_Jiesuo_Add_One_Order();
                }

            }

            self.m_parent_game.Refresh_GeDan_Jindu();
        }),
        cc.delayTime(last_delytime),
         
        cc.callFunc(()=>
            {
                    
                self.Refresh_Top_Guest_Info();
                self.m_parent_game.Refresh_Info();
                cb();
            }
        )
        
        
        );

        this.m_parent_game_node.runAction(pseq);

    }

    Get_Left_Kongwei_Count()
    {
        var ikopngweic = 0; 
        for(var tt=0;tt<this.m_center_valid_bk_pos_list.length;tt++)
        {
            var tt_pos = this.m_center_valid_bk_pos_list[tt];
    
            var tt_has = this.m_center_pos_banzi_info_map.has_key_By_Logic_Pos(tt_pos);

            if(!tt_has)
            {
                ikopngweic ++;
            }

        }

        return ikopngweic;
    }

    Check_Add_Del_Logic_Pos_Diaoluo_Jinbi( logic_pos,dest_top3_index)
    {
        if(this.m_b_in_first_gk_yd)
        {
            return;
        }
        if(this.m_gk_cur_wave_diaoluoed_jinbi_count >= 3)
        {
            return;
        }

        if(this.m_center_logic_pos_has_diaoluo_jinbi_map.has_key_By_Logic_Pos(logic_pos))
        {
            return;
        }

        var dialoluogailv = 0.1;
        if(dest_top3_index > 0)
        {
            dialoluogailv = 0.5;
        }

        var irand = this.m_rand_mng.Get_Seed_Index_Next_Random(11);

        var bdiaoluo = 0;
        if(irand <dialoluogailv )
        {
            bdiaoluo = 1;
        }

        if(!bdiaoluo)
        {
            return;
        }

        this.m_gk_cur_wave_diaoluoed_jinbi_count++;
        this.m_center_logic_pos_has_diaoluo_jinbi_map.putData(logic_pos,1)

        this.Refresh_Logci_Pos_Diaoluo_Xianjing_Node();
    }
    Refresh_Logci_Pos_Diaoluo_Xianjing_Node()
    {
        var move_xianjin_preab = this.m_parent_game.move_xianjin_preab;

        var need_remove_logic_map = new WMap();


        for(var ff=0;ff<this.m_center_logic_pos_diaoluo_xianjing_node_map.size();ff++)
        {
            var ff_logic_pos = this.m_center_logic_pos_diaoluo_xianjing_node_map.GetKeyByIndex(ff);
            var ff_node = this.m_center_logic_pos_diaoluo_xianjing_node_map.GetEntryByIndex(ff);

            if(!this.m_center_logic_pos_has_diaoluo_jinbi_map.has_key_By_Logic_Pos(ff_logic_pos))
            {
                need_remove_logic_map.putData(ff_logic_pos,1)
            }
        }
        for(var ff=0;ff<need_remove_logic_map.size();ff++)
        {
            var ff_logic_pos = need_remove_logic_map.GetKeyByIndex(ff);
            var ff_ndoe = this.m_center_logic_pos_diaoluo_xianjing_node_map.get_Data_By_Logic_Pos(ff_logic_pos);

            NodeComPoolUtils.GetInstance().putANode("move_xianjin_preab",ff_ndoe);
            this.m_center_logic_pos_diaoluo_xianjing_node_map.Remove_By_Logic_Pos(ff_logic_pos)
        }


        var center_node = cc.find("wuping/center",this.m_parent_game_node)
        

        for(var ff=0;ff<this.m_center_logic_pos_has_diaoluo_jinbi_map.size();ff++)
        {
            var ff_logic_pos = this.m_center_logic_pos_has_diaoluo_jinbi_map.GetKeyByIndex(ff);
     

            if(!this.m_center_logic_pos_diaoluo_xianjing_node_map.has_key_By_Logic_Pos(ff_logic_pos))
            {
                var ff_real_oos = this.Get_Logic_Pos_Center_Real_World_Pos(ff_logic_pos[0],ff_logic_pos[1])
                 var pxianjinnode = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("move_xianjin_preab",move_xianjin_preab);
                 center_node.addChild(pxianjinnode,20);
                 pxianjinnode.setPosition(ff_real_oos);
                 this.m_center_logic_pos_diaoluo_xianjing_node_map.putData(ff_logic_pos,pxianjinnode)
            }
        }
        
    }

    Add_Move_Lizi_From_Center_To_Top_Drink_Info(logic_pos, tiaozhan_drink_info:Per_Tiaozhan_Top_Drink_Info)
    {
        var dest_node = tiaozhan_drink_info.m_node;
        var dest_pos = ComFunc.NodeWorldPos(dest_node);
        var real_pos = this.Get_Logic_Pos_Center_Real_World_Pos(logic_pos[0],logic_pos[1]);
     
        var move_lizi_preab = this.m_parent_game.move_lizi_preab;

        var effect_node = cc.find("wuping/effect",this.m_parent_game_node)
        var pnode = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("move_lizi_preab", move_lizi_preab);
        effect_node.addChild(pnode,20);
        pnode.setPosition(real_pos);
        pnode.active = true;

        var pseq = cc.sequence(cc.targetedAction(pnode,cc.moveTo(0.5,dest_pos)),cc.callFunc(()=>
        {
            NodeComPoolUtils.GetInstance().putANode("move_lizi_preab",pnode);

            tiaozhan_drink_info.Set_Existed(1);

        }));

        this.m_parent_game_node.runAction(pseq);

        


    }
    Add_MoveLizi_From_Center_To_Top(logic_pos, top3_index)
    {
        var real_pos = this.Get_Logic_Pos_Center_Real_World_Pos(logic_pos[0],logic_pos[1]);
     
     
        var move_lizi_preab = this.m_parent_game.move_lizi_preab;

        var effect_node = cc.find("wuping/effect",this.m_parent_game_node)
        
        var bjyyuebtn_node = cc.find("common_mode/bjyyue/bjyyuebtn",this.m_parent_game_node)
      
        var dest_node = bjyyuebtn_node;

        if(top3_index > 0)
        {
            dest_node= cc.find("common_mode/topbar/"+top3_index+"/com/icon",this.m_parent_game_node)
        }

        var dest_pos = ComFunc.NodeWorldPos(dest_node);

        
        var pnode = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("move_lizi_preab", move_lizi_preab);
        effect_node.addChild(pnode,20);
        pnode.setPosition(real_pos);
        pnode.active = true;

        var pseq = cc.sequence(cc.targetedAction(pnode,cc.moveTo(0.5,dest_pos)),cc.callFunc(()=>
        {
            NodeComPoolUtils.GetInstance().putANode("move_lizi_preab",pnode)
        }));

        this.m_parent_game_node.runAction(pseq)

    }

    Chec_Remove_Full_Cell_Top3_Jiubei(removed_jiubei_type_count_map,remove_logic_pos_jiubeitype_map)
    {

        var gk_basicinfo = juba_Config_Mng.GetInstance().Find_GK_Basci_Info(this.m_jiba_lv);
        var jm = gk_basicinfo.jm;

     
        var top3_pos_has_xiaochued_map = new WMap();
        var deled_pos_map  = new WMap();
        var ireal_removed_top_c=  0;

        //这个男模需要显示聊天
        var need_show_chat_guest_id_map = new WMap();
        var need_show_chat_posid_map = new WMap();

        for(var ff=0;ff<this.m_top3_pos_need_finish_drink_id_map.size();ff++)
        {
            var ff_top3_pos = this.m_top3_pos_need_finish_drink_id_map.GetKeyByIndex(ff);
            var ff_drinkid = this.m_top3_pos_need_finish_drink_id_map.GetEntryByIndex(ff);


            var ff_left_c = this.m_top3_pos_left_need_finish_drink_count_map.getData(ff_top3_pos);
            if(!ff_left_c)
            {
                ff_left_c=  0;
            }

            var cur_removec = 0;
            if(removed_jiubei_type_count_map.hasKey(ff_drinkid))
            {
                cur_removec = removed_jiubei_type_count_map.getData(ff_drinkid);
            }

            ff_left_c -= cur_removec;

            ireal_removed_top_c += cur_removec;

            if(cur_removec > 0 )
            {
                top3_pos_has_xiaochued_map.putData(ff_top3_pos,1);
            }

            if(ff_left_c <= 0)
            {
                deled_pos_map.putData(ff_top3_pos,1)

                var ff_guest_id = this.m_top3_pos_guest_id_map.getData(ff_top3_pos);

                //增加这个guest完成的订单数目 
                if(ff_guest_id > 0)
                {
                    juba_Game_Mng.GetInstance().Add_GuimiID_Finished_Dingdan_Count(ff_guest_id,1);

                    if(need_show_chat_guest_id_map.size() == 0)
                    {
                        var ff_bnned = this.Check_Finish_Order_Guest_Need_Show_Game_Chat(ff_guest_id);

                        if(ff_bnned)
                        {
                            need_show_chat_guest_id_map.putData(ff_guest_id,ff_top3_pos);
                            need_show_chat_posid_map.putData(ff_top3_pos,ff_guest_id);
                        }
                    }
                   
                }
                

            }else{
                this.m_top3_pos_left_need_finish_drink_count_map.putData(ff_top3_pos,ff_left_c);
            }

        }

       

        this.m_gk_finished_guest_jiubei_count += deled_pos_map.size();

        this.m_gk_cur_wave_has_Finished_drink_count += deled_pos_map.size();
         
        var iaddgamejinbi = jm*ireal_removed_top_c;

        this.m_cur_game_jinbi += iaddgamejinbi;


      
        var max_need_c = juba_Config_Mng.GetInstance().Get_Gk_Finish_Need_Jiubei( this.m_jiba_lv)

        if(this.m_gk_finished_guest_jiubei_count >= max_need_c)
        {

            for(var tt=0;tt<top3_pos_has_xiaochued_map.size();tt++)
            {
                var tt_top3_pos_index = top3_pos_has_xiaochued_map.GetKeyByIndex(tt);
        
                var tt_deled_all = 0;
                
                if(deled_pos_map.hasKey(tt_top3_pos_index))
                {
                    tt_deled_all = 1;
                }
    
    
                //
                var tt_icon_ndoe = cc.find("common_mode/topbar/"+tt_top3_pos_index+"/com",this.m_parent_game_node)
    
                var tt_start_pos=  ComFunc.NodeWorldPos(tt_icon_ndoe);
                
                this.Show_Huode_Xianjin_Moveto_JinbiLan_Anim(tt_start_pos);
    
              
                
    
            }
            //关卡胜利
            this.Notify_Game_Success();

            this.Refresh_Top_Guest_Info();
            this.m_parent_game.Refresh_Info();
            return;
        }

        //这一波结束
        if(this.m_gk_cur_wave_has_Finished_drink_count >= this.m_gk_cur_wave_Need_Finished_drink_count )
        {
            this.On_Change_To_GK_Next_Wave();
        }

        var lv_wave_info_arr = juba_Config_Mng.GetInstance().Fing_GK_Wave_Info(this.m_jiba_lv,this.m_cur_lv_wave);
        var wave_need_finish_drink_c = lv_wave_info_arr[3];
        if(!wave_need_finish_drink_c)
        {
            wave_need_finish_drink_c = 1;
        }
        var cur_wave_jiesuo_drinkid = this.Get_GK_Wave_Jiesuo_DrinkID(this.m_jiba_lv,this.m_cur_lv_wave)

        var new_wave_first_show_pos_drinkid_info =  null;
        for(var tt=0;tt<deled_pos_map.size();tt++)
        {
            var tt_pos = deled_pos_map.GetKeyByIndex(tt);

            //不在引导里面，切换上方的guest和饮品
            if(!this.m_b_in_first_gk_yd)
            {
                var show_guest_id  = this.Find_Next_Show_Guest_ID(tt_pos);
                this.m_top3_pos_guest_id_map.putData(tt_pos,show_guest_id);
        
                var nex_show_drink_id_type =  this.Get_Next_Top3_Show_Drink_ID(tt_pos);
    
                this.m_top3_pos_need_finish_drink_id_map.putData(tt_pos,nex_show_drink_id_type)
    
    
            }

          

            this.m_top3_pos_left_need_finish_drink_count_map.putData(tt_pos,wave_need_finish_drink_c);
    


            if(cur_wave_jiesuo_drinkid == nex_show_drink_id_type && cur_wave_jiesuo_drinkid > 0)
            {
                //var icc = this.m_cur_gk_show_new_drinkid_map.getData(nex_show_drink_id_type);
               
                if(!this.m_cur_gk_show_new_drinkid_map.hasKey(nex_show_drink_id_type))
                {
                    this.m_cur_gk_show_new_drinkid_map.putData(nex_show_drink_id_type,1);
                    //第一次出现

                    new_wave_first_show_pos_drinkid_info  =  [tt_pos,cur_wave_jiesuo_drinkid]
                }
            }
        }


        if(new_wave_first_show_pos_drinkid_info)
        {
            //有新品出现，就不显示聊天了
            need_show_chat_guest_id_map.clear();
        }



        for(var tt=0;tt<top3_pos_has_xiaochued_map.size();tt++)
        {
            var tt_top3_pos_index = top3_pos_has_xiaochued_map.GetKeyByIndex(tt);
    
            var tt_deled_all = 0;
            
            if(deled_pos_map.hasKey(tt_top3_pos_index))
            {
                tt_deled_all = 1;
            }


            //
            var tt_icon_ndoe = cc.find("common_mode/topbar/"+tt_top3_pos_index+"/com",this.m_parent_game_node)

            var tt_start_pos=  ComFunc.NodeWorldPos(tt_icon_ndoe);
            
            this.Show_Huode_Xianjin_Moveto_JinbiLan_Anim(tt_start_pos);

            //这个guest完成订单了
            if(tt_deled_all)
            {
                if(!this.m_b_in_first_gk_yd && !need_show_chat_posid_map.hasKey(tt_top3_pos_index))
                {
                    //不在引导中，移动头像出去再回来，并看看是否有新品弹框
                    this.Add_Top3_Guest_Move_Anim(tt_top3_pos_index,new_wave_first_show_pos_drinkid_info);
                }
                
                
            }

        }


        var self = this;
        if(need_show_chat_guest_id_map.size() > 0)
        {
            var need_show_guestid = need_show_chat_guest_id_map.GetKeyByIndex(0);
            var need_show_pos_index = need_show_chat_guest_id_map.GetEntryByIndex(0);

            var people_chatid = juba_Game_Mng.GetInstance().Get_Guest_Next_Show_Chat_ID(this.m_jiba_lv, need_show_guestid);
            this.m_cur_gk_has_showed_chat_guest_id_map.putData(need_show_guestid,1)
            juba_Game_Mng.GetInstance().On_Guest_Game_Chat_Show(this.m_jiba_lv, need_show_guestid,people_chatid)
            this.m_parent_game.Show_People_Chat_Msg_Dlg(need_show_pos_index,need_show_guestid,people_chatid,()=>
            {
                self.Add_Top3_Guest_Move_Anim(need_show_pos_index,null);
            })
        }

        
       // this.Refresh_Top_Guest_Info();
        //this.m_parent_game.Refresh_Info();
    }


    Check_Finish_Order_Guest_Need_Show_Game_Chat( guest_id)
    {
        var people_chatid = juba_Game_Mng.GetInstance().Get_Guest_Next_Show_Chat_ID(this.m_jiba_lv,guest_id);

        if(people_chatid == 0)
        {
            return false;
        }

        //已经显示过聊天了
        if(this.m_cur_gk_has_showed_chat_guest_id_map.size() > 0)
        {
            return false;
        }

          
        if(this.m_gk_finished_guest_jiubei_count < 10)
        {
             return false;
        }
        if(this.m_gk_finished_guest_jiubei_count  > 15)
        {
            return false;
        }


        if(!ComFunc.arrayShuzuContain(this.m_cur_gk_all_can_show_game_chat_guest_id_list,guest_id))
        {
            return false;
        }
    

        return true;
    }
    On_First_GK_Yingdao_Finished_Recreate()
    {
        this.m_b_in_first_gk_yd = 0;

        var tt_pos = 2;
        var show_guest_id  = this.Find_Next_Show_Guest_ID(tt_pos);
        this.m_top3_pos_guest_id_map.putData(tt_pos,show_guest_id);

        var nex_show_drink_id_type =  this.Get_Next_Top3_Show_Drink_ID(tt_pos);

        this.m_top3_pos_need_finish_drink_id_map.putData(tt_pos,nex_show_drink_id_type)

        this.Add_Top3_Guest_Move_Anim(2,null,0.01,0.1);



        this.Recreate_Bottom_Pabzi();
    }
    TestTop(iindex)
    {
        var tt_icon_ndoe = cc.find("common_mode/topbar/"+iindex+"/com",this.m_parent_game_node)

        var tt_start_pos=  ComFunc.NodeWorldPos(tt_icon_ndoe);
        
        this.Show_Huode_Xianjin_Moveto_JinbiLan_Anim(tt_start_pos)

    }

    Add_Top3_Guest_Move_Anim( top3_pos_index,new_wave_first_show_pos_drinkid_info,delytime1 = 0.3,delytime2 = 0.5)
    {
        var com_node = cc.find("common_mode/topbar/"+top3_pos_index+"/com",this.m_parent_game_node)
        var  ren_node = cc.find("common_mode/renwu/"+top3_pos_index+"",this.m_parent_game_node);

        var self = this;
        var ren_pos  = new cc.Vec2(0,340);
        if(top3_pos_index == 1)
        {
            ren_pos  = new cc.Vec2(-225,340);
        }
        else if(top3_pos_index == 3)
        {
            ren_pos  = new cc.Vec2( 225,340);
        }
        
        var pseq = cc.sequence(cc.delayTime(delytime1),
            cc.callFunc(()=>
            {
                com_node.active = false;

                BackGroundSoundUtils.GetInstance().Play_Effect("com/sb_im_ready")
            }),
            cc.delayTime(delytime2),
            cc.callFunc(()=>
            {

                ren_node.runAction(cc.moveTo(0.2,-700,ren_pos.y))
            }),
            cc.delayTime(0.15),
            cc.callFunc(()=>
            {
                self.Refresh_Top_Guest_Info_Index(top3_pos_index);
                com_node.active = false;
            }),
            cc.delayTime(0.2),
            cc.callFunc(()=>
            {
                BackGroundSoundUtils.GetInstance().Play_Effect("com/chupai")
                ren_node.runAction(cc.moveTo(0.2,ren_pos.x,ren_pos.y))
            })
            ,cc.delayTime(0.3),
            cc.callFunc(()=>
            {
                if(new_wave_first_show_pos_drinkid_info && new_wave_first_show_pos_drinkid_info[0] == top3_pos_index)
                {
                    com_node.active = false;
                    self.Pop_Show_New_Drink_Info(new_wave_first_show_pos_drinkid_info);
                }
                else{
                    com_node.active = true;
                }
                
            })
        
        );

        this.m_parent_game_node.runAction(pseq)
    }

    Pop_Show_New_Drink_Info(new_wave_first_show_pos_drinkid_info)
    {
        var top3_pos_index = new_wave_first_show_pos_drinkid_info[0];
        var drinkid = new_wave_first_show_pos_drinkid_info[1];
        


        juba_Game_Mng.GetInstance().On_New_Drink_ID_Show(drinkid);


        this.m_b_show_new_drink_id_top_index = top3_pos_index;
       
        var gk_basicinfo = juba_Config_Mng.GetInstance().Find_GK_Basci_Info(this.m_jiba_lv);
        var sm = ComFunc.Check_Read_Number( gk_basicinfo.sm);


        var self = this;
        var new_jiubei_show_dlg = this.m_parent_game.new_jiubei_show_dlg;

        var pndoe = cc.instantiate(new_jiubei_show_dlg);
      
        var new_jiubei_show_dlg=  pndoe.getComponent("new_jiubei_show_dlg");


        new_jiubei_show_dlg.SetInfo(

            {
                share_money:sm,
                drink_id:drinkid,
                top3_pos_index:top3_pos_index,
                lingqucb:(im)=>
                {
                    self.m_cur_game_jinbi+=im;
                    self.Refresh_Info();
                },
                cb:()=>
                {
                    self.m_b_show_new_drink_id_top_index = 0;
     
                    self.On_Finish_New_Drink_Info_Dlg_Show(drinkid,top3_pos_index);
                }

            }
        )

        this.m_parent_game_node.addChild(pndoe,30);
    }
    On_Finish_New_Drink_Info_Dlg_Show(drinkid,top3_pos_index)
    { 
        var ff_jiubei_type = drinkid;

        var effect_node=  cc.find("wuping/effect",this.m_parent_game_node);

        var ff_preab_name = "guaishou_jiubei_Preab_"+ff_jiubei_type;
        var ff_preab = juba_Game_Mng.GetInstance().Get_Preab_By_Name(ff_preab_name)
    
       // var jiubei_preab = juba_Game_Mng.GetInstance().m_jiubei_preab ;
  
    
 
  

        var ff_ndoe = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node(ff_preab_name,ff_preab);
        ff_ndoe.active = true;
        ff_ndoe.scale = 1;
      //  var ff_ndoe = Node_Pool_Utils.GetInstance().Get_Prab_Name_Node("jiubei_preab",jiubei_preab);
     
        effect_node.addChild(ff_ndoe,50);

      //  var jiubei_preab:jiubei_preab = ff_ndoe.getComponent("jiubei_preab")
    
        var w_node:cc.Node = cc.find("w",ff_ndoe);
      
        if(w_node)
        {
            var sanimname = juba_Config_Mng.GetInstance().Get_Guaishou_Type_Anim_Name(drinkid,1);
            var sp_com = w_node.getComponent(sp.Skeleton);

            if(sp_com)
            {
                sp_com.timeScale = 0.5;
                sp_com.setAnimation(0,sanimname,true)

            }
         
        }


     //   BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("jiubei_xunlian",jiubei_icon_node,"drink/"+ff_jiubei_type,{width:150,height:150})
      
      
      
        ff_ndoe.setPosition(0,0);
     
     
     
        w_node.active = true;


        ff_ndoe.active = true;
        var top_com_node=  cc.find("common_mode/topbar/"+top3_pos_index+"/com",this.m_parent_game_node);
 
        var top_com_icon_node=  cc.find("common_mode/topbar/"+top3_pos_index+"/com/icon",this.m_parent_game_node);
        var dest_pos=  ComFunc.NodeWorldPos(top_com_icon_node);

        var pseq = cc.sequence(cc.targetedAction(ff_ndoe, 
            
            cc.spawn(
                cc.moveTo(0.3,dest_pos),
                cc.scaleTo(0.3,7/15)
            )
            
            ),
        cc.callFunc(()=>
        {
            ff_ndoe.scale = 1;
            NodeComPoolUtils.GetInstance().putANode(ff_preab_name,ff_ndoe);
            top_com_node.active = true;
        })
        
        )

        this.m_parent_game_node.runAction(pseq);
        
    }
    Show_Huode_Xianjin_Moveto_JinbiLan_Anim(startpos)
    {
        
        BackGroundSoundUtils.GetInstance().Play_Effect("com/huode_xianjin",2)
     
        var effect_node=  cc.find("wuping/effect",this.m_parent_game_node)

         
        
       var baoxiang_node=  cc.find("common_mode/topmenu/jinbi/tiao",this.m_parent_game_node)
       var baoxiang_pos = ComFunc.NodeWorldPos(baoxiang_node)

        var lingshi_pos_list = [];
        lingshi_pos_list.push([-50,-18])
        lingshi_pos_list.push([-30,-6])
        lingshi_pos_list.push([35,-40])
        lingshi_pos_list.push([30, 10])
        lingshi_pos_list.push([69, 50])
        lingshi_pos_list.push([30, 60])
        lingshi_pos_list.push([-35, 45]);

        lingshi_pos_list.push([-50,-18])
        lingshi_pos_list.push([-30,-6])
        lingshi_pos_list.push([35,-40]) 
      

   
        var move_xianjin_preab=  this.m_parent_game.move_xianjin_preab;
        for(var ff=0;ff<lingshi_pos_list.length;ff++)
        {
            var ff_pos = lingshi_pos_list[ff];
            var realx = ff_pos[0]+  startpos.x;
            var realy = ff_pos[1]+  startpos.y;

            var pndoe2 = NodeComPoolUtils.GetInstance().Get_Prab_Name_Node("move_xianjin_preab",move_xianjin_preab);
            effect_node.addChild(pndoe2,20);
           // pndoe2.setPosition(realx,realy);
            pndoe2.setPosition(startpos);
 

            this.Add_Move_Fenjie_Daoju_Anim(0.01+ff*0.03,  pndoe2,new cc.Vec2(realx,realy),baoxiang_pos,0.1)
        }


      
 
        
    }
    Add_Move_Fenjie_Daoju_Anim(first_delaytime, pndoe,middlept,lingshi_dest_pos,middledealytime)
    {
        pndoe.active = false;
        var pmove1 = cc.targetedAction(pndoe,cc.moveTo(0.3,middlept));
        var pmove2 = cc.targetedAction(pndoe,cc.moveTo(0.7,lingshi_dest_pos));
        
        var pseq = cc.sequence(
            cc.delayTime(first_delaytime),
            cc.callFunc(()=>
            {
                pndoe.active = true;
     
            }),
            pmove1,
            cc.delayTime(middledealytime),
            pmove2,cc.callFunc(()=>
        {
            NodeComPoolUtils.GetInstance().putANode("move_xianjin_preab",pndoe);
        }));

        this.m_parent_game_node.runAction(pseq);

    }
    Check_Remove_Full_Cell_Index_Zhoubian_Box(cell_index_removed_map)
    {
        var zhoubian_cell_index_removed_count_map = new WMap();

        for(var ff=0;ff<cell_index_removed_map.size();ff++)
        {
            var ff_cell_index=  cell_index_removed_map.GetKeyByIndex(ff);
            var fF_pos  = this.Translate_Cell_Index_To_Logic_Pos(ff_cell_index);
            var ff_logic_x = fF_pos[0] ;
            var ff_logic_y = fF_pos[1] ;

            var cell_index1 = this.Translate_Logic_Pos_To_Cell_Index([ff_logic_x+1,ff_logic_y]);

            if(ff_logic_x >=4)
            {
                cell_index1 = -1;
            }

            var cell_index2 = this.Translate_Logic_Pos_To_Cell_Index([ff_logic_x-1,ff_logic_y])
            if(ff_logic_x  <= 1)
            {
                cell_index2 = -1;
            }


            var cell_index3 = this.Translate_Logic_Pos_To_Cell_Index([ff_logic_x,ff_logic_y+1]);

            if(ff_logic_y >=6)
            {
                cell_index3 = -1;
            }

            var cell_index4 = this.Translate_Logic_Pos_To_Cell_Index([ff_logic_x,ff_logic_y-1]);


            if(ff_logic_y  <= 1)
            {
                cell_index4 = -1;
            }
            

            if(!zhoubian_cell_index_removed_count_map.hasKey(cell_index1))
            {
                zhoubian_cell_index_removed_count_map.putData(cell_index1,1);
            }else{
                var prev1 = zhoubian_cell_index_removed_count_map.getData(cell_index1);
                zhoubian_cell_index_removed_count_map.putData(cell_index1,1+prev1);
            }
 

            if(!zhoubian_cell_index_removed_count_map.hasKey(cell_index2))
            {
                zhoubian_cell_index_removed_count_map.putData(cell_index2,1);
            }else{
                var prev2 = zhoubian_cell_index_removed_count_map.getData(cell_index2);
                zhoubian_cell_index_removed_count_map.putData(cell_index2,1+prev2);
            }
 

            if(!zhoubian_cell_index_removed_count_map.hasKey(cell_index3))
            {
                zhoubian_cell_index_removed_count_map.putData(cell_index3,1);
            }else{
                var prev3 = zhoubian_cell_index_removed_count_map.getData(cell_index3);
                zhoubian_cell_index_removed_count_map.putData(cell_index3,1+prev3);
            }

            if(!zhoubian_cell_index_removed_count_map.hasKey(cell_index4))
            {
                zhoubian_cell_index_removed_count_map.putData(cell_index4,1);
            }else{
                var prev4 = zhoubian_cell_index_removed_count_map.getData(cell_index4);
                zhoubian_cell_index_removed_count_map.putData(cell_index4,1+prev4);
            }
        }


        var need_remove_index_map = new WMap();

        var remove_pos_subindex_map = new WMap();

        for(var ff=0;ff<this.m_gk_pos_index_speical_cur_box_info_map.size();ff++)
        {
            var ff_cellindex=  this.m_gk_pos_index_speical_cur_box_info_map.GetKeyByIndex(ff);
            var ff_boxinfo:Juba_Game_Spcieal_Pos_Info = this.m_gk_pos_index_speical_cur_box_info_map.GetEntryByIndex(ff);

            if(ff_boxinfo.itype!=2)
            {
                continue;
            }

            var need_desc_c = 0;
            if(zhoubian_cell_index_removed_count_map.hasKey(ff_cellindex))
            {
                need_desc_c = zhoubian_cell_index_removed_count_map.getData(ff_cellindex);
            }
           
            var src_count = ff_boxinfo.icount ;
           
            ff_boxinfo.icount -= need_desc_c;

            if(ff_boxinfo.icount <= 0)
            {
                need_remove_index_map.putData(ff_cellindex,1);
            }


            var remoced_sub_index_list = [];
            for(var gg=0;gg<need_desc_c;gg++)
            {
                var gg_index = src_count-gg;
                if(gg_index >= 1)
                {
                    remoced_sub_index_list.push(gg_index);
                }
            }
            if(remoced_sub_index_list.length > 0)
            {
                remove_pos_subindex_map.putData(ff_cellindex,remoced_sub_index_list);
            }
            
        }


        for(var ff=0;ff<remove_pos_subindex_map.size();ff++)
        {
            var ff_index3 = remove_pos_subindex_map.GetKeyByIndex(ff);
            var ff_sub_index_list = remove_pos_subindex_map.GetEntryByIndex(ff);
          
            for(var tt=0;tt<ff_sub_index_list.length;tt++)
            {
                var tt_subindex=  ff_sub_index_list[tt];

                this.Add_Cell_Index_Sub_Index_Box_Xiaochu_Anim(ff_index3,tt_subindex);
            }
        }



        for(var tt=0;tt<need_remove_index_map.size();tt++)
        {
            var tt_index=  need_remove_index_map.GetKeyByIndex(tt);
            this.m_gk_pos_index_speical_cur_box_info_map.RemoveKey(tt_index);

            this.Notify_Jiesuo_Cell_Index( tt_index)

        }

        this.Refresh_Special_Node_Item_Node();

    }
    Add_Cell_Index_Sub_Index_Box_Xiaochu_Anim(cellindex,isubindex)
    {
        BackGroundSoundUtils.GetInstance().Play_Effect("com/liekaixz");

        var celllogicpos=  this.Translate_Cell_Index_To_Logic_Pos(cellindex);
        var real_pos = this.Get_Logic_Pos_Center_Real_World_Pos(celllogicpos[0],celllogicpos[1]);

        var subpos = new cc.Vec2(0,0);

        if(isubindex == 1)
        {
            subpos = new cc.Vec2(-40,20);
        } 
        else if(isubindex == 2)
        {
            subpos = new cc.Vec2( 40,20);
        }else if(isubindex == 3)
        {
            subpos = new cc.Vec2( -40,-20);
        }else if(isubindex == 4)
        {
            subpos = new cc.Vec2(  40,-20);
        }

        var animpos = new cc.Vec2(real_pos.x + subpos.x,real_pos.y + subpos.y);


        var effect_node = cc.find("wuping/effect",this.m_parent_game_node);
        var effect_xiangshang_anim = this.m_parent_game.effect_xiangshang_anim;

        var pndoe = cc.instantiate(effect_xiangshang_anim);
        pndoe.setPosition(animpos)
        effect_node.addChild(pndoe,10);

        var w_nmode=  pndoe.getChildByName("w");
        var w_anim = w_nmode.getComponent(cc.Animation);
        w_anim.play();

        var pseq = cc.sequence(cc.delayTime(0.85 ),cc.callFunc(()=>
        {
            pndoe.destroy();
        }));

        this.m_parent_game_node.runAction(pseq)

    }
    ReGenerate_Center_Pos_Banzi_Info(new_map:WMap)
    {
        for(var ff=0;ff<this.m_center_pos_banzi_info_map.size();ff++)
        {
            var ff_center_pos = this.m_center_pos_banzi_info_map.GetKeyByIndex(ff);
            var ff_banziinfo :guaishou_juba_Banzi_Info = this.m_center_pos_banzi_info_map.GetEntryByIndex(ff);
          
            var ff_new_type_list = new_map.get_Data_By_Logic_Pos(ff_center_pos);
            if(!ff_new_type_list)
            {
                ff_new_type_list = [];
            }
            ff_banziinfo.Set_New_Jiubei_Type_List(ff_new_type_list);
        }
    }

    
}