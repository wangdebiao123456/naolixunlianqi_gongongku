 
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import juba_Game_Mng from "../mng/juba_Game_Mng";
import { Juba_Game_Spcieal_Pos_Info } from "./guaishoujubagamedata";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class game_spceial_item extends cc.Component {

    m_boxinfo = null;

    m_plisnter = null;
    m_gamejinbi = 0;
    m_cell_index= 0;
    
    onLoad () 
    {
        var jiesuobtn = cc.find("1/jiesuobtn",this.node)
        jiesuobtn.on("click",this.OnBtnJiesuo.bind(this))

        var jibni_jiesuobtn = cc.find("3/jiesuobtn",this.node)
        jibni_jiesuobtn.on("click",this.OnBtn_Jinbi_Jiesuo.bind(this))

 
    }
    On_Change_Pifu(pifuindex)
    {
        for(var ff=1;ff<=4;ff++)
        {
            var ff_ndoe = cc.find("1/jiesuobtn/"+ff,this.node);
            if(!ff_ndoe)
            {
                continue;
            }

            if(ff == pifuindex)
            {
                ff_ndoe.active = true;
            }else{
                ff_ndoe.active = false;
            }
        }
    }
    OnBtn_Jinbi_Jiesuo()
    {
        var boxinfo:Juba_Game_Spcieal_Pos_Info = this.m_boxinfo;

        var itype = boxinfo.itype;
        var icount = boxinfo.icount;

        if(itype != 3)
        {
            return;
        }

        if(icount > this.m_plisnter.Get_Game_Jinbi())
        {
            return;
        }
        this.m_plisnter.Notify_Jinbi_Jiesuo_Cell(this.m_cell_index,icount)
    }
    OnBtnJiesuo()
    {
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "解锁酒杯中间位置",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.Real_jiesuo();

        });
      

    }
    Real_jiesuo()
    {
        if(this.m_plisnter)
        {
            this.m_plisnter.Notify_Jiesuo_Cell_Index(this.m_cell_index)
        }
    }
    SetInfo(paradata)
    {
        this.m_boxinfo = paradata.boxinfo;
        this.m_gamejinbi = paradata.gamejinbi;
        this.m_plisnter = paradata.plisnter;
        this.m_cell_index = paradata.cell_index;

        this.Refresh_Info();
        this.Change_Pifu();
    }
    Change_Pifu()
    {
        var pifuindex = juba_Game_Mng.GetInstance().m_default_pifu_index;
        this.On_Change_Pifu(pifuindex)
    }
    Refresh_Info()
    {
        var boxinfo:Juba_Game_Spcieal_Pos_Info = this.m_boxinfo;

        var itype = boxinfo.itype;
        var icount = boxinfo.icount;


        for(var ff=1;ff<=3;ff++)
        {
            var ff_ndoe = cc.find(""+ff,this.node);

            if(itype == ff)
            {
                ff_ndoe.active = true;


                if(itype == 3)
                {

                    var ff_jiesuo_c_label = cc.find("3/jiesuobtn/c",this.node);
                    var ff_invalid_c_label = cc.find("3/invalid/c",this.node);

                    var ff_jiesuobtn = cc.find("3/jiesuobtn",this.node);
                    var ff_invalid_btn = cc.find("3/invalid",this.node);
  
                    ff_jiesuo_c_label.getComponent(cc.Label).string = ""+icount;
                    ff_invalid_c_label.getComponent(cc.Label).string = ""+icount;
                       
                     
                    if(this.m_gamejinbi >= icount)
                    {
                        ff_jiesuobtn.active = true;
                        ff_invalid_btn.active = false;
                    }
                    else{
                        ff_jiesuobtn.active = false;
                        ff_invalid_btn.active = true;
                    }

                }
                else if(itype == 2)
                {


                    for(var tt=1;tt<=4;tt++)
                    {
                        var tt_node = cc.find(""+tt,ff_ndoe);
                        tt_node.active = false;

                        if(tt <= icount)
                        {
                            tt_node.active = true;
                        }
                    }
                }

            }else{
                ff_ndoe.active = false;


            }
        }


    }
}
