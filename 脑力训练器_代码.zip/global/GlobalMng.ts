
export default class GlobalMng 
{

    static _instance:GlobalMng = null;
    static GetInstance() 
    {
        if (!GlobalMng._instance) {
            // doSomething
            GlobalMng._instance = new GlobalMng();
             
        }
        return GlobalMng._instance;
    }
    m_all_tiaoguangka_count = 2;
    m_all_tishika_count = 2;

    m_xiaotishika_count = 2;
    m_datishika_count = 2;  


    m_chongwan_ka_count = 2;

    constructor()
    {
     

        this.InitReadDaojuInfo();

    }


    Add_DaTishiKa_Count(icc)
    {
      
        this.m_datishika_count += icc;
        if(this.m_datishika_count <= 0)
        {
            this.m_datishika_count = 0;
        }
        this.SaveDaoJuInfo();
    }
    GetDaTishiKaCount()
    {
        return this.m_datishika_count ;
    }


    Change_ChongwanKa_Count(icc)
    {
        this.m_chongwan_ka_count += icc; 
        if(this.m_chongwan_ka_count <= 0)
        {
            this.m_chongwan_ka_count = 0;
        }
        this.SaveDaoJuInfo();
    }

    Get_Chongwan_Ka_Count()
    {
        return this.m_chongwan_ka_count;
    }

    Add_XiaoTishiKa_Count(icc)
    {
        if(this.m_xiaotishika_count <= 0)
        {
            this.m_xiaotishika_count = 0;
        }
        this.m_xiaotishika_count += icc;
        
        this.SaveDaoJuInfo();
    }
    GetXiaoTishiKaCount()
    {
        return this.m_xiaotishika_count ;
    }
    CheckReadNumber(num)
    {
        if(!num)
        {
            return 0;
        }
        var imun = Number(num);
        if(isNaN(imun))
        {
            return 0;
        }



        return  imun;
    }
    InitReadDaojuInfo()
    {
        var prevdaoju = cc.sys.localStorage.getItem("shaonao_global_daoju");
        if(prevdaoju)
        {
            try{
                var obj = JSON.parse(prevdaoju);

                if(obj)
                {
                    this.m_all_tishika_count = this.CheckReadNumber(obj.m_all_tishika_count);
                    this.m_all_tiaoguangka_count = this.CheckReadNumber(obj.m_all_tiaoguangka_count);
                    this.m_xiaotishika_count = this.CheckReadNumber(obj.m_xiaotishika_count);
                    this.m_datishika_count= this.CheckReadNumber(obj.m_datishika_count);

                    this.m_chongwan_ka_count= this.CheckReadNumber(obj.m_chongwan_ka_count);

                    
                }

            }catch(e)
            {

            }
        }

    }
    SaveDaoJuInfo()
    {
        var sinfo  = {m_all_tishika_count:this.m_all_tishika_count,m_all_tiaoguangka_count:this.m_all_tiaoguangka_count,
            m_xiaotishika_count:this.m_xiaotishika_count,m_datishika_count:this.m_datishika_count,
            m_chongwan_ka_count:this.m_chongwan_ka_count
        
        
        };
        
        cc.sys.localStorage.setItem("shaonao_global_daoju",JSON.stringify(sinfo));
        
    }

    GetTiaoGuangKaCount()
    {
        return this.m_all_tiaoguangka_count;

    }

    GetTitshiKaCount()
    {
        return this.m_all_tishika_count;
    }
    Add_TiaoGuangKa_Count(icc)
    {
        this.m_all_tiaoguangka_count += icc;

        this.SaveDaoJuInfo();
    }
}