import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
import NodeComPoolUtils from "../WDT/NodeComPoolUtils";

  

const {ccclass, property} = cc._decorator;

@ccclass
export class BoomEffectAnim extends cc.Component {
    @property({type: cc.Animation, tooltip: '动画'})
    anim: cc.Animation = null;


    m_initscale = 0;
    m_parent_notifyer = null;

    m_test_index = 0;

    init(parentnotifyer, index: string, isEnemy: boolean = false,playeffect = 1) {

        NodeComPoolUtils.GetInstance().m_pool_test_index++;
        this.m_test_index = NodeComPoolUtils.GetInstance().m_pool_test_index;
       // console.log("init  m_test_index="+this.m_test_index)


        this.removeEvent();
        let str = '';
        this.m_initscale=  this.node.scale;
        this.m_parent_notifyer = parentnotifyer;
        
        this.addEvent();
        // this.anim.play('boom_' + index);
        switch (index) {
            case '1':
            case '2':
                str = 'boom_' + index;
                this.node.anchorY = 0.5;
                break;
            case '4':
                str = 'boom_' + index;
                this.node.anchorY = 0.1;
                break;
            case '6':
                str = 'boom_' + index;
                this.node.anchorY = 0.2;

                if(playeffect)
                {
                    BackGroundSoundUtils.GetInstance().Play_Effect('com/boom');
                }
               
                break;
            case '7':
                str = 'boom_' + index;
                this.node.anchorY = 0.15;
                if(playeffect)
                {
                    BackGroundSoundUtils.GetInstance().Play_Effect('com/boom');
                }

                break;
            case 'destroy':
                str = index;
                this.node.anchorY = 0;
                if(playeffect)
                {
                    BackGroundSoundUtils.GetInstance().Play_Effect('com/peng');
                }
                break;
            case 'boom':
                    str = index;
                    this.node.anchorY = 0;
                     this.node.scale = 3;
                     if(playeffect)
                     {
                        BackGroundSoundUtils.GetInstance().Play_Effect('com/boom4');
                     }
            break;
            case 'shoujida':
                str = 'shoujida' ;
                this.node.anchorY = 0.2;
                //SoundManager.GetInstance().Play_Effect('boom');
                break;

        }

        this.anim.play(str);

    }


    recycle() {
      //  console.log("recycle  m_test_index="+this.m_test_index)

        if(this.m_initscale > 0)
        {
            this.node.scale = this.m_initscale;
            this.m_initscale  = 0;
        }
      
        this.anim.stop();

        if(this.m_parent_notifyer)
        {

            this.m_parent_notifyer.Notify_Boomb_Anim_End();
            this.m_parent_notifyer = null;
        }
        
    }

    addEvent() {
        this.anim.on('finished', this.recycle, this);

    }

    removeEvent() {
        this.anim.off('finished', this.recycle, this);

    }
}
