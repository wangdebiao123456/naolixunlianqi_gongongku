import NodeComPoolUtils from "../comfuncs/NodeComPoolUtils";

  
const {ccclass, property} = cc._decorator;

@ccclass
export default class ShowHpDeamge extends cc.Component {

    init(str,bself) {
        this.node.getChildByName("l").getComponent(cc.Label).string = str;

        if(bself)
        {
            this.node.getChildByName("l").color = cc.color(255,0,0);
        }else{
            this.node.getChildByName("l").color = cc.color(255,215,0);
        }

        var self = this;

        cc.tween(this.node) .by(0.15, {y: 30}).delay(0.3)  .call(() => {
            self.recycle();
        })
        .start();
 
    }
    recycle() {
        var poolname = "preyuzhi/effect/ShowHpDeamge";

        NodeComPoolUtils.GetInstance().putANode(poolname, this.node);
    }
}
