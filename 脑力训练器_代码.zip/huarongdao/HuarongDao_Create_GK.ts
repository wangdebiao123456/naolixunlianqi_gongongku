import WMap from "../WDT/WMap";

export default  class HuarongDao_Create_GK
{
    static _instance:HuarongDao_Create_GK = null;
    static GetInstance() 
    {
        if (!HuarongDao_Create_GK._instance) {
            // doSomething
            HuarongDao_Create_GK._instance = new HuarongDao_Create_GK();
             
        }
        return HuarongDao_Create_GK._instance;
    }


    constructor()
    {

    }


   // [0,2,2,3,1],
    Get_Per_Muk_Use_Pos_Lsit(ff_mukuai)
    {
        var itype = ff_mukuai[0];
       
        var if_wx = ff_mukuai[1];
        var if_wy = ff_mukuai[2];
        var ff_x = ff_mukuai[3];
        var ff_y = ff_mukuai[4];
        
        var all_used_arr = [];
        if(itype == 0)
        {

            for(var ff=0;ff<2;ff++)
            {
                for(var gg=0;gg<2;gg++)
                {
                    var ix = ff_x + ff;
                    var iy = ff_y + gg;
                    
                    var pos = ix*10+iy;
                    all_used_arr.push(pos);
                }
            
            }
        }
        else{

            for(var ff=0;ff<if_wx;ff++)
            {
                for(var gg=0;gg<if_wy;gg++)
                {
                    var ix =  ff_x + ff;
                    var iy = ff_y + gg;
                    var pos = ix*10+iy;
                    all_used_arr.push(pos);
                }

                 
            }


        }

        return all_used_arr;
    }


    Check_Arr_Exist_Same(tt_used_pos_list,exist_pos_list)
    {
        for(var ff=0;ff<tt_used_pos_list.length;ff++)
        {
            for(var tt=0;tt<exist_pos_list.length;tt++)
            {
                var ff_t = tt_used_pos_list[ff];
                var ff_g = exist_pos_list[tt];
    
                if(ff_t == ff_g)
                {
                    return true;
                }
            }
    
        }


        return false;
    }


    Check_Two_Pos_Xiangling(pos1,pos2)
    {

        if(pos1[0] == pos2[0])
        {
            if(pos1[1] == pos2[1])
            {
                return false;
            }

            var absc = Math.abs(pos1[1]  - pos2[1] );

            if(absc == 1)
            {
                return true;
            }
            
            return false;
        }

        if(pos1[1] == pos2[1])
        {
            if(pos1[0] == pos2[0])
            {
                return false;
            }

            var absc = Math.abs(pos1[0]  - pos2[0] );

            if(absc == 1)
            {
                return true;
            }
            
            return false;
        }

        return false;
    }


    Check_LVSe_Dange_Pos_LiangLiang_Xaingling(lv_se_dange_pos_list)
    {
        if(lv_se_dange_pos_list.length == 0)
        {
            return true;
        }

        if(lv_se_dange_pos_list.length == 2)
        {
            var pos1 = lv_se_dange_pos_list[0];
            var pos2 = lv_se_dange_pos_list[1];

             
            if(this.Check_Two_Pos_Xiangling(pos1,pos2))
            {
                return true;
            }

            return false;
        }


        if(lv_se_dange_pos_list.length != 4)
        {
            return false;
        }


        //两两组合只有 0-1,2,3  1-   

        

        for(var ff=1;ff<=3;ff++)
        {
            var pos1 = lv_se_dange_pos_list[0];
            var pos2 = lv_se_dange_pos_list[ff];

            var same1= false;
            if(this.Check_Two_Pos_Xiangling(pos1,pos2))
            {
                same1 = true;
            }


            if(!same1)
            {
                continue;
            }

            var other_pos_list = [];
            
            for(var hh=1;hh<=3;hh++)
            {
                if(hh!=ff)
                {
                    other_pos_list.push(hh);
                }
            }

            var pos3 = lv_se_dange_pos_list[other_pos_list[0]];
            var pos4 = lv_se_dange_pos_list[other_pos_list[1]];

            var same2= false;
            if(this.Check_Two_Pos_Xiangling(pos3,pos4))
            {
                same2= true;
            }

            if(!same2)
            {
                continue;
            }


            return true;
        }



        return false;
    }
    Get_Mukuai_Can_Valid_Zuhe_Pos_List(mukuai_list,iwx,iwy,icount)
    {

        var exist_pos_list = [];

        for(var ff=0;ff<mukuai_list.length;ff++)
        {
            var ff_mukuai = mukuai_list[ff];
            var used_pos_list = this.Get_Per_Muk_Use_Pos_Lsit(ff_mukuai);
            exist_pos_list = exist_pos_list.concat(used_pos_list);
        }

        var valid_pos_zuhe_list = [];

        var ix_add = iwx - 1;
        var iy_add = iwy - 1;

       
       

        var all_can_pos_list = [];

        for(var ff=1;ff<=4;ff++)
        {
            for(var tt=1;tt<=5;tt++)
            {
                var x_max = ff  + ix_add; 
                var y_max = tt  + iy_add; 

                if(x_max > 4)
                {
                    continue;
                }
                if(y_max > 5)
                {
                    continue;
                }

                var tt_mk = [1,iwx,iwy,ff,tt];
                if(iwx > 2 || iwy > 2)
                {
                    console.log("iwx > 2 || iwy > 2");
                }
                var tt_used_pos_list = this.Get_Per_Muk_Use_Pos_Lsit(tt_mk);

                if(this.Check_Arr_Exist_Same(tt_used_pos_list,exist_pos_list))
                {
                    continue;
                }
      
                all_can_pos_list.push([ff,tt]);
            }
        }


        //从组合里面取出icount个组合
        var sub_index_zuhe_list = this.Get_Arr_SubIndex_Zuhe_List(all_can_pos_list.length,icount);



        for(var ff=0;ff<sub_index_zuhe_list.length;ff++)
        {
            var ff_arr = sub_index_zuhe_list[ff];

            //绿色单个的四个小方块必须保证一点，也就是必须 两组互相挨在一起的

            var b_dange_valid = true;
            if(iwx == 1 && iwy == 1)
            {
                var lv_se_dange_pos_list = [];
                for(var gg=0;gg<ff_arr.length;gg++)
                {
                    var gg_t_index = ff_arr[gg];
                    var gg_pos = all_can_pos_list[gg_t_index];
                    lv_se_dange_pos_list.push(gg_pos);
                }
                b_dange_valid = this.Check_LVSe_Dange_Pos_LiangLiang_Xaingling(lv_se_dange_pos_list);

            }


            if(!b_dange_valid)
            {
                continue;
            }
         


            var mk_info_list = [];


            for(var gg=0;gg<ff_arr.length;gg++)
            {
                var gg_t_index = ff_arr[gg];
                var gg_pos = all_can_pos_list[gg_t_index];

                var tt_mk = [1,iwx,iwy,gg_pos[0],gg_pos[1]];


                if(iwx > 2 || iwy > 2)
                {
                    console.log("iwx > 2 || iwy > 2");
                }

                mk_info_list.push(tt_mk)
            }

              //首先，判断加上这些以后，组合间会不会有重叠的
              var bhaschongdie = this.Check_Zuhe_Tu_Has_Chongdie(mk_info_list)


              if(!bhaschongdie)
              {
                valid_pos_zuhe_list.push(mk_info_list);
              }
            
        }

        return valid_pos_zuhe_list;
    }

    Check_Zuhe_Tu_Has_Chongdie(mk_info_list)
    {
        var exsit_pos_list =[];

        for(var ff=0;ff<mk_info_list.length;ff++)
        {
            var ff_mk = mk_info_list[ff];
            var ff_pos_lsit=  this.Get_Per_Muk_Use_Pos_Lsit(ff_mk);

            if(this.Check_Arr_Exist_Same(ff_pos_lsit,exsit_pos_list))
            {
                return true;
            }

            exsit_pos_list = exsit_pos_list.concat(ff_pos_lsit);
        }

        return false;
    }
    Get_Arr_SubIndex_Zuhe_List(arrlen, icount)
    {
        var suiji_arr = [];

        for(var ff=0;ff<arrlen;ff++)
        {
            suiji_arr.push(ff);
        }


        //从suiji_Arr里面取出icount个，不相同的组合

        if(suiji_arr.length < icount)
        {
            return [];
        }

        if(suiji_arr.length == icount)
        {
            return [suiji_arr];
        }


        var zuhe_arr =[];
     

        for(var ff=0;ff<suiji_arr.length;ff++)
        {
            var ff_d = suiji_arr[ff];
            var left_arr = suiji_arr.slice(0);
            left_arr.splice(0,1+ff);

            var arr = [ff_d];
           // arr.push(arr);

            if(icount > 1)
            {
                var subn_arr = this.Get_Left_Suiji_Arr_Zuhe(left_arr,icount-1);

                for(var jj=0;jj<subn_arr.length;jj++)
                {
                    var jj_arr = subn_arr[jj];
                    var new_arr = arr.concat(jj_arr);
                    zuhe_arr.push(new_arr);
                }

            }else{

                zuhe_arr.push(arr);
            }
        
        }

        return zuhe_arr;
    }
    Get_Left_Suiji_Arr_Zuhe(srcarr,icount)
    {
        if(icount == 0)
        {
            return [];
        }
        
        var zuhe_arr =[];
     
        for(var ff=0;ff<srcarr.length;ff++)
        {
            var ff_d = srcarr[ff];
            var left_arr = srcarr.slice(0);
            left_arr.splice(0,1+ff);

            var arr = [ff_d];
            // arr.push(arr);
 
             if(icount > 1)
             {
                 var subn_arr = this.Get_Left_Suiji_Arr_Zuhe(left_arr,icount-1);
 
                 for(var jj=0;jj<subn_arr.length;jj++)
                 {
                     var jj_arr = subn_arr[jj];
                     var new_arr = arr.concat(jj_arr);
                     zuhe_arr.push(new_arr);
                 }
 
             }else{
 
                 zuhe_arr.push(arr);
             }

        }

        return zuhe_arr;
    }
    Get_Keng_Zuhe_List(tt_arr,itype_lvse_2_heng,itype_lvse_2_shu,itype_lvse_1_shu)
    {
        if(itype_lvse_2_heng == 0 && itype_lvse_2_shu == 0 && itype_lvse_1_shu == 0)
        {
            return tt_arr;
        }

        var all_zuhe_arr1 = [];

        if(itype_lvse_2_heng > 0)
        {
           

            for(var ff=0;ff<tt_arr.length;ff++)
            {
                var ff_mukuai_list = tt_arr[ff];


                var hengxiang_2_valid_pos_list = this.Get_Mukuai_Can_Valid_Zuhe_Pos_List(ff_mukuai_list,2,1,itype_lvse_2_heng);

                if(hengxiang_2_valid_pos_list.length == 0)
                {
                    continue;
                }

                for(var gg=0;gg<hengxiang_2_valid_pos_list.length;gg++)
                {
                    var gg_mukuailist = hengxiang_2_valid_pos_list[gg];

                    var con_mukuailist = ff_mukuai_list.slice(0);
                    con_mukuailist = con_mukuailist.concat(gg_mukuailist);
                    all_zuhe_arr1.push(con_mukuailist);
                }
            }


            return this.Get_Keng_Zuhe_List(all_zuhe_arr1,0,itype_lvse_2_shu,itype_lvse_1_shu)
        }

        if(itype_lvse_2_shu > 0)
        {
          
            for(var ff=0;ff<tt_arr.length;ff++)
            {
                var ff_mukuai_list = tt_arr[ff];

                var shuxiang_2_valid_pos_list = this.Get_Mukuai_Can_Valid_Zuhe_Pos_List(ff_mukuai_list,1,2,itype_lvse_2_shu);
 

                if(shuxiang_2_valid_pos_list.length == 0)
                {
                    continue;
                }

                for(var gg=0;gg<shuxiang_2_valid_pos_list.length;gg++)
                {
                    var gg_mukuailist = shuxiang_2_valid_pos_list[gg];

                    var con_mukuailist = ff_mukuai_list.slice(0);
                    con_mukuailist = con_mukuailist.concat(gg_mukuailist);
                    all_zuhe_arr1.push(con_mukuailist);
                }
            }


            return this.Get_Keng_Zuhe_List(all_zuhe_arr1,0,0,itype_lvse_1_shu)
        }

        if(itype_lvse_1_shu > 0)
        {
          
            for(var ff=0;ff<tt_arr.length;ff++)
            {
                var ff_mukuai_list = tt_arr[ff];

                var shuxiang_1_valid_pos_list = this.Get_Mukuai_Can_Valid_Zuhe_Pos_List(ff_mukuai_list,1,1,itype_lvse_1_shu);
 

                if(shuxiang_1_valid_pos_list.length == 0)
                {
                    continue;
                }

                for(var gg=0;gg<shuxiang_1_valid_pos_list.length;gg++)
                {
                    var gg_mukuailist = shuxiang_1_valid_pos_list[gg];


                   


                    var con_mukuailist = ff_mukuai_list.slice(0);
                    con_mukuailist = con_mukuailist.concat(gg_mukuailist);
                    all_zuhe_arr1.push(con_mukuailist);
                }
            }


            return all_zuhe_arr1;
        }
    }


    Get_Suiji_List()
    {
        var itype_lvse_2_heng = 1;
        var itype_lvse_2_shu = 4;
        var itype_lvse_1_shu = 4;


        //大方块只有1
        var all_keneng_list = [];


        for(var ff=1;ff<=3;ff++)
        {
            for(var tt=2;tt<=4;tt++)
            {
                if(ff == 2 && tt == 2)
                {
                    continue;
                }

                var tt_arr = [];

                var tt_huangse = [ [0,2,2,ff,tt]  ];
                tt_arr.push(tt_huangse);
                var tt_keneng_list = this.Get_Keng_Zuhe_List(tt_arr,itype_lvse_2_heng,itype_lvse_2_shu,itype_lvse_1_shu);


                for(var hh=0;hh<tt_keneng_list.length;hh++)
                {
                    var hh_list = tt_keneng_list[hh];
                    all_keneng_list.push(hh_list);
                }
            }
        }

        var iran1 = Math.floor(all_keneng_list.length*Math.random());

        var suiji_liat = all_keneng_list[iran1];
        return suiji_liat;


    }
    Get_All_Keneng_Show_List()
    {
        var itype_da_huang = 1;
        var itype_lvse_2_heng = 1;
        var itype_lvse_2_shu = 4;
        var itype_lvse_1_shu = 4;


        //大方块只有1
        var all_keneng_list = [];


        for(var ff=1;ff<=3;ff++)
        {
            for(var tt=1;tt<=4;tt++)
            {
                var tt_arr = [];

                var tt_huangse = [ [0,2,2,ff,tt]  ];
                tt_arr.push(tt_huangse);
                var tt_keneng_list = this.Get_Keng_Zuhe_List(tt_arr,itype_lvse_2_heng,itype_lvse_2_shu,itype_lvse_1_shu);


                for(var hh=0;hh<tt_keneng_list.length;hh++)
                {
                    var hh_list = tt_keneng_list[hh];
                    all_keneng_list.push(hh_list);
                }
            }
        }


        //首先得到ok的


        var all_oked_list = [];
        var not_oked_list = [];

        for(var ff=0;ff<all_keneng_list.length;ff++)
        {
            var ff_keneng_arr = all_keneng_list[ff];

            var find_huanse = null;


            for(var gg=0;gg<ff_keneng_arr.length;gg++)
            {
                var gg_arr = ff_keneng_arr[gg];

                if(gg_arr[0] == 0)
                {
                    find_huanse = gg_arr;
                }
            }

            if(!find_huanse)
            {
                continue;
            }


            var ff_x = find_huanse[3];
            var ff_y = find_huanse[4];

            if(ff_x == 2 && ff_y == 1)
            {
                all_oked_list.push(ff_keneng_arr);
            }else{

                not_oked_list.push(ff_keneng_arr);
            }

        }



        var step_map_list = new WMap();
        step_map_list.putData(1,all_oked_list);



    
        console.log("all_oked_list.len="+all_oked_list.length+",not oklist.len="+not_oked_list.length);
       // console.log("all_keneng_list.len="+all_keneng_list.length);

        //var all_keneng_list = this.Get_


    }

    Find_Mukuai_Move_Valid_Arr(srcarr,iindex,in_mukuai,fxlist)
    {
        var exist_pos_list = [];

        var other_muykuai_list = [];
        for(var ff=0;ff<srcarr.length;ff++)
        {
            var ff_mukuai = srcarr[ff];
            if(iindex == ff)
            {
                continue;
            }

            other_muykuai_list.push(ff_mukuai);

            var ff_pos_list = this.Get_Per_Muk_Use_Pos_Lsit(ff_mukuai);
            exist_pos_list = exist_pos_list.concat(ff_pos_list);
        }



        var in_muk_t = in_mukuai[0];
       
        var in_muk_fx = in_mukuai[1];
       
        var in_muk_w = in_mukuai[2];
       
        var in_muk_x = in_mukuai[3];
        var in_muk_y = in_mukuai[4];


        var min_x = in_muk_x;
        var min_y = in_muk_y;

        var max_x = in_muk_x;
        var max_y = in_muk_y;


        if(in_muk_t == 0)
        {
            max_x = in_muk_x +1;
            max_y = in_muk_y +1;
            
        }else{

            if(in_muk_fx == 1)
            {
                max_x = in_muk_x + in_muk_w-1 ;
            }else{
                max_y= in_muk_y + in_muk_w-1 ;
            }
        }


        var valid_yidong_fx_list = [];

        for(var ff=0;ff<fxlist.length;ff++)
        {
            var ff_fx =  fxlist[ff];

            var new_min_x = min_x;
            var new_min_y = min_y;
    
            var new_max_x = max_x;
            var new_max_y = max_y;
    
         
            if(ff_fx == 1)
            {
                new_min_y += 1;
                new_max_y+=1;
            } 
            else if(ff_fx == 2)
            {
                new_min_y -= 1;
                new_max_y -=1;
            }
            else if(ff_fx == 3)
            {
                new_min_x += 1;
                new_max_x+=1;
            } 
            else if(ff_fx == 4)
            {
                new_min_x += -1;
                new_max_x += -1;
            }

            if(new_min_x < 1)
            {
                continue;
            }

            if(new_min_x  > 4)
            {
                continue;
            }


            if(new_max_x < 1)
            {
                continue;
            }

            if(new_max_x  > 4)
            {
                continue;
            }

            if(new_min_y < 1)
            {
                continue;
            }

            if(new_min_y  > 5)
            {
                continue;
            }
            
            if(new_max_y < 1)
            {
                continue;
            }

            if(new_max_y  > 5)
            {
                continue;
            }
            

            var newmukuai = [in_muk_t,in_muk_fx,in_muk_w,new_min_x,new_min_y];


            var new_pos_list = this.Get_Per_Muk_Use_Pos_Lsit(newmukuai);
   
            if(this.Check_Arr_Exist_Same(new_pos_list,exist_pos_list))
            {
                continue;
            }

            //判断有没有可能变成功了

            if(in_muk_t == 0)
            {
                if(new_min_x == 2 && new_min_y == 1)
                {
                    continue;
                }
            }

            //成功

            var new_mklist=  other_muykuai_list.slice(0);
            new_mklist.push(newmukuai);

            valid_yidong_fx_list.push(new_mklist);
        }

        return valid_yidong_fx_list;

    }
    Find_Valid_Can_Move_Mukuai_New_Arr(srcarr)
    {

        var existed_tuan_list = [];

        var new_arr = [];

        for(var ff=0;ff<srcarr.length;ff++)
        {
            var ff_mukuai  = srcarr[ff];

            //上下左右
            var vald_fx = [1,2,3,4]

            if(ff_mukuai[0] == 0)
            {
                vald_fx = [1,2,3,4]
            }else{

                if(ff_mukuai[1] == 1 )
                {
                    vald_fx = [ 3,4]
                }else{
                    vald_fx = [ 1,2]
                }
            }

            var mukuai_can_move_to_arr = this.Find_Mukuai_Move_Valid_Arr(srcarr,ff,ff_mukuai,vald_fx);

            new_arr = new_arr.concat(mukuai_can_move_to_arr);
        }



        return new_arr;
    }


    Get_Mukuai_Tu_All_Pos_List(mulist)
    {
        var allposlist=  [];

        for(var ff=0;ff<mulist.length;ff++)
        {
            var ff_mukuai = mulist[ff];
            var ff_pos_list = this.Get_Per_Muk_Use_Pos_Lsit(ff_mukuai);

            allposlist = allposlist.concat(ff_pos_list);
        }

        return allposlist;

    }
    Get_Mukuai_Tu_All_Pos_List_ByType(mukuai_tu,itype,ifx,iw)
    {
        var all_pos_list = new WMap();



        for(var ff=0;ff<mukuai_tu.length;ff++)
        {
            var ff_mukuai = mukuai_tu[ff];

            if(ff_mukuai[0] != itype)
            {
                continue;
            }
            if(ff_mukuai[1] != ifx)
            {
                continue;
            }
            if(ff_mukuai[2] != iw)
            {
                continue;
            }

            var ffx = ff_mukuai[3];
            var ffy = ff_mukuai[4];

            var pos=  10*ffx + ffy;
            all_pos_list.putData(pos,1);
        }

    
        return all_pos_list;


    }

    IsArraySame(pmap1,pmap2)
    {
        if(pmap1.size() != pmap2.size())
        {
            return false;
        }


        for(var ff=0;ff<pmap1.size();ff++)
        {
            var ff_pos=  pmap1.GetKeyByIndex(ff);
            var ff_v = pmap1.GetEntryByIndex(ff);

            if(!pmap2.hasKey(ff_pos))
            {
                return false;
            }
            var ff_v2 = pmap2.getData(ff_pos);

            if(ff_v != ff_v2)
            {
                return false;
            }
        }

        return true;
    }
    IsSameTu(ff_mktu,gg_tu)
    {
        var huangse_pos_list = [];
        var ff_poslist1 =  this.Get_Mukuai_Tu_All_Pos_List_ByType(ff_mktu,0,2,2);
        var ff_poslist2 =  this.Get_Mukuai_Tu_All_Pos_List_ByType(gg_tu,0,1,2);

        if(!this.IsArraySame(ff_poslist1,ff_poslist2))
        {

            return false;
        }


        var ut =1;


        var ff_poslist3 =  this.Get_Mukuai_Tu_All_Pos_List_ByType(ff_mktu,ut,1,2);
        var ff_poslist4 =  this.Get_Mukuai_Tu_All_Pos_List_ByType(gg_tu,ut,1,2);

        if(!this.IsArraySame(ff_poslist3,ff_poslist4))
        {

            return false;
        }


        var ff_poslist5 =  this.Get_Mukuai_Tu_All_Pos_List_ByType(ff_mktu,ut,1,1);
        var ff_poslist6 =  this.Get_Mukuai_Tu_All_Pos_List_ByType(gg_tu,ut,1,1);

        if(!this.IsArraySame(ff_poslist5,ff_poslist6))
        {

            return false;
        }

        var ff_poslist7 =  this.Get_Mukuai_Tu_All_Pos_List_ByType(ff_mktu,ut,2,2);
        var ff_poslist8 =  this.Get_Mukuai_Tu_All_Pos_List_ByType(gg_tu,ut,2,2);

        if(!this.IsArraySame(ff_poslist7,ff_poslist8))
        {

            return false;
        }


        var ff_poslist7 =  this.Get_Mukuai_Tu_All_Pos_List_ByType(ff_mktu,ut,2,1);
        var ff_poslist8 =  this.Get_Mukuai_Tu_All_Pos_List_ByType(gg_tu,ut,2,1);

        if(!this.IsArraySame(ff_poslist7,ff_poslist8))
        {

            return false;
        }



        return true;
    }
    Paichu_Same_List(find_can_move_mukuai_step_list,exist_suiji_tuan_list)
    {
        var not_has_same_list = [];


        for(var ff=0;ff<find_can_move_mukuai_step_list.length;ff++)
        {
            var ff_mktu  = find_can_move_mukuai_step_list[ff];

            //var ff_poslist =  this.Get_Mukuai_Tu_All_Pos_List(ff_mktu);


            var bhassametu = false;
            for(var gg=0;gg<exist_suiji_tuan_list.length;gg++)
            {
                var gg_tu = exist_suiji_tuan_list[gg];
                //var gg_pos_lsit=  this.Get_Mukuai_Tu_All_Pos_List(gg_tu);

                if(this.IsSameTu(ff_mktu,gg_tu))
                {
                    bhassametu = true;
                    break;
                }
            }

            if(!bhassametu)
            {
                not_has_same_list.push(ff_mktu);
            }

        }

        return not_has_same_list;
    }

    Suiji_Zoubu_Arr(exist_suiji_tuan_list)
    {
        var new_list = exist_suiji_tuan_list.slice(0);


        for(var ff=0;ff<exist_suiji_tuan_list.length;ff++)
        {
            var ff_arr = exist_suiji_tuan_list[ff];
            var can_move_arr = this.Suiji_Zoubu(ff_arr,new_list);


            new_list = new_list.concat(can_move_arr);
            
        }

        return new_list;
    }
    Suiji_Zoubu(new_arr,exist_suiji_tuan_list)
    {
        //找出能走的歩

        var find_can_move_mukuai_step_list = this.Find_Valid_Can_Move_Mukuai_New_Arr(new_arr);
        var paichu_same_list=  this.Paichu_Same_List(find_can_move_mukuai_step_list,exist_suiji_tuan_list);

        return paichu_same_list;
        /*
        if(find_can_move_mukuai_step_list.length > 0)
        {

            var paichu_same_list=  this.Paichu_Same_List(find_can_move_mukuai_step_list,exist_suiji_tuan_list);


            if(paichu_same_list.length > 0)
            {
                var irand2 = Math.floor(Math.random()*paichu_same_list.length);



                var new_arr2 = paichu_same_list[irand2];
                return new_arr2;
            }
            var irand1 = Math.floor(Math.random()*find_can_move_mukuai_step_list.length);



            var new_arr1 = find_can_move_mukuai_step_list[irand1];

            return new_arr1;
        }


        return new_arr;
        */
    }

    Generate_GK_Data(ilevel)
    {
        var strlevel = [
            [0,2,2,2,4],

            [1,1,1,1,1], 
            [1,1,1,4,1],
            [1,1,1,2,2], 
            [1,1,1,3,2],


            [1,1,2,1,2],
            [1,1,2,1,4],
            [1,1,2,4,2],
            [1,1,2,4,4],

            
            [1,2,1,2,3]
        ];

        //随机混乱
        var keneng_list = this.Get_Suiji_List();
        return keneng_list;

/*
        var new_arr = strlevel.slice(0);
        var exist_suiji_tuan_list = [];
        exist_suiji_tuan_list.push(new_arr);


        var zoulu_arr = [];
        zoulu_arr.push(new_arr);

        for(var ff=0;ff<15;ff++)
        {
            var suiji_Arr = this.Suiji_Zoubu_Arr(zoulu_arr);
            zoulu_arr = suiji_Arr;
        }

        var istart = Math.floor(zoulu_arr.length/2) ;
        var iend = Math.floor(zoulu_arr.length) ;

        var irand11 = Math.floor(Math.random()*(iend- istart))+istart;

        if(irand11 >= iend)
        {
            irand11=  iend-1;
        }

        var use_arr = zoulu_arr[irand11];

      //  var keneng_list = this.Get_All_Keneng_Show_List();



        return use_arr;
        */
    }

}