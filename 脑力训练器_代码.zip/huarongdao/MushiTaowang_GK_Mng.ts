import WMap from "../WDT/WMap";



export default  class MushiTaowang_GK_Mng
{

    static _instance:MushiTaowang_GK_Mng = null;
    static GetInstance() 
    {
        if (!MushiTaowang_GK_Mng._instance) {
            // doSomething
            MushiTaowang_GK_Mng._instance = new MushiTaowang_GK_Mng();
             
        }
        return MushiTaowang_GK_Mng._instance;
    }
   
    m_local_file_index_data_map = new WMap();
  
    constructor()
    {

    }

    Real_Get_Gk_Data(ilevel,callback)
    {
        var self= this;
       
        var findd_data = this.Find_GK_Real_Data(ilevel);
        if(findd_data)
        {
            callback(true,findd_data)
            return true;
        }

        return false;
    }
    Get_GK_Str(ilevel,callback)
    {
        var bsuc1=  this.Real_Get_Gk_Data(ilevel,callback);
        if(bsuc1)
        {
            return;
        }

        var irealindex = ilevel -1;

        var subfileindex = Math.floor(irealindex/500);
       
        var sfilename = "conf/mushi/gk/mushi_gk_data_"+subfileindex;


        var self = this;
        cc.resources.load(sfilename,cc.JsonAsset,(err,asserts:cc.JsonAsset)=>
        {
            if(err || !asserts)
            {
                console.log("加载关卡数据失败:"+err)
                callback(false);
                return;
            }

            var jsonobj = asserts.json;

            //console.log("加载关卡数据成功:"+jsonobj)
            self.m_local_file_index_data_map.putData(subfileindex,jsonobj);
            self.Real_Get_Gk_Data(ilevel,callback);
        });

    }
    Find_GK_Real_Data(ilevel)
    {
        var irealindex = ilevel -1;

        var subfileindex = Math.floor(irealindex/500);
        
     
        var findd_data = null;

        if(this.m_local_file_index_data_map.hasKey(subfileindex))
        {
            var localdata  = this.m_local_file_index_data_map.getData(subfileindex);


            for(var ff=0;ff<localdata.length;ff++)
            {
                var ff_info = localdata[ff];
                var ff_l = ff_info.l;
                var ff_d = ff_info.d;


          
                if(ff_l == irealindex)
                {
                    findd_data = ff_d;
                    break;
                }
            }
           
        }


        return findd_data;
    }
}