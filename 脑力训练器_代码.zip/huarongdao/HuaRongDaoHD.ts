
export default  class HuaRongDaoHD 
{
    m_id = 0;
    m_itype = 0;
    m_iwidth = 0;
    m_iheight =0;
    x = 0;
    y = 0;

     offsetx = 0;
     offsety = 0;
 
    //ifangxiang:1:横向，2：竖向,
    //iwidth:占用几格
    ////type,方向，宽度，最左下x,y
   // [0,1,2,1,4],
	Init(id, infoarr) 
    {
        this.m_id = id;
        this.m_itype = infoarr[0];
        this.m_iwidth = infoarr[1];
        this.m_iheight = infoarr[2];
        this.x = infoarr[3];
        this.y = infoarr[4];

         this.offsetx = 0;
         this.offsety = 0;
         
    }

    constructor() 
    {

    }

    GetMargin()
    {
        return 133;
    }

    ToAarry()
    {
        var arr = [];

        arr[0] = this.m_itype;
        arr[1] = this.m_iwidth;
        arr[2] = this.m_iheight;
        arr[3] = this.x;
        arr[4] = this.y; 

 
        return arr;
    }
    Copy()
    {
        var copyd = new HuaRongDaoHD();
        copyd.m_id = this.m_id;
        copyd.m_itype = this.m_itype;
        copyd.m_iheight = this.m_iheight;
        copyd.m_iwidth = this.m_iwidth;
        copyd.x = this.x;
        copyd.y = this.y;


        return copyd;

    }
    MoveStep(offset_x,offset_y)
    {
        this.x += offset_x;
        this.y += offset_y;
        
    }
    SetOffetPtXY(x,y)
    {
        this.offsetx = x;
        this.offsety = y;
    }

    GetGridCenterPt(x,y)
    {
        var imargin = this.GetMargin();
        var starx = 0- imargin*2 + imargin/2;
        var xxpt = starx + (x-1)*imargin;

        var stary = 0- imargin*3 + imargin/2 + 85;
        var yypt = stary + (y-1)*imargin;

        var centex = xxpt + this.offsetx;
        var centey = yypt + this.offsety;
 

        return {x:centex,y:centey};
    }

    GetRect()
    {
        var imargin = this.GetMargin();
    
        var centerpt = this.GetCenterPt();

        var ptleft_x = centerpt.x - this.m_iwidth*imargin/2;
        var ptleft_y = centerpt.y - this.m_iheight* imargin/2; 

        return new cc.Rect(ptleft_x,ptleft_y,this.m_iwidth*imargin,this.m_iheight* imargin);
 
    }

    GetCenterPt()
    {
        var istartx = this.x;
        var iendx = this.x + this.m_iwidth - 1;
        var istarty = this.y;
        var iendy = this.y + this.m_iheight - 1;

        

        var startpt = this.GetGridCenterPt(istartx,istarty);
        var endpt = this.GetGridCenterPt(iendx,iendy);

        var centex = Math.floor(startpt.x+endpt.x)/2;
        var centery = Math.floor(startpt.y+endpt.y)/2;

        return {x:centex,y:centery};
        /*
        if(this.m_ifangxiang == 1)
        {
            var istartx = this.x;
            var iendx = this.x + this.m_iwidth - 1;
            

            var startpt = this.GetGridCenterPt(istartx,this.y);
            var endpt = this.GetGridCenterPt(iendx,this.y);

            var centex = Math.floor(startpt.x+endpt.x)/2;
            var centery = Math.floor(startpt.y+endpt.y)/2;

            return {x:centex,y:centery};

        }
        else
        {
            var istarty = this.y;
            var iendy = this.y + this.m_iwidth - 1;
            

            var startpt = this.GetGridCenterPt(this.x,istarty);
            var endpt =this. GetGridCenterPt(this.x,iendy);

            var centex = Math.floor(startpt.x+endpt.x)/2;
            var centery = Math.floor(startpt.y+endpt.y)/2;

            return {x:centex,y:centery};
        }
        */
 
    }

    GetImageFrameIndex()
    {
        if(this.m_itype == 0)
        {
             
            return 7;
        }


        if(this.m_iwidth == 2 && this.m_iheight == 1)
        {
            return 1
        }
        if(this.m_iwidth == 1 && this.m_iheight == 1)
        {
            return 6;
        }

        if(this.m_iwidth == 2 && this.m_iheight == 2)
        {
            return 7;
        }
        return 3;
/*
        if(this.m_ifangxiang == 1)
        {
            if(this.m_iwidth  == 3)
            {
                return 2;
            }
            return 1;
        }else{
            if(this.m_iwidth  == 3)
            {
                return 4;
            }
            return 3;
        }
        */

    }
}