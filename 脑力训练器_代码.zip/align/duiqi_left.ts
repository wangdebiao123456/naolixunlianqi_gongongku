 

const {ccclass, property} = cc._decorator;

@ccclass
export default class duiqi_left extends cc.Component {

 
    @property
    alginleft: number = 0;

 
    
    onLoad () 
    {
 

        var mysize = cc.director.getWinSize();
        var cx1 = mysize.width;
        var cy1 =  mysize.height;

        let size_frame = cc.view.getFrameSize();
        var cx_2  = size_frame.width;
        var cy_2 =  size_frame.height;

        
        var icomss = cx1/cy1;
        var ireals = cx_2/cy_2;


        var cal_width = cx1/2;
        if(ireals > icomss)
        {
            //宽比实际宽
            cal_width = cx1/2 * ireals/icomss;;
        }
        else if(ireals < icomss)
        {
            //高比实际高

            cal_width =cx1/2;

        }else
        {
            cal_width = cx1/2 ;
        }

        this.node.x =  -1* cal_width   + this.alginleft;


    }
 
}
