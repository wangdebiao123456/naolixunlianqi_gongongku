 
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";
import PlatFormType from "../PlatForm/PlatFormType";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
import WMap from "../WDT/WMap";

 
export default class Start_Game_InfoMng
{
    public static  m_ins:Start_Game_InfoMng = null;
    static shieldVersion = '1.1'

    m_b_lanuch_from_shoucang = 0;
    m_b_lanuch_from_zhuomian = 0;

    timeStamp_hide = 0;
    m_b_in_share_msg = 0;

    initTime = 0;
    m_wx_show_hide_event_lisnter_map = new WMap();

    public static GetIns()
    {
        if(Start_Game_InfoMng.m_ins == null)
        {
            Start_Game_InfoMng.m_ins  =  new Start_Game_InfoMng();
        }

        return Start_Game_InfoMng.m_ins;
    }

    constructor()
    {
        this.resetInitTime();
        this.Reg_WX_Hide_Show();
 
    }
    Check_BK_Musci()
    {

    }
    Reg_WX_Hide_Show()
    {
        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }

        var self=  this;
        wx.onHide(()=>
        {
            self.On_WX_Hide_Event();
        });

        wx.onShow( (res)=>
        {
            self.On_WX_Show_Event(res);
        });

        wx.showShareMenu() 
    }
    Get_WX_Lanuch_Scece_Info()
    {
        
        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
        var langop = wx.getEnterOptionsSync();
        var scene = langop.scene;


        console.log("启动场景:"+scene)

        if(scene == 1257 || scene == 1103 || scene == 1104)
        {
            this.m_b_lanuch_from_shoucang = 1;
        }


         if(scene == 1023)
        {
            this.m_b_lanuch_from_zhuomian = 1;
        }
    }


    Notify_WX_Show_Hide_Event(bshow)
    {
        var copymap = this.m_wx_show_hide_event_lisnter_map.Copy();

        for(var ff=0;ff<copymap.size();ff++)
        {
            var ff_lisnetr = copymap.GetKeyByIndex(ff);
            ff_lisnetr.Notify_WX_Show_Hide_Event(bshow)
        }

        BackGroundSoundUtils.GetInstance().ResumeBkMusic()
    }

    On_WX_Hide_Event()
    {
        this.timeStamp_hide = new Date().getTime();
 

        this.Notify_WX_Show_Hide_Event(0)
    }
    resetInitTime(){
        this.initTime = Date.now();
    }
    On_WX_Show_Event(res)
    {
        if (this.timeStamp_hide) {
            this.resetInitTime();
        }

        
        this.Notify_WX_Show_Hide_Event(1)
    }

    Add_WX_Show_Hide_Event_Lisnter(lisnter)
    {

        this.m_wx_show_hide_event_lisnter_map.putData(lisnter,1);
    }
    Remove_WX_Show_Hide_Event_Lisnter(lisnter)
    {

        this.m_wx_show_hide_event_lisnter_map.RemoveKey(lisnter);
    }



}