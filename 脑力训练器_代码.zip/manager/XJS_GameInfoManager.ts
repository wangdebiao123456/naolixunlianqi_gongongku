import ComFunc from "../comfuncs/ComFunc";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import MyLocalStorge from "../WDT/MyLocalStorge";
import WMap from "../WDT/WMap";

 

export default class XJS_GameInfoManager 
{
    static _instance:XJS_GameInfoManager = null;
    static GetInstance() :XJS_GameInfoManager
    {
        if (!XJS_GameInfoManager._instance) {
            // doSomething
            XJS_GameInfoManager._instance = new XJS_GameInfoManager();
             
        }
        return XJS_GameInfoManager._instance;
    }

    m_i_enter_game_mode = 1;
    m_i_current_enter_gk = 1;
    m_name_preabnode_map = new WMap();
    
    m_fuben_type_first_entered_map = new WMap();

    m_all_in_bag_daoju_type_leftcount_map = new WMap();
    
    constructor()
    {
        this.InitRead_JSGame_Basic_Info();

    }
    Get_Preb_ByName(preabname){
        if(this.m_name_preabnode_map.hasKey(preabname)){
            var preabg=  this.m_name_preabnode_map.getData(preabname);
            return preabg;
        }

        return null;
    }
    Set_Readed_Preab_Info(preabname,preab){
        this.m_name_preabnode_map .putData(preabname,preab);
    }
    Set_Fuben_Type_Entered(ifubentype)
    {
        this.m_fuben_type_first_entered_map.putData(ifubentype,1);

      
    }
    Get_Fuben_Type_Entered(ifubentype)
    {

        if(this.m_fuben_type_first_entered_map.hasKey(ifubentype))
        {
            return 1;
        }

        return 0;

    
    }

    Get_Fubentype_Name(ifubentype)
    {
        if(ifubentype == 31)
        {
            return "新手副本";
        }
        if(ifubentype == 32)
        {
            return "日常副本";
        }
        if(ifubentype == 33)
        {
            return "高手副本";
        }
       
        if(ifubentype == 35)
        {
            return "怪兽对战副本";
        }
       


        return "副本";
    }
    Get_Fuben_Type_Max_Winned_GK( ifubentype)
    {
 
        return 0;
    }
    On_User_New_EnterGame()
    {

    }
    Save_JSGame_Basic_Info()
    {
        var basicinfo = { m_all_in_bag_daoju_type_leftcount_map: ComFunc.Format_Save_OBJ_Map(this.m_all_in_bag_daoju_type_leftcount_map) 
        };
    
        MyLocalStorge.setItem("naoli_xjs_base_info",JSON.stringify(basicinfo));

    }
    InitRead_JSGame_Basic_Info()
    {

        var str= MyLocalStorge.getItem("naoli_xjs_base_info");
        if(!str)
        {
            return;
        }

        var basic_obj = JSON.parse(str);
        if(!basic_obj)
        {
            return;
        }

     
        this.m_all_in_bag_daoju_type_leftcount_map = ComFunc.Serize_Saved_OBJ_Map(basic_obj.m_all_in_bag_daoju_type_leftcount_map);
    }
    Add_DaojuType_Count_List(awarddaoju,ibeishu = 1)
    { 
        GlobalGameMng.GetInstance().Common_Add_Award_List(awarddaoju,ibeishu);
    
     
    }
    Change_Self_DaojuType_Count(ff_t,ff_c){
        GlobalGameMng.GetInstance().Change_Self_DaojuType_Count(ff_t,ff_c)
      
        /*
        if(!this.m_all_in_bag_daoju_type_leftcount_map.hasKey(ff_t)){
            this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_t,ff_c);
        }else{
            var iprevc = this.m_all_in_bag_daoju_type_leftcount_map.getData(ff_t);

            var inewc = ff_c + iprevc;

            if(inewc <= 0)
            {
                inewc = 0;
            }

            this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_t,inewc);
        }
        this.Save_JSGame_Basic_Info();
        */
    }
    Get_Self_DestType_Daoju_Count(itype)
    {
        return GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(itype);

    
    }
    On_GameType_GK_Guoguang(imode,igk)
    {
        
    }
    Get_Guoguang_Gk_Jiangli(imode,igk)
    {
        return[];
    }

    Get_JSGame_Gk_Winned_Jiangli(igamemode, igk,bfistwin = 0)
    {
        var ijinbiadd = 5;
        var ixuanzhangadd = 0;
        if(bfistwin)
        {
            ijinbiadd = 10;
            ixuanzhangadd = 5;

            if(igk%4 == 0   )
            {
                ijinbiadd += 10;
                ixuanzhangadd += 5;
            }
        
        }
 
        var com = [{"t":1,"c":ijinbiadd}];
        
        if(61 == igamemode)
        {
            com = [{"t":1,"c":50},{"t":2,"c":100}];
        }
        var gk_reward_info = {

            "first":[],
            "common":com
        }




        return gk_reward_info;
    }


    Get_Game_Type_Name(igmaemode, igametype)
    {
       
        
        if(igmaemode == 2)
        {
            return  "移箱子";
        }
     
        if(igmaemode == 3)
        {
            return  "推箱子";
        }
        

        if(igmaemode == 4)
        {
            return  "木室逃亡";
        }


        if(igmaemode == 5)
        {
            return  "数字华容道";
        }

        if(igmaemode == 36)
        {
            return "打出一亿伤害";
        }
 

        if(igmaemode == 11)
        {
            return "怪兽集合训练";
        }
 

        if(igmaemode == 12)
        {
            return "怪兽疯狂集合训练";
        }
 

        if(igmaemode == 13)
        {
            return "酒吧调酒训练";
        }
 

        if(igmaemode == 14)
        {
            return "酒吧调酒挑战";
        }
 
        if(igmaemode == 21 || igametype == 22)
        {
            return "怪兽排序训练";
        }
  
        if(igmaemode == 61)
        {
            return  "螺丝排序";
        }
        

        if(igmaemode == 62)
        {
            return  "螺丝合成";
        }
        

        if(igmaemode == 63)
        {
            return  "打螺丝";
        }

        if(igmaemode == 1)
        {
            if(igametype == 1)
            {
                return  "滑木块 简单模式";
            }
            if(igametype >130 && igametype < 150)
            {
                var inandu = igametype- 130;
                return  "滑木块 "+this.Get_Nandu_Str(inandu)+"模式";
            }
        }

     


        return "";
    }
    Get_Nandu_Str(inandu)
    {
        if(inandu == 1)
        {
            return "简单";
        }

        if(inandu == 2)
        {
            return "普通";
        }
        if(inandu == 3)
        {
            return "中等";
        }


        if(inandu == 4)
        {
            return "困难";
        }

        if(inandu == 5)
        {
            return "特难";
        }

        return "";
    }
}