
export default class XJS_Delay_Delete_OBJ 
{
    m_parentmng = null;

    m_b_need_delay_destroyed = 0;
    m_delay_destroy_need_tick = 0;
    m_delay_destroy_start_tick  = 0;
    m_real_jsobj_wuping_node = null;
    m_i_srcx = 0
    m_i_srcy = 0;
    
    m_specialtype = 0;
    m_main_node  = null;


    constructor(parentmng)
    {
        this.m_parentmng = parentmng;

        this.m_b_need_delay_destroyed = 0;
        this.m_delay_destroy_need_tick = 0;
        this.m_delay_destroy_start_tick  = 0;

        this.m_i_srcx = 0
        this.m_i_srcy = 0;
        
        this.m_specialtype = 0;
    }
    GetX()
    {
        return this.m_i_srcx;
    }
    IS_Common_Basic_OBJ()
    {
        return false;
    }
    GetY()
    {
        return this.m_i_srcy;
    }
     
    SetJSOBJDelayDeleteSec(itick)
    {
        this.m_b_need_delay_destroyed = 1;
        this.m_delay_destroy_need_tick = itick;
        this.m_delay_destroy_start_tick  = Date.now();

    }
    DeleteRNode()
    {
        if(this.m_main_node)
        {
            this.m_main_node.destroy();
            this.m_main_node = null;
        }
    }
    On_JSGame_Update_Tick(dt)
    {

    }
    setScale(scale)
    {
        if(this.m_main_node)
        {
            this.m_main_node.scale = scale
           
        }
    }
    Update_JS_Game_Tick_SRC(dt)
    {
        if(!this.m_b_need_delay_destroyed)
        {
            this.On_JSGame_Update_Tick(dt);
            return;
        }
        var icurtick = Date.now();
        var ieplasetick = icurtick - this.m_delay_destroy_start_tick;

         
        if(ieplasetick > this.m_delay_destroy_need_tick )
        {
            this.m_parentmng.DestroyDelayObj(this);
        }


    }
    setPosition(x ,y)
    {
        this.m_i_srcx = x;
        this.m_i_srcy = y;
        this.m_main_node.setPosition(x ,y);

        this.m_main_node.zIndex = 2280-y;
  
    }
    Change_JSOBJ_NodeState_Anim()
    {

    }
    CreateOBJRealOBJNode()
    {
        var node = new cc.Node();
   
        return node;
    }
    InitJSGameOBJInfo(parentnode,zorder=10)
    {
       // this.Init_Offset_And_Pos_Scale();
         this.m_main_node = new cc.Node();
        var pnode = this.CreateOBJRealOBJNode();
        
        this.m_main_node.addChild(pnode,20);
        this.m_real_jsobj_wuping_node = pnode; 

        parentnode.addChild(this.m_main_node,zorder);
        this.m_main_node.setPosition(this.m_i_srcx,this.m_i_srcy)

        this.Change_JSOBJ_NodeState_Anim();
    }
}