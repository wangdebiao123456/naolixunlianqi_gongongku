 
import XJS_GameInfoManager from "./XJS_GameInfoManager"; 
import XJS_Delay_Delete_OBJ from "./XJS_Delay_Delete_OBJ";
import NodeComPoolUtils from "../WDT/NodeComPoolUtils";
import { BoomEffectAnim } from "../effect/BoomEffectAnim";

export default class XJS_BoombAnim_OBJ extends XJS_Delay_Delete_OBJ
{

    m_preab_name = "preyuzhi/effect/anim";

    m_boom_animate_name=  "";

    m_effect_delay_show_sec = 0;
    m_delay_eplase_sec = 0;

    m_is_real_created_boom_node = 0;


    m_boom_real_obj = null;

    m_b_play_effect = 1;

    //攻击后，出现的攻击特效
    constructor( boomaniname,delay_sec, iboombanimytype:number,  parentmng,b_play_effect = 1)
    {
        super(parentmng);

        this.m_b_play_effect = b_play_effect;
        this.m_boom_animate_name = boomaniname;
        this.m_effect_delay_show_sec = delay_sec;
       // this.SetJSOBJDelayDeleteSec(2000); 
    }

    On_JSGame_Update_Tick(dt)
    {
        this.m_delay_eplase_sec += dt;
        if(this.m_effect_delay_show_sec <=  0)
        {
            return;
        }

        if(this.m_is_real_created_boom_node)
        {
            return;
        }

        if(this.m_delay_eplase_sec >= this.m_effect_delay_show_sec)
        {
            var boomnode = this.CreateRealBoombNode();
            this.m_main_node.addChild(boomnode,20); 
            this.m_real_jsobj_wuping_node = boomnode;

        }

      

    }


    Notify_Boomb_Anim_End()
    {
        this.SetJSOBJDelayDeleteSec(10); 
    }

    CreateRealBoombNode()
    { 

        var preab = XJS_GameInfoManager.GetInstance().Get_Preb_ByName(this.m_preab_name);
        var pnode=  NodeComPoolUtils.GetInstance().GetPrabbNameNode(this.m_preab_name,preab);
         
        let anim: BoomEffectAnim = pnode.getComponent("BoomEffectAnim");
        anim.init(this, this.m_boom_animate_name,false,this.m_b_play_effect);

        this.m_is_real_created_boom_node = 1;
       
        this.m_boom_real_obj = pnode;
        return pnode;
    }

    CreateOBJRealOBJNode()
    {
        if(this.m_effect_delay_show_sec > 0)
        {
            return new cc.Node();
        }
       
        var realboombnode = this.CreateRealBoombNode(); 

        return realboombnode;
    }



    DeleteRNode()
    {
        if(this.m_boom_real_obj)
        {

            NodeComPoolUtils.GetInstance().putANode(this.m_preab_name,this.m_boom_real_obj);
            this.m_boom_real_obj = null;
        }

        super.DeleteRNode();

    }
}