import ComFunc from "../comfuncs/ComFunc";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import IPlatBannerMng from "./IPlatBannerMng";

export default class BytedanceBannerMng  extends IPlatBannerMng
{
    constructor()
    {
       super();
    }
    Get_Game_Inner_Banner_Bottom_Banner_Y(ibannertype,bannerheight = null)
    {

        
         var res = tt.getSystemInfoSync();
 
        var windowWidth = res.windowWidth;
        var windowHeight = res.windowHeight;
 
        //真实分辨率
        var irealheight = this.Get_Real_Height();
 
    
        //真实分辨率 
        var ibilv_y = windowHeight/irealheight;


        var iyy1 = 113;
        if(ibannertype == 1)
        {
            iyy1 = 80;

        }

        if(bannerheight && bannerheight > 0)
        {
            iyy1 = bannerheight +2;

        }


        var alginbottom = GlobalGameMng.GetInstance().IS_Game_Scence_Bottom_Banner_Align_Bottom(ibannertype);
        var y =  windowHeight - iyy1;  

        if(alginbottom)
        {
            if(ComFunc.ISChaoGaoPing())
            {
                y -= 20;

            }
        }
        else{
            var itopy = irealheight  - 1100 - 5   ;

            if(ComFunc.ISChaoGaoPing())
            {
               itopy = irealheight  - 1160 -5 ;

            }

            var idibuy =   itopy;

            var aligin_y =  windowHeight - idibuy*ibilv_y;
            
            if(aligin_y > windowHeight - iyy1)
            {
                aligin_y = windowHeight - iyy1;
            }
            
            y= aligin_y;
        }

        console.log("调整 ibannertype="+ibannertype+",alginbottom="+alginbottom+",windowHeight="+windowHeight+",y="+y)

        return y;
    }

    GetBanner_Pos(ibannerindex)
    {
         
        var  bchaogaoping =  ComFunc.ISChaoGaoPing();



        var res = tt.getSystemInfoSync();
 
        var windowWidth = res.windowWidth;
        var windowHeight = res.windowHeight; 


        var winsize_pixel =  cc.director.getWinSizeInPixels();

       // console.log("winsize_pixel.cx="+winsize_pixel.width+",winsize_pixel.cy="+winsize_pixel.height);

        var pix_bili_y1 = windowHeight/winsize_pixel.height;
 
 
        //真实分辨率
        var irealheight = this.Get_Real_Height();
 
        var ireal_width = this.Get_Real_Width();
        var ibilv = windowWidth/ireal_width;
     
        var x = 0;
        var y = 2000;

       
        var cx = windowWidth;
        if(windowWidth > 400)
        {
            cx = 400;
        }
        var ileft =  2;

    
        //真实分辨率 
        var ibilv_y = windowHeight/irealheight;

        var itop = windowHeight/2 + 400*ibilv_y;


         
        if(ibannerindex  == 17 || ibannerindex == 18 || ibannerindex == 199|| ibannerindex == 198)
        {
            x = 2;

            y =  60;

            if(bchaogaoping)
            {
                y =  100;

            }
         
        } 
        
        else if(  ibannerindex  == 161)
        {
            
            x = 5;

            y =  windowHeight/2 + 295*ibilv_y; 
        }
        else if(ibannerindex  == 101)
        {
            // /大厅左边格子

             x=10;
             y = windowHeight -  180*ibilv_y;

        } 
        else if(ibannerindex  == 102)
        {
            // /大厅边格子

             x=windowWidth - 80;
             y = windowHeight - 180*ibilv_y;

        }   
        else if(ibannerindex  == 41 )
        {
            //胜利弹框上面格子
            
            x = 5;
             y = windowHeight/2 -  330*ibilv_y;
 
 
          
        }else if(ibannerindex  == 42  )
        {
            //胜利弹框下方格子
            
            x = 5;

            y =  windowHeight/2 + 410*ibilv_y;;  
        }
        else if(  ibannerindex  == 44)
        {
            
            x = 5;
           
 
             var itopy = irealheight/2 - 640  +410;


             if(ComFunc.ISChaoGaoPing())
             {
                itopy = irealheight/2 - 700  +410;
 
             }

         //    var ineeddescyt = irealheight/2 - itopy;


             y = windowHeight/2 -  itopy*ibilv_y;
 
        }else if(  ibannerindex  == 45)
        {
            //失败弹框下方格子
            
            x = 5;

            y =  windowHeight/2 + 410*ibilv_y;;  
        } else if(ibannerindex  == 57)
        {
            
            x = 5;

            y =  windowHeight/2 + 180*ibilv_y;;  
        }
        else if(ibannerindex  == 61  )
        {
            
            x = 5;

            y =  windowHeight/2 + 295*ibilv_y; 
        }
         
        else if( ibannerindex  == 151 || ibannerindex  == 88 ||  ibannerindex  == 82 ||  ibannerindex  == 72  ||  ibannerindex  == 92||  ibannerindex  == 112)
        {
            
            x = 5;

           
            y= this.Get_Game_Inner_Banner_Bottom_Banner_Y(1);
         
           

        }
        else if(    ibannerindex  == 152   ||  ibannerindex  == 89   || ibannerindex  == 83 || ibannerindex  == 93 ||  ibannerindex == 73 ||  ibannerindex == 113  )
        {
            
              
            x = (windowWidth-360)/2;

            y= this.Get_Game_Inner_Banner_Bottom_Banner_Y(2);
          
           
        }else if(  ibannerindex  >= 261 && ibannerindex  <= 265)
        {
            //单格子

            var index11 = ibannerindex - 261;
            x = index11 * 76;
         
            y = windowHeight - 120;

            console.log("格子 261")
        }
        else if(ibannerindex  == 40    )
        { 

            x = 2;

            y =  1080*ibilv_y; 
        }
        else if(ibannerindex  == 121)
        {
            // /大厅左边格子

             x=10;
             y = windowHeight -  180*ibilv_y;

        }  
             else if(ibannerindex  == 123)
        {
            // /大厅左边格子

             x=1;
             y = windowHeight/2 + 300*ibilv_y;

        } else if(ibannerindex  == 32)
        {
            
            x = 5;

            y =  windowHeight/2 + 150*ibilv_y; 
        }
         
        else if(ibannerindex  == 77)
        {
            
            x = 5;

            y =  windowHeight/2 + 355*ibilv_y;;  
        }
        else if(  ibannerindex  == 95)
        {
            //退出确认中间弹框格子
            x = 5;
           
 
             var itopy = 150;


             if(ComFunc.ISChaoGaoPing())
             {
                itopy = 150 +60;
 
             }

         //    var ineeddescyt = irealheight/2 - itopy;


             y =  itopy*ibilv_y;
 
        }
        else if(  ibannerindex  == 96)
        {
            x = 2;

            y =  390*ibilv_y+10;

        }else if(  ibannerindex  == 97)
        {
             //退出确认弹框左边格子
             x = 2;
         
             y = windowHeight/2 + 340*ibilv_y;

        }else if(  ibannerindex  == 98)
        {
             //退出确认弹框左边格子
             x = windowWidth - 80;
         
             y = windowHeight/2 + 340*ibilv_y;

        }  else if(ibannerindex  == 155)
        {
            x = 2;

            y =  480*ibilv_y+10;
        }
        else if(  ibannerindex  == 177)
        {
            x = 2;

            y =  390*ibilv_y+10;

        }else if(  ibannerindex  == 195)
        {
            x = 2;

            y =  500*ibilv_y+2;

        }
        else if(ibannerindex == 76 || ibannerindex ==  31 || ibannerindex ==  56  || ibannerindex ==  122
             || ibannerindex ==  62 || ibannerindex ==  162)
        {
            x=2;
             y = 1;
        }
        else{


            x = ileft;
            y = itop;
        }


 


        return {x:x,y:y}
    }

    Get_Banner_Union_ID(ibannerindex)
    {
      
        if(ibannerindex == 1)
        {
            return "4rvl13gdeuo4jknh34";

        }  

        return "4rvl13gdeuo4jknh34";
   
    }
    On_Banner_Pos_Resize(bannerAd,ibannerindex,size_width, size_height)
    {
        const { windowWidth, windowHeight } = tt.getSystemInfoSync();
    
        if(ibannerindex == 1)
        {
            bannerAd.style.top = windowHeight - size_height;
            bannerAd.style.left = (windowWidth - size_width) / 2;
          
        }

    }
    //ibannertype:1-普通banner,2:格子       
    Check_Create_Banner(ibannerindex,ibannertype, callback)
    {
        return;
        var self = this;

        if(this.m_banner_index_banner_map.hasKey(ibannerindex))
        {
            var banner = this.m_banner_index_banner_map.getData(ibannerindex);
            callback(true,ibannerindex, banner);
            return;
        } 
       
        var banner_ubiinid = this.Get_Banner_Union_ID(ibannerindex);

        this.m_banner_index_type_map.putData(ibannerindex,ibannertype);


        var bannerpos = this.GetBanner_Pos(ibannerindex);

        if(ibannertype == 1)
        {

            console.log("createGameBanner left="+bannerpos.x+",top="+bannerpos.y);
    

           
            var gezi_guanggao_obj = tt.createBannerAd( 
                {
                    
                    adUnitId:banner_ubiinid, 
                    adIntervals:30,
                    style:{
                        left:bannerpos.x,
                        top:bannerpos.y ,
                        width: 300,
                        adIntervals: 35,
                        height:80
                    }
                
                }
            ); 
            gezi_guanggao_obj.onError(
                (err)=>
                {
                
                    ////console.log("格子广告错误:"+JSON.stringify(err));
                    //gezi_guanggao_obj.destroy();
                    //self.m_banner_index_banner_map.RemoveKey(ibannerindex);
                }
            );
        
          
            console.log("ibannerindex="+ibannerindex+",gezi_guanggao_obj="+gezi_guanggao_obj)
            this.m_banner_index_banner_map.putData(ibannerindex,gezi_guanggao_obj);

            callback(true,ibannerindex,gezi_guanggao_obj);
        }
        else if(ibannertype == 2)
        {
            

        }else
        {
            callback(false);
        }

    }
    Check_Banner_Need_Destroy_Shuaxin(ibannerindex,ibanenrtype)
    {

        return false;
    }
    Refresh_Banner_Change_Show(ibannerindex)
    {
        return;
        var last_show_tick = 0;
        if(this.m_banner_index_last_first_show_tick_map.hasKey(ibannerindex))
        {
            last_show_tick = this.m_banner_index_last_first_show_tick_map.getData(ibannerindex);
        }

        var bshow = this.Is_Banner_Show_Now(ibannerindex);

        console.log(ibannerindex+",Is_Banner_Show_Now  bshow= "+bshow)

        var self = this;
        
        if(this.m_banner_index_banner_map.hasKey(ibannerindex))
        {
            var banner  = this.m_banner_index_banner_map.getData(ibannerindex);
         
            var ibanenrtype = this.Get_Banner_Type(ibannerindex);
       

            if(last_show_tick > 0 && Date.now() - last_show_tick > 33*1000 
                 && this.Check_Banner_Need_Destroy_Shuaxin(ibannerindex,ibanenrtype)  )
            {
                //先销毁

                console.log("销毁banner ibannerindex="+ibannerindex);
                banner.destroy();
                this.m_banner_index_banner_map.RemoveKey(ibannerindex);
                this.m_banner_index_last_first_show_tick_map.RemoveKey(ibannerindex);
                this.m_banner_index_has_showed_map.RemoveKey(ibannerindex);


                this.Check_Create_Banner(ibannerindex,ibanenrtype, ()=>
                {
                   // self.Refresh_Banner_Change_Show(ibannerindex);

                })

                return;
            }
           

          //  console.log("Refresh_Banner_Change_Show bshow="+bshow);

            if(ibanenrtype == 2)
            {
                if(bshow)
                {
                    if(!banner.isShow() || !this.Has_Banner_Showed(ibannerindex))
                    {
                        banner.show();
                        this.Set_Banner_Showed(ibannerindex);
                    }
                    
                    if(!this.m_banner_index_last_first_show_tick_map.hasKey(ibannerindex))
                    {
                        this.m_banner_index_last_first_show_tick_map.putData(ibannerindex,Date.now());
                    }
                   
                }else{

                    
                    if(banner.isShow())
                    {
                        banner.hide();
                    } 

                }
            }else{

              

                if(bshow)
                {
                    if(!this.Is_Banner_Show_Now(ibannerindex))
                    {
                        console.log("显示 banner:"+ibannerindex);
                        banner.show();
                        this.Set_Banner_Showed(ibannerindex);

                        this.Set_Banner_Need_Show(ibannerindex,bshow)
    
                        if(!this.m_banner_index_last_first_show_tick_map.hasKey(ibannerindex))
                        {
                            this.m_banner_index_last_first_show_tick_map.putData(ibannerindex,Date.now());
                        }
                    }
                   
                   

                }else{

                    if(this.Is_Banner_Show_Now(ibannerindex))
                    {
                       banner.hide();
                       this.Set_Banner_Need_Show(ibannerindex,bshow)
    
                    }
                }


            }
            
          
        }
        else{

           
        }
    }

}