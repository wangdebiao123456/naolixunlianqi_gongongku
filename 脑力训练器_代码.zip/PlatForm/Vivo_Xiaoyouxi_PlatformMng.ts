import IPlatformMng from "./IPlatformMng";


export default class Vivo_Xiaoyouxi_PlatformMng extends IPlatformMng
{
  
    m_all_reward_video = null;
    constructor()
    {
        super();

    }

    IS_Fenxiang_Btn_Show()
    {
      return false;

    }
    Check_Show_YonghuXieyi()
    {
        return true;
    }

    Dating_Fenxiang()
    {
      qg.share();
    }
    CheckShowChaiping()
    {
        const interstitialAd = qg.createInterstitialAd({
            posId:'87c9b0eb4418495d978665adc5b19162' 
          });
          interstitialAd.onError(err => {
            console.log("插屏广告加载失败", err);
          });
        
          interstitialAd.show().then(()=>{ 
            console.log('插屏广告展示完成');
          }).catch((err)=>{
            console.log('插屏广告展示失败', JSON.stringify(err));
          })
    }

    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        const rewardedAd = qg.createRewardedVideoAd({
            posId:'0d8c7afdb2e84bca86348024a1b6a1da',
          });


          if(this.m_all_reward_video == null)
          {
            this.m_all_reward_video = rewardedAd;

          }else{
         
          }
           rewardedAd.load();

          rewardedAd.onError(err => {
            console.log("激励视频广告加载失败", err);
          });



          rewardedAd.onLoad(function(res) { 
            rewardedAd.show().then(()=>{ 
              console.log('激励视频广告展示完成');
            }).catch((err)=>{
              console.log('激励视频广告展示失败', JSON.stringify(err));
            }) 
          });

        
         
          rewardedAd.onClose(res => {
            if (res && res.isEnded) {
                callback(true);
              console.log("正常播放结束，可以下发游戏奖励");
            } else {
                callback(false);
              console.log("播放中途退出，不下发游戏奖励");
            }
          });
    }


    
    Watch_Com_Guanggao_ID_B(guanggaoname,in_cb,errorload_cb,agv,callback)
    {
      
      
       this.Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    }

    Get_Global_Config_Server_Path()
    {
        var irand11 = Math.floor(Math.random()*1000) ;
        var config_json = "https://outercoms.zfgame123.com/config/shaonaomukuai/vivo/vivo_shaonaomukuai_config.json?r="+irand11;

        return config_json; 
    }

    IS_Can_Show_Zidingyi_TuijianWei()
    {
        return false;
    }
    IS_Dating_Game_Quanping_Gezi_Btn_Show()
    {
        return false;
    }
}