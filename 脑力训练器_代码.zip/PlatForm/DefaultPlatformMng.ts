import IPlatformMng from "./IPlatformMng";

 

export default class DefaultPlatformMng extends IPlatformMng
{
    constructor()
    {
        super();

    }

    Check_Show_YonghuXieyi()
    {
        return true;
    }
    Is_Dating_Show_Tuijian_Tiaozhuan()
    {
        return false;
    }
    IS_Fenxiang_Btn_Show()
    {

        return true;
    }
    IS_Can_Show_Zidingyi_TuijianWei()
    {
        return false;
    }
    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        callback(true);
    }

    Watch_Com_Guanggao_ID_B(guanggaoname,in_cb,errorload_cb,agv,callback)
    {
        callback(true);
 
    }
}