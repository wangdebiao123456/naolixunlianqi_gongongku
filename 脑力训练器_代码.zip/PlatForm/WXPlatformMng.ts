import MyHttpPostInfoUtil from "../comfuncs/MyHttpPostInfoUtil"; 
import MyLocalStorge from "../WDT/MyLocalStorge";
import WMap from "../WDT/WMap";
import IPlatformMng from "./IPlatformMng";
import WXBannerMng from "./WXBannerMng";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import LeoGameInfoMng from "../WDT/LeoGameInfoMng";


export default class WXPlatformMng extends IPlatformMng
{
    m_video = null;
    m_appid_navaiged_tick_map = new WMap();

    m_readed_wx_openid_info=  null;

    m_guanangao_id_viedeo_map = new WMap();

    m_last_vide_union_id = "";

    constructor()
    {
        super();

        wx.onShareAppMessage(function () {
            return {
                "query":this.Get_Share_Query() 
              
            }
          })


          wx.showShareMenu({
            withShareTicket: true,
            menus: ['shareAppMessage', 'shareTimeline']
          })

    }
    IS_Can_Show_Zidingyi_TuijianWei()
    {
        return true;
    }
    ReadPrev_WX_OpenID_Info()
    {
        var str= MyLocalStorge.getItem("shaonaomukuai_wx_openid_info");
        if(!str)
        {
            return null;
        }

        var obj = JSON.parse(str);
        if(!obj)
        {
            return null;
        }


        var openid = obj.openid;
        if(!openid)
        {
            return null;
        }

        return obj;
    }
    Get_Share_Query()
    {
        var appid = this.Get_Saved_GUID();

        var strquery = "fromopenid="+appid+"&plate=wx&u=1";
        return strquery;
    }
    Share_Msg(strtiel,strtyip)
    {
        if(this.Is_In_Test_Version())
        {

            return;
        }
        wx.shareAppMessage({
            "query":this.Get_Share_Query(),
            title: strtyip
          });
    }
    Post_Server_Req_OpenID_Info(scode,callback)
    {

    
       
        var obj =
        {
            code: scode,
            appid:"wxc5c5bac259ded771"
          };


          var self = this;

        var str = JSON.stringify(obj);
        MyHttpPostInfoUtil.POSTData( 'https://outercoms.zfgame123.com/Get_WX_Login_OpenID_Info.aspx',str,
        (bsuc,response)=>
        {
            console.log("Get_WX_Login_OpenID_Info response="+response);
        
            if(!bsuc)
            {
                console.log("获取openid错误:");
                callback();
                return;
            }

            var resobj = JSON.parse(response);

            var openid = resobj.openid;

            if(!openid)
            {
                callback();
                return;
            }
            var unionid = resobj.unionid;
            if(!unionid)
            {
                unionid = "";
            }
            console.log("获取openid:"+openid);


            LeoGameInfoMng.GetIns().On_Readed_WX_OpenId(openid);
            
            var saveifo = {unionid:unionid,openid:openid};

            var jsaveinfoi = JSON.stringify(saveifo);
            MyLocalStorge.setItem("shaonaomukuai_wx_openid_info",jsaveinfoi);

            self.m_readed_wx_openid_info = saveifo;



            callback();

        });
       
        
    }
    Check_WX_Login_Read_OpenId(callback)
    { 
        if(this.Is_In_Test_Version())
        {
            return ;
        }
 
        var wx_openinfo = this.ReadPrev_WX_OpenID_Info();
        if(wx_openinfo)
        {
            this.m_readed_wx_openid_info = wx_openinfo;
            callback();
            return;
        }

     
       
        var self = this;

        //读取
        wx.login({
            success (res) {
              if (res.code) {

                console.log("登录code=" + res.code);

                self.Post_Server_Req_OpenID_Info(res.code,callback);
              


              } else {
                callback();
                console.log('登录失败！' + res.errMsg)
              }
             
            }
          })
         
    }


    Check_Read_WX_OpenID()
    {
       // return LeoGameInfoMng.GetIns().m_wx_openid;

    
        if(this.m_readed_wx_openid_info )
        {
            return  this.m_readed_wx_openid_info.openid;

        }

        var wx_openinfo = this.ReadPrev_WX_OpenID_Info();
        if(wx_openinfo)
        {
            this.m_readed_wx_openid_info = wx_openinfo;
      
            return  wx_openinfo.openid;
        }
        return "";
        
    }
    Create_Banner_Mng()
    {
        return new WXBannerMng();
    }
    
    IS_Fenxiang_Btn_Show()
    {

        return true;
    }
    Get_Saved_GUID()
    {

        if(this.Is_In_Test_Version())
        {
            return super.Get_Saved_GUID();
        }

        
        var stropeniud = this.Check_Read_WX_OpenID();

        return stropeniud;
         
    }
    Dating_Fenxiang()
    {
        if(this.Is_In_Test_Version())
        {

            return;
        }
        
        wx.shareAppMessage({
            title: '烧脑木块,这个游戏太好玩了,我过关过的好辛苦啊,你也来试试吧'
          });
    }
    IS_Zhanghuan_Gongzhanghao_Info_Show()
    {
        return true;
    }
    Is_Dating_Show_Tuijian_Tiaozhuan()
    {
        return true;
    }
    Tiaozhuan_Tuijian_AppID(appid)
    {
        if(this.Is_In_Test_Version())
        {

            return;
        }
        
        wx.navigateToMiniProgram({appId:appid})
    }


    Get_Chaiping_Union_ID(ichaipingtype)
    {

        /*
        if(ichaipingtype == 12)
        {
            //签到
            return "adunit-f7886d372067d171";
        }


        
        if(ichaipingtype  >= 21 && ichaipingtype <= 25)
        {
            return "adunit-686564f12a7ff468";
        }


        if(ichaipingtype  >= 26 && ichaipingtype <= 29)
        {
            return "adunit-d64d3117e662bc23";
        }


        if(ichaipingtype  >= 31 && ichaipingtype <= 39)
        {
            return "adunit-1d0cde2b627301f1";
        }


        */

        return "adunit-c087057546046cab";
    }

    CheckShowChaiping(ichaipingtype   = 0)
    {
        if(this.Is_In_Test_Version())
        {

            return;
        }


        var chaipingid = this.Get_Chaiping_Union_ID(ichaipingtype);


        
        var self = this;
        
        var chaping_gg = wx.createInterstitialAd({ adUnitId: chaipingid});
        chaping_gg.load(()=>{})

        chaping_gg.onLoad(() => {
            console.log('插屏 广告加载成功');
           // 
         
         });


          chaping_gg.onError(err => {
                chaping_gg.destroy();
              console.log("onError:"+err)
         });

         chaping_gg.onClose(res => {
            chaping_gg.destroy();
            console.log('插屏 广告关闭')
        });


        chaping_gg.show().catch((err) => {

            if(err)
            {
             
                console.error("显示error:"+ JSON.stringify(err) )
            }
            else{
                console.log('show 正常') 
            }
           
          });

    }



    Get_Guangao_ID_By_Name_MX(guanggaoname)
    {
       
        /*
        if(guanggaoname == "购买道具")
        {
            return "adunit-34a1118f56080a0d";
        }


        if(guanggaoname == "视频解锁华容道模式")
        {
            return "adunit-87e3ea7fbf7be524";
        }
      

        if(guanggaoname == "视频解锁关卡")
        {
            return "adunit-67df9707877faa5e";
        }


  
        if(guanggaoname == "连续购买体力")
        {
            return "adunit-0c4315ffabfe3a22";
        }

        if(guanggaoname == "连续购买48小时体力")
        {
            return "adunit-a644696a42fb5afc";
        }


        if(guanggaoname == "普通购买体力")
        {
            return "adunit-60f5c5c949017575";
        }

        if(guanggaoname == "游戏胜利双倍")
        {
            return "adunit-b7f9b5858b337b35";
        }

        if(guanggaoname == "购买继续游戏道具")
        {
            return "adunit-5c7ee461d4a7a690";
        }
        
        if(guanggaoname == "签到双倍")
        {
            return "adunit-2a89e4c6ad052fdc";
        }
        

        if(guanggaoname == "视频解锁难度")
        {
            return "adunit-908b804a01e3e7e2";
        }


        if(guanggaoname == "领取首看礼包")
        {
            return "adunit-3469f0f7be01e571";
        }

          
        if(guanggaoname == "商城购买道具")
        {
            return "adunit-3fb8b719ee684d32";
        }

        
        if(guanggaoname == "复活")
        {
            return "adunit-8b1a563015527c45";
        }



    
        if(guanggaoname == "三消消复活")
        {
            return "adunit-3d6cf2a40fa7b7fb";
        }


        if(guanggaoname == "购买三消消道具")
        {
            return "adunit-f439236fb0ce2d03";
        }


        if(guanggaoname == "三消消使用移除")
        {
            return "adunit-15db4e7053ddbafe";
        }

         
        if(guanggaoname == "弹出弹框购买道具")
        {
            return "adunit-b67726d2ad466066";
        }

        
        
        if(guanggaoname == "抽奖全要")
        {
            return "adunit-355ff7a9cff7f36b";
        }

        
        */

        
        return "adunit-c89694cd7c686a92";
    }

    Get_Guangao_ID_By_Name(guanggaoname)
    {
       
        return "adunit-c89694cd7c686a92";

    }
    DestroyVideoAD()
    {
        if (this.m_video)
        {
            this.m_video.destroy();
            this.m_video = null;

        }
    }

    Watch_Com_Guanggao_ID_B_Qufen_MX(guanggaoname,in_cb, agv,callback)
    {

        var self =  this;
        
        var guangaounitid =  this.Get_Guangao_ID_By_Name_MX(guanggaoname);


        if(this.m_last_vide_union_id != guangaounitid)
        {
            if(GlobalGameMng.GetInstance().IS_Watch_Video_Guanggao_Not_Same_Unionid_Need_Destroy_Prev())
            {
                if(this.m_video)
                {
                    this.m_video.destroy();
                }
                this.m_video = null;
            }
        }


        this.m_last_vide_union_id = guangaounitid;
        

        var videoAd = wx.createRewardedVideoAd({
            adUnitId: guangaounitid
        });




        var prevhas = false;

        if(this.m_video == videoAd)
        {
            
            prevhas = true;
           
        }
        this.m_video = videoAd;

        console.log("guangaounitid="+guangaounitid+",prevhas="+prevhas);

        videoAd.offError();
        videoAd.offClose();
        
        videoAd.onError(  (err)=> {
             callback(false,1,"视频播放错误:"+err.errCode);
             wx.showToast({
                 title: "视频播放错误:"+err.errCode,
                 icon: "error",
                 duration: 1500
                 });

           //  HDZhanZhengGameMng.GetInstance().Notify_HD_Event(HDZhanzheng_Event.HDZhanzheng_Event_Play_Vieo_Fail)
         });
         videoAd.onClose(function (res) {
             // 用户点击了【关闭广告】按钮
             // 小于 2.1.0 的基础库版本，res 是一个 undefined
             if (res && res.isEnded || res === undefined) {
                 // 正常播放结束，可以下发游戏奖励
                 callback(true);
             }
             else {
                 // 播放中途退出，不下发游戏奖励
                 callback(false,0,"用户中途退出");
             }
         });
        
        // 用户触发广告后，显示激励视频广告
        videoAd.show().catch(  (err)=> {
            // 失败重试
            videoAd.load()
                .then(function () { return videoAd.show(); })
                .catch(function (err) {
            
                     // self.m_b_playing_video = false;
                    //self.OnVideFailEnd();
                    callback(false,2,"无视频广告:"+err.errCode)
                    wx.showToast({
                        title: "暂无视频广告,请稍后再试:"+err.errCode,
                        icon: "error",
                        duration: 1500
                    })
                    console.log('激励视频 广告显示失败'+JSON.stringify(err));

            });
        });
    }
    Watch_Com_Guanggao_ID_B(guanggaoname,in_cb,errorload_cb,agv,callback)
    {
        if(this.Is_In_Test_Version())
        {

            callback(true);
            return;
        }
 
        var bqufen_mixi =  GlobalGameMng.GetInstance().IS_Watch_Video_Guanggao_Qufen_Mingxi();

        if(bqufen_mixi)
        {
 
             this.Watch_Com_Guanggao_ID_B_Qufen_MX(guanggaoname,in_cb, agv,callback)
             return;
        }


        var self =  this;
    
 
        var guangaounitid =  this.Get_Guangao_ID_By_Name(guanggaoname);


        if (!this.m_video) {
            // 创建激励视频广告实例，提前初始化
            var videoAd = wx.createRewardedVideoAd({
                adUnitId: guangaounitid
            });
            this.m_video = videoAd;
            this.m_video.onError(  (err)=> {
                callback(false,1,"视频播放错误:"+err.errCode);
                wx.showToast({
                    title: "视频播放错误:"+err.errCode,
                    icon: "error",
                    duration: 1500
                })
              //  HDZhanZhengGameMng.GetInstance().Notify_HD_Event(HDZhanzheng_Event.HDZhanzheng_Event_Play_Vieo_Fail)
            });
            this.m_video.onClose(function (res) {
                // 用户点击了【关闭广告】按钮
                // 小于 2.1.0 的基础库版本，res 是一个 undefined
                if (res && res.isEnded || res === undefined) {
                    // 正常播放结束，可以下发游戏奖励
                   callback(true);
                    // cb(agv);
                }
                else {
                    // 播放中途退出，不下发游戏奖励
                    callback(false,0,"用户中途退出");
                }
            });
        }
        // 用户触发广告后，显示激励视频广告
        this.m_video.show().catch(  (err)=> {
            // 失败重试
            self.m_video.load()
                .then(function () { return self.m_video.show(); })
                .catch(function (err) {
                    callback(false,2,"无视频广告:"+err.errCode)
                    wx.showToast({
                        title: "暂无视频广告,请稍后再试:"+err.errCode,
                        icon: "error",
                        duration: 1500
                    })
                console.log('激励视频 广告显示失败'+JSON.stringify(err));
 
            });
        });

  
 

    }
    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        if(this.Is_In_Test_Version())
        {

            callback(true);
            return;
        }

        var self =  this;
        
        var guangaounitid =  this.Get_Guangao_ID_By_Name(guanggaoname);

        /*
        if (!this.m_video) {
            // 创建激励视频广告实例，提前初始化
            var videoAd = wx.createRewardedVideoAd({
                adUnitId: guangaounitid
            });
            this.m_video = videoAd;
            this.m_video.onError(  (err)=> {
             
              //  HDZhanZhengGameMng.GetInstance().Notify_HD_Event(HDZhanzheng_Event.HDZhanzheng_Event_Play_Vieo_Fail)
            });
            this.m_video.onClose(function (res) {
                // 用户点击了【关闭广告】按钮
                // 小于 2.1.0 的基础库版本，res 是一个 undefined
                if (res && res.isEnded || res === undefined) {
                    // 正常播放结束，可以下发游戏奖励
                   callback(true);
                    // cb(agv);
                }
                else {
                    // 播放中途退出，不下发游戏奖励
                    callback(false);
                }
            });
        }
        // 用户触发广告后，显示激励视频广告
        this.m_video.show().catch(  (err)=> {
            // 失败重试
            self.m_video.load()
                .then(function () { return self.m_video.show(); })
                .catch(function (err) {
                
                console.log('激励视频 广告显示失败'+JSON.stringify(err));
 
            });
        });

        */



       
/*
        var videoAd = wx.createRewardedVideoAd({
            adUnitId: guangaounitid
        });
        videoAd.onError(  (err)=> {
           // callback(false);

          //  HDZhanZhengGameMng.GetInstance().Notify_HD_Event(HDZhanzheng_Event.HDZhanzheng_Event_Play_Vieo_Fail)
        });
        videoAd.onClose(function (res) {
            // 用户点击了【关闭广告】按钮
            // 小于 2.1.0 的基础库版本，res 是一个 undefined
            if (res && res.isEnded || res === undefined) {
                // 正常播放结束，可以下发游戏奖励
                callback(true);
            }
            else {
                // 播放中途退出，不下发游戏奖励
              //  callback(false);
            }
        });
    
        // 用户触发广告后，显示激励视频广告
        videoAd.show().catch(  (err)=> {
            // 失败重试
            videoAd.load()
                .then(function () { return videoAd.show(); })
                .catch(function (err) {
            
                     // self.m_b_playing_video = false;
                    //self.OnVideFailEnd();

                    console.log('激励视频 广告显示失败'+JSON.stringify(err));

            });
        });
 
        */
    }

    Check_Update()
    {
        const updateManager = wx.getUpdateManager()

            updateManager.onCheckForUpdate(function (res) {
            // 请求完新版本信息的回调
            console.log(res.hasUpdate)
            })

            updateManager.onUpdateReady(function () {
            wx.showModal({
                title: '更新提示',
                content: '新版本已经准备好，是否重启应用？',
                success(res) {
                if (res.confirm) {
                    // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                    updateManager.applyUpdate()
                }
                }
            })
            })

            updateManager.onUpdateFailed(function () {
            // 新版本下载失败
            })
    }



    Jump_To_App_Game_By_Data(data)
    {
       
        let gameJumpData = data; 
        var appId = gameJumpData.toAppID;

        if(this.m_appid_navaiged_tick_map.hasKey(appId))
        {
            var lasttick = this.m_appid_navaiged_tick_map.getData(appId);

            if(Date.now() - lasttick < 1000)
            {
                return;
            }
        }
        this.m_appid_navaiged_tick_map.putData(appId,Date.now());
        
        let wx_ = wx;
        let self = this;
        //游戏跳转参数
        // let appId = data.appId;
        let sysinfo = wx_.getSystemInfoSync();
        let plat = 3;
        if (sysinfo.platform == "ios") plat = 1;
        if (sysinfo.platform == "android") plat = 2;
        // if (!appId) appId = gameJumpData.appId;
        let jumpObj = {
            toName: gameJumpData.toName,
            toAppID: gameJumpData.toAppID,
            togameid: gameJumpData.togameid,
            toAppPath: gameJumpData.toAppPath,
            addtiond: gameJumpData.addtiond,
            platform: plat 
        }
 
      
        console.log("jumto :"+gameJumpData.toAppID+",path="+gameJumpData.toAppPath);
      
        wx_.navigateToMiniProgram({
            appId: gameJumpData.toAppID,
            extraData:jumpObj,
            path: gameJumpData.toAppPath,
            success(res) {
                ClientLogUtils.GetInstance().Poset_Server_JS_Log(39, "成功跳转微信小程序", 0,
                "appid:"+appId, 0, ""+gameJumpData.toName, 0,  "");
            },
            fail(res) {
             
            }
        });

        
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(38, "点击跳转微信小程序", 0,
        "appid:"+appId, 0, ""+gameJumpData.toName, 0,  "");
    }


    showToast(para)
    {
     
        wx.showToast(para);
    }

    Get_Global_Config_Server_Path()
    {
        var irand11 = Math.floor(Math.random()*1000) ;
        var config_json = "https://outercoms.zfgame123.com/config/shaonaomukuai/wx/shaonaomukuai_common_config.json?r="+irand11;

        return config_json;
    }

    IS_Dating_Game_Quanping_Gezi_Btn_Show()
    {
        return true;
    }
}