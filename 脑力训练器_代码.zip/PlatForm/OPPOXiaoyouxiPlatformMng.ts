import IPlatformMng from "./IPlatformMng";

export default class OPPOXiaoyouxiPlatformMng extends IPlatformMng
{
    m_all_reward_video=  null;
    constructor()
    {
        super();

    }
    IS_Fenxiang_Btn_Show()
    {

        return false;
    }

    Dating_Fenxiang()
    {

    }
    CheckShowChaiping()
    {
       
    }
    Check_Show_YonghuXieyi()
    {
        return true;
    }

    
    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        var rewardedAd = qg.createRewardedVideoAd({
            adUnitId: "636241",
          });

          if(this.m_all_reward_video == null)
          {
            this.m_all_reward_video = rewardedAd;

          }else{
           
          }
          rewardedAd.load();

          rewardedAd.onError(err => {
            console.log("激励视频广告加载失败", err);
          });
          rewardedAd.onLoad(function(res) {
            console.log('激励视频广告加载完成-onload触发', JSON.stringify(res));
            rewardedAd.show().then(()=>{ 
              console.log('激励视频广告展示完成');
            }).catch((err)=>{
              console.log('激励视频广告展示失败', JSON.stringify(err));
            }) 
          })
         
          rewardedAd.onClose(res => {
            if (res && res.isEnded) {
                callback(true);
              console.log("正常播放结束，可以下发游戏奖励");
            } else {
                callback(false);
              console.log("播放中途退出，不下发游戏奖励");
            }
          });
    }
}