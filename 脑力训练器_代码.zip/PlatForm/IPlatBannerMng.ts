import WMap from "../WDT/WMap";

export default class IPlatBannerMng  
{

    m_banner_index_type_map  = new WMap();
    m_banner_index_banner_map  = new WMap();
    m_banner_index_banner_show_map = new WMap();
    m_banner_index_has_showed_map  = new WMap();

    m_banner_index_last_first_show_tick_map = new WMap();



    m_bannerindex_ensure_need_created_map = new WMap();

    m_last_banner_try_create_tick_map = new WMap();


    constructor()
    {
       
    }


    Set_Banner_Showed(ibannerindex)
    {
        this.m_banner_index_has_showed_map.putData(ibannerindex,1);
    }
    Has_Banner_Showed(ibannerindex)
    {
        if(this.m_banner_index_has_showed_map.hasKey(ibannerindex))
        {
            return true;
        }

        return false;
    }
    Manual_Destroy_banner(ibannerindex)
    {
           
        if(this.m_banner_index_banner_map.hasKey(ibannerindex))
        {
            var banner  = this.m_banner_index_banner_map.getData(ibannerindex);
         
            console.log("销毁banner ibannerindex="+ibannerindex);
            banner.destroy();
            this.m_banner_index_banner_map.RemoveKey(ibannerindex); 
            this.m_banner_index_has_showed_map.RemoveKey(ibannerindex);

        }

    }

    FD_Banner_Mng_Timer(pmainnode) 
    {
       // console.log("FD_Banner_Mng_Timer");
        this.Refresh_All_Banner_Show();
    }
    FD_Timer_Banner_Index(ibanerindex)
    {

    }

    Refresh_All_Banner_Show()
    {

        var banner_map = this.m_banner_index_banner_map.Copy();
        for(var ff=0;ff<banner_map.size();ff++)
        {
            var ff_banerindex = banner_map.GetKeyByIndex(ff);
           // var ff_banner = this.m_banner_index_banner_map.GetEntryByIndex(ff);
           // console.log("Refresh_All_Banner_Show ff_banerindex ff_banerindex="+ff_banerindex);
            this.FD_Timer_Banner_Index(ff_banerindex);
            this.Refresh_Banner_Change_Show(ff_banerindex);
        }
    }
    Get_Real_Height()
    {
        var winsize = cc.director.getWinSize();
        var cx = winsize.width;
        var cy=  winsize.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icomss = cx/cy;
        var ireals = cx2/cy2;


        var caculate_topy = cy;
        if(ireals > icomss)
        {
            //宽比实际宽
            caculate_topy = cy;
        }
        else if(ireals < icomss)
        {
            //高比实际高

            caculate_topy = cy * icomss/ireals;

        }else
        {
            caculate_topy = cy;
        }

        return caculate_topy;
    }
    Get_Real_Width()
    {
        var winsize = cc.director.getWinSize();
        var cx = winsize.width;
        var cy=  winsize.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icomss = cx/cy;
        var ireals = cx2/cy2;


        var caculate_w = cx;
        if(ireals > icomss)
        {
            //宽比实际宽
            caculate_w = cx*ireals/icomss;
        }
        else if(ireals < icomss)
        {
            //高比实际高

            caculate_w = cx;

        }else
        {
            caculate_w = cx;
        }

        return caculate_w;
    }

    Is_Banner_Show_Now(ibannerindex)
    {

        if(this.m_banner_index_banner_show_map.hasKey(ibannerindex))
        {
            var bshownow = this.m_banner_index_banner_show_map.getData(ibannerindex);
            return bshownow;
        }

        return false;
    }

    Set_Banner_Need_Show(ibannerindex,bshow)
    {
        this.m_banner_index_banner_show_map.putData(ibannerindex,bshow);
        this.Refresh_Banner_Change_Show(ibannerindex);
    }


    Get_Banner_Type(ibannerindex)
    {
        if(this.m_banner_index_type_map.hasKey(ibannerindex))
        {

            var ibannertype=  this.m_banner_index_type_map.getData(ibannerindex);
            return ibannertype;
        }

        return 0;
    }
    Check_Create_Banner(ibannerindex,ibannertype, callback)
    {
        
    }
    Refresh_Banner_Change_Show(backbannerindex)
    {
       
    }

}