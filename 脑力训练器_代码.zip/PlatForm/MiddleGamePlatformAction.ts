import ComFunc from "../comfuncs/ComFunc";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import WMap from "../WDT/WMap";
import MiddleBanner_Gezi_Mng from "./MiddleBanner_Gezi_Mng";
import PlatFormMng from "./PlatFormMng";
import PlatFormParaMng from "./PlatFormParaMng";
import PlatFormType from "./PlatFormType";


export default class MiddleGamePlatformAction
{

    static _instance:MiddleGamePlatformAction = null;
    static GetInstance() 
    {
        if (!MiddleGamePlatformAction._instance) {
            // doSomething
            MiddleGamePlatformAction._instance = new MiddleGamePlatformAction();
             
        }
        return MiddleGamePlatformAction._instance;
    }

    
    //1-暂停，2：成功，3：复活,4:失败, 5:选关 ,6:选择最高记录，7：选择存档开始 ,8:帮助弹框  ,9:排行榜,10:游戏内道具   
    // 11:全屏格子 ,12:三消消购买道具  15:选择难度,19:商城,199:全屏格子,191:视频失败处理,  181:抽奖
    //188:morewanfa
    m_in_subgame_opened_need_close_dlg_index_map = new WMap();


    

    //游戏场下方交替出现的格子列表
    m_in_subgame_jiaoti_show_gezi_list = [];
    m_in_subgame_jiaoti_show_gezi_cur_index=  0;
    m_last_subgame_jaioti_show_gezi_change_tick = 0;



    //是否在游戏场里面
    m_in_subgme_now = false;
    m_cur_in_subgame_type = 0;
    m_cur_subgame_gezi_guangao_bannerindex_arr = [];


    //最后一次检查游戏场内banner是否出错的tick
    m_last_check_ingame_recreate_banner_tick = 0;

    m_last_from_dating_enter_subgame_tick = 0;


    
    m_banner_id_has_showned_count_map = new WMap();
    m_banner_id_first_show_tick_map = new WMap();
    m_banner_id_last_show_tick_map = new WMap();
    m_banner_id_last_hide_tick_map = new WMap();
    m_banner_id_last_manual_destroy_tick_map = new WMap();

    m_banner_error_destroyed_map = new WMap();
 
    m_manual_need_destroy_banner_lsit = []

    constructor()
    {

    }
    Is_Subgame_Gezi_Dlg_Has_One_Show()
    {
        if(this.m_in_subgame_opened_need_close_dlg_index_map.size() > 0)
        {
            return true;
        }

        return false;
    }

    On_Banner_Recreated(ibannerindex)
    {

        this.m_banner_error_destroyed_map.RemoveKey(ibannerindex);
    }
    Set_Pause_Dlg_Gezi_Sgow(bshow)
    {
        var all_gezi_list = [];

        all_gezi_list = MiddleBanner_Gezi_Mng.GetInstance().Get_Pause_Gezi_List();
        /*
        all_gezi_list.push([61,2]);
      
        all_gezi_list.push([62,2]);


        */
      
        this.Set_Com_Gezi_Show(all_gezi_list,  bshow);



 
    }
    IS_Show_Zidingyi_TuijianWei()
    {
        var bcanshow = PlatFormMng.GetInstance().IS_Can_Show_Zidingyi_TuijianWei();

        return bcanshow;
    }
    Refresh_All_Banner_Show()
    {
        PlatFormMng.GetInstance().Refresh_All_Banner_Show();

    }
    Check_Subgame_Banner_In_Jiaohuan_And_Can_Show(ibannerindex)
    {
        if(!ComFunc.arrayShuzuContain(this.m_in_subgame_jiaoti_show_gezi_list,ibannerindex))
        {
            //格子不在交替出现的格子列表里面 - 是可以显示的
            return true;
        } 
        //现在已经确定在交替出现列表里面了

        if(this.m_in_subgame_jiaoti_show_gezi_cur_index >= this.m_in_subgame_jiaoti_show_gezi_list.length)
        {
            this.m_in_subgame_jiaoti_show_gezi_cur_index = 0;
        }

        var cur_active_jiaohuan_gezi_index = this.m_in_subgame_jiaoti_show_gezi_list[this.m_in_subgame_jiaoti_show_gezi_cur_index];

        if(cur_active_jiaohuan_gezi_index != ibannerindex)
        {
            //不是正在显示的轮流交换显示的格子
            return false;
        }

        return true;
    }
    Refresh_Subgame_Banner_Show()
    {
        var bgeishow = true;
        if(this.m_in_subgame_opened_need_close_dlg_index_map.size() > 0)
        {
            bgeishow = false;
        }

        for(var ff=0;ff<this.m_cur_subgame_gezi_guangao_bannerindex_arr.length;ff++)
        {
            var ff_bannerindex=  this.m_cur_subgame_gezi_guangao_bannerindex_arr[ff];

            var relcheckshow = bgeishow;

            if(bgeishow)
            {
                relcheckshow = this.Check_Subgame_Banner_In_Jiaohuan_And_Can_Show(ff_bannerindex);
            }

            this.Set_Banner_Index_Show(ff_bannerindex,relcheckshow);

        }
    }
    Set_Banner_Index_Show(ibanetindex,bshow,bchangeorngal = false)
    {

        
       

        PlatFormMng.GetInstance().Set_Banner_Need_Show(ibanetindex,bshow);

        if(bchangeorngal)
        {
            this.On_Orignal_Chnage_Banner_Show(ibanetindex,bshow)
        }
    
    }
    Set_Subgame_Gezi_Dlg_Is_Show(index,bshow)
    {
        if(!bshow)
        {
            this.m_in_subgame_opened_need_close_dlg_index_map.RemoveKey(index);
        }else{
            this.m_in_subgame_opened_need_close_dlg_index_map.putData(index,1);
        
        }

     //   this.Refresh_All_Banner_Show();

    }
    Timer_Count_Down_Tili_InGame()
    {

        //游戏场里面能增加体力
        if(GlobalGameMng.GetInstance().IS_InGamePlay_Time_Can_Add_Tili())
        {
            //console.log("Timer_Count_Down_Tili_InGame ");
            GlobalGameMng.GetInstance().Count_Down_Add_Tili(); 
        }

    }



    //游戏场内,判断如果上次banner出错了，重新创建
    Timer_Check_ReCreate_InSubgame_Banner()
    {
        if(this.m_last_check_ingame_recreate_banner_tick == 0)
        {
            this.m_last_check_ingame_recreate_banner_tick = Date.now();
        }
        var iepalsetick = Date.now() - this.m_last_check_ingame_recreate_banner_tick;

        //每10秒钟检查一遍
        if(iepalsetick < 10000)
        {
            return;
        }

        this.m_last_check_ingame_recreate_banner_tick = Date.now();
        //开始检查
       /// console.log("开始检查  banner是否出错");

      //  var jiaoti_show this.m_last_subgame_jaioti_show_gezi_change_tick;

        for(var ff=0;ff<this.m_cur_subgame_gezi_guangao_bannerindex_arr.length;ff++)
        {
            var ff_bannerindex = this.m_cur_subgame_gezi_guangao_bannerindex_arr[ff];
            var ff_show =  PlatFormMng.GetInstance().Is_Banner_Show_Now(ff_bannerindex);

            var ff_baneertype = PlatFormMng.GetInstance().Get_Banner_Type(ff_bannerindex);

            if(ff_show && ff_baneertype > 0)
            {
                this.Check_Create_Common_Banner(ff_bannerindex,ff_baneertype);

              //  console.log("Timer_Check_ReCreate_InSubgame_Banner ff_bannerindex="+ff_bannerindex+",ff_baneertype="+ff_baneertype);

            }

        }
        
    }
    Change_InSubgame_Bottom_Gezi_Show()
    {
        if(this.m_in_subgame_jiaoti_show_gezi_list.length <= 0)
        {
            return;
        }

        if(this.m_in_subgame_jiaoti_show_gezi_cur_index >=  this.m_in_subgame_jiaoti_show_gezi_list.length )
        {
            this.m_in_subgame_jiaoti_show_gezi_cur_index = 0;
        }

        if(this.m_in_subgame_jiaoti_show_gezi_cur_index < 0)
        {
            this.m_in_subgame_jiaoti_show_gezi_cur_index = 0;
        }



        var valid_gezi_index =  this.m_in_subgame_jiaoti_show_gezi_list[this.m_in_subgame_jiaoti_show_gezi_cur_index];

        for(var ff=0;ff<this.m_in_subgame_jiaoti_show_gezi_list.length;ff++)
        {
            var ff_baneerindex=  this.m_in_subgame_jiaoti_show_gezi_list[ff];

            if(ff_baneerindex != valid_gezi_index)
            {
                this.Set_Banner_Index_Show(ff_baneerindex,false);
     
            }else{



               // var ibannertype = PlatFormMng.GetInstance().Get_Banner_Type(ff_baneerindex);
            //    this.Check_Create_Common_Banner(ff_baneerindex,ibannertype);


                var bgeishow = true;
                if(this.m_in_subgame_opened_need_close_dlg_index_map.size() > 0)
                {
                    bgeishow = false;
                }
                this.Set_Banner_Index_Show(ff_baneerindex,bgeishow);
     
            }
        }

    }
    Timer_Check_Change_Subgame_Bottom_Gezi_Show()
    {
        if(this.m_last_subgame_jaioti_show_gezi_change_tick == 0)
        {
            this.m_last_subgame_jaioti_show_gezi_change_tick = Date.now();
        }
        var iepalsetick = Date.now() - this.m_last_subgame_jaioti_show_gezi_change_tick;


        var ineedsec = GlobalGameMng.GetInstance().Get_Game_Inner_Bottom_Gezi_Or_banner_Type3_Change_Sec();

        //每35秒交换下格子显示
        if(iepalsetick < ineedsec*1000)
        {
            return;
        }

       // console.log("开始交换底部格子显示:"+ineedsec);

        this.m_last_subgame_jaioti_show_gezi_change_tick = Date.now();
        this.m_in_subgame_jiaoti_show_gezi_cur_index ++;

        this.Change_InSubgame_Bottom_Gezi_Show();

    }

    Timer_Check_In_Subgame_Event()
    {
        this.Timer_Count_Down_Tili_InGame();
        this.Timer_Check_ReCreate_InSubgame_Banner();
        this.Timer_Check_Change_Subgame_Bottom_Gezi_Show();
    }
    FD_Banner_Mng_Timer(pnode)
    {
        this.Refresh_Subgame_Banner_Show();

        if(this.m_in_subgme_now)
        {
        
           

        }

        PlatFormMng.GetInstance().FD_Banner_Mng_Timer(pnode);

        if(this.m_in_subgme_now)
        {
            this.Timer_Check_In_Subgame_Event();
        }

        this.Check_Need_Manual_Destroy_Or_Create_Banners();
        this.Timer_Destroy_Bkground_Banner();

    }
    Stop_Luping()
    {
        PlatFormMng.GetInstance().Stop_Luping();
    }


    Add_Manual_Destroyed_Banner_Index(ibannerindex)
    {
        this.m_banner_id_last_manual_destroy_tick_map.putData(ibannerindex,Date.now());
    }


    Check_Need_Manual_Destroy_Or_Create_Banners()
    {
        var banner_manula_destroy_config_list = GlobalGameMng.GetInstance().Get_Banner_Manual_Destroy_Config();

        //首先，删除显示足够次数needc,第一次显示到现在超过needsec,最后一次隐藏大于needds的，正在隐藏的配置的id的banner
        var need_destroy_id_map = new WMap();

        var banner_id_config_recreate_sec_map = new WMap();

        var banner_id_config_errored_recreate_sec_map = new WMap();


        for(var ff=0;ff<banner_manula_destroy_config_list.length;ff++)
        {
            var ff_info = banner_manula_destroy_config_list[ff];

            var ff_id_list = ff_info.il;
            var ff_i = ff_info.i;

            if(!ff_id_list)
            {
                ff_id_list = [];

                if(ff_i)
                {
                    ff_id_list.push(ff_i);
                }
            }

            var ff_need_sec = ff_info.sec;
            var ff_need_c = ff_info.c;
            var ff_need_ds = ff_info.ds;

            var ff_re = ff_info.re;

            var ff_erc = ff_info.erc;

         
            for(var hh=0;hh<ff_id_list.length;hh++)
            {
                var ff_id = ff_id_list[hh];

              
    
                banner_id_config_errored_recreate_sec_map.putData(ff_id,ff_erc);
    
                banner_id_config_recreate_sec_map.putData(ff_id,ff_re);
    
                var is_show_now = PlatFormMng.GetInstance().Is_Banner_Show_Now(ff_id);
    
                if(is_show_now)
                {
                    //还在显示的格子肯定不能删除
                    continue;
                }
    
    
                var ff_has_show_count = 0;
                if(this.m_banner_id_has_showned_count_map.hasKey(ff_id))
                {
                    ff_has_show_count = this.m_banner_id_has_showned_count_map.getData(ff_id);
                }
    
                var ff_showed_total_Sec = 0;
                if(this.m_banner_id_first_show_tick_map.hasKey(ff_id))
                {
                    var first_tick = this.m_banner_id_first_show_tick_map.getData(ff_id);
                    var ipelasetick = Date.now() - first_tick;
                    ff_showed_total_Sec = ipelasetick/1000;
                }
    
                var ff_last_show_ds = 0;
    
                if(this.m_banner_id_last_hide_tick_map.hasKey(ff_id))
                {
                    var last_show_tick = this.m_banner_id_last_hide_tick_map.getData(ff_id);
                    var last_pelasetick = Date.now() - last_show_tick;
                    ff_last_show_ds = last_pelasetick/1000;
                }
    
    
                if(ff_has_show_count >= ff_need_c  && ff_showed_total_Sec >= ff_need_sec && ff_last_show_ds >= ff_need_ds)
                {
                    need_destroy_id_map.putData(ff_id,1);

                    console.log("need_destroy_id_map 增加:"+ff_id);
                }

            }

           //var ff_id = ff_info.i;
            
        }


        for(var ff=0;ff<need_destroy_id_map.size();ff++)
        {
            var ff_id = need_destroy_id_map.GetKeyByIndex(ff);
            PlatFormMng.GetInstance().Manual_Destroy_banner(ff_id);

            this.m_banner_id_has_showned_count_map.RemoveKey(ff_id);
            this.m_banner_id_first_show_tick_map.RemoveKey(ff_id);
            this.m_banner_id_last_show_tick_map.RemoveKey(ff_id);
            this.m_banner_id_last_hide_tick_map.RemoveKey(ff_id);


            this.m_banner_id_last_manual_destroy_tick_map.putData(ff_id,Date.now());
        }


        var need_recrate_id_map = new WMap();

        for(var ff=0;ff<this.m_banner_id_last_manual_destroy_tick_map.size();ff++)
        {
            var ff_id = this.m_banner_id_last_manual_destroy_tick_map.GetKeyByIndex(ff);
            var ff_destroy_tick = this.m_banner_id_last_manual_destroy_tick_map.GetEntryByIndex(ff);

            var ieplase_sec = (Date.now() - ff_destroy_tick)/1000;

            var recreate_need_sec = 5;
            if(banner_id_config_recreate_sec_map.hasKey(ff_id))
            {
                recreate_need_sec = banner_id_config_recreate_sec_map.getData(ff_id);
            }


            
            if(isNaN(recreate_need_sec) || recreate_need_sec <= 0)
            {
                recreate_need_sec=  5;
            }

            if(ieplase_sec > recreate_need_sec)
            {
                console.log("ieplase_sec="+ieplase_sec+",recreate_need_sec="+recreate_need_sec);
                need_recrate_id_map.putData(ff_id,1);
            }
        }


        for(var ff=0;ff<this.m_banner_error_destroyed_map.size();ff++)
        {
            var ff_id = this.m_banner_error_destroyed_map.GetKeyByIndex(ff);
            var ff_destroy_tick = this.m_banner_error_destroyed_map.GetEntryByIndex(ff);


            if(!PlatFormMng.GetInstance().Is_Banner_Show_Now(ff_id))
            {
                continue;
            }

            var ieplase_sec = (Date.now() - ff_destroy_tick)/1000;

            var error_recreate_need_sec = 10;
            if(banner_id_config_errored_recreate_sec_map.hasKey(ff_id))
            {
                error_recreate_need_sec = banner_id_config_errored_recreate_sec_map.getData(ff_id);
            }


            
            if(isNaN(error_recreate_need_sec) || error_recreate_need_sec <= 0)
            {
                error_recreate_need_sec=  10;
            }

            if(ieplase_sec > error_recreate_need_sec)
            {
                console.log("ieplase_sec="+ieplase_sec+",error recreate_need_sec="+error_recreate_need_sec);
                need_recrate_id_map.putData(ff_id,1);
            }

        }

        
        for(var ff=0;ff<need_recrate_id_map.size();ff++)
        {
            var ff_id = need_recrate_id_map.GetKeyByIndex(ff);
            this.m_banner_id_last_manual_destroy_tick_map.RemoveKey(ff_id);

            this.m_banner_error_destroyed_map.RemoveKey(ff_id);

            var ibannertype = PlatFormMng.GetInstance().Get_Banner_Type(ff_id);

            this.Check_Create_Common_Banner(ff_id,ibannertype);

            console.log("need_recrate_id_map 重建id :"+ff_id);
        }
       
        
    }
    Hide_ALl_Inner_Game_Show()
    {
        
        this.Set_Banner_Index_Show(11,false);
        this.Set_Banner_Index_Show(13,false);
    }
    Start_Luping()
    {
        PlatFormMng.GetInstance().Start_Luping();
    }
    Create_Game_Chang_Banners()
    {
        
    }
    
    //返回大厅确认弹框
    Set_FanhuiDating_Queren_Dlg_Gezi_Sgow(bshow)
    {

        var fanhuidating_quren_mode = GlobalGameMng.GetInstance().Get_Cur_Process_FanhuiDating_Queren_Dlg_Mode();

        var bchaogaoping = ComFunc.ISChaoGaoPing();

        var all_gezi_list = [];


        if(fanhuidating_quren_mode == 2)
        {
            all_gezi_list.push([96,2]);
          
        }else{
            all_gezi_list.push([95,2]);
            all_gezi_list.push([97,2]);
            all_gezi_list.push([98,2]);
        }
      
         
      
 
        this.Set_Com_Gezi_Show(all_gezi_list,  bshow);
    }
    Set_In_Subgame_Bottom_Jiaoti_Show_Gezi_List(in_subgame_jiaoti_gezi_arr)
    {

        if(this.m_in_subgame_jiaoti_show_gezi_list.length > 0)
        {
            //过去的交替出现的格子，不在列表里面的全部隐藏掉
            for(var ff=0;ff<this.m_in_subgame_jiaoti_show_gezi_list.length;ff++)
            {
                var ff_bannerindex = this.m_in_subgame_jiaoti_show_gezi_list[ff];

                if(!ComFunc.arrayShuzuContain(in_subgame_jiaoti_gezi_arr,ff_bannerindex))
                {
                    this.Set_Banner_Index_Show(ff_bannerindex,false);
                } 
            }
        }

        this.m_in_subgame_jiaoti_show_gezi_list = in_subgame_jiaoti_gezi_arr;
       
        this.Change_InSubgame_Bottom_Gezi_Show();
    }
    Set_In_Subgame_Valid_Gezi_Guangao_Bannerindex_Arr_Info(binsubgame,isubgametype,valid_gezi_bannerindex_arr = [])
    {

        var prev_gametype  = this.m_cur_in_subgame_type;

        this.Set_In_Subgame_Bottom_Jiaoti_Show_Gezi_List([]);

        //先把之前的游戏场格子，现在不在有效列表的隐藏掉
        if(this.m_cur_subgame_gezi_guangao_bannerindex_arr && this.m_cur_subgame_gezi_guangao_bannerindex_arr.length > 0)
        {
            for(var ff=0;ff<this.m_cur_subgame_gezi_guangao_bannerindex_arr.length;ff++)
            {
                var ff_bannerindex = this.m_cur_subgame_gezi_guangao_bannerindex_arr[ff];


                if(!ComFunc.arrayShuzuContain(valid_gezi_bannerindex_arr,ff_bannerindex))
                {
                    this.Set_Banner_Index_Show(ff_bannerindex,false);
                }
            }
        }

       

        this.m_in_subgme_now = binsubgame;
        this.m_cur_in_subgame_type = isubgametype;
        this.m_cur_subgame_gezi_guangao_bannerindex_arr = valid_gezi_bannerindex_arr;
        this.m_in_subgame_opened_need_close_dlg_index_map.clear();

        this.m_last_check_ingame_recreate_banner_tick = Date.now();

        if(prev_gametype != isubgametype)
        {
            this.m_in_subgame_jiaoti_show_gezi_cur_index =  0;
            this.m_last_subgame_jaioti_show_gezi_change_tick = Date.now();
    
        }

     


        if(prev_gametype  == 0 && isubgametype > 0)
        {
            //从大厅进入游戏场里面
            this.m_last_from_dating_enter_subgame_tick = Date.now();
        }
        else if(prev_gametype > 0 && isubgametype == 0)
        {
            //从游戏场返回大厅


            if(this.m_last_from_dating_enter_subgame_tick > 0)
            {
                var istay_tick   = Date.now() -this.m_last_from_dating_enter_subgame_tick;
                var istaysec = Math.floor(istay_tick/1000);


                GlobalGameMng.GetInstance().Record_User_Stay_In_Subgame_Sec(prev_gametype,istaysec);

            }
         
            this.m_last_from_dating_enter_subgame_tick = 0;
        }
    }

    Show_InGame_MoreGame_Quanping_Gezi(){
        MiddleGamePlatformAction.GetInstance().Check_Create_Common_Banner(17,2);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(17,2);

        this.Set_Subgame_Gezi_Dlg_Is_Show(11,true);

        this.Refresh_All_Banner_Show();
    }
    
      //igameendtankuangindex:1-复活,2-成功，3：失败 4:三消消复活  0-全部不显示
    Set_Show_Game_End_Tankuang_Index(igameendtankuangindex)
    {
         
        var bchangeorignal = true;

        if(igameendtankuangindex == 1)
        {
            //31:上面banner,32:下面格子
            this.Check_Create_Common_Banner(31,2);
            this.Check_Create_Common_Banner(32,2);

            this.Set_Banner_Index_Show(31,true,bchangeorignal);
            this.Set_Banner_Index_Show(32,true,bchangeorignal);

            this.Set_Banner_Index_Show(41,false,bchangeorignal);
            this.Set_Banner_Index_Show(42,false,bchangeorignal);

            
            this.Set_Banner_Index_Show(44,false,bchangeorignal);
            this.Set_Banner_Index_Show(45,false,bchangeorignal);

            this.Set_Banner_Index_Show(56,false,bchangeorignal);
            this.Set_Banner_Index_Show(57,false,bchangeorignal);

        }
        else if(igameendtankuangindex == 2)
        {
            //41:成功弹框 中间格子,42:下方格子
            this.Check_Create_Common_Banner(41,2);
            this.Check_Create_Common_Banner(42,2);

            this.Set_Banner_Index_Show(41,true,bchangeorignal);
             this.Set_Banner_Index_Show(42,true,bchangeorignal);

                
            this.Set_Banner_Index_Show(44,false,bchangeorignal);
            this.Set_Banner_Index_Show(45,false,bchangeorignal);


             this.Set_Banner_Index_Show(31,false,bchangeorignal);
             this.Set_Banner_Index_Show(32,false,bchangeorignal);
 
            this.Set_Banner_Index_Show(56,false,bchangeorignal);
            this.Set_Banner_Index_Show(57,false,bchangeorignal);

        }else if(igameendtankuangindex == 3)
        {
            //44:失败弹框 中间格子,42:下方格子
            this.Check_Create_Common_Banner(44,2);
            this.Check_Create_Common_Banner(45,2);

             this.Set_Banner_Index_Show(31,false,bchangeorignal);
             this.Set_Banner_Index_Show(32,false,bchangeorignal);

             this.Set_Banner_Index_Show(41,false,bchangeorignal);
             this.Set_Banner_Index_Show(42,false,bchangeorignal);
 
 
             this.Set_Banner_Index_Show(44,true,bchangeorignal);
             this.Set_Banner_Index_Show(45,true,bchangeorignal);

            this.Set_Banner_Index_Show(56,false,bchangeorignal);
            this.Set_Banner_Index_Show(57,false,bchangeorignal);

        } else if(igameendtankuangindex == 4)
        {
            //56:三消消复活弹框上方banner,57:三消消下方格子
            this.Check_Create_Common_Banner(56,2);
            this.Check_Create_Common_Banner(57,2);

             this.Set_Banner_Index_Show(31,false,bchangeorignal);
             this.Set_Banner_Index_Show(32,false,bchangeorignal);
 
             this.Set_Banner_Index_Show(41,false,bchangeorignal);
             this.Set_Banner_Index_Show(42,false,bchangeorignal);
 
   
             this.Set_Banner_Index_Show(44,false,bchangeorignal);
             this.Set_Banner_Index_Show(45,false,bchangeorignal);
 
             this.Set_Banner_Index_Show(56,true,bchangeorignal);
             this.Set_Banner_Index_Show(57,true,bchangeorignal);

        } 
        else if(igameendtankuangindex == 0)
        {
            this.Set_Banner_Index_Show(31,false,bchangeorignal);
            this.Set_Banner_Index_Show(32,false,bchangeorignal);

            this.Set_Banner_Index_Show(41,false,bchangeorignal);
            this.Set_Banner_Index_Show(42,false,bchangeorignal);

            this.Set_Banner_Index_Show(44,false,bchangeorignal);
            this.Set_Banner_Index_Show(45,false,bchangeorignal);

            this.Set_Banner_Index_Show(56,false,bchangeorignal);
            this.Set_Banner_Index_Show(57,false,bchangeorignal);

        }

        this.Refresh_All_Banner_Show();
    }
    Show_Qiandao_Banners(bshow)
    {
        /*
        var ibbanerindex = 121;

        var ibannertype = 1;
       
        if(bshow)
        {
            this.Check_Create_Common_Banner(ibbanerindex,ibannertype);
   
            PlatFormMng.GetInstance().Set_Banner_Need_Show(ibbanerindex,true);
        
        }else{
            PlatFormMng.GetInstance().Set_Banner_Need_Show(ibbanerindex,false);
   
        }

*/
        var bchaogaoping = ComFunc.ISChaoGaoPing();



        var all_gezi_list = [];


        if(bchaogaoping)
        {
            all_gezi_list.push([122,2]);
            all_gezi_list.push([123,2]);
      
        }else{
            all_gezi_list.push([121,1]);
      
        }
     
         
      
 
        this.Set_Com_Gezi_Show(all_gezi_list,  bshow);
    }
    On_Banner_Error(ibannerindex)
    {
        this.m_banner_error_destroyed_map.putData(ibannerindex,Date.now());
    }
    Set_Com_Gezi_Show(all_gezi_list,  bshow)
    {

        for(var ff=0;ff<all_gezi_list.length;ff++)
        {
            var ff_info  = all_gezi_list[ff];

            var ff_id = ff_info[0];
            var ff_banner_type = ff_info[1];
            
            if(bshow)
            { 


                this.Check_Create_Common_Banner(ff_id,ff_banner_type); 
            }else{
                
            }
            this.Set_Banner_Index_Show(ff_id,bshow);
            this.On_Orignal_Chnage_Banner_Show(ff_id,bshow);
 
        }
        this.Refresh_All_Banner_Show();

    }
    Get_Game_Bottom_DanGezi_Arr()
    {
        return [];
    }
    Set_Show_Game_Fail_Continue_Next_Dlg_Banner(bshow)
    {
        var all_gezi_list = [];


        all_gezi_list.push([177,2]);
      
        this.Set_Com_Gezi_Show(all_gezi_list,  bshow);
    }
    Check_Create_Show_Game_Banner_A(igeziindex,ibannertype)
    {
        this.Check_Create_Common_Banner(igeziindex,ibannertype);
     
        this.Set_Banner_Index_Show(igeziindex,true);
        this.On_Orignal_Chnage_Banner_Show(igeziindex,true);
    }
    On_Orignal_Chnage_Banner_Show(ibanerindex,bshow)
    {
      //  var realAd = PlatFormMng.GetInstance().Get_Banner_Real_Exist_Ad(ibanerindex);

        var bshow_now = PlatFormMng.GetInstance().Is_Banner_Show_Now(bshow);
        if(bshow_now == bshow)
        {
            return;
        }

        if(bshow)
        {
            if(!this.m_banner_id_has_showned_count_map.hasKey(ibanerindex))
            {
                this.m_banner_id_has_showned_count_map.putData(ibanerindex,1);
            }else{
                var iprevc = this.m_banner_id_has_showned_count_map.getData(ibanerindex);
                this.m_banner_id_has_showned_count_map.putData(ibanerindex,1 + iprevc);
            }


            if(!this.m_banner_id_first_show_tick_map.hasKey(ibanerindex))
            {
                this.m_banner_id_first_show_tick_map.putData(ibanerindex,Date.now());
            }

            this.m_banner_id_last_show_tick_map.putData(ibanerindex,Date.now());
        }
        else{

            this.m_banner_id_last_hide_tick_map.putData(ibanerindex,Date.now());
        }

      

    }
    Set_SanXiaoxiao_GoumaiDaouju_Dlg_Gezi_Sgow(bshow)
    {
        var all_gezi_list = [];


        all_gezi_list.push([76,2]);
        all_gezi_list.push([77,2]);
      
        this.Set_Com_Gezi_Show(all_gezi_list,  bshow);

       



    }
    Set_Game_Libao_Dlg_Gezi_Sgow(bshow)
    {

        if(bshow)
        {
            this.Check_Create_Common_Banner(161,2);
            this.Check_Create_Common_Banner(162,2);

            this.Set_Banner_Index_Show(161,true);
            this.Set_Banner_Index_Show(162,true);
        }else{

            this.Set_Banner_Index_Show(161,false);
            this.Set_Banner_Index_Show(162,false);
        }

        this.Refresh_Subgame_Banner_Show();

        this.Refresh_All_Banner_Show();
    }
    Check_Create_Common_Banner(ibbanerindex,ibannertype)
    {
       
        PlatFormMng.GetInstance().Check_Create_Banner(ibbanerindex,ibannertype,(bsuc,backbannerindex, banner)=>
        {
            if(!bsuc)
            {
                    return;
            }
        
            PlatFormMng.GetInstance().Refresh_Banner_Change_Show(backbannerindex);

        });
       
    }

    Hide_Dating_Gezi_Show()
    {
        
        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
        this.Set_Banner_Index_Show(101,false);
        this.Set_Banner_Index_Show(102,false);
        this.Show_Qiandao_Banners(false);
 
    }
    Check_BK_Create_GameFail_Banners()
    {

        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }

        this.Check_Create_Common_Banner(44,2);
        this.Check_Create_Common_Banner(45,2);
    


    }




    Check_Create_Bk_Gezi_List(gezi_info_list)
    {
        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
        for(var ff=0;ff<gezi_info_list.length;ff++)
        {
            var ff_info = gezi_info_list[ff];
            var ff_id = ff_info[0];
            var ff_type = ff_info[1];
            this.Check_Create_Common_Banner(ff_id,ff_type);
    
        }

    }


    Ensure_Create_BK_GameSuc_Fail_Fuhuo_Grzi()
    {
        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
      
        //成功
        this.Check_Create_Common_Banner(41,2);
        this.Check_Create_Common_Banner(42,2);

        //失败
       // this.Check_BK_Create_GameFail_Banners();

       // this.Check_BK_Create_GameSuc_EndLingqu_Banners();


        //this.Check_Create_Common_Banner(31,1);
        //this.Check_Create_Common_Banner(32,2);


        //this.Check_Create_Common_Banner(56,1);
       // this.Check_Create_Common_Banner(57,2);


       //暂停
        this.Check_Create_Common_Banner(61,2);
        this.Check_Create_Common_Banner(62,2);

       

    }
    Check_BK_Create_GameSuc_EndLingqu_Banners()
    {
        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
        this.Check_Create_Common_Banner(155,2);
     
    }
    Ensure_Create_Gamefail_Continue_Next_Banner()
    {
        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
        this.Check_Create_Common_Banner(177,2);
    }
    Ensure_Create_Bk_Tuichu_Queren_Banner()
    {
        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }

        var fanhui_dating_queren_mode = GlobalGameMng.GetInstance().Get_Cur_Process_FanhuiDating_Queren_Dlg_Mode();

        if(fanhui_dating_queren_mode == 2)
        { 
            this.Check_Create_Common_Banner(96,2); 
        }
        else{
            this.Check_Create_Common_Banner(95,2); 
            this.Check_Create_Common_Banner(97,2);
            this.Check_Create_Common_Banner(98,2);
        }


      
    }

    Show_GameEnd_Lingqu_Dlg_Banners(bshow)
    {
        var bchaogaoping = ComFunc.ISChaoGaoPing();

        var all_gezi_list = [];
        all_gezi_list.push([155,2]);
      
         
      
 
        this.Set_Com_Gezi_Show(all_gezi_list,  bshow);
    }
    Hide_Other_In_Game_Dlg_Gezi_Show(icurdlgtype)
    {
        if(icurdlgtype == 1)
        {
            this.Set_Game_Libao_Dlg_Gezi_Sgow(false); 
            this.Set_Show_Game_End_Tankuang_Index(0);
            
        } 
        else if(icurdlgtype == 2)
        {
            this.Set_Pause_Dlg_Gezi_Sgow(false); 
            this.Set_Show_Game_End_Tankuang_Index(0);
        }
        else if(icurdlgtype == 3 || icurdlgtype == 4 || icurdlgtype == 5 || icurdlgtype == 6)
        {
            this.Set_Game_Libao_Dlg_Gezi_Sgow(false);
            this.Set_Pause_Dlg_Gezi_Sgow(false); 
     
        }  
        else if(icurdlgtype == 9)
        {
            this.Set_Game_Libao_Dlg_Gezi_Sgow(false);
            this.Set_Pause_Dlg_Gezi_Sgow(false);
            this.Set_Show_Game_End_Tankuang_Index(0);
 
        }

    }
    Timer_Destroy_Bkground_Banner()
    {

        for(var ff=this.m_manual_need_destroy_banner_lsit.length - 1;ff>=0;ff--)
        {
            var ff_info = this.m_manual_need_destroy_banner_lsit[ff];

            var ff_baner_index = ff_info[0];
            var ff_baner_tick = ff_info[1];

            if(Date.now() - ff_baner_tick > 8000)
            {
                this.Real_Destroy_Banner(ff_baner_index);
                this.m_manual_need_destroy_banner_lsit.splice(ff,1);
            }
        }

         
    }

    Real_Destroy_Banner(ibannerindex)
    {
        PlatFormMng.GetInstance().Manual_Destroy_banner(ibannerindex);
       
    }
    Manual_Destroy_Banner(ibannerindex)
    {
       ///

       var bexist = 0;

       for(var ff=0;ff<this.m_manual_need_destroy_banner_lsit.length;ff++)
       {
            var ff_info = this.m_manual_need_destroy_banner_lsit[ff];
            var ff_banneridex  = ff_info[0];
            if(ff_banneridex == ibannerindex)
            {
                bexist=  1;
            }
       }

       if(bexist)
       {
            return;
       }
      
       this.m_manual_need_destroy_banner_lsit.push([ibannerindex,Date.now()])
     
    }
    Destroy_Refuhuo_Banners()
    {
        this.Manual_Destroy_Banner(32);
        this.Manual_Destroy_Banner(33);
        
    }
    Show_Refuhuo_Banners(bshow)
    {
        var bchaogaoping = ComFunc.ISChaoGaoPing();

 
        var all_gezi_list = [];


         all_gezi_list.push([32,2]);
      
         all_gezi_list.push([33,2]);
     
        this.Set_Com_Gezi_Show(all_gezi_list,  bshow);
    }

    Check_Show_Quanping_Gezi_ChaiPing(itype)
    {
        var all_gezi_list = [];
  
        var subdlgtype = 199;

        if(itype == 1)
        {
            all_gezi_list.push([198,2]); 
            subdlgtype = 198;
        }else{
            all_gezi_list.push([199,2]); 
            subdlgtype = 199;
        }
        
        this.Set_Com_Gezi_Show(all_gezi_list,  true);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(subdlgtype,true);

    }

    Show_Watch_Fail_Deal_Dlg_Gezi_Show(bshow)
    {
        var all_gezi_list = [];
  
        all_gezi_list.push([195,2]); 
         
        
        this.Set_Com_Gezi_Show(all_gezi_list,  bshow);
      
        this.Refresh_All_Banner_Show();
    }
    Manual_Detroy_Game_End_Tankuang(igameendtankuangindex)
    {
        if(igameendtankuangindex == 2)
        {
            this.Manual_Destroy_Banner(41);
            this.Manual_Destroy_Banner(42);

        }
        if(igameendtankuangindex == 3)
        {
            this.Manual_Destroy_Banner(44);
            this.Manual_Destroy_Banner(45);

        }




    }
}