import PlatFormParaMng from "./PlatFormParaMng";
import PlatFormType from "./PlatFormType";



export default class MiddleBanner_Gezi_Mng
{
    constructor()
    {

    }
  static _instance:MiddleBanner_Gezi_Mng = null;
    static GetInstance() 
    {
        if (!MiddleBanner_Gezi_Mng._instance) {
            // doSomething
            MiddleBanner_Gezi_Mng._instance = new MiddleBanner_Gezi_Mng();
             
        }
        return MiddleBanner_Gezi_Mng._instance;
    }
    GetPaltformType() 
    {
        return PlatFormParaMng.GetInstance().GetPlatFormType();
    }
    Get_Pause_Gezi_List()
    {
        var all_gezi_list = [];

        if(this.GetPaltformType() == PlatFormType.PlatFormType_WX)
        {
            all_gezi_list.push([61,2]);
      
            all_gezi_list.push([62,2]);
    
        } 
        else if(this.GetPaltformType() == PlatFormType.PlatFormType_ByteDance)
        {
            all_gezi_list.push([61 ,1]);
      
            all_gezi_list.push([62,1]);
    
        }


        return all_gezi_list;
    }

}