import IPlatformMng from "./IPlatformMng";

export default class QQXiaoyouxiPlatformMng extends IPlatformMng
{
    constructor()
    {
        super();

    }
    Exit_Game()
    {
        qq.exitMiniProgram();
    }
    IS_Fenxiang_Btn_Show()
    {

        return true;
    }
    Dating_Fenxiang()
    {
         var str=  this.Get_Dating_Fenxiang_Str();
        
         qq.shareAppMessage({
            title: '好玩的小兵大战僵尸小游戏'
          })
    }
    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        const rewardedVideoAd = qq.createRewardedVideoAd({ adUnitId: "995bf98b23bd1318aee6a97095ee6533" });
        rewardedVideoAd.onLoad(() => {
             console.log("激励视频 广告加载成功");
        
        });
       // rewardedVideoAd.show().then(() => console.log("激励视频 广告显示"));
       rewardedVideoAd.load().then(() => rewardedVideoAd.show());

       /*
        rewardedVideoAd.show().catch(err => {
            rewardedVideoAd.load().then(() => rewardedVideoAd.show());
          });

          */
         
        rewardedVideoAd.onClose((res)=>
        {
            if(res.isEnded)
            {
                callback(true);
            }

        })
    }

    CheckShowChaiping()
    {
                /* 建议放在onReady里执行，提前加载广告 */
        let InterstitialAd = qq.createInterstitialAd({
            adUnitId: "8ae5f440b26e51216108971c0a7d5d8b"
        });
        InterstitialAd.load().catch((err) => {
            console.error('load',err)
        })        
        InterstitialAd.onLoad(() => {
            console.log('onLoad event emit') 
        })
        InterstitialAd.onClose(() => {
            console.log('close event emit')
        })       
        InterstitialAd.onError((e) => {
            console.log('error', e)
        })    
        /* 建议放在需要展示插屏广告的时机执行 */
        InterstitialAd.show().catch((err) => {
            console.error('show',err)
        })
    }

}