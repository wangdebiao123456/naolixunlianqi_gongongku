import ComFunc from "../comfuncs/ComFunc"; 
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import WMap from "../WDT/WMap";
import IPlatBannerMng from "./IPlatBannerMng";
import MiddleGamePlatformAction from "./MiddleGamePlatformAction";

export default class WXBannerMng  extends IPlatBannerMng
{
    constructor()
    {
       super();
    }

    IS_GaoBili_Pingmu() 
    {
 

        var windows_size = cc.director.getWinSize();
        var cx1 = windows_size.width;
        var cy1 =  windows_size.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icom_sclae = cx1/cy1;
        var ireal_sclae = cx2/cy2;
  
        if(ireal_sclae < icom_sclae)
        {
            //高比实际高

          
            if(icom_sclae/ireal_sclae > 1.1)
            {
                return true;
            }


           
        } 

        return false;

    }



    Get_Scale_aujust_y()
    {
        var winsize_pixel =  cc.director.getWinSizeInPixels();

        var iscale1 = 1;

        var adjuesty=  winsize_pixel.height;
        if(winsize_pixel.height/winsize_pixel.width > 1280/720)
        {
            //屏幕高比较高

            iscale1 = winsize_pixel.width/720;
            adjuesty =  winsize_pixel.height/iscale1;

        }

    }
    Get_Game_Inner_Banner_Bottom_Banner_Y(ibannertype,bannerheight = null)
    {

        
        let systemInfo  = wx.getSystemInfoSync();
          var windowHeight = systemInfo.windowHeight;
 
 
 
        //真实分辨率
        var irealheight = this.Get_Real_Height();
 
    
        //真实分辨率 
        var ibilv_y = windowHeight/irealheight;


        var iyy1 = 113;
        if(ibannertype == 1)
        {
            iyy1 = 80;

        }

        if(bannerheight && bannerheight > 0)
        {
            iyy1 = bannerheight +2;

        }


        var alginbottom = GlobalGameMng.GetInstance().IS_Game_Scence_Bottom_Banner_Align_Bottom(ibannertype);
        var y =  windowHeight - iyy1;  

        if(alginbottom)
        {
            if(ComFunc.ISChaoGaoPing())
            {
                y -= 20;

            }
        }
        else{
            var itopy = irealheight  - 1100 - 5   ;

            if(ComFunc.ISChaoGaoPing())
            {
               itopy = irealheight  - 1160 -5 ;

            }

            var idibuy =   itopy;

            var aligin_y =  windowHeight - idibuy*ibilv_y;
            
            if(aligin_y > windowHeight - iyy1)
            {
                aligin_y = windowHeight - iyy1;
            }
            
            y= aligin_y;
        }

        console.log("调整 ibannertype="+ibannertype+",alginbottom="+alginbottom+",windowHeight="+windowHeight+",y="+y)

        return y;
    }

    GetBanner_Pos(ibannerindex)
    {

       
        var  bchaogaoping =  ComFunc.ISChaoGaoPing();



        let systemInfo  = wx.getSystemInfoSync();
        var windowWidth = systemInfo.windowWidth;
        var windowHeight = systemInfo.windowHeight;


        var winsize_pixel =  cc.director.getWinSizeInPixels();

       // console.log("winsize_pixel.cx="+winsize_pixel.width+",winsize_pixel.cy="+winsize_pixel.height);

        var pix_bili_y1 = windowHeight/winsize_pixel.height;
 
 
        //真实分辨率
        var irealheight = this.Get_Real_Height();
 
        var ireal_width = this.Get_Real_Width();
        var ibilv = windowWidth/ireal_width;
     
        var x = 0;
        var y = 2000;

       
        var cx = windowWidth;
        if(windowWidth > 400)
        {
            cx = 400;
        }
        var ileft =  2;

    
        //真实分辨率 
        var ibilv_y = windowHeight/irealheight;

        var itop = windowHeight/2 + 400*ibilv_y;


         
        if(ibannerindex  == 17 || ibannerindex == 18 || ibannerindex == 199|| ibannerindex == 198)
        {
            x = 2;

            y =  60;

            if(bchaogaoping)
            {
                y =  100;

            }
         
        } 
        
        else if(  ibannerindex  == 161)
        {
            
            x = 5;

            y =  windowHeight/2 + 295*ibilv_y; 
        }
        else if(ibannerindex  == 101)
        {
            // /大厅左边格子

             x=10;
             y = windowHeight -  180*ibilv_y;

        } 
        else if(ibannerindex  == 102)
        {
            // /大厅边格子

             x=windowWidth - 80;
             y = windowHeight - 180*ibilv_y;

        }   
        else if(ibannerindex  == 41 )
        {
            //胜利弹框上面格子
            
            x = 5;
             y = windowHeight/2 -  330*ibilv_y;
 
 
          
        }else if(ibannerindex  == 42  )
        {
            //胜利弹框下方格子
            
            x = 5;

            y =  windowHeight/2 + 410*ibilv_y;;  
        }
        else if(  ibannerindex  == 44)
        {
            
            x = 5;
           
 
             var itopy = irealheight/2 - 640  +410;


             if(ComFunc.ISChaoGaoPing())
             {
                itopy = irealheight/2 - 700  +410;
 
             }

         //    var ineeddescyt = irealheight/2 - itopy;


             y = windowHeight/2 -  itopy*ibilv_y;
 
        }else if(  ibannerindex  == 45)
        {
            //失败弹框下方格子
            
            x = 5;

            y =  windowHeight/2 + 410*ibilv_y;;  
        } else if(ibannerindex  == 57)
        {
            
            x = 5;

            y =  windowHeight/2 + 180*ibilv_y;;  
        }
        else if(ibannerindex  == 61  )
        {
            
            x = 5;

            y =  windowHeight/2 + 295*ibilv_y; 
        }
         
        else if( ibannerindex  == 151 || ibannerindex  == 88 ||  ibannerindex  == 82 ||  ibannerindex  == 72  ||  ibannerindex  == 92||  ibannerindex  == 112)
        {
            
            x = 5;

           
            y= this.Get_Game_Inner_Banner_Bottom_Banner_Y(1);
         
           

        }
        else if(    ibannerindex  == 152   ||  ibannerindex  == 89   || ibannerindex  == 83 || ibannerindex  == 93 ||  ibannerindex == 73 ||  ibannerindex == 113  )
        {
            
              
            x = (windowWidth-360)/2;

            y= this.Get_Game_Inner_Banner_Bottom_Banner_Y(2);
          
           
        }else if(  ibannerindex  >= 261 && ibannerindex  <= 265)
        {
            //单格子

            var index11 = ibannerindex - 261;
            x = index11 * 76;
         
            y = windowHeight - 120;

            console.log("格子 261")
        }
        else if(ibannerindex  == 40    )
        { 

            x = 2;

            y =  1080*ibilv_y; 
        }
        else if(ibannerindex  == 121)
        {
            // /大厅左边格子

             x=10;
             y = windowHeight -  180*ibilv_y;

        }  
             else if(ibannerindex  == 123)
        {
            // /大厅左边格子

             x=1;
             y = windowHeight/2 + 300*ibilv_y;

        } else if(ibannerindex  == 32)
        {
            
            x = 5;

            y =  windowHeight/2 + 150*ibilv_y; 
        }
         
        else if(ibannerindex  == 77)
        {
            
            x = 5;

            y =  windowHeight/2 + 355*ibilv_y;;  
        }
        else if(  ibannerindex  == 95)
        {
            //退出确认中间弹框格子
            x = 5;
           
 
             var itopy = 150;


             if(ComFunc.ISChaoGaoPing())
             {
                itopy = 150 +60;
 
             }

         //    var ineeddescyt = irealheight/2 - itopy;


             y =  itopy*ibilv_y;
 
        }
        else if(  ibannerindex  == 96)
        {
            x = 2;

            y =  390*ibilv_y+10;

        }else if(  ibannerindex  == 97)
        {
             //退出确认弹框左边格子
             x = 2;
         
             y = windowHeight/2 + 340*ibilv_y;

        }else if(  ibannerindex  == 98)
        {
             //退出确认弹框左边格子
             x = windowWidth - 80;
         
             y = windowHeight/2 + 340*ibilv_y;

        }  else if(ibannerindex  == 155)
        {
            x = 2;

            y =  480*ibilv_y+10;
        }
        else if(  ibannerindex  == 177)
        {
            x = 2;

            y =  390*ibilv_y+10;

        }else if(  ibannerindex  == 195)
        {
            x = 2;

            y =  500*ibilv_y+2;

        }
        else if(ibannerindex == 76 || ibannerindex ==  31 || ibannerindex ==  56  || ibannerindex ==  122
             || ibannerindex ==  62 || ibannerindex ==  162)
        {
            x=2;
             y = 1;
        }
        else{


            x = ileft;
            y = itop;
        }


 


        return {x:x,y:y}
    }

    Get_Banner_Union_ID(ibannerindex,ibannertype)
    {

        //大厅全屏
        if(ibannerindex == 18 )
        {
            return "adunit-41a67bd4030e2cbe";
        }

        //游戏场全屏
        if(ibannerindex == 17 )
        {
            return "adunit-193c5093d2a06761";
        }

       // if(ibannerindex == 31 )
      //  {
          //  return "adunit-b9eb20fb024ff6ca";
       // }


        if(ibannerindex == 32)
        {

            if(ComFunc.ISChaoGaoPing())
            {
                return "adunit-3a88c6e38737a9da";

            }
           

            return "adunit-24c548ef2f0bb8d6";
        }

        if(ibannerindex == 101 || ibannerindex == 102)
        {
            return "adunit-5b3fe5eff9b65421";
        }
        
        //暂停弹框下方格子
        if(ibannerindex == 61 )
        {
            if(ComFunc.ISChaoGaoPing())
            {
                return "adunit-cbe44aea10f6535b";
            }
            return "adunit-24c548ef2f0bb8d6";
        }


          //暂停弹框下方banner
        if(ibannerindex == 62 )
        {
          //  return "adunit-cefd9a4e60eace9e";
        }


        if(ibannerindex == 41 )
        {
            return "adunit-8ada756628358622";
        }

        if(ibannerindex == 42 )
        {
            return "adunit-f2145e18e52a64ae";
        }





        if(ibannerindex == 44)
        {
            return "adunit-6ffe0db769ef54f9";
        }

        if(ibannerindex == 45)
        {
            return "adunit-f2d9b3575fb13ea0";
        }
        
        if(ibannerindex == 155)
        {
            return "adunit-f12ce651b826b994";
        }
        
        
        //滑木块下方banner
        if(ibannerindex == 88)
        {
            

            return "adunit-a94eace6d839fe6c"
            
        }


        if(ibannerindex == 177)
        {
            

            return "adunit-334acbd1c4a5064b"
            
        }

        

        if(ibannerindex == 152)
        {
            return "adunit-32bcf2c8170988ba"
            
        }


        if(ibannerindex == 76 || ibannerindex ==  31 || ibannerindex ==  56  || ibannerindex ==  122 || ibannerindex ==  62 || ibannerindex ==  162)
        {
            return "adunit-e0e672b78b5e8083"
            
        }

        if(ibannerindex == 77)
        {
            return "adunit-d08244c12780ae57"
            
        }
        


        //滑木块下方格子
        if(ibannerindex == 89)
        {
            return "adunit-2ff83e6bfed07f86"
            
        }
 

           //移箱子下方格子
        if(ibannerindex == 83)
        {
            

            return "adunit-6d8b8f8ca2a90a04"
            
        }

 

           //推箱子下方格子
        if(ibannerindex == 73)
        {
            

            return "adunit-6d8b8f8ca2a90a04"
            
        }

        if(ibannerindex == 92)
        {
            

            return "adunit-6d8b8f8ca2a90a04"
            
        }

           //木室下方格子
        if(ibannerindex == 93)
        {
            

            return "adunit-6d8b8f8ca2a90a04"
            
        }

        //if(ibannerindex == 56)
        //{
            

         //   return "adunit-1438a6e9082bf02d"
            
      //  }

        if(ibannerindex == 57)
        {
            return "adunit-c79937848a28c837"

            
        }
        
        
        //退出确定弹框 95:中间格子,96:下方格子,97:左边竖着格子,98:右边竖着格子
        if(ibannerindex == 95 || ibannerindex == 96)
        {

            return "adunit-465755275de3c13c"
            
        }



        if(ibannerindex == 195)
        {

            return "adunit-2d252fb5e570519c"
            
        }

 

           //数字华容道下方格子
        if(ibannerindex == 113)
        {
            

            return "adunit-b0559d271c4b78be"
            
        }

  
 
        if(ibannerindex == 123)
         {
            return "adunit-c75cabc9bbcd77cf";
        }
         
        if(ibannerindex == 40)
        {
           return "adunit-e841c549086eb08f";
       }
        
       if(ibannerindex == 198)
       {
           return "adunit-ef5888193b8163c3";
       }
    
        if(ibannerindex == 199)
        {
            return "adunit-d985ee8223f13e48";
        }
        
        

        if(  ibannerindex == 161)
        {
            if(ComFunc.ISChaoGaoPing())
            {
                return "adunit-eb9c5e3b4f48cd43";
            }

            return "adunit-9f6570718a088f67"
          
        }
        if(ibannerindex >= 261 && ibannerindex <= 265)
        {
            return "adunit-7fb2226367372edc";
   
        }


        return "adunit-7fb2226367372edc";
   
    }
    On_Banner_Recreated(ibannerindex)
    {
        MiddleGamePlatformAction.GetInstance().On_Banner_Recreated(ibannerindex);
 
    }
    //ibannertype:1-普通banner,2:格子       
    Check_Create_Banner(ibannerindex,ibannertype, callback)
    {
        var self = this;

        if(this.m_banner_index_banner_map.hasKey(ibannerindex))
        {
            var banner = this.m_banner_index_banner_map.getData(ibannerindex);

            if(callback)
            {
                callback(true,ibannerindex, banner);
            }
            
            return;
        } 
       
        var bneed_pingbi_banner =  GlobalGameMng.GetInstance().Check_Banner_Index_Need_Pingbi(ibannerindex);
        if(bneed_pingbi_banner)
        {
            return;
        }

       
        this.On_Banner_Recreated(ibannerindex);


        //确定这个创建过了
        this.m_bannerindex_ensure_need_created_map.putData(ibannerindex,1);


        var banner_ubiinid = this.Get_Banner_Union_ID(ibannerindex,ibannertype);

        this.m_banner_index_type_map.putData(ibannerindex,ibannertype);


        var bannerpos = this.GetBanner_Pos(ibannerindex);
        var gezi_guanggao_obj = null;

           
        var banner_shuaixn_sec = GlobalGameMng.GetInstance().Get_BannerIndex_Shuaxin_Sec(ibannerindex);

        if(banner_shuaixn_sec >= 0 && banner_shuaixn_sec <= 30)
        {
            banner_shuaixn_sec = 32;
        }

       
        if(ibannertype == 1)
        {

            console.log("createGameBanner left="+bannerpos.x+",top="+bannerpos.y);
    
 

            if(banner_shuaixn_sec == -1)
            {
                gezi_guanggao_obj = wx.createBannerAd( 
                    {
                        
                        adUnitId:banner_ubiinid,  
                        style:{
                            left:bannerpos.x,
                            top:bannerpos.y ,
                            width: 300, 
                            height:80
                        }
                    
                    }
                ); 
            }
            else{
                gezi_guanggao_obj = wx.createBannerAd( 
                    {
                        
                        adUnitId:banner_ubiinid, 
                        adIntervals: banner_shuaixn_sec,
                        style:{
                            left:bannerpos.x,
                            top:bannerpos.y ,
                            width: 300,
                            adIntervals: banner_shuaixn_sec,
                            height:80
                        }
                    
                    }
                ); 

            }
           
            


            gezi_guanggao_obj.onError(
                (err)=>
                {
                
                    console.log("格子广告错误:"+JSON.stringify(err));
                    gezi_guanggao_obj.destroy();
                    self.m_banner_index_banner_map.RemoveKey(ibannerindex);

                    self.On_Banner_Error(ibannerindex);
                }
            );
        

         //   console.log("ibannerindex="+ibannerindex+",gezi_guanggao_obj="+gezi_guanggao_obj)
          //  this.m_banner_index_banner_map.putData(ibannerindex,gezi_guanggao_obj);

           // callback(true,ibannerindex,gezi_guanggao_obj);
        }
        else if(ibannertype == 2)
        {
            if(banner_shuaixn_sec == -1)
            {

                gezi_guanggao_obj = wx.createCustomAd( 
                    {
                        
                        adUnitId:banner_ubiinid,
                        style:{
                            left:bannerpos.x,
                            top:bannerpos.y 
                        }
                    
                    }
                ); 
            }else{
                gezi_guanggao_obj = wx.createCustomAd( 
                    {
                        
                        adUnitId:banner_ubiinid,
                        adIntervals:banner_shuaixn_sec,
                        style:{
                            left:bannerpos.x,
                            adIntervals: banner_shuaixn_sec,
                            top:bannerpos.y 
                        }
                    
                    }
                ); 
            }
             
            gezi_guanggao_obj.onError(
                (err)=>
                {
                
                    console.log("格子广告错误:"+JSON.stringify(err));
                    gezi_guanggao_obj.destroy();
                    self.m_banner_index_banner_map.RemoveKey(ibannerindex);
                    self.On_Banner_Error(ibannerindex);
                }
            );

            
           // this.m_banner_index_banner_map.putData(ibannerindex,gezi_guanggao_obj);


        }else
        {
            callback(false);
            return;
        }


        let systemInfo  = wx.getSystemInfoSync();
        var windowWidth = systemInfo.windowWidth;
        var windowHeight = systemInfo.windowHeight;

        //真实分辨率
        var irealheight = this.Get_Real_Height();
           //真实分辨率 
           var ibilv_y = windowHeight/irealheight;

 
        if(gezi_guanggao_obj && gezi_guanggao_obj.onResize)
        {
            if(ibannerindex == 101)
            {
                //大厅左边
               
            }else if(ibannerindex == 102)
            {
                //大厅右边
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = windowWidth - res.width - 5;
     
                
                });
            }
             
             else if( ibannerindex == 32  )
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
    
                  
                
                });
            }else if(  ibannerindex == 42 || ibannerindex == 45)
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
    
                  
                
                });
            } else if(ibannerindex == 57)
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
                  
                  
                
                });
            }
            else if(ibannerindex == 61  )
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
                  
                  
                
                });
            }else if(ibannerindex == 62  )
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
                  //  gezi_guanggao_obj.style.top =  windowHeight - res.height - 8;
             
                  
                   gezi_guanggao_obj.style.top =  windowHeight/2 - res.height  - 350*ibilv_y;
             
                });
            }else if(ibannerindex == 88  || ibannerindex == 151  || ibannerindex  == 82 || ibannerindex  == 72  || ibannerindex  == 92  || ibannerindex  == 112)
            {
                gezi_guanggao_obj.onResize(res => {
        
                         gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
                   
                   
                   
                        var newy= this.Get_Game_Inner_Banner_Bottom_Banner_Y(1,res.height);
         
 
                        gezi_guanggao_obj.style.top =  newy;
             
                  
                
                });
            }
            else if(ibannerindex == 121)
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
                  //  gezi_guanggao_obj.style.top =  windowHeight - res.height - 8;
             
                  
                   gezi_guanggao_obj.style.top =  windowHeight - res.height  - 2;
             
                });
            }else if(ibannerindex == 122  )
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2; 
             
                });
            }
  
            else if( ibannerindex == 73  ||  ibannerindex == 83  || ibannerindex == 89 ||  ibannerindex == 93  || ibannerindex  == 113 )
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;

                    var newy= this.Get_Game_Inner_Banner_Bottom_Banner_Y(2,res.height);
         
 
                    gezi_guanggao_obj.style.top =  newy;
         
                
                });
            } 
 
        }
        

        if(gezi_guanggao_obj)
        {
           
            if(ibannerindex == 17 || ibannerindex == 18)
            {
                gezi_guanggao_obj.offClose();
                gezi_guanggao_obj.offHide();


                gezi_guanggao_obj.onClose(()=>
                {
                   // self.Set_Banner_Need_Show(ibannerindex,false);

                   MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(ibannerindex,false,true);

                    MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(11,false);

                })
    
                gezi_guanggao_obj.onHide(()=>
                {
                    //self.Set_Banner_Need_Show(ibannerindex,false);
                    MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(ibannerindex,false,true);

                    MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(11,false);

                })
    
    
            }
            else if(ibannerindex == 199 || ibannerindex == 198)
            {

                gezi_guanggao_obj.offClose();
                gezi_guanggao_obj.offHide();
            
                gezi_guanggao_obj.onClose(()=>
                {
                   // self.Set_Banner_Need_Show(ibannerindex,false);

                   MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(ibannerindex,false,true);

                    MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(ibannerindex,false);

                    gezi_guanggao_obj.destroy();
                    self.m_banner_index_banner_map.RemoveKey(ibannerindex);
              


                    if(GlobalGameMng.GetInstance().IS_Quanping_Gezi_Cahiping_Manual_Destroy_Need_Auto_ReCreate())
                    {
                        MiddleGamePlatformAction.GetInstance().Add_Manual_Destroyed_Banner_Index(ibannerindex);
                        console.log(ibannerindex+" 格子 销毁 ,需要自动创建");
                    }else{
                        console.log(ibannerindex+" 格子 销毁");
                    }
                 
                   
                })
    
                gezi_guanggao_obj.onHide(()=>
                {
                   // self.Set_Banner_Need_Show(ibannerindex,false);

                    MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(ibannerindex,false,true);

                    MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(ibannerindex,false);
                    gezi_guanggao_obj.destroy();
                    self.m_banner_index_banner_map.RemoveKey(ibannerindex); 

                    if(GlobalGameMng.GetInstance().IS_Quanping_Gezi_Cahiping_Manual_Destroy_Need_Auto_ReCreate())
                    {
                        MiddleGamePlatformAction.GetInstance().Add_Manual_Destroyed_Banner_Index(ibannerindex);
                        console.log(ibannerindex+" 格子 销毁 ,需要自动创建");
                    }else{
                        console.log(ibannerindex+" 格子 销毁");
                    }
                    
                })
    
               
            }
           
        }
        
       

        //console.log("ibannerindex="+ibannerindex+",gezi_guanggao_obj="+gezi_guanggao_obj)
        this.m_banner_index_banner_map.putData(ibannerindex,gezi_guanggao_obj);

 
      //  this.m_banner_index_banner_map.putData(ibannerindex,gezi_guanggao_obj);

        callback(true,ibannerindex,gezi_guanggao_obj);
    }
    On_Banner_Error(ibannerindex)
    {
        MiddleGamePlatformAction.GetInstance().On_Banner_Error(ibannerindex);
    }

    //给出屏蔽掉自动销毁刷新的banner，比如胜利失败成功，复活弹框，全屏格子这些，不需要销毁刷新
    Filter_Auto_Destroy_Shuaixin(ibannerindex,ibanenrtype)
    {

        //胜利失败，复活弹框
        var filter_map = new WMap();
        /*
        filter_map.putData(31,1);

        filter_map.putData(32,1);
        filter_map.putData(41,1);
        filter_map.putData(42,1);


        filter_map.putData(44,1);
        filter_map.putData(45,1);


        filter_map.putData(56,1);
        filter_map.putData(57,1);

        // /大厅全屏
        filter_map.putData(18,1);
 
        //游戏场全屏
        filter_map.putData(17,1);
        */
  

        if(filter_map.hasKey(ibannerindex))
        {
            return true;
        }

        return false;
    }

    Check_Banner_Need_Destroy_Shuaxin(ibannerindex,ibanenrtype)
    {

        //服务器明确配置这个id必须刷新还是不刷新
        var mq_kzhi = GlobalGameMng.GetInstance().IS_Server_JingQue_Kongzhi_Banner_Need_Auto_Shuaxin(ibannerindex);
        if(mq_kzhi[0])
        {
            var needshauxin = mq_kzhi[1];


            return needshauxin;
        }

        if(this.Filter_Auto_Destroy_Shuaixin(ibannerindex,ibanenrtype))
        {
            return false;
        }

        if(GlobalGameMng.GetInstance().Check_Banner_Need_Zidong_Shuaxin(ibannerindex,ibanenrtype))
        {
            return true;
        }

        return false;
    }

    FD_Timer_Banner_Index(ibannerindex)
    {
         
    }
    Refresh_Banner_Change_Show(ibannerindex)
    {
        var last_show_tick = 0;
        if(this.m_banner_index_last_first_show_tick_map.hasKey(ibannerindex))
        {
            last_show_tick = this.m_banner_index_last_first_show_tick_map.getData(ibannerindex);
        }

        var bshow = this.Is_Banner_Show_Now(ibannerindex);


        var self = this;
        
        if(this.m_banner_index_banner_map.hasKey(ibannerindex))
        {
            var banner  = this.m_banner_index_banner_map.getData(ibannerindex);
         
            var ibanenrtype = this.Get_Banner_Type(ibannerindex);
       

            if(last_show_tick > 0 && Date.now() - last_show_tick > 33*1000 
                 && this.Check_Banner_Need_Destroy_Shuaxin(ibannerindex,ibanenrtype)  )
            {
                //先销毁

                console.log("销毁banner ibannerindex="+ibannerindex);
                banner.destroy();
                this.m_banner_index_banner_map.RemoveKey(ibannerindex);
                this.m_banner_index_last_first_show_tick_map.RemoveKey(ibannerindex);
                this.m_banner_index_has_showed_map.RemoveKey(ibannerindex);


                this.Check_Create_Banner(ibannerindex,ibanenrtype, ()=>
                {
                   // self.Refresh_Banner_Change_Show(ibannerindex);

                })

                return;
            }
           

          //  console.log("Refresh_Banner_Change_Show bshow="+bshow);

            if(ibanenrtype == 2)
            {
                if(bshow)
                {
                    if(!banner.isShow() || !this.Has_Banner_Showed(ibannerindex))
                    {
                        banner.show();
                        this.Set_Banner_Showed(ibannerindex);
                    }
                    
                    if(!this.m_banner_index_last_first_show_tick_map.hasKey(ibannerindex))
                    {
                        this.m_banner_index_last_first_show_tick_map.putData(ibannerindex,Date.now());
                    }
                   
                }else{

                    
                    if(banner.isShow())
                    {
                        banner.hide();
                    } 

                }
            }else{

              

                if(bshow)
                {
                    banner.show();
                    this.Set_Banner_Showed(ibannerindex);

                    if(!this.m_banner_index_last_first_show_tick_map.hasKey(ibannerindex))
                    {
                        this.m_banner_index_last_first_show_tick_map.putData(ibannerindex,Date.now());
                    }
                   

                }else{

                    
                    banner.hide();
                }


            }
            
          
        }
        else{

            /*
            //已经创建过这个banner,并且要求显示，但是现在这个格子不存在
            if(this.m_bannerindex_ensure_need_created_map.hasKey(ibannerindex) && bshow)
            {
                //应该有这个banner

                var last_create_tick = 0;
                if(this.m_last_banner_try_create_tick_map.hasKey(ibannerindex))
                {
                    last_create_tick = this.m_last_banner_try_create_tick_map.getData(ibannerindex);
                }

                //不能太频繁创建,在失败的情况下
                if(last_create_tick > 0 &&  (Date.now()  -  last_create_tick < 5000) )
                {
                    return;
                }
                this.m_last_banner_try_create_tick_map.putData(ibannerindex,Date.now());
           
                this.Check_Create_Banner(ibannerindex,ibanenrtype, ()=>
                {
                    self.Refresh_Banner_Change_Show(ibannerindex);

                })


               
            }
            
            */
        }
    }

}