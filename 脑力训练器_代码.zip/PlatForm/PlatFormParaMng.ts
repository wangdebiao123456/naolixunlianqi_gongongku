import PlatFormType from "./PlatFormType";

export default class PlatFormParaMng 
{
       
    //当前上线的平台,必须修改两个参数
    m_platform_type=  PlatFormType.PlatFormType_WX;
    
    //m_b_in_wx = false;
    m_b_in_test = false;
    m_version_str= "2.11";
    m_cur_version = 2.11; 
    

    m_xianding_tishen_fangkai_day = 20230611;
    
    static _instance:PlatFormParaMng = null;
    static GetInstance() 
    {
        if (!PlatFormParaMng._instance) {
            // doSomething
            PlatFormParaMng._instance = new PlatFormParaMng();
             
        }
        return PlatFormParaMng._instance;
    }

    GetPlatFormType():number
    {
        return this.m_platform_type;
    }

    Get_Cur_Version()
    {

        return this.m_cur_version;
    }

   
}