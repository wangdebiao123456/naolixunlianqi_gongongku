 
import DefaultPlatformMng from "./DefaultPlatformMng";
import IPlatformMng from "./IPlatformMng";
import PlatFormType from "./PlatFormType";
import WXPlatformMng from "./WXPlatformMng";
import ByteDancePlatformMng from "./ByteDancePlatformMng";
import LeTianTangAppStorePlatformMng from "./LeTianTangAppStorePlatformMng";
import KuaiShouPlatformMng from "./KuaiShouPlatformMng";
import QQXiaoyouxiPlatformMng from "./QQXiaoyouxiPlatformMng";
import P_4399_XiaoyouxiHezi_PlatformMng from "./P_4399_XiaoyouxiHezi_PlatformMng";
import HuaWei_Xiaoyou_PlatformMng from "./HuaWei_Xiaoyou_PlatformMng";
import Vivo_Xiaoyouxi_PlatformMng from "./Vivo_Xiaoyouxi_PlatformMng";
import Momoyu_Android_PlatformMng from "./Momoyu_Android_PlatformMng";
import ChuanShanjia_Com_PlatformMng from "./ChuanShanjia_Com_PlatformMng";
import P_4399_H5_Xiaoyouxi_PlatormMng from "./P_4399_H5_Xiaoyouxi_PlatormMng";
import P_233_Lianyun_PlatformMng from "./P_233_Lianyun_PlatformMng";
import PlatFormParaMng from "./PlatFormParaMng";
import OPPOXiaoyouxiPlatformMng from "./OPPOXiaoyouxiPlatformMng";
 

export default class PlatFormMng 
{
    

    
    static _instance:PlatFormMng = null;
    static GetInstance() 
    {
        if (!PlatFormMng._instance) {
            // doSomething
            PlatFormMng._instance = new PlatFormMng();
             
        }
        return PlatFormMng._instance;
    }

   



    m_delay_task_list = [];

    m_default_mng =  null;
    m_wx_mng = null;
    m_bytedance_mng = null;

    m_letiantang_appstore_mng = null;
    m_kuaishou_mng=  null;
    m_qq_xiaoyouxi_mng = null;
    m_4399_xiaoyouxi_hezi_mng = null;
    m_huawei_xiaoyouxi_mng = null;

    m_vivo_xiaoyouxi_mng = null;
    m_oppo_xiaoyouxi_mng=  null;

    m_momoyu_android_mng = null;
    //穿山甲
    m_quanshanjia_common_android_mng = null;

    m_4399_h5_xiaoyouxi_mng = null;
    m_233_lianyun_mng = null;
 
    
    constructor()
    {
        this.m_default_mng =  new DefaultPlatformMng();
    }
    GetPlatFormType():number
    {
        return PlatFormParaMng.GetInstance().GetPlatFormType();
    }
 
    Get_PlatFormManger():IPlatformMng
    {
        if(this.GetPlatFormType() == PlatFormType.PlatFormType_WX)
        {
            if(this.m_wx_mng == null)
            {
                this.m_wx_mng = new WXPlatformMng();
            }
            return this.m_wx_mng;
        }

        if(this.GetPlatFormType() == PlatFormType.PlatFormType_ByteDance)
        {
            if(this.m_bytedance_mng == null)
            {
                this.m_bytedance_mng = new ByteDancePlatformMng();
            }
            return this.m_bytedance_mng;
        }

        
        if(this.GetPlatFormType() == PlatFormType.PlatFormType_LeTiantang_IOS_AppStore)
        {
            if(this.m_letiantang_appstore_mng == null)
            {
                this.m_letiantang_appstore_mng = new LeTianTangAppStorePlatformMng();
            }
            return this.m_letiantang_appstore_mng;
        }


        if(this.GetPlatFormType() == PlatFormType.PlatFormType_Kuaishou_Xiaoyouxi)
        {
            if(this.m_kuaishou_mng == null)
            {
                this.m_kuaishou_mng = new KuaiShouPlatformMng();
            }
            return this.m_kuaishou_mng;
        }


        if(this.GetPlatFormType() == PlatFormType.PlatFormType_QQ_Xiaoyouxi)
        {
            if(this.m_qq_xiaoyouxi_mng == null)
            {
                this.m_qq_xiaoyouxi_mng = new QQXiaoyouxiPlatformMng();
            }
            return this.m_qq_xiaoyouxi_mng;
        }

 

        if(this.GetPlatFormType() == PlatFormType.PlatFormType_4399_Xiaoyouxi_Hezi)
        {
            if(this.m_4399_xiaoyouxi_hezi_mng == null)
            {
                this.m_4399_xiaoyouxi_hezi_mng = new P_4399_XiaoyouxiHezi_PlatformMng();
            }
            return this.m_4399_xiaoyouxi_hezi_mng;
        }

 
        if(this.GetPlatFormType() == PlatFormType.PlatFormType_Huaiwei_Xiaoyouxi)
        {
            if(this.m_huawei_xiaoyouxi_mng == null)
            {
                this.m_huawei_xiaoyouxi_mng = new HuaWei_Xiaoyou_PlatformMng();
            }
            return this.m_huawei_xiaoyouxi_mng;
        }

        if(this.GetPlatFormType() == PlatFormType.PlatFormType_Vivo_Xiaoyouxi)
        {
            if(this.m_vivo_xiaoyouxi_mng == null)
            {
                this.m_vivo_xiaoyouxi_mng = new Vivo_Xiaoyouxi_PlatformMng();
            }
            return this.m_vivo_xiaoyouxi_mng;
        }
        if(this.GetPlatFormType() == PlatFormType.PlatFormType_OPPO_Xiaoyouxi)
        {
            if(this.m_oppo_xiaoyouxi_mng == null)
            {
                this.m_oppo_xiaoyouxi_mng = new OPPOXiaoyouxiPlatformMng();
            }
            return this.m_oppo_xiaoyouxi_mng;
        }
        if(this.GetPlatFormType() == PlatFormType.PlatFormType_Momoyu_Android)
        {
            if(this.m_momoyu_android_mng == null)
            {
                this.m_momoyu_android_mng = new Momoyu_Android_PlatformMng();
            }
            return this.m_momoyu_android_mng;
        }

        
        if(this.GetPlatFormType() == PlatFormType.PlatFormType_Chuangshanjia_common)
        {
            if(this.m_quanshanjia_common_android_mng == null)
            {
                this.m_quanshanjia_common_android_mng = new ChuanShanjia_Com_PlatformMng();
            }
            return this.m_quanshanjia_common_android_mng;
        }



        if(this.GetPlatFormType() == PlatFormType.PlatFormType_4399_H5_Xiaoyouxi)
        {
            if(this.m_4399_h5_xiaoyouxi_mng == null)
            {
                this.m_4399_h5_xiaoyouxi_mng = new P_4399_H5_Xiaoyouxi_PlatormMng();
            }
            return this.m_4399_h5_xiaoyouxi_mng;
        }


        
        if(this.GetPlatFormType() == PlatFormType.PlatFormType_233)
        {
            if(this.m_233_lianyun_mng == null)
            {
                this.m_233_lianyun_mng = new P_233_Lianyun_PlatformMng();
            }
            return this.m_233_lianyun_mng;
        }

        
        
        return this.m_default_mng;
    }
    Dating_Fenxiang()
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Dating_Fenxiang();
    }
    Watch_Com_Guanggao_ID_B(guanggaoname,in_cb,errorload_cb,agv,callback)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Watch_Com_Guanggao_ID_B(guanggaoname,in_cb,errorload_cb,agv,callback);
    }

    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback);
    }

    CheckShowChaiping(ichaipingtype = 0 )
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.CheckShowChaiping(ichaipingtype);
    }

    Start_Luping()
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Start_Luping();
    }

    Stop_Luping()
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Stop_Luping();
    }

    Fengxiang_Youxi_Luping(stitle,sscontent,callback)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Fengxiang_Youxi_Luping(stitle,sscontent,callback);
    }
    IS_Game_End_Xuanyao_Luping_Shiping()
    {
        var  platformmng = this.Get_PlatFormManger();
        return platformmng.IS_Game_End_Xuanyao_Luping_Shiping();
  
    }
    Add_Delay_Task(delaytime,callback)
    {
        this.m_delay_task_list.push([Date.now(), delaytime,callback]);

    }
    PreLoad_Jili_Shiping(itype)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.PreLoad_Jili_Shiping(itype);
    }
    Deal_With_Delay_Task()
    {
        if(this.m_delay_task_list.length == 0)
        {
            return;
        }

        var curtick = Date.now();
        var ilen1 = this.m_delay_task_list.length-1;

        for(var ff=ilen1;ff>=0;ff--)
        {
            var ff_task = this.m_delay_task_list[ff];
            var ff_start_tick = ff_task[0];
            var ff_delaytick = ff_task[1];
            var ff_callback = ff_task[2];

            if(curtick - ff_start_tick > ff_delaytick )
            {
                this.m_delay_task_list.splice(ff,1);
                ff_callback();

            }
            
        } 

    }
    FD_Mng_Timer(mainnode:cc.Node)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.FD_Mng_Timer(mainnode);

        this.Deal_With_Delay_Task();

    }
    Check_WX_Login_Read_OpenId(callback)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Check_WX_Login_Read_OpenId(callback)
    }

    Get_Banner_Type(ibannerindex)
    {
        var  platformmng = this.Get_PlatFormManger();
        return platformmng.Get_Banner_Type(ibannerindex);
    }
    Exit_Game()
    {
        var  platformmng = this.Get_PlatFormManger();

        return platformmng.Exit_Game();
    }
    Check_Show_YonghuXieyi()
    {
        var  platformmng = this.Get_PlatFormManger();

        return platformmng.Check_Show_YonghuXieyi();
    }
    IS_Game_End_Xuanyao_Btn_Show()
    {
        var  platformmng = this.Get_PlatFormManger();

        return platformmng.IS_Game_End_Xuanyao_Btn_Show();
    }
    OnBtnGengduoYouxi()
    {
        var  platformmng = this.Get_PlatFormManger();

        return platformmng.OnBtnGengduoYouxi();
    }
    IS_Fenxiang_Btn_Show()
    {
        var  platformmng = this.Get_PlatFormManger();

        return platformmng.IS_Fenxiang_Btn_Show();
    }
    Check_Update()
    {
        var  platformmng = this.Get_PlatFormManger();

          platformmng.Check_Update();
    }
    IS_Can_Show_Zidingyi_TuijianWei()
    {
        var  platformmng = this.Get_PlatFormManger();
        return platformmng.IS_Can_Show_Zidingyi_TuijianWei()
    }
    Get_Storge_Type()
    {
        var  platformmng = this.Get_PlatFormManger();

        return  platformmng.Get_Storge_Type();
    }

    Get_Saved_GUID()
    {
        var  platformmng = this.Get_PlatFormManger();

        return platformmng.Get_Saved_GUID();
    }
    Set_Banner_Need_Show(ibannerindex,bshow)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Set_Banner_Need_Show(ibannerindex,bshow);
    }
    Is_Dating_Show_Tuijian_Tiaozhuan()
    {
        var  platformmng = this.Get_PlatFormManger();
        return platformmng.Is_Dating_Show_Tuijian_Tiaozhuan();
    }

    Is_Banner_Show_Now(ibannerindex)
    {
        var  platformmng = this.Get_PlatFormManger();
        return platformmng.Is_Banner_Show_Now(ibannerindex);
    }
    Check_Create_Banner(ibannerindex,ibannertype, callback)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Check_Create_Banner(ibannerindex,ibannertype, callback);
    }
    Refresh_Banner_Change_Show(backbannerindex)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Refresh_Banner_Change_Show(backbannerindex)
    }
    Tiaozhuan_Tuijian_AppID(appid)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Tiaozhuan_Tuijian_AppID(appid);
    }

    Jump_To_App_Game_By_Data( app_info)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Jump_To_App_Game_By_Data( app_info);
    }
    FD_Banner_Mng_Timer(pmainnode)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.FD_Banner_Mng_Timer(pmainnode);
    }
    IS_Zhanghuan_Gongzhanghao_Info_Show()
    {
        var  platformmng = this.Get_PlatFormManger();
       return platformmng.IS_Zhanghuan_Gongzhanghao_Info_Show();
    }
    Manual_Destroy_banner(ibannerindex)
    {
        var  platformmng = this.Get_PlatFormManger();
        return platformmng.Manual_Destroy_banner(ibannerindex);
    }
    Share_Msg(strtiel, strtyip)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Share_Msg(strtiel,strtyip);
    }
  
    Refresh_All_Banner_Show()
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.Refresh_All_Banner_Show();
    }

    showToast(para)
    {
        var  platformmng = this.Get_PlatFormManger();
        platformmng.showToast(para)
    }

    Get_Global_Config_Server_Path()
    {
        var  platformmng = this.Get_PlatFormManger();
        return platformmng.Get_Global_Config_Server_Path();
    }

    IS_Dating_Game_Quanping_Gezi_Btn_Show()
    {
        var  platformmng = this.Get_PlatFormManger();
        return platformmng.IS_Dating_Game_Quanping_Gezi_Btn_Show();
    }
}
