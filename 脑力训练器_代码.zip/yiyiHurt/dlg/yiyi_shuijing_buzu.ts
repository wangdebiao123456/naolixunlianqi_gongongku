import ComFunc from "../../comfuncs/ComFunc"; 
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import yiyiHurtMng from "../yiyiHurtMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class yiyi_shuijing_buzu extends cc.Component {

    m_cb = null;
    
    onLoad () 
    {
        var btn_exit = cc.find("panel/exit",this.node);
        btn_exit.on("click",this.OnBtnExit.bind(this));
       
        var huoqubtn = cc.find("panel/huoqubtn",this.node);
        huoqubtn.on("click",this.OnBtnHuoqu.bind(this));
        
    }

    OnBtnExit()
    {
        this.node.destroy();


        if(this.m_cb)
        {
            this.m_cb();
        }
        BackGroundSoundUtils.GetInstance().Play_Effect('com/btn');
     
    }

    SetInitData(pingo)
    { 
        this.m_cb = pingo.cb;
        var zuanshi_c_label= cc.find("panel/zuanshi/c",this.node);
        zuanshi_c_label.getComponent(cc.Label).string = ""+yiyiHurtMng.GetInstance().m_i_zuanshi;
        
    }

    Real_Huopqu()
    {
        yiyiHurtMng.GetInstance().Change_Zuanshi(100)

            
        var self = this;
        var hnq = [{"t":42,"c":100}];
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, hnq, 1, 
            ()=>
            {
                self.OnBtnExit();
            });
       
    }

    OnBtnHuoqu()
    {
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,()=>{},


            "一亿万水晶不足",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }
            self.Real_Huopqu();
 
        })
    }
    


}
