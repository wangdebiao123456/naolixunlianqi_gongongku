 
import BundleLoadUtils from "../../comfuncs/BundleLoadUtils";
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
 
import yiyiHurtMng from "../yiyiHurtMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class yiy_open_wuping_dlg extends cc.Component {

    m_cb = null;
    m_wupinglist = [];
    m_opened_wuping_list = [];
    m_show_open_type_list = [];

    m_last_bk_op_tick = 0;

    m_i_status = 1;
    m_show_wuping_index = 0;
    
    @property(cc.Node)
    per_wuping_node: cc.Node = null;


    onLoad () 
    {

        var bk = cc.find("bk",this.node)
        bk.on("click",this.OnBtnClickBK.bind(this))

        var nextbtn = cc.find("panel/staus1/com/nextbtn",this.node)
        nextbtn.on("click",this.OnBtnNext.bind(this))

        var allbtn = cc.find("panel/staus2/allbtn",this.node)
        allbtn.on("click",this.OnBtnShouxia.bind(this))

        var kaiqiallbtn = cc.find("panel/staus1/com/allbtn",this.node)
        kaiqiallbtn.on("click",this.OnBtnAllkai.bind(this))


        
        this.m_last_bk_op_tick = Date.now()
    }
    OnBtnClickBK()
    {
        if(Date.now() - this.m_last_bk_op_tick < 1000)
        {
            return;
        }

        this.OnBtnNext();
    }
    SetInitData(pinfo)
    {
        this.m_cb = pinfo.cb;
        this.m_wupinglist = pinfo.wupinglist;

        /*

        //1:普通道具，1金币2钻石
        wupinglist.push([1,1,500*ibeishu])
        wupinglist.push([1,2,20*ibeishu])

          //3:神器碎片，第二个参数>0对应英雄碎片,0:未知英雄
        wupinglist.push([3,0,1*ibeishu])
        
        //11-14：英雄卡片，0未知英雄，>0对应英雄
        //11-14为四个档次的卡片
        wupinglist.push([12,0,1*ibeishu])
        wupinglist.push([13,0,1*ibeishu])


        */
        this.m_opened_wuping_list = [];
        this.m_show_open_type_list = [];

        for(var ff=0;ff<this.m_wupinglist.length;ff++)
        {
            var ff_info  = this.m_wupinglist[ff];

            var ff_type = ff_info[0];
            var ff_sub_type = ff_info[1];
            var ff_c = ff_info[2];
            
            var newinfo = [ff_type,ff_sub_type,ff_c]

            if(ff_type == 3)
            {
               

                    for(var gg=0;gg<ff_c;gg++)
                    {
                        if(ff_sub_type == 0)
                        {
                            var ff_heroid = yiyiHurtMng.GetInstance().Get_Next_Rand_HeroId();
 
                            this.m_opened_wuping_list.push([ff_type,ff_heroid,1])
                            this.m_show_open_type_list.push([ff_type,ff_heroid,1])
                        }else{
                            this.m_opened_wuping_list.push([ff_type,ff_sub_type,1])
                            this.m_show_open_type_list.push([ff_type,ff_sub_type,1])

                        }
                        
                    }

                  
                
            } 
            else  if(ff_type  >= 11 && ff_type <= 14)
            {
                
                for(var gg=0;gg<ff_c;gg++)
                {
                    if(ff_sub_type == 0)
                    {
                        var ff_heroid = yiyiHurtMng.GetInstance().Get_Next_Rand_HeroId();
                        this.m_show_open_type_list.push([ff_type,0,1])
                        this.m_opened_wuping_list.push([ff_type,ff_heroid,1])
                        this.m_show_open_type_list.push([ff_type,ff_heroid,1])
                    }else{
                        this.m_opened_wuping_list.push([ff_type,ff_sub_type,1])
                        this.m_show_open_type_list.push([ff_type,ff_sub_type,1])

                    }
                    
                }

            }else{
                this.m_opened_wuping_list.push(newinfo)
                this.m_show_open_type_list.push(newinfo)

            }

           
        }


        if(this.m_show_open_type_list.length == 1)
        {
            this.m_i_status = 2;
            this.Change_Show_All()
            this.Refresh_Info(); 
            
            BackGroundSoundUtils.GetInstance().Play_Effect("com/huode_jp")
        }else{
            this.m_i_status = 1;
            this.m_show_wuping_index = 0;
            var icon  = cc.find("panel/staus1/com/1",this.node)
            icon.scale = 0.2;
            icon.runAction(cc.scaleTo(0.2,1))
    
            this.Refresh_Info(); 
            BackGroundSoundUtils.GetInstance().Play_Effect("com/huode_jp")
        }
 
     
    }

    Refresh_Info()
    {
        var staus1_ndoe = cc.find("panel/staus1",this.node)
        var staus2_ndoe = cc.find("panel/staus2",this.node)

        if(this.m_i_status == 1)
        {
            staus1_ndoe.active = true;
            staus2_ndoe.active = false;

            this.Show_Wuping();
        }
        else{
            staus1_ndoe.active = false;
            staus2_ndoe.active = true;
        }
        
    }
    Show_Item_Info(ff_info,ff_node)
    {
        var wuping_info = ff_info;

        var itype =  wuping_info[0];
        var isubtype =  wuping_info[1];
        var icount =  wuping_info[2];


 
        var com_suipian_bk_ndoe = cc.find("suipian",ff_node)
        var com_kabao_bk_ndoe = cc.find("kabao",ff_node)
     
        com_suipian_bk_ndoe.active = false;
        com_kabao_bk_ndoe.active = false;
    
 { 

            var name_ndoe = cc.find("name",ff_node)
            var icon_ndoe = cc.find("icon",ff_node)
            var c_ndoe = cc.find("c",ff_node)
 
 
    
            if(itype == 1)
            {
                if(isubtype == 1)
                {
                    name_ndoe.getComponent(cc.Label).string = "金币";

                   
                }
                if(isubtype == 2)
                {
                    name_ndoe.getComponent(cc.Label).string = "伤害水晶";
                    
                }

                var iindex2 = isubtype + 40;
                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",icon_ndoe,
                "daoju/com/"+iindex2,{width:60,height:60});


                c_ndoe.getComponent(cc.Label).string = "+"+icount;
            }
            
            if(itype == 3)
            {
                name_ndoe.getComponent(cc.Label).string =  "碎片";

                com_suipian_bk_ndoe.active = true;
    
                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("yiyiHurt",icon_ndoe,
                "people/"+isubtype,{width:40,height:40});

                c_ndoe.getComponent(cc.Label).string = "";
            }

            if(itype  >= 11 && itype <= 14)
            {
                name_ndoe.getComponent(cc.Label).string = yiyiHurtMng.GetInstance().Get_HeroID_Name(isubtype)+"";
               
                var kabao_bk_ndoe = cc.find("kabao/bk",ff_node)
 
                var iindex= itype -  10;

                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("yiyiHurt",kabao_bk_ndoe,
                "kuang/k"+iindex,{width:100,height:100});

               
               
                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("yiyiHurt",icon_ndoe,
                "people/"+isubtype,{width:40,height:40})

                com_kabao_bk_ndoe.active = true;
    
                var add_attr_v =  yiyiHurtMng.GetInstance().Get_HeroID_Kabao_Pingji_Add_Attr_Value(isubtype,itype-10);
                c_ndoe.getComponent(cc.Label).string = "+"+add_attr_v;
            }
        }
    }
    Show_Wuping()
    {
        var wuping_info = this.m_show_open_type_list[this.m_show_wuping_index];

        var itype =  wuping_info[0];
        var isubtype =  wuping_info[1];
        var icount =  wuping_info[2];

        var nextbtn = cc.find("panel/staus1/com/nextbtn",this.node)
        var allbtn = cc.find("panel/staus1/com/allbtn",this.node)
    
        if(this.m_show_wuping_index == this.m_show_open_type_list.length-1)
        {
            nextbtn.active = false;
            allbtn.x = 0;
        }else{
            nextbtn.active = true;
            allbtn.x = 251;
        }

        

        var com_ndoe = cc.find("panel/staus1/com",this.node)
        var kabao_ndoe = cc.find("panel/staus1/kabao",this.node)
 
        var com_suipian_bk_ndoe = cc.find("panel/staus1/com/1/suipian",this.node)
        var com_kabao_bk_ndoe = cc.find("panel/staus1/com/1/kabao",this.node)
     
        com_suipian_bk_ndoe.active = false;
        com_kabao_bk_ndoe.active = false;
    

        if(itype >= 11 && itype <= 14 && isubtype == 0)
        {
            var iindex= itype -  10;

            var kabao_icon_ndoe = kabao_ndoe.getChildByName("icon")
            
            BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("yiyiHurt",kabao_icon_ndoe,
            "kuang/bao"+iindex,{width:100,height:100});

            com_ndoe.active = false;
            kabao_ndoe.active = true;

        }
        else{
            com_ndoe.active = true;
            kabao_ndoe.active = false;

            var name_ndoe = cc.find("panel/staus1/com/1/name",this.node)
            var icon_ndoe = cc.find("panel/staus1/com/1/icon",this.node)
            var c_ndoe = cc.find("panel/staus1/com/1/c",this.node)
 
 
    
            if(itype == 1)
            {
                if(isubtype == 1)
                {
                    name_ndoe.getComponent(cc.Label).string = "金币";

                   
                }
                if(isubtype == 2)
                {
                    name_ndoe.getComponent(cc.Label).string = "伤害水晶";
                    
                }

                var iindex2 = isubtype + 40;
                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",icon_ndoe,
                "daoju/com/"+iindex2,{width:60,height:60});


                c_ndoe.getComponent(cc.Label).string = "+"+icount;
            }
            
            if(itype == 3)
            {
                name_ndoe.getComponent(cc.Label).string = yiyiHurtMng.GetInstance().Get_HeroID_Name(isubtype)+"碎片";

                com_suipian_bk_ndoe.active = true;
    
                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("yiyiHurt",icon_ndoe,
                "people/"+isubtype,{width:60,height:60});

                c_ndoe.getComponent(cc.Label).string = "";
            }

            if(itype  >= 11 && itype <= 14)
            {
                name_ndoe.getComponent(cc.Label).string = yiyiHurtMng.GetInstance().Get_HeroID_Name(isubtype)+"";
               
                var kabao_bk_ndoe = cc.find("panel/staus1/com/1/kabao/bk",this.node)
 
                var iindex= itype -  10;

                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("yiyiHurt",kabao_bk_ndoe,
                "kuang/k"+iindex,{width:160,height:160});

               
               
                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("yiyiHurt",icon_ndoe,
                "people/"+isubtype,{width:60,height:60})

                com_kabao_bk_ndoe.active = true;
    
                var add_attr_v =  yiyiHurtMng.GetInstance().Get_HeroID_Kabao_Pingji_Add_Attr_Value(isubtype,itype-10);
                c_ndoe.getComponent(cc.Label).string = "+"+add_attr_v;
            }
        }

    }
    Get_Pos(iidnex,ialllen)
    {

        if(ialllen  <= 1)
        {
            return new cc.Vec2(0,0);
        }
        if(ialllen  == 2)
        {
            if(iidnex == 0)
            {
                return new cc.Vec2(-150,0);
            }
            return new cc.Vec2(150,0);
        }

        if(ialllen  == 3)
        {
            if(iidnex == 0)
            {
                return new cc.Vec2(-200,0);
            } 
            else if(iidnex == 1)
            {
                return new cc.Vec2( 0,0);
            }
            return new cc.Vec2(200,0);
        }
        if(ialllen  == 4)
        {
            if(iidnex == 0)
            {
                return new cc.Vec2(-225,0);
            } 
            else if(iidnex == 1)
            {
                return new cc.Vec2( -75,0);
            } else if(iidnex == 2)
            {
                return new cc.Vec2( 75,0);
            }
            return new cc.Vec2(225,0);
        }

        if(ialllen  == 5)
        {
            if(iidnex == 0)
            {
                return new cc.Vec2(-260,0);
            } 
            else if(iidnex == 1)
            {
                return new cc.Vec2( -130,0);
            } else if(iidnex == 2)
            {
                return new cc.Vec2( 0,0);
            }else if(iidnex == 3)
            {
                return new cc.Vec2( 130,0);
            }
            return new cc.Vec2(260,0);
        }


        var iy1 = Math.floor(iidnex/5);
        var startindex = iy1*5;
       
        var ileftc = ialllen - 5*iy1;



        var isubindex = iidnex - 5*iy1;

    
        var ypos = iy1*240-120;

        var ic1 = 5;
        if(ileftc > 5)
        {
            ic1 = 5;
        }else{
            ic1 = ileftc;
        }
        var pos11 = this.Get_Pos(isubindex,ic1)

        var xpos = pos11.x;

        return new cc.Vec2(xpos,ypos)
    }
    Change_Show_All()
    {
        this.m_i_status = 2;
        var wuping_node  = cc.find("panel/staus2/wuping",this.node)
     
        
        for(var ff=0;ff<this.m_opened_wuping_list.length;ff++)
        {
            var ff_info = this.m_opened_wuping_list[ff];
            var ff_node =  cc.instantiate(this.per_wuping_node);
            ff_node.active = true;
            wuping_node.addChild(ff_node,20);

            var ff_pos = this.Get_Pos(ff,this.m_opened_wuping_list.length)
            ff_node.setPosition(ff_pos);

            this.Show_Item_Info(ff_info,ff_node);
        }

    }

    OnBtnAllkai()
    {
        this.Change_Show_All();

        this.Refresh_Info();
            
        BackGroundSoundUtils.GetInstance().Play_Effect("com/huoquwuping")
    }
    OnBtnNext()
    {

        this.m_show_wuping_index++;

        if(this.m_show_wuping_index >= this.m_show_open_type_list.length)
        {
            this.Change_Show_All();

            
            BackGroundSoundUtils.GetInstance().Play_Effect("com/huoquwuping")
        }else{

            var icon  = cc.find("panel/staus1/com/1",this.node)
            icon.scale = 0.2;
            icon.runAction(cc.scaleTo(0.2,1))


            BackGroundSoundUtils.GetInstance().Play_Effect("com/huode_jp")

        }

        this.Refresh_Info();
        //this.FinishedAll();
    }
    OnBtnShouxia()
    {
        this.FinishedAll();
    }
    FinishedAll()
    {


        for(var ff=0;ff<this.m_opened_wuping_list.length;ff++)
        {
            var ff_info =  this.m_opened_wuping_list[ff];
            var ff_type = ff_info[0];
            var ff_subtype = ff_info[1];
            var ff_c = ff_info[2];

            if(ff_type == 1)
            {
                if(ff_subtype == 1)
                {
                    yiyiHurtMng.GetInstance().Change_Money(ff_c);
                }
                if(ff_subtype == 2)
                {
                    yiyiHurtMng.GetInstance().Change_Zuanshi(ff_c);
                }

            }
           
            if(ff_type == 3)
            {

                yiyiHurtMng.GetInstance().Add_Shenqi_Suipian_List([ff_subtype])
            }


            if(ff_type >= 11 && ff_type <= 14)
            {

                var iindex = ff_type - 10;
                var demage_addc = yiyiHurtMng.GetInstance().Get_HeroID_Kabao_Pingji_Add_Attr_Value(ff_subtype,iindex);
                yiyiHurtMng.GetInstance().Add_HeroID_Attr(ff_subtype,demage_addc);
            }

        }


        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(this.m_opened_wuping_list);
        }
    }

}
