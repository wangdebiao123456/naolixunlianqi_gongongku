import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class yiy_tiaozhan_suc_dlg extends cc.Component {

    m_cb = null;
    
    
    onLoad () 
    {

        var btn_com = cc.find("panel/1",this.node)
        var btn_gaoji = cc.find("panel/2",this.node)
        

        btn_com.on("click",this.OnBtnComLingqu.bind(this))
        btn_gaoji.on("click",this.OnBtnGaojiLingqu.bind(this))

    }

    Real_Lingqu(ibeishu)
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(ibeishu);
        }
    }
    OnBtnGaojiLingqu()
    {
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,()=>{},
            "一亿视频双倍领取礼盒",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }
            self.Real_Lingqu(3);

        });
 
    }
    OnBtnComLingqu()
    {
        this.Real_Lingqu(1);

    }
    SetInitData(pinfo)
    {
        this.m_cb = pinfo.cb;

        this.Refresh_Info();
    }
    Refresh_Info()
    {

    }
}
