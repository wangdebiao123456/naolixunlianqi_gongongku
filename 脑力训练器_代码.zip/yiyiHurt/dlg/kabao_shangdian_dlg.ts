import BaseUIUtils from "../../comfuncs/BaseUIUtils";
import BundleLoadUtils from "../../comfuncs/BundleLoadUtils";
import ComFunc from "../../comfuncs/ComFunc";
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import yiyiHurtMng from "../yiyiHurtMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class kabao_shangdian_dlg extends cc.Component {

    m_cb = null;
    
    @property(cc.Prefab)
    yiyi_shuijing_buzu: cc.Prefab = null;

    
 
    @property(cc.Prefab)
    show_get_hero_shenqi_suipian_dlg: cc.Prefab = null;


    
    onLoad () {

        var exitbtn = cc.find("panel/exitbtn",this.node)
        exitbtn.on("click",this.OnBtnExit.bind(this))
        

        var shuaixinbtn = cc.find("panel/kapai/shuaixinbtn",this.node)
        shuaixinbtn.on("click",this.OnBtnShuaxin.bind(this));

        var  shuijing_goumai_btn = cc.find("panel/shengqi/com/1/btn",this.node)
        shuijing_goumai_btn.on("click",this.OnBtnGoumaiShuijing.bind(this));



        
        var kabao_shuaixinbtn = cc.find("panel/kabao/com/shuaixinbtn",this.node)
        kabao_shuaixinbtn.on("click",this.OnBtnShuaxinKabao.bind(this));

        
   
        var shengqi_shuaixinbtn = cc.find("panel/shengqi/com/shuaixinbtn",this.node)
        shengqi_shuaixinbtn.on("click",this.OnBtnShuaxinShenqi.bind(this));

        
        
        for(var ff=1;ff<=4;ff++)
        {
            var ff_btn = cc.find("panel/kapai/"+ff+"/btn",this.node)
            ff_btn.on("click",this.OnBtnKapai.bind(this,ff));

        }
             
        for(var ff=1;ff<=4;ff++)
        {
            var ff_btn = cc.find("panel/kabao/com/"+ff+"/btn",this.node)
            ff_btn.on("click",this.OnBtnKaBao.bind(this,ff));

        }

        for(var ff=2;ff<=4;ff++)
        {
            var ff_btn = cc.find("panel/shengqi/com/"+ff+"/btn",this.node)
            ff_btn.on("click",this.OnBtnShenqiGoumai.bind(this,ff));

        }


       
        
    }
    OnBtnShuaxinKabao()
    {
        if(yiyiHurtMng.GetInstance().m_i_zuanshi < 2)
        {
            BaseUIUtils.ShowTipTxtDlg("水晶不足",this.node)
            return;
        }
        yiyiHurtMng.GetInstance().Change_Zuanshi(-2)
        yiyiHurtMng.GetInstance().On_Zuanshi_Shuaxin_Kabao();
    
        this.Refresh_Info();

        BaseUIUtils.ShowTipTxtDlg("刷新成功",this.node)
    }

    OnBtnShuaxinShenqi()
    {
        if(yiyiHurtMng.GetInstance().m_i_zuanshi < 2)
        {
            BaseUIUtils.ShowTipTxtDlg("水晶不足",this.node)
            return;
        }
        yiyiHurtMng.GetInstance().Change_Zuanshi(-2)
        yiyiHurtMng.GetInstance().On_Zuanshi_Shuaxin_Shenqi();
    
        this.Refresh_Info();

        BaseUIUtils.ShowTipTxtDlg("刷新成功",this.node)
    }
    OnBtnShuaxin()
    {
        if(yiyiHurtMng.GetInstance().m_i_zuanshi < 2)
        {
            BaseUIUtils.ShowTipTxtDlg("水晶不足",this.node)
            return;
        }
        yiyiHurtMng.GetInstance().Change_Zuanshi(-2)
        yiyiHurtMng.GetInstance().On_Zuanshi_Shuaxin_Kapai();
    
        this.Refresh_Info();

        BaseUIUtils.ShowTipTxtDlg("刷新成功",this.node)
    }
    OnBtnExit()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(0);
        }
    }
    
    SetInitData(pinfo)
    {
        this.m_cb = pinfo.cb;

        this.Refresh_Info();
    }

    Refresh_Info()
    {
        var ff_ndoe  =  cc.find("panel/kapai/"+ff,this.node);
         

        var jinbi_t_label = cc.find("panel/top/jinbi/t",this.node)
        jinbi_t_label.getComponent(cc.Label).string = yiyiHurtMng.GetInstance().m_i_money+"";

        var zuanshi_t_label = cc.find("panel/top/zuanshi/t",this.node)
        zuanshi_t_label.getComponent(cc.Label).string = yiyiHurtMng.GetInstance().m_i_zuanshi+"";



        var imainenerindex = yiyiHurtMng.GetInstance().m_i_main_enemry_index;
        var show_kapai_list = yiyiHurtMng.GetInstance().Get_Cur_Show_Kapai_Heroid_List(imainenerindex);
        var cur_show_kabao_has_pursed_index_map = yiyiHurtMng.GetInstance().m_cur_show_kabao_has_pursed_index_map;


        for(var ff=1;ff<=4;ff++)
        {
            var ff_heroid = show_kapai_list[ff-1];

            var ff_ndoe  =  cc.find("panel/kapai/"+ff,this.node);
            var ff_name_node = cc.find("name",ff_ndoe)
            ff_name_node.getComponent(cc.Label).string = yiyiHurtMng.GetInstance().Get_HeroID_Name(ff_heroid);

            var ff_addc_node = cc.find("btn/addc",ff_ndoe)
        

            var ff_addc = yiyiHurtMng.GetInstance().Get_HeroID_Kabao_Pingji_Add_Attr_Value(ff_heroid,ff);
            ff_addc_node.getComponent(cc.Label).string = "+"+ff_addc

            var ff_yishoujing_node = cc.find("btn/yishoujing",ff_ndoe)
            var ff_icon_node = cc.find("btn/icon",ff_ndoe)
            var ff_need_c_node = cc.find("need/c",ff_ndoe)
      
            if(cur_show_kabao_has_pursed_index_map.hasKey(ff))
            {
                ff_yishoujing_node.active = true;
                ff_icon_node.active = false;

                if(ff == 4)
                {
                    ff_need_c_node.getComponent(cc.Label).string = "1/1"
                }
            }
            else{
                ff_yishoujing_node.active = false;

                ff_icon_node.active = true;

                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("yiyiHurt",ff_icon_node,
                "people/"+ff_heroid,{width:60,height:60})

                if(ff == 4)
                {
                    ff_need_c_node.getComponent(cc.Label).string = "0/1"
                }
            }
            
            
        }






         var cur_show_second_kabao_has_pursed_index_map = yiyiHurtMng.GetInstance().m_cur_show_second_kabao_has_pursed_index_map;


        for(var ff=1;ff<=4;ff++)
        {
          
            var ff_ndoe  =  cc.find("panel/kabao/com/"+ff,this.node);
           
            var ff_yishoujing_node = cc.find("btn/yishoujing",ff_ndoe)
             var ff_need_c_node = cc.find("need/c",ff_ndoe)
      
            if(cur_show_second_kabao_has_pursed_index_map.hasKey(ff))
            {
                ff_yishoujing_node.active = true;
               
                
            }
            else{
                ff_yishoujing_node.active = false;
  
              
            }
            
            
        }






        var shenqi_suipian_heroid_list = yiyiHurtMng.GetInstance().Get_Cur_Show_Shenqi_Suipian_Heroid_List(imainenerindex);
        var shenqi_suipian_has_pursed_index_map = yiyiHurtMng.GetInstance().m_shenqi_suipian_has_pursed_index_map;


        for(var ff=1;ff<=4;ff++)
        {
          
            var ff_ndoe  =  cc.find("panel/shengqi/com/"+ff,this.node);
           
            var ff_yishoujing_node = cc.find("btn/yishoujing",ff_ndoe)
             var ff_need_c_node = cc.find("need/c",ff_ndoe)
      
          
             
             if(ff == 2 || ff== 3)
             {
                var ff_icon_node = cc.find("btn/suipian/icon",ff_ndoe)
                var ff_suipian_node = cc.find("btn/suipian",ff_ndoe)

                var ff_heorid = shenqi_suipian_heroid_list[ff-2];
              
                var ff_name_node = cc.find("name",ff_ndoe)
                ff_name_node.getComponent(cc.Label).string = yiyiHurtMng.GetInstance().Get_HeroID_Name(ff_heorid);
    

                if(shenqi_suipian_has_pursed_index_map.hasKey(ff))
                {
                    ff_yishoujing_node.active = true;
                    ff_suipian_node.active = false;
                    
                }
                else{
                    ff_yishoujing_node.active = false;
                    ff_suipian_node.active = true;
      
                    BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("yiyiHurt",ff_icon_node,
                    "people/"+ff_heorid,{width:45,height:45})
    
                }
             }
             else{


                if(shenqi_suipian_has_pursed_index_map.hasKey(ff))
                {
                    ff_yishoujing_node.active = true;

                    if(ff== 4)
                    {
                        ff_need_c_node.getComponent(cc.Label).string = "1/1"
                    }
                     
                }
                else{
                    ff_yishoujing_node.active = false;
                    if(ff== 4)
                    {
                        ff_need_c_node.getComponent(cc.Label).string = "0/1"
                    }
                }

             }
          
             

           
            
            
        }






        




        var shengqi_com_node = cc.find("panel/shengqi/com",this.node)
        var shengqi_lock_node = cc.find("panel/shengqi/lock",this.node)
      
        if(imainenerindex >= 30)
        {
            shengqi_com_node.active = true;
            shengqi_lock_node.active = false;

        }
        else{
            shengqi_com_node.active = false;
            shengqi_lock_node.active = true;

        }



        var kabao_com_node = cc.find("panel/kabao/com",this.node)
        var kabao_lock_node = cc.find("panel/kabao/lock",this.node)
      
        if(imainenerindex >= 20)
        {
            kabao_com_node.active = true;
            kabao_lock_node.active = false;

        }
        else{
            kabao_com_node.active = false;
            kabao_lock_node.active = true;

        }

 




    }
    Real_Goumai_Shuijing()
    {

        yiyiHurtMng.GetInstance().Change_Zuanshi(100);
        this.Refresh_Info();

        ComFunc.Open_Get_Daoju_Award_Dlg(this.node,
            [
                {
                    "t":42,
                    "c":100
                }
            ],1);


    }
    OnBtnGoumaiShuijing()
    {
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,()=>{},
            "一亿视频购买水晶",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }
            self.Real_Goumai_Shuijing();
 
        })
    }
    Real_Goumai_Kapai(iindex)
    {
        var show_kabao_heroid_list = yiyiHurtMng.GetInstance().m_last_show_kabao_heroid_list;
        var show_heroid = show_kabao_heroid_list[iindex-1];

        var demage_addc = yiyiHurtMng.GetInstance().Get_HeroID_Kabao_Pingji_Add_Attr_Value(show_heroid,iindex);
        yiyiHurtMng.GetInstance().m_cur_show_kabao_has_pursed_index_map.putData(iindex,1)
       // yiyiHurtMng.GetInstance().Add_HeroID_Attr(show_heroid,demage_addc);

        this.Refresh_Info();
       // BaseUIUtils.ShowTipTxtDlg("购买成功",this.node)
          

       this.node.destroy();
       if(this.m_cb)
       {
            this.m_cb(1,iindex,show_heroid,demage_addc)
       }
    }
    Real_Goumai_Second_Kapai(iindex)
    {
        var icount = 3;

        var second_kabao_pai_list=  yiyiHurtMng.GetInstance().Get_Second_Kabao_Out_Pai_List(icount);
        yiyiHurtMng.GetInstance().m_cur_show_second_kabao_has_pursed_index_map.putData(iindex,1)
    

        /*
        for(var tt=0;tt<second_kabao_pai_list.length;tt++)
        {
            var tt_heroid = second_kabao_pai_list[tt];
            var demage_addc = yiyiHurtMng.GetInstance().Get_HeroID_Kabao_Pingji_Add_Attr_Value(tt_heroid,iindex);
            yiyiHurtMng.GetInstance().Add_HeroID_Attr(tt_heroid,demage_addc);

        }
        */

        this.node.destroy();
        if(this.m_cb)
        {
             this.m_cb(2,iindex,second_kabao_pai_list)
        }
    }
    Show_Shuijing_Buzu()
    {
        var self = this;
        var pnode = cc.instantiate(this.yiyi_shuijing_buzu);
        var yiyi_shuijing_buzu = pnode.getComponent("yiyi_shuijing_buzu");
        yiyi_shuijing_buzu.SetInitData(
            {

                cb:()=>
                {
                    self.Refresh_Info();
                }
            }
        )
        this.node.addChild(pnode,20)
    }
    OnBtnKaBao(iindex)
    {
        var cur_show_second_kabao_has_pursed_index_map = yiyiHurtMng.GetInstance().m_cur_show_second_kabao_has_pursed_index_map;
        if(cur_show_second_kabao_has_pursed_index_map.hasKey(iindex))
        {
            return;
        }
        var self = this;
        if(iindex == 4)
        {
            if(yiyiHurtMng.GetInstance().m_i_zuanshi < 200)
            {

                this.Show_Shuijing_Buzu();
                return;
            }
            yiyiHurtMng.GetInstance().Change_Zuanshi(-200);
            this.Real_Goumai_Second_Kapai(iindex);
            
 
        }
        else{

            var ineedm = 800;
            if(iindex == 2)
            {
                ineedm = 2200;
            }
            if(iindex == 3)
            {
                ineedm = 8800;
            }


            if(yiyiHurtMng.GetInstance().m_i_money < ineedm)
            {
                BaseUIUtils.ShowTipTxtDlg("金币不足",this.node)
                return;
            }
            yiyiHurtMng.GetInstance().Change_Money(-1*ineedm);
            this.Real_Goumai_Second_Kapai(iindex);
        }

    }
    Real_Goumai_Shenqi(iindex)
    {
        var shenqi_id_list = [];
        var shenqi_suipian_heroid_list = yiyiHurtMng.GetInstance().m_shenqi_suipian_heroid_list;
        yiyiHurtMng.GetInstance().m_shenqi_suipian_has_pursed_index_map.putData(iindex,1);

        if(iindex >= 2 && iindex <= 3)
        {
            var get_heroid = shenqi_suipian_heroid_list[iindex-2];


            for(var tt=0;tt<3;tt++)
            {
                shenqi_id_list.push(get_heroid);
            }

        }else if(iindex == 4)
        {
            shenqi_id_list = yiyiHurtMng.GetInstance().Get_Shenqi_Kabao_Out_Heroid_List(5)
        }
  
        yiyiHurtMng.GetInstance().Add_Shenqi_Suipian_List(shenqi_id_list);

        var self = this;
        var pnode = cc.instantiate(this.show_get_hero_shenqi_suipian_dlg);
        var show_get_hero_shenqi_suipian_dlg=  pnode.getComponent("show_get_hero_shenqi_suipian_dlg");

        show_get_hero_shenqi_suipian_dlg.SetAward(shenqi_id_list,1)
        this.node.addChild(pnode,40)


        this.Refresh_Info();
    }
    OnBtnShenqiGoumai(iindex)
    {
        var shenqi_suipian_has_pursed_index_map = yiyiHurtMng.GetInstance().m_shenqi_suipian_has_pursed_index_map;
        if(shenqi_suipian_has_pursed_index_map.hasKey(iindex))
        {
            return;
        }

        var self = this;
        if(iindex == 4)
        {
            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
                this.node,()=>{},
                "一亿视频购买神器",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
                self.Real_Goumai_Shenqi(iindex);
     
            })
        }
        else{

            var ineedm = 60;
           


            if(yiyiHurtMng.GetInstance().m_i_zuanshi < ineedm)
            {
                this.Show_Shuijing_Buzu();
                return;
            }
            yiyiHurtMng.GetInstance().Change_Zuanshi(-1*ineedm);
            this.Real_Goumai_Shenqi(iindex);
        }
    }
    OnBtnKapai(iindex)
    {
        var cur_show_kabao_has_pursed_index_map = yiyiHurtMng.GetInstance().m_cur_show_kabao_has_pursed_index_map;
        if(cur_show_kabao_has_pursed_index_map.hasKey(iindex))
        {
            return;
        }
        var self = this;
        if(iindex == 4)
        {
            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
                this.node,()=>{},
                "一亿视频购买卡牌",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
                self.Real_Goumai_Kapai(iindex);
     
            })
        }
        else{

            var ineedm = 300;
            if(iindex == 2)
            {
                ineedm = 800;
            }
            if(iindex == 3)
            {
                ineedm = 3000;
            }


            if(yiyiHurtMng.GetInstance().m_i_money < ineedm)
            {
                BaseUIUtils.ShowTipTxtDlg("金币不足",this.node)
                return;
            }
            yiyiHurtMng.GetInstance().Change_Money(-1*ineedm);
            this.Real_Goumai_Kapai(iindex);
        }

    }
}
