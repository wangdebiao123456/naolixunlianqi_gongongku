import MiddleGamePlatformAction from "../../PlatForm/MiddleGamePlatformAction";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class yiy_tiaozhan_fail_dlg extends cc.Component {

    
    m_cb = null;
    
    
    onLoad () 
    {
        var exitbtn = cc.find("panel/exitbtn",this.node)
        exitbtn.on("click",this.OnBtnExit.bind(this))
        
        var quedingbtn = cc.find("panel/quedingbtn",this.node)
        quedingbtn.on("click",this.OnBtnExit.bind(this))
        
 
    }
    SetInitData(pinfo)
    {
        this.m_cb = pinfo.cb;
 
     
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(222,true);
        MiddleGamePlatformAction.GetInstance().Show_Refuhuo_Banners(true);

    }
    
    OnBtnExit()
    {

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(222,false);
        MiddleGamePlatformAction.GetInstance().Show_Refuhuo_Banners(false);

        MiddleGamePlatformAction.GetInstance().Destroy_Refuhuo_Banners();
    


        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb();
        }

    }
}
