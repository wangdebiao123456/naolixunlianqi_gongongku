import BundleLoadUtils from "../../comfuncs/BundleLoadUtils";
import yiyiHurtMng from "../yiyiHurtMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class yiyi_shenqi_dlg extends cc.Component {

    m_cb = null;
    
    onLoad () {

        var exitbtn = cc.find("panel/exitbtn",this.node)
        exitbtn.on("click",this.OnBtnExit.bind(this))
        
    }
    OnBtnExit()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb();
        }
    }
    
    SetInitData(pinfo)
    {
        this.m_cb = pinfo.cb;

        this.Refresh_Info();
    }
    
    Refresh_Info()
    {

        var heorid_shenqi_count_map = yiyiHurtMng.GetInstance().m_hero_id_shenqi_count_map;
        for(var ff=1;ff<=8;ff++)
        {
            var ff_shenqi_node = cc.find("panel/shenqi/"+ff,this.node)

            var ff_suo_node=  cc.find("suo",ff_shenqi_node);
            var ff_com_node=  cc.find("com",ff_shenqi_node);
            
            if(ff > heorid_shenqi_count_map.size())
            {
                ff_com_node.active  = false;
                ff_suo_node.active = true;
                continue;
            }
            ff_com_node.active  = true;
            ff_suo_node.active = false;

            var ff_heroid = heorid_shenqi_count_map.GetKeyByIndex(ff-1);
            var ff_c = heorid_shenqi_count_map.GetEntryByIndex(ff-1);

            var ff_icon_node = cc.find("icon",ff_com_node);

            BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("yiyiHurt",ff_icon_node,
            "people/"+ff_heroid,{width:60,height:60})


            var ff_shenqi_lv_arr = yiyiHurtMng.GetInstance().Get_HeroId_Shenqi_LV_Info(ff_heroid);

            var ff_cur_lv = ff_shenqi_lv_arr[0]

            var ff_c1_node = cc.find("c1",ff_com_node);
            ff_c1_node.getComponent(cc.Label).string = "等级"+ff_cur_lv;


            var demage_rate = 1 + 0.1*ff_cur_lv

            var ff_demage_label = cc.find("layer/c1",ff_com_node);
            ff_demage_label.getComponent(cc.Label).string =  "x"+ demage_rate.toFixed(1);

            var ff_pro_c_node = cc.find("pro/c",ff_com_node);
            ff_pro_c_node.getComponent(cc.Label).string = ff_shenqi_lv_arr[1]+"/"+ff_shenqi_lv_arr[2];

            var iprogress = ff_shenqi_lv_arr[1]/ff_shenqi_lv_arr[2];
            var ff_pro_bar_node = cc.find("pro/bar",ff_com_node);
         
            ff_pro_bar_node.getComponent(cc.Sprite).fillRange = iprogress;
 
        }
    }

}
