 

const {ccclass, property} = cc._decorator;

@ccclass
export default class first_gk_dlg extends cc.Component {

    
    
    onLoad () 
    {
        

        this.scheduleOnce(this.FD_Exit.bind(this),1.5)
    }


    FD_Exit()
    {
        this.node.destroy();
    }


    
}
