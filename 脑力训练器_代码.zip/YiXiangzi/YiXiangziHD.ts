
export default  class YiXiangziHD 
{
    m_id = 0;
    m_itype = 0;  
    x = 0;
    y = 0;

    offsetx = 0;
    offsety = 0;

	constructor() 
    {

    }

    Init(id, infoarr) 
    {
        this.m_id = id;
        this.m_itype = infoarr[0];  
        this.x = infoarr[1];
        this.y = infoarr[2];

         this.offsetx = 0;
         this.offsety = 0;
    }

    ToAarry()
    {
        var arr = [];

        arr[0] = this.m_itype;
        arr[1] = this.x;
        arr[2] = this.y; 

 
        return arr;
    }
    Copy()
    {
        var copyd = new YiXiangziHD();
        copyd.m_id = this.m_id;
        copyd.m_itype = this.m_itype;
     
        copyd.x = this.x;
        copyd.y = this.y;


        return copyd;

    }

    Get_Add_Move_Step_Center_PT(ifx)
    {
        var moveto_center_pt = this.Get_Move_To_Center_Pt(ifx);
    
   
        return moveto_center_pt;
    }
    GetID()
    {
        return this.m_id;
    }
    SetOffetPtXY(x,y)
    {
        this.offsetx = x;
        this.offsety = y;
    }
    GetMarginX()
    {
        return 100;
    }
    GetMarginY()
    {
        return 95;
    }
    GetGridCenterPt(x,y)
    {
        var imarginx = this.GetMarginX();
        var imarginy = this.GetMarginY();
      

        var yypt = y*imarginy   - 497;
        var centex =  x*imarginx;
        var centey = yypt  ;
 

        return {x:centex,y:centey};
    }

    Get_Orignal_Center_Pt()
    {
        var gridpt = this. GetGridCenterPt(this.x,this.y);
        var centex = gridpt.x  ;
        var centey = gridpt.y  ;
 
        return   {x:centex,y:centey};
    }
    GetCenterPt()
    {
        var gridpt = this. GetGridCenterPt(this.x,this.y);
        var centex = gridpt.x + this.offsetx;
        var centey = gridpt.y + this.offsety;
 
        return   {x:centex,y:centey};
 
    }
    GetFKKuangdu()
    {
        return 90;
    }

    Get_Move_To_Center_Pt(fx)
    {

        var newx = this.x;
        var newy=  this.y;

        if(fx == 1)
        {
            newy += 1;
        } 
        
        if(fx == 2)
        {
            newy += -1;
        }

        if(fx == 3)
        {
            newx += -1;
        }

        if(fx == 4)
        {
            newx += 1;
        }


        var gridpt = this. GetGridCenterPt(newx,newy);
        var centex = gridpt.x  ;
        var centey = gridpt.y ;
 
        return   {x:centex,y:centey};

 
    }
    Get_Move_To_Rect( fx)
    {
        var moveto_center_pt = this.Get_Move_To_Center_Pt(fx);
        var ikuadu = this.GetFKKuangdu();

        var leftx=  moveto_center_pt.x - ikuadu/2;
        var lefty = moveto_center_pt.y - ikuadu/2;

        

        return new cc.Rect(leftx,lefty,ikuadu,ikuadu);
    }


    GetRect()
    {
        var centerpt = this.GetCenterPt();
        var ikuadu = this.GetFKKuangdu();

        var leftx=  centerpt.x - ikuadu/2;
        var lefty = centerpt.y - ikuadu/2;

        

        return new cc.Rect(leftx,lefty,ikuadu,ikuadu);
      
    }
    MoveStep(ineedaddx,ineedaddy)
    {
        this.x += ineedaddx;
        this.y += ineedaddy;
    }
    GetImageFrameIndex()
    {
        return this.m_itype;
    }
}