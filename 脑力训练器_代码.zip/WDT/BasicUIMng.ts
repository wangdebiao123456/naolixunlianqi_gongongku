export default class BasicUIMng 
{
    constructor()
    {

    }
   static ShowNodePic(pnode,sfilename,size = null)
    {
        cc.resources.load(sfilename, cc.SpriteFrame, 
            (err, spriteFrame) =>{
                var psrite = pnode.getComponent(cc.Sprite);
    
               psrite.spriteFrame = spriteFrame;

               if(size)
               {
                    pnode.width = size.cx;
                    pnode.height = size.cy;

               }
           });
   
    }


}