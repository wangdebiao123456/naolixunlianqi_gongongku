export default class MyLabel extends cc.Node
{
    constructor(sfilename)
    {
        super();

    }
}