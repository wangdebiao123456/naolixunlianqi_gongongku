import MyLocalStorge from "./MyLocalStorge";
import WMap from "./WMap";

export class Utils
{
    static rectContainsPoint(rc,pt)
    {
        if(rc.x < pt.x &&  (rc.x + rc.width > pt.x))
        {
            if(rc.y < pt.y &&  (rc.y + rc.height > pt.y) )
            {
                return true;
            }
        }
        return false;
    }
    static  ReadSysLocalStorgeStr(name){

        var str = MyLocalStorge.getItem(name);
        if(str)
        {
            return str;
        }
        return "";
    }
    
  
    static  NodeWorldPos(pnode,srcpt?){
        let parentnode=  pnode.parent;
        let worldpt = parentnode.convertToWorldSpaceAR(srcpt || pnode.getPosition());
        let newx = worldpt.x - 360;
        let newy = worldpt.y - 640;
        return  new cc.Vec2(newx,newy);
    }
    static Rand_Digit_List(show_digit_arr)
    {
        var ilen = show_digit_arr.length;

        for(var ff=0;ff<ilen;ff++)
        {
            var ff_rand1 = Math.floor(ilen*Math.random());
            var ff_c1 = show_digit_arr[ff];
            var ff_c2 = show_digit_arr[ff_rand1];

            show_digit_arr[ff] = ff_c2;
            show_digit_arr[ff_rand1] = ff_c1;
            
        }

        return show_digit_arr;
    }
    
    static Check_Read_Number(num)
    {
        if(!num)
        {
            return 0;
        }
        var imun = Number(num);
        if(isNaN(imun))
        {
            return 0;
        }



        return  imun;
    }
    public static randomArray(arr: number[]) {
        let newArr = []
        let count = arr.length
        for (let i = 0; i < count; i++) {
            let rnd = Math.floor(Math.random() * arr.length)
            newArr.push(arr[rnd])
            arr.splice(rnd, 1)
        }
        return newArr
    }
    static localConvertWorldPointAR(node) {
        if (node) {
            return node.convertToWorldSpaceAR(cc.v2(0, 0));
        } return null;
    }
    static worldConvertLocalPointAR(node, worldPoint) {
        if (node) {
            return node.convertToNodeSpaceAR(worldPoint);
        }
        return null;
    }
    static convetOtherNodeSpaceAR(node, targetNode): cc.Vec2 {
        if (!node || !targetNode) {
            return null;
        }
        let worldPoint = Utils.localConvertWorldPointAR(node);
        return Utils.worldConvertLocalPointAR(targetNode, worldPoint);
    }
    public static IsElementInArray(element: any, arr) {
        for (let i = arr.length - 1; i >= 0; i--) {
            if (arr[i] == element) {
              
                return true;
            }
        }

        return false;
    }
    static Get_Saved_GUID()
    {
       
        var strguid = MyLocalStorge.getItem("shaonaomukuai_localguid");
        if(!strguid)
        {
            var newguid=  MyLocalStorge.newCreateGuid();
            MyLocalStorge.setItem("shaonaomukuai_localguid",newguid);
            strguid = newguid;

        }  
        return strguid;
        
    }
    public static removeElementFromArray(element: any, arr) {
        for (let i = arr.length - 1; i >= 0; i--) {
            if (arr[i] == element) {
                arr.splice(i, 1)
                break
            }
        }
    }

    static setSpriteFrame(sp: cc.Sprite, path: string, bundle: string = 'resources', callback = null): void {
        let loader = cc.assetManager.getBundle(bundle)
        loader.load(path, cc.Texture2D, (error, assets: cc.Texture2D) => {
            if (error) {
                cc.log('error', path)
                return
            }
            sp.spriteFrame =new cc.SpriteFrame(assets)
            callback && callback()
        })
    }
    static onLoadTxtTipOk(node,str,pos,idisplaytime){
        let txt = node.getChildByName("txt_info").getComponent(cc.Label);
        txt.string = str;
        node.setPosition(pos.x,pos.y);
        node.runAction(cc.sequence(cc.moveBy(0.2,0,-60),cc.delayTime(idisplaytime),cc.moveBy(0.2,0,60),cc.callFunc(function(){ node.destroy(); })));
    }
    static setGray(icon: cc.Sprite, isGray: boolean) {
        if (isGray) {
            icon.setMaterial(0, cc.Material.getBuiltinMaterial('2d-gray-sprite'));
        } else {
            icon.setMaterial(0, cc.Material.getBuiltinMaterial('2d-sprite'));
        }
    }
    static ShowTipsTxt(str,pnode,pos=cc.v2(0,640+30),idisplaytime = 3){
        let self = this;
        let node = pnode ;
        cc.resources.load("preab/txttipui", function (err, prefab) {
            if (err) { return cc.error(err); }
            let ui = cc.instantiate(prefab);
            node.addChild(ui);
            Utils.onLoadTxtTipOk(ui,str,pos,idisplaytime);
        });
    }

    static Format_Save_OBJ_Map( daoju_type_leftcount_map:WMap)
    {
        var save_arr = [];

        for(var ff=0;ff<daoju_type_leftcount_map.size();ff++)
        {
            var ff_t = daoju_type_leftcount_map.GetKeyByIndex(ff);
            var ff_c = daoju_type_leftcount_map.GetEntryByIndex(ff);

            save_arr.push(
                {
                    "k":ff_t,
                    "e":ff_c
                }
            )
        }

        return save_arr;
    }
    static Serize_Saved_OBJ_Map(savearr)
    {
        if(!savearr)
        {
            return new  WMap();
        }
        if(savearr.length ==0  || ! savearr.length)
        {
            return new  WMap();
        }

        var pmap=  new WMap();
        for(var ff=0;ff<savearr.length;ff++)
        {
            var ff_info  =savearr[ff];
            var ff_k = ff_info.k;
            var ff_e = ff_info.e;

            if(ff_k == undefined)
            {
                continue;
            }

            pmap.putData(ff_k,ff_e);
        }

        return pmap;
    }
}