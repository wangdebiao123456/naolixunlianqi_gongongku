 
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import MyHttpPostInfoUtil from "../comfuncs/MyHttpPostInfoUtil";
import PlatFormMng from "../PlatForm/PlatFormMng";
import PlatFormType from "../PlatForm/PlatFormType";  
import WMap from "../WDT/WMap"; 

export default class LeoGameInfoMng
{
    public static  m_ins:LeoGameInfoMng = null;
    static shieldVersion = '1.1'


    public static GetIns()
    {
        if(LeoGameInfoMng.m_ins == null)
        {
            LeoGameInfoMng.m_ins  =  new LeoGameInfoMng();
        }

        return LeoGameInfoMng.m_ins;
    }

    m_yaoqing_info_posted = 0;
    m_last_post_code_openid_tick = 0;
    m_wx_openid = "";

    m_leo_login_data = null;
    m_leo_login_token = "";

    m_denglu_shangbaoed = 0;
    m_last_post_denglu_tick = 0;

    timeStamp_hide = 0;

    initTime = 0;
    m_enter_from_other_user_openid = "";

    m_last_post_yaoqing_tick = 0;


    m_b_in_share_msg = 0;

    m_wx_show_hide_event_lisnter_map = new WMap();

    m_last_error_response=  "";

    constructor()
    {
        this.resetInitTime();
        this.Reg_WX_Hide_Show();
 

       
    }
    resetInitTime(){
        this.initTime = Date.now();
    }

    Add_WX_Show_Hide_Event_Lisnter(lisnter)
    {

        this.m_wx_show_hide_event_lisnter_map.putData(lisnter,1);
    }
    Remove_WX_Show_Hide_Event_Lisnter(lisnter)
    {

        this.m_wx_show_hide_event_lisnter_map.RemoveKey(lisnter);
    }

    Check_Tongbu_WX_ID()
    {
        this.m_wx_openid = PlatFormMng.GetInstance().Get_Saved_GUID();
        
    }
    Notify_WX_Show_Hide_Event(bshow)
    {
        var copymap = this.m_wx_show_hide_event_lisnter_map.Copy();

        for(var ff=0;ff<copymap.size();ff++)
        {
            var ff_lisnetr = copymap.GetKeyByIndex(ff);
            ff_lisnetr.Notify_WX_Show_Hide_Event(bshow)
        }
    }

    On_WX_Hide_Event()
    {
        this.timeStamp_hide = new Date().getTime();
        this.Send_OnLine_Time_On_Hide();

        this.Notify_WX_Show_Hide_Event(0)
    }
    On_WX_Show_Event(res)
    {
        if (this.timeStamp_hide) {
            this.resetInitTime();
        }

        
        this.Notify_WX_Show_Hide_Event(1)
    }

    public get_onlineTime(): number {
        return Math.round((Date.now() - this.initTime) * 0.001);
    }
    Send_OnLine_Time_On_Hide()
    {
        var online_time = this.get_onlineTime();
        if(online_time < 1)
        {
            return;
        }

       



        let head = {
            'X-LEYO-TOKEN': this.m_leo_login_token,
            "X-LEYO-APP-ID":this.Get_Leyo_AppId(),
            "X-LEYO-VERSION":LeoGameInfoMng.shieldVersion,
            'User-Agent': 'Apifox/1.0.0 (https://apifox.com)',
            'Content-Type': 'application/json'
        }

        var raw = JSON.stringify({
            "uid": this.m_wx_openid  ,
            "length": online_time
         });

         
      /*
         var self = this;
        MHttp.sendMessageHead("https://data.3yoqu.com/api/v1.index/online", raw,head, (userData)=>
        {
            console.log("发送在线时长 online_time="+online_time+":status="+userData.status +",message="+userData.message)

            if (userData.status == 200) {
                console.log('发送在线时长成功上报---成功');

              
            }
            else {
                console.log('发送在线时长---失败:'+userData.status )
            }
        })  
        */

    }




    Reg_WX_Hide_Show()
    {
        if(PlatFormMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }

        var self=  this;
        wx.onHide(()=>
        {
            self.On_WX_Hide_Event();
        });

        wx.onShow( (res)=>
        {
            self.On_WX_Show_Event(res);
        });

        wx.showShareMenu() 
    }
    Init_Hide_Func()
    {
       
    }
    Get_Leyo_AppId()
    {
        return "";
    }

    Post_Denglu_Info()
    {
        if(PlatFormMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
        if(Date.now() - this.m_last_post_denglu_tick < 1000*10)
        {
            return;
        }
        this.m_last_post_denglu_tick = Date.now();


        let head = {
            "X-LEYO-APP-ID":this.Get_Leyo_AppId(),
            "X-LEYO-VERSION":LeoGameInfoMng.shieldVersion,
            'User-Agent': 'Apifox/1.0.0 (https://apifox.com)',
            'Content-Type': 'application/json'
        }

        var raw = JSON.stringify({
            "uid": this.m_wx_openid 
           
         });

         /*
      
         var self = this;
        MHttp.sendMessageHead("https://data.3yoqu.com/api/v1.index/login", raw,head, (userData)=>
        {
            console.log("登陆:status="+userData.status +",message="+userData.message)

            if (userData.status == 200) {
                console.log('乐游login---成功:'+ JSON.stringify(userData.data) );

                self.m_denglu_shangbaoed = 1;
                self.m_leo_login_data = userData.data;
                self.m_leo_login_token=  userData.data.token;
            }
            else {
                console.log('乐游登陆---失败')
            }
        })  ;


      
        */

      
    }
    Post_User_Login_From_Yaoqing(self_openid, from_other_user_openid)
    {
        if(!self_openid)
        {
            return;
        }

        if(!from_other_user_openid)
        {
            return;
        }
        if(Date.now() - this.m_last_post_yaoqing_tick < 3000)
        {

            return;
        }
 

       this.m_last_post_yaoqing_tick = Date.now();
        

      
        console.log("Post_User_Login_From_Yaoqing  from_other_user_openid="+from_other_user_openid+",self_openid="+self_openid)
       
        var self = this;
        var obj =
        {
            to_uid: self_openid,
            from_uid:from_other_user_openid,
            wxappid:"wxab871df21a3d8078"
         };


        var str = JSON.stringify(obj);
        MyHttpPostInfoUtil.POSTData_Json( 'https://dianjitaitan.zfgame123.com/recv_yaoqing_haoyou_info.aspx',str,
        (bsuc,response)=>
        {
            self.m_yaoqing_info_posted = 1;
      
            self.m_last_error_response = "bsuc:"+bsuc+",response = "+response;
            

        });
        



          
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(2, "进入大厅", 1,
        "大厅界面", 0, "", 0, "",(err,res)=>
        {
            self.m_last_error_response = "日志:"+res;
           
        });
       
    }
    On_Readed_WX_OpenId(read_openid)
    {

        this.m_wx_openid = read_openid;
        console.log("On_Readed_WX_OpenId openid:"+read_openid);

        if(this.m_enter_from_other_user_openid && this.m_wx_openid)
        {
            this.Post_User_Login_From_Yaoqing(this.m_wx_openid,this.m_enter_from_other_user_openid);
        }

        if(this.m_denglu_shangbaoed)
        {
            return;
        }


        this.Post_Denglu_Info();
    }
    Post_Server_Req_OpenID_Info(scode,callback)
    {

     
        var obj =
        {
            code: scode,
            appid:"wxab871df21a3d8078"
          };


          var self = this;

       
        var str = JSON.stringify(obj);
        MyHttpPostInfoUtil.POSTData( 'https://dianjitaitan.zfgame123.com/Get_WX_Login_OpenID_Info.aspx',str,
        (bsuc,response)=>
        {
            console.log("Get_WX_Login_OpenID_Info response="+response);
        
            if(!bsuc)
            {
                console.log("获取openid错误:");
                callback(false);
                return;
            }

            var resobj = JSON.parse(response);

            var openid = resobj.openid;

            if(!openid)
            {
                callback(false);
                return;
            }
            var unionid = resobj.unionid;
            if(!unionid)
            {
                unionid = "";
            }
            console.log("获取openid:"+openid);
            
         
            callback(true,openid);

        });
       
      
        
    }
    Check_Read_Code_Wx(scode)
    {
        let self = this;
        this.Post_Server_Req_OpenID_Info(scode,(bsuc,read_openid)=>
        {
            if(bsuc)
            {
                self.On_Readed_WX_OpenId(read_openid);
            }else{
                console.log('获取openid---失败')
            }
        })
        /*
    
        let head = {
            "X-LEYO-APP-ID":this.Get_Leyo_AppId(),
            "X-LEYO-VERSION":LeoGameInfoMng.shieldVersion,
            'User-Agent': 'Apifox/1.0.0 (https://apifox.com)',
            'Content-Type': 'application/json'
        }

        var raw = JSON.stringify({
            "code": scode
           
         });

         
        MHttp.sendMessageHead("https://data.3yoqu.com/api/v1.index/get_openid", raw,head, (userData)=>
        {
            console.log("获取openid:status="+userData.status +",message="+userData.message)

            if (userData.status == 200) {
                console.log('乐游获取openid---成功:'+userData.data.openid);

                var read_openid = userData.data.openid;
                self.On_Readed_WX_OpenId(read_openid);
             
            }
            else {
                console.log('乐游获取openid---失败')
            }
        })  
        */


    }

    Check_WX_Load_From_Openid()
    {
        if(PlatFormMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
        this.Check_Tongbu_WX_ID();
       
     
        var langop = wx.getLaunchOptionsSync();
        var l_query = langop.query;

        var l_fromopenid = l_query["fromopenid"];
        if(!l_fromopenid)
        {
            l_fromopenid = "";
        }


        console.log("获得分享参数 l_fromopenid="+l_fromopenid);

       // var wx_ppid=  "wxab871df21a3d8078";


        this.m_enter_from_other_user_openid = l_fromopenid;

        if(this.m_wx_openid && l_fromopenid)
        {
            this.Post_User_Login_From_Yaoqing(this.m_wx_openid,l_fromopenid)
        }
       

    }
    Check_Post_Read_OpenId()
    {
        if(PlatFormMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }

        if(Date.now() - this.m_last_post_code_openid_tick < 10*1000)
        {
            return;
        }

        if(this.m_wx_openid && this.m_wx_openid.length > 3)
        {
            console.log('已经存在wxopenid:' +this.m_wx_openid);
            this.On_Readed_WX_OpenId(this.m_wx_openid)
            return;
        }

        this.m_last_post_code_openid_tick = Date.now();

        var self = this;


        wx.login({
            success (res) {
              if (res.code) {
                //发起网络请求
                 self.Check_Read_Code_Wx(res.code);
              } else {
                console.log('登录失败！' + res.errMsg)
              }
            }
          })


       

    }

    OnVideoSuccessEnd()
    {
        if(PlatFormMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
       
    }

 
}