  
import WMap from "./WMap";
import MyLocalStorge from "../WDT/MyLocalStorge";
import BundleLoadUtils from "../comfuncs/BundleLoadUtils";


var sound_bkmusicname = "bk_music_shaonaomukuai_volum";
var sound_bkeffectcname = "bk_sound_shaonaomukuai_volum";


 
//工具类，保存音效音乐音量，播放音乐音效等
export default class BackGroundSoundUtils 
{
    static _instance:BackGroundSoundUtils = null;
    m_sound_kai = true;
       
    m_bk_music_sound_volum = 0.1;
    m_effect_sound_volum = 0.5;
    m_b_record_or_playing_user_sound = false;
    m_bkMusics = null;


    m_filename_audio_map = new WMap();

    static GetInstance() 
    {
        if (!BackGroundSoundUtils._instance) {
            // doSomething
            BackGroundSoundUtils._instance = new BackGroundSoundUtils();
             
        }
        return BackGroundSoundUtils._instance;
    }

    constructor() {

        this.m_sound_kai = true;
       
        this.m_bk_music_sound_volum = 0.1;
        this.m_effect_sound_volum = 0.5;
        this.InitMusicSoundInfo();


        this.m_b_record_or_playing_user_sound = false;
    }
 

    // 初始读取声音保存的值
    InitMusicSoundInfo() {
        const music = MyLocalStorge.getItem(sound_bkmusicname);
        if (music != null && music != undefined && music!= "") this.m_bk_music_sound_volum = Number(music);
        else {
            this.m_bk_music_sound_volum = 0.5;
            this.saveMusic();
        }
        const sound = MyLocalStorge.getItem(sound_bkeffectcname);
        if (sound != null && sound != undefined && sound != "") this.m_effect_sound_volum = Number(sound);
        else {
            this.m_effect_sound_volum = 0.5;
            this.saveSound();
        } 
    }

    Play_Music(strfilename,iv=1)  
    {
        this.playBackgroundMusic(strfilename,iv) 
    }
    playBackgroundMusic(strfilename,iv=1)    //循环播放
    {
        var endfix = strfilename.substr(strfilename.length - 4, 4);
        if (endfix == ".mp3") {
            strfilename = strfilename.substr(0, strfilename.length - 4);
        }

        let self = this;
        /*
        cc.resources.load(strfilename, cc.AudioClip, function (err, audioClip) {
            if (!err) {
                if (self.m_bkMusics !== undefined) {
                    cc.audioEngine.stop(self.m_bkMusics);
                    self.m_bkMusics = undefined;
                }
                //cc.log(audioClip);
                self.m_bkMusics = cc.audioEngine.play(audioClip as cc.AudioClip, true, self.m_bk_music_sound_volum);
            }
        });
        */

        BundleLoadUtils.GetInstance().CheckLoadedBundle("music",(err,bundle)=>
        {
            if(err)
            {
                return;
            }

            bundle.load(strfilename, cc.AudioClip, (err, audioClip)=>
            {
                if (!err) {
                    if (self.m_bkMusics !== undefined) {
                        cc.audioEngine.stop(self.m_bkMusics);
                        self.m_bkMusics = undefined;
                    }
                    //cc.log(audioClip);
                    self.m_bkMusics = cc.audioEngine.play(audioClip as cc.AudioClip, true, self.m_bk_music_sound_volum*iv);
                }
            });

        });

    }

    Play_Effect(str,ivlummul = 1) {
        this.Play_FullName_Effect(str,ivlummul  );
    }


    PlayTapButtonEffect()
    {
        this.Play_Effect("Sounds/TapButton1") ;
    }

    Play_FullName_Effect(str,ivlummul = 1)    //播放一遍
    {
        if(this.m_b_record_or_playing_user_sound)
        {
            return;
        }

        var strfilename = str;
        var endfix = strfilename.substr(strfilename.length - 4, 4);
        if (endfix == ".mp3") {
            strfilename = strfilename.substr(0, strfilename.length - 4);
        }

        if (this.m_sound_kai) 
        {
            


            if(this.m_filename_audio_map.hasKey(strfilename))
            {
                var audip = this.m_filename_audio_map.getData(strfilename);
                cc.audioEngine.play(audip as cc.AudioClip, false, BackGroundSoundUtils.GetInstance().m_effect_sound_volum*ivlummul);
            }
            else{
                var self = this;

                BundleLoadUtils.GetInstance().CheckLoadedBundle("music",(err,bundle)=>
                {
                    if(err)
                    {
                        return;
                    }
    
                    bundle.load(strfilename, cc.AudioClip, (err, audioClip)=>
                    {
                        if (!err) {

                            self.m_filename_audio_map.putData(strfilename,audioClip);
                            cc.audioEngine.play(audioClip as cc.AudioClip, false, BackGroundSoundUtils.GetInstance().m_effect_sound_volum*ivlummul);

                        }
                    });
    
                });
    

            }

        

        }
    }

    Play_Effect_Audio_Clip(music_audio_clip)
    {
        if(this.m_b_record_or_playing_user_sound)
        {
            return;
        }
        cc.audioEngine.play(music_audio_clip, false, BackGroundSoundUtils.GetInstance().m_effect_sound_volum);
    }

    Stop_Background_Music() {
        let self = this;
        if (self.m_bkMusics !== undefined) {
            cc.audioEngine.stop(self.m_bkMusics);
            self.m_bkMusics = undefined;
        }
    }
    
    ResumeBkMusic() {
        let self = this;
        if (self.m_bkMusics !== undefined) {
            cc.audioEngine.resume(self.m_bkMusics);
        }
    }

    Pause_Background_Music() {
        let self = this;
        if (self.m_bkMusics !== undefined) {
            cc.audioEngine.pause(self.m_bkMusics);
        }
    }

    ResumeBkMusic_On_Record_Playing_Other_User_Sound_Finish()
    {
        this.m_b_record_or_playing_user_sound = false;
        this.ResumeBkMusic();
      
    }

    StopAllOtherSound_On_Record_Playing_Other_User_Sound()
    {
        this.m_b_record_or_playing_user_sound = true;
        this.Pause_Background_Music();
        
    }


    PlayButtonSound() {
        this.Play_FullName_Effect('anniu.mp3');
    }

    

    playSound(str) {
        this.Play_FullName_Effect(str);
    }

    PlaySoundEffect(str)
    {
        this.Play_Effect("Sounds/"+str);

    }

    PlaySoundEffectMulVoum(str,ivlummul)
    {
        this.Play_Effect("Sounds/"+str,ivlummul);

    }
    playGameSound(str) {
        //var strallfilename = 'Games/shisanshui/audio/' + str; 
        this.Play_FullName_Effect(str);

    }

    SetBackGroundMusicVolum(ivolum) {
        this.m_bk_music_sound_volum = ivolum;
        if (this.m_bkMusics !== undefined) cc.audioEngine.setVolume(this.m_bkMusics, this.m_bk_music_sound_volum);

        MyLocalStorge.setItem(sound_bkmusicname, ivolum);
    }

    SetEffectSoundVolum(ivolum) {
        this.m_effect_sound_volum = ivolum;
        
        MyLocalStorge.setItem(sound_bkeffectcname, ivolum);
    }

    GetEffectSoundVolum() {
        return this.m_effect_sound_volum;
    }

    GetBackGroundMusicVolum() {
        return this.m_bk_music_sound_volum;
    }

    // 保存音乐的声音
    saveMusic() {
        MyLocalStorge.setItem(sound_bkmusicname, this.m_bk_music_sound_volum+"");
    }

    // 保存音效的声音
    saveSound() {
        MyLocalStorge.setItem(sound_bkeffectcname, this.m_effect_sound_volum+"");
    }
    
    public static getServerTime() {
        return new Date().getTime() ;
    }


    private lastplaysfxtime = {};
    Play_Effect_Check_Delay(url: string,playDelay:number=20) {

        if (this.lastplaysfxtime[url]) {
            if (BackGroundSoundUtils.getServerTime() - this.lastplaysfxtime[url] < playDelay) {
                // console.log(url,"跳过")
                return;
            }
        }

        this.lastplaysfxtime[url] = BackGroundSoundUtils.getServerTime();

        this.Play_Effect(url);


    }

    Play_Click_Btn_Effect()
    {
        this.Play_Effect("huaduoppingping/btn_rouhe");
    }
}

