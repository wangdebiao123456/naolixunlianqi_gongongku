import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";

  
 
const {ccclass, property} = cc._decorator;

@ccclass
export default class tankuang extends cc.Component {

  

    @property(cc.Node)
    exitbtn:cc.Node = null;
   
    @property(cc.Node)
    exitbtn2:cc.Node = null;
    

    m_pingbi_close_event = 0;

    m_plinster = null;

    m_b_closed = 0;

    m_pingbi_start_donghua = 0;
    
    onLoad () 
    {

        const node = this.node;
   
        const panel = node.getChildByName('panel');


 


        if(!this.m_pingbi_start_donghua)
        {
   
            node.on('active-in-hierarchy-changed', () => {
                if (node.active === true) {
                    panel.scale = 0.01;
                    const action = cc.scaleTo(0.2, 1);
                    panel.runAction(action);
    
                   
                }
            });
        }
  


        if(this.exitbtn)
        {
            this.exitbtn.on("click",this.OnBtnExit.bind(this))
        }
        
        if(this.exitbtn2)
        {
            this.exitbtn2.on("click",this.OnBtnExit.bind(this))
        }

        
    }
    Set_Pingbi_Close_Event(p)
    {
        this.m_pingbi_close_event = p;
    }
    ResetClose_Func(calback)
    {
        this.exitbtn.off("click" )
        this.exitbtn.on("click",calback)
    }

    Set_Pingbi_Start_Donghua(bpingbi)
    {
        this.m_pingbi_start_donghua = bpingbi;

    }

    Set_Close_Lisnter(plinster)
    {

        this.m_plinster = plinster;
    }

    Real_Exit()
    {
        //this.node.destroy();

        if(this.m_plinster)
        {
            this.m_plinster.On_Tankuang_Real_Exit();
        }else{
            this.node.destroy();
        }
    }
    OnBtnExit()
    {
        if(this.m_b_closed)
        {
            return;
        }

         
        if(this.m_pingbi_close_event)
        {
            return;
        }



        this.m_b_closed = 1;

        const node = this.node;
   
        const panel = node.getChildByName('panel');
   
        var self  = this;
        const action = cc.scaleTo(0.15, 0.01);
        const call = cc.callFunc(() => {
            self.Real_Exit();
        });
        const seq = cc.sequence(action,call);
        panel.runAction(seq); 


        BackGroundSoundUtils.GetInstance().Play_Click_Btn_Effect();
    }
}
