import ComFunc from "../comfuncs/ComFunc";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import HMK_GK_Mng from "../huamukuai/HMK_GK_Mng";
import juba_Game_Mng from "../jiubei/mng/juba_Game_Mng";
import Luosi_Game_Mng from "../luosi/Luosi_Game_Mng";
import TiaozhanChang_Mng from "../luosi/TiaozhanChang_Mng";
import GlobalData from "../main/GlobalData";
import paixuGameMng from "../paixu/paixuGameMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import shuziHuaRongDaoLogicMng from "../shuzihuarongdao/shuziHuaRongDaoLogicMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class more_wanfa_dlg extends cc.Component {

    m_itype =  0;
    m_cb=  null;
    
    onLoad () 
    {

        var exitbtn = cc.find("panel/bottommenu/exitbtn",this.node)
        exitbtn.on("click",this.OnBtnExit.bind(this))



        var huamukuai = cc.find("panel/menu/1/huamukuai",this.node)
        huamukuai.on("click",this.OnBtnHuaMuKuai.bind(this))


        var yixiangzi = cc.find("panel/menu/1/yixiangzi",this.node)
        yixiangzi.on("click",this.OnBtnYiXiangzi.bind(this))


        var tuixiangzi = cc.find("panel/menu/1/tuixiangzi",this.node)
        tuixiangzi.on("click",this.OnBtnTuiXiangzi.bind(this))


        
        var mushitaowang = cc.find("panel/menu/1/mushitaowang",this.node)
        mushitaowang.on("click",this.OnBtnMoxiTaowang.bind(this))
   
        var shuzihuarongdao = cc.find("panel/menu/1/shuzihuarongdao",this.node)
        shuzihuarongdao.on("click",this.OnBtnShuziHuaRongDao.bind(this))


        var yidianshanghai = cc.find("panel/menu/5/yidianshanghai",this.node)
        yidianshanghai.on("click",this.OnBtnYiyiShanghai.bind(this))


        var shuipaixu1_enterbtn = cc.find("panel/menu/4/1/com/button_jinru",this.node)
        shuipaixu1_enterbtn.on("click",this.OnBtnEnterShuipaixu1.bind(this))

        var shuipaixu1_enterbtn = cc.find("panel/menu/4/4/com/button_jinru",this.node)
        shuipaixu1_enterbtn.on("click",this.OnBtnEnterShuipaixu2.bind(this))


        var juba_game1_enterbtn = cc.find("panel/menu/4/2/com/button_jinru",this.node)
        juba_game1_enterbtn.on("click",this.OnBtnEnterJuba1.bind(this))

        var juba_game2_enterbtn = cc.find("panel/menu/4/3/com/button_jinru",this.node)
        juba_game2_enterbtn.on("click",this.OnBtnEnterJuba2.bind(this))

        

        var luosihechengbtn = cc.find("panel/menu/2/luosihechengbtn",this.node)
        luosihechengbtn.on("click",this.OnBtnLuosiHeCheng.bind(this))

        var meiritiaozhan = cc.find("panel/menu/2/meiritiaozhan",this.node)
        meiritiaozhan.on("click",this.OnBtnLuosiPaixu.bind(this))

 

        var luosixiaochubtn = cc.find("panel/menu/2/luosixiaochubtn",this.node)
        luosixiaochubtn.on("click",this.OnBtnLuosiXiaochu.bind(this))

 


        var startyingyebtn = cc.find("panel/menu/3/startyingyebtn",this.node)
        startyingyebtn.on("click",this.OnBtnJuba_Yingye.bind(this))

 

        var juba_tiaozhan_btn = cc.find("panel/menu/3/meiritiaozhenbtn",this.node)
        juba_tiaozhan_btn.on("click",this.OnBtnJuba_Tiaozhan.bind(this))
       
       
        var curentergk = juba_Game_Mng.GetInstance().Get_Cur_Enter_Day_GK();

        var juba_tiaozhan_label = cc.find("panel/menu/3/startyingyebtn/c",this.node)
        juba_tiaozhan_label.getComponent(cc.Label).string = "第"+curentergk+"天";
        
  
    }
    OnBtnLuosiXiaochu()
    {
        Luosi_Game_Mng.GetInstance().On_Enter_Daluosi_Game();
       
        GlobalGameMng.GetInstance().m_loading_to_game_scence_name = "daluosi";
        cc.director.loadScene("loadingtogame"); 
        
    }
    OnBtnLuosiPaixu()
    {

        TiaozhanChang_Mng.GetInstance().On_Enter_Tiaozhanchang(21)
        GlobalGameMng.GetInstance().m_loading_to_game_scence_name = "luosipaixu";
        cc.director.loadScene("loadingtogame"); 
    }
    OnBtnLuosiHeCheng()
    {  
        GlobalGameMng.GetInstance().m_loading_to_game_scence_name = "luosi_hecheng";
        cc.director.loadScene("loadingtogame"); 

    }
    On_Select_ShuziHuarongDao_Xuanguan(imode)
    {
        var isubgametype = shuziHuaRongDaoLogicMng.GetInstance().Get_Mode_GameType(imode);
        this.OnBtn_Select_SubgAme_GK(isubgametype);


    }

    OnBtnShuziHuaRongDao()
    {
        ComFunc.OpenNewDialog(this.node,"preab/shuzihuarogndao/shuzihuarongdao_sel_mode","shuzihuarongdao_sel_mode",{
            parentgame:this,cb:this.On_Select_ShuziHuarongDao_Xuanguan.bind(this)

        });
    }
    OnBtnMoxiTaowang()
    {
       

        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(4);
   
 
      
        this.Real_Start_Goto_Game(4,igk);
        
    }
    OnBtnTuiXiangzi()
    {
       

        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(3);
   

        if(igk >= 3)
        {
            //第三关后，点击开始选关

           // this.OnBtn_Select_SubgAme_GK(3);
 

           // return;
        }
      
        this.Real_Start_Goto_Game(3,igk);
 
    }

    OnBtnYiXiangzi()
    {
        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(2);
   

        if(igk >= 3)
        {
            //第三关后，点击开始选关

       
        }
      
        this.Real_Start_Goto_Game(2,igk);
 
    }
    GoToLevel(isubgametype,lv)
    {
       // if(isubgametype == 2)
        {
            this.Real_Start_Goto_Game(isubgametype,lv);
        }
    }


    Real_Start_Goto_Game(isubgametype,igk)
    {
       

        if(isubgametype == 1)
        {
            GlobalData.GetInstance().m_select_enter_hmk_nandu = 1;
            GlobalData.GetInstance().m_select_enter_hmk_gk = igk;
            cc.director.loadScene("huamukuai");
           
        }
        else if(isubgametype == 2)
        {

            GlobalData.GetInstance().m_select_enter_yixiangzz_gk = igk;
            cc.director.loadScene("YiXiangzi");
        }
        else if(isubgametype == 3)
        {


            GlobalData.GetInstance().m_select_enter_txz_gk = igk;
            cc.director.loadScene("Tuixiangzi");
        }
        else if(isubgametype == 4)
        {


            GlobalData.GetInstance().m_select_enter_huarongdao_gk = igk;
            cc.director.loadScene("huarongdao");
        }
        else if(isubgametype  > 100 && isubgametype < 120)
        {

            var imode = isubgametype - 100;
            shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_mode_type =  imode;
            shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_gk =    igk;
    
            cc.director.loadScene("shuzihuarongdao");

        }  
        else if(isubgametype  > 130 && isubgametype < 140)
        {

            GlobalData.GetInstance().m_select_enter_hmk_nandu = isubgametype - 130;
            GlobalData.GetInstance().m_select_enter_hmk_gk = igk;
            cc.director.loadScene("huamukuai");
        }
    }
    OnBtn_Select_SubgAme_GK(isubgametype)
    { 
      
        var imax_can_enter_gk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(isubgametype);
        var igk = imax_can_enter_gk;
    
        var self = this;
        ComFunc.OpenNewDialog(this.node,"preab/selectgk","selectgk", { parentgame:this,
            imax_can_enter_gk:imax_can_enter_gk,
            isubgametype:isubgametype,igk:igk,
            cb:(lv)=>
        {
           
            self.GoToLevel(isubgametype,lv);
          
        }}); 

    }

    On_Select_Subgame_Nandu(igametype,inandu,bxuanguang)
    {
        var irealsubgametype = igametype;

        if(igametype == 1)
        {
            irealsubgametype = HMK_GK_Mng.GetInstance().Get_Mode_GameType(inandu);
        }


        var imax_can_enter_gk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(irealsubgametype);
        var igk = imax_can_enter_gk;

        if(bxuanguang)
        {
            this.OnBtn_Select_SubgAme_GK(irealsubgametype);
        }else{
            this.Real_Start_Goto_Game(irealsubgametype,igk);
    
        }

         // 

 
    }
    OnBtn_Select_Subgame_Nandu(igametype)
    {


        var self = this;
        ComFunc.OpenNewDialog(this.node,"preab/common/com_sel_nandu","com_sel_nandu", { parentgame:this, 
            isubgametype:igametype ,
            cb:(inandu,bxuanguang)=>
        {
           
            self.On_Select_Subgame_Nandu(igametype,inandu,bxuanguang);
            //self.GoToLevel(isubgametype,lv);

        

        }});
          
        
    }
    OnBtnEnterJuba2()
    {
        juba_Game_Mng.GetInstance().m_enter_game_mode = 2;
        cc.director.loadScene("loadingto_juba_game");

    }
    OnBtnJuba_Tiaozhan()
    {
        juba_Game_Mng.GetInstance().m_enter_game_mode = 4;
        cc.director.loadScene("loadingto_juba_game");

    }
    OnBtnJuba_Yingye()
    {
        juba_Game_Mng.GetInstance().m_enter_game_mode = 3;
        cc.director.loadScene("loadingto_juba_game");

    }
    OnBtnEnterJuba1()
    {
        juba_Game_Mng.GetInstance().m_enter_game_mode = 1;
        cc.director.loadScene("loadingto_juba_game");

    }
    OnBtnEnterShuipaixu2()
    {
        paixuGameMng.GetInstance().m_enter_game_mode = 2;
       
        cc.director.loadScene("loadingto_paixigame");

    }
    OnBtnEnterShuipaixu1()
    {
        paixuGameMng.GetInstance().m_enter_game_mode = 1;
       
        cc.director.loadScene("loadingto_paixigame");


    }
    OnBtnYiyiShanghai()
    {
        cc.director.loadScene("yiyiHurt")
    }
    OnBtnHuaMuKuai()
    {

        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(1);
        if(igk >= 3)
        {
            //第三关后，点击开始选关

         //   this.OnBtn_Select_SubgAme_GK(1);

            //首先，选择难度
 
            this.OnBtn_Select_Subgame_Nandu(1);

            return;
        }
      
        this.Real_Start_Goto_Game(1,igk);
 
    }
    OnBtnExit()
    {
        GlobalData.GetInstance().m_morewafa_last_opend_type = 0;
        this.node.destroy();

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(188,false);
    }

    SetInfo(pinfo)
    {
        this.m_itype = pinfo.itype;

        GlobalData.GetInstance().m_morewafa_last_opend_type = this.m_itype;

        this.m_cb = pinfo.cb;


        this.Refresh_Info();

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(188,true);
    }

    Refresh_Info()
    {
        var usebkindex=  1;

        if(this.m_itype == 1)
        {
            usebkindex=  1;
        }
        else if(this.m_itype == 2)
        {
            usebkindex=  2;
        }
        else if(this.m_itype == 3)
        {
            usebkindex=  3;
        }if(this.m_itype == 2)
        {
            usebkindex=  2;
        }
        else if(this.m_itype == 4)
        {
            usebkindex=  2;
        } else if(this.m_itype == 5)
        {
            usebkindex=  3;
        }

        for(var ff=1;ff<=3;ff++)
        {
            var ff_bk_node = cc.find("panel/bk/"+ff,this.node);

            if(ff == usebkindex)
            {
                ff_bk_node.active = true;
            }else{
                ff_bk_node.active = false;
            }
        }


        for(var tt=1;tt<=6;tt++)
        {
            var tt_menu =  cc.find("panel/menu/"+tt,this.node);
            if(!tt_menu)
            {
                continue;
            }

            if(tt == this.m_itype )
            {
                tt_menu.active = true;
            }else{
                tt_menu.active = false;
            }
        }
    }
}

