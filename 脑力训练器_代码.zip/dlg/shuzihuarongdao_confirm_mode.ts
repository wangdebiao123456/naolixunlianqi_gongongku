import ComCodeFuncMng from "../comfuncs/ComCodeFuncMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import shuziHuaRongDaoLogicMng from "../shuzihuarongdao/shuziHuaRongDaoLogicMng";
import MySprite from "../WDT/MySprite";

const {ccclass, property} = cc._decorator;

@ccclass
export default class shuzihuarongdao_confirm_mode extends cc.Component {

    @property(cc.Prefab)
    shuzi_perfk = null;
    
    m_imode = 0;

  


    onLoad () 
    {
        var exit_btn = cc.find("node_ui/exit",this.node);
        exit_btn.on("click",this.OnBtnExit.bind(this));
        
        var startgame = cc.find("node_ui/startgame",this.node);
        startgame.on("click",this.OnBtnStartGame.bind(this));


       

        
    }
    Check_Has_Tili_Enter_Subgame_And_Kouchu(isbugametype)
    {


        var bsuc = ComCodeFuncMng.Check_Has_Tili_Enter_Subgame_And_Kouchu(isbugametype,this.node);
      
        return bsuc;
    }
    Hide_Dating_Gezi_Show()
    {
        MiddleGamePlatformAction.GetInstance().Hide_Dating_Gezi_Show();
       
    }
    OnBtnStartGame()
    {

        var isubgametype = shuziHuaRongDaoLogicMng.GetInstance().Get_Mode_GameType(this.m_imode);

        
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(isubgametype))
        {
            return;
        }

        this.Hide_Dating_Gezi_Show();
        shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_mode_type =  this.m_imode;
        shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_gk =    shuziHuaRongDaoLogicMng.GetInstance().Get_Sub_Mode_Max_Can_Enter_GK(this.m_imode);
     

        cc.director.loadScene("shuzihuarongdao");
    }
    OnBtnExit()
    {
        this.node.destroy();
    }
    SetInitData(paradata)
    {
        this.m_imode = paradata.imode;

        var mubiao =  cc.find("node_ui/mubiao",this.node);
        mubiao.getComponent(cc.Label).string = "选择"+this.m_imode+"x"+this.m_imode+"模式";
        
        this.Refresh_Mode_FKS();
        
    }

    Refresh_Mode_FKS()
    {
        var iallwidth = 680;

        var istartx = -1*680/2;
        var istarty = 680/2 + 5;


        var iperw = Math.floor(iallwidth/this.m_imode);
       
        var gamenode =  cc.find("node_ui/gamenode",this.node);
   
        for(var ff=0;ff<this.m_imode;ff++)
        {
            for(var gg=0;gg<this.m_imode;gg++)
            {
                var iindex = ff*this.m_imode + gg  +1;

                if(ff == this.m_imode -1 && gg == this.m_imode -1)
                {
                    continue;
                }

                var pnode = cc.instantiate(this.shuzi_perfk);
                gamenode.addChild(pnode,10);

                var news = iperw/226;
                pnode.scale = news;

                var plabel  = pnode.getChildByName("c");
            
                plabel.getComponent(cc.Label).string = ""+iindex;


                var ix = istartx +iperw/2  + gg*iperw;
                var iy = istarty -iperw/2  - ff*iperw;
                pnode.setPosition(ix,iy);
           
                /*
                var pndoe = new MySprite("game/fk/fk",iperw,iperw);

                gamenode.addChild(pndoe,10);

                var plabel  = new cc.Node();
                plabel.addComponent(cc.Label);

                pndoe.addChild(plabel);

                plabel.getComponent(cc.Label).string = ""+iindex;
                plabel.getComponent(cc.Label).enableBold = true;
                plabel.getComponent(cc.Label).fontSize = 60;
          
                plabel.color = cc.color(93,37,16);
 
                */
            }
        }


    }

}
