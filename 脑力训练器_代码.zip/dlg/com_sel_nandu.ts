import HMK_GK_Mng from "../huamukuai/HMK_GK_Mng";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import BaseUIUtils from "../comfuncs/BaseUIUtils";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import GlobalGameMng from "../comfuncs/GlobalGameMng";

import GlobalData from "../main/GlobalData";
import ComCodeFuncMng from "../comfuncs/ComCodeFuncMng";
 
const {ccclass, property} = cc._decorator;

@ccclass
export default class com_sel_nandu extends cc.Component {

   
    m_cb = null;
    
    m_haumukuai_jiesuo_need_shiping = 1;
    onLoad () 
    {
        var exit_btn = cc.find("node_ui/exit",this.node);
        exit_btn.on("click",this.OnBtnExit.bind(this))

        this.m_haumukuai_jiesuo_need_shiping = GlobalGameMng.GetInstance().Get_Huamukuai_Jiesuo_Nandu_Need_Shiping();


        for(var ff=1;ff<=5;ff++)
        {
            var ff_node = cc.find("node_ui/mode/"+ff,this.node);
            ff_node.on("click",this.OnBtnSelNandu.bind(this,ff));

            var ff_xuanguang_node = cc.find("node_ui/mode/"+ff+"/xuanguang",this.node);
            ff_xuanguang_node.on("click",this.OnBtnXuanguang.bind(this,ff));


            var ff_cur_gk = ff_node.getChildByName("curgk");

            var isubgametype = 130+ff;
            if(ff == 1)
            {
                isubgametype = 1;
            }

            var max_gk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(isubgametype);

            ff_cur_gk.getComponent(cc.Label).string = "第"+max_gk+"关";
        }

        this.Refresh_Jiesuo_Flags();

        
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(15,true);
   
        BannerGuangaoMng.GetInstance().CheckShowChaiping(2);
    }
    SetInitData(paradata)
    {
        this.m_cb  = paradata.cb;
      

    }
    OnBtnExit()
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(15,false);
   
        this.node.destroy();
    }

    Refresh_Jiesuo_Flags()
    {
        for(var ff=2;ff<=5;ff++)
        {
            var ff_locked_node = cc.find("node_ui/mode/"+ff+"/locked",this.node);
     
            var bjiesuoed = HMK_GK_Mng.GetInstance().IS_ModeType_Jiesuoed(ff);

            if(!this.m_haumukuai_jiesuo_need_shiping)
            {
                bjiesuoed = true;
            }

            var ff_xuanguang_node = cc.find("node_ui/mode/"+ff+"/xuanguang",this.node);
     

            
            if(bjiesuoed)
            {
                ff_locked_node.active = false;
                ff_xuanguang_node.active = true;
            }else{
                ff_locked_node.active = true;
                ff_xuanguang_node.active = false;
            }

        }
    }

    RealSelNandu(inandu,bxuanguang = 0)
    {
        var bjiesuoed = HMK_GK_Mng.GetInstance().IS_ModeType_Jiesuoed(inandu);

        if(!this.m_haumukuai_jiesuo_need_shiping)
        {
            bjiesuoed = true;
        }
        var self=  this;
        if(!bjiesuoed)
        {
            
            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
                this.node,       
                ()=>
                {

                },"视频解锁难度",(bsuc,arg,  ierrorcode,errordesc)=>
            {
                if(!bsuc)
                { 
                    return;
                }
                HMK_GK_Mng.GetInstance().Set_ModeType_Jiesuoed(inandu);
                BaseUIUtils.ShowTipTxtDlg("难度模式解锁成功",self.node);

                self.Refresh_Jiesuo_Flags();
            },"");


            return;
        }

        this.m_cb (inandu,bxuanguang);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(15,false);


        if(bxuanguang)
        {
            this.node.destroy();
        }
    }

    OnBtnXuanguang(inandu)
    {
        this.RealSelNandu(inandu,1);

    }
    OnBtnSelNandu(inandu)
    {
        this.RealSelNandu(inandu,0);

   
       // this.node.destroy();
    }


}
