 
import BundleLoadUtils from "../comfuncs/BundleLoadUtils";
import ComFunc from "../comfuncs/ComFunc";
import HuaMuKuaiMng from "../huamukuai/HuaMuKuaiMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import { Utils } from "../WDT/Utils";
import GlobalData from "../main/GlobalData";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import BaseUIUtils from "../comfuncs/BaseUIUtils";
import YiXiangZiLogicMng from "../YiXiangzi/YiXiangZiLogicMng";
import TuiXiangziGameMng from "../TuiXiangzi/TuiXiangziGameMng";
import huarongdaoGameLogic from "../huarongdao/huarongdaoGameLogic";
import HuaRongDaoMng from "../huarongdao/HuaRongDaoMng";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import ComCodeFuncMng from "../comfuncs/ComCodeFuncMng";
import WMap from "../WDT/WMap";



const {ccclass, property} = cc._decorator;


const PAGE_COUNT = 20;


@ccclass
export default class selectgk extends cc.Component {

    private maxpage: number = 0;
    private curpage: number = 0;

    private btn_pre:cc.Node  = null;
    private btn_next:cc.Node  = null;
    private txt_curlvevel: cc.Label = null;
    private txt_chater: cc.Label = null;

    @property(cc.Prefab)
    per_item:cc.Prefab = null;


    m_close_exit_Callback = null;
    m_cb=  null;


    m_all_child_item_list = [];

    m_isubgametype = 0;
    m_cur_level = 0;


    m_max_level = 0; 

    m_imax_can_enter_gk = 0;

    m_tuijianwe_dest_info_map=  new WMap()
    m_last_tuijian_change_tick = 0;
    
     onLoad () 
     {
       


        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(5,true);
        MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);

        MiddleGamePlatformAction.GetInstance().Hide_ALl_Inner_Game_Show(); 

        BannerGuangaoMng.GetInstance().CheckShowChaiping(13);
        
        this.Init_Top_Tuijian_Guangao();
      


     }

     Init_Top_Tuijian_Guangao()
    { 
         
      //  var othergame_node = cc.find("bottom/othergame",this.node);

       // ComCodeFuncMng.Init_SelGK_Tuijian_Guangao(this,this.node,othergame_node);
       var othergame_node = cc.find("bottom/othergame",this.node);

       var pos1 = this.m_isubgametype + 61000 ; 
       var pos2 = this.m_isubgametype + 62000 ; 


       var pos_arr = [pos1,pos2];
       ComCodeFuncMng.Init_Com_Two_Guangao(this,this.node,othergame_node,pos_arr);
    }
     Get_Total_Level_Count(isubgametype)
     {
        if(isubgametype == 1)
        {
            return HuaMuKuaiMng.GetTotalGuangkaCount();
        }

        if(isubgametype == 2)
        {
            return YiXiangZiLogicMng.GetTotalGuangkaCount();
        }

        if(isubgametype == 3)
        {
            return TuiXiangziGameMng.GetInstance().GetTotalGuangkaCount();
        }

        
        if(isubgametype == 4)
        {
            return HuaRongDaoMng.GetInstance().GetTotalGuangkaCount();
        }

 
        return 5000;

     }

     OnBtnPageAdd(ipagechange)
     {
        this.curpage += ipagechange;

        if(this.curpage >= this.maxpage)
        {
            this.curpage  = this.maxpage-1;
        }
        if(this.curpage  <= 0)
        {
            this.curpage  = 0;
        }


        this.refresitems();
        this.refreshbtns();
     }
     InitAllData()
     {
        this.m_max_level = this.Get_Total_Level_Count(this.m_isubgametype);
        this.maxpage = Math.ceil(this.m_max_level/ PAGE_COUNT);
       
        this.node_items = this.node.getChildByName("node_items");
        this.curpage = Math.floor((this.m_cur_level -1)/ PAGE_COUNT);


        var btn_close = cc.find("top/btn_close",this.node);
        btn_close.on("click",this.OnBtnExit.bind(this));
        
        this.btn_pre = cc.find("menu/btn_pre",this.node);
        this.btn_pre.on("click",this.OnBtnPrePage.bind(this));
   
        this.btn_next = cc.find("menu/btn_next",this.node);
        this.btn_next.on("click",this.OnBtnNextPage.bind(this));



        var show_fast_lv_btn =  cc.find("bottom/btn_empty",this.node);
        show_fast_lv_btn.on("click",this.OnBtnFastStart.bind(this));

   
        this.txt_chater = cc.find("top/cro/txt_chater",this.node).getComponent(cc.Label);
        this.txt_curlvevel = cc.find("top/bkg_top/txt_curlvevel",this.node).getComponent(cc.Label);



        var zjj_desc20   = cc.find("bottom/zjj_desc20",this.node);
        var zjj_add20   = cc.find("bottom/zjj_add20",this.node);
     
        zjj_add20.on("click",this.OnBtnPageAdd.bind(this,20));
        zjj_desc20.on("click",this.OnBtnPageAdd.bind(this,-20));
   
        
   
        
        this.InitCreateAllItems();
        this.refresitems();
        this.refreshbtns();
        this.txt_curlvevel.string = "关卡 " + this.m_cur_level + "";


     }
     SetInitData(paradata)
     {
         this.m_cb  = paradata.cb;
         this.m_close_exit_Callback = paradata.close_exit_Callback;

         this.m_isubgametype = paradata.isubgametype;

         this.m_cur_level = paradata.igk;

       

         this.m_imax_can_enter_gk = paradata.imax_can_enter_gk;

 
 
         this.InitAllData();


         var show_fast_lv_label =  cc.find("bottom/btn_empty/lv",this.node);
         show_fast_lv_label.getComponent(cc.Label).string = "第"+this.m_cur_level+"关";
         


         var gamenandu_node=  cc.find("title/gamenandu",this.node);
         gamenandu_node.active = false;

         
         var gamename_node=  cc.find("title/gamename",this.node);
         gamename_node.active = false;

         for(var ff=1;ff<=4;ff++)
         {
            var game_title = cc.find("title/game"+ff,this.node);

            if(ff == this.m_isubgametype)
            {
                game_title.active = true;
            }else{
                game_title.active = false;
            }

            if(this.m_isubgametype >= 130 && this.m_isubgametype <= 140)
            {
                if(ff == 1)
                {

                    game_title.active = true;
                }
            }
         }


         if(this.m_isubgametype > 100 && this.m_isubgametype < 120)
         {
            gamename_node.active = true;

            var imode = this.m_isubgametype - 100;
            gamename_node.getComponent(cc.Label).string = "数字华容道 "+imode+"x"+imode+"模式";

         }
         else if( (this.m_isubgametype > 130 && this.m_isubgametype < 150) )
         {
           // gamename_node.active = true;

            var inandu = this.m_isubgametype - 130;
          //  gamename_node.getComponent(cc.Label).string = "滑木块 -"+ this.Get_Nandu_Str(inandu);

            gamenandu_node.active = true;
            gamenandu_node.getComponent(cc.Label).string = ""+ GlobalData.GetInstance().Get_Nandu_Str(inandu)+"模式";

         }else if(this.m_isubgametype  == 1  )
         {
           // gamename_node.active = true;

            var inandu = 1;
          //  gamename_node.getComponent(cc.Label).string = "滑木块 -"+ this.Get_Nandu_Str(inandu);

            gamenandu_node.active = true;
            gamenandu_node.getComponent(cc.Label).string = ""+ GlobalData.GetInstance().Get_Nandu_Str(inandu)+"模式";

         }

     }

     OnBtnExit()
     {

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(5,false);

         this.node.destroy();

         if(this.m_close_exit_Callback )
         {
            this.m_close_exit_Callback (0);
         }
      
     }

     OnBtnPrePage()
     {
        if (this.curpage > 0) {
            this.curpage--;
            this.refresitems();
            this.refreshbtns();
        }
     }
     OnBtnNextPage()
     {
        if (this.curpage < this.maxpage -1) {
            this.curpage++;
            this.refresitems();
            this.refreshbtns();
        }
     }
     private refreshbtns() {
        this.btn_pre.opacity = this.curpage == 0 ? 200 : 255;
        this.btn_next.opacity = this.curpage == this.maxpage ? 200 : 255;
        this.txt_chater.string = "第" + (this.curpage + 1) + "章"

        this.btn_pre.getComponent(cc.Button).interactable = this.curpage != 0;
        this.btn_next.getComponent(cc.Button).interactable = this.curpage != this.maxpage;
    }

    InitCreateAllItems()
    {
        for(var ff=0;ff<20;ff++)
        {
            var pnode = cc.instantiate(this.per_item);

            this.node_items.addChild(pnode,19);

            var irow = Math.floor(ff/4);
            var icol = ff - irow*4;

            var ix = -240 + icol*160;
            var iy = -64 - irow*160;
            pnode.setPosition(ix,iy);

            this.m_all_child_item_list[ff] = pnode;
        }
    }

    private node_items: cc.Node = null;
    private refresitems() 
    {



        var shiping_jiesuoed_gk_list = GlobalData.GetInstance().Get_Shiping_Jiesuoed_GK_List(this.m_isubgametype);

        for (let i = 0; i < PAGE_COUNT; ++i) {
            let lv = this.curpage * PAGE_COUNT + i + 1;
            let item = this.m_all_child_item_list[i];


            //奖励标识
            let node_box = item.getChildByName('node_box')
            if (!node_box) {
                node_box = new cc.Node()
                node_box.name="node_box"
                let sp = node_box.addComponent(cc.Sprite)
                 BundleLoadUtils.ShowIconNodePicBundle ( 'resources',sp, 'game/icon_gift')
                node_box.parent = item
                node_box.x = 74
                node_box.y = 60
            }

            node_box.active = lv >= 4 && lv % 4 == 0;


            Utils.setGray(node_box.getComponent(cc.Sprite), this.m_cur_level <lv)

            item.active = lv <= this.m_max_level;



            if(lv < this.m_imax_can_enter_gk)
            {
                item.getChildByName("bkg_current").active = false;
                item.getChildByName("bkg_lock").active = false;
                item.getChildByName("bkg_pass").active = true;
            }  
            else if(lv == this.m_imax_can_enter_gk)
            {
                item.getChildByName("bkg_current").active = true;
                item.getChildByName("bkg_lock").active = false;
                item.getChildByName("bkg_pass").active = false;

            }
            else{
                //还没玩到这个关

                var shipingjiesuoed  =false;
                var wined_gk = false;


                for(var ff=0;ff<shiping_jiesuoed_gk_list.length;ff++)
                {
                    var ff_infp  = shiping_jiesuoed_gk_list[ff];
                    if(ff_infp.g == lv)
                    {
                        shipingjiesuoed=  true;
                        wined_gk = ff_infp.w;
                    }
                }



                if(shipingjiesuoed)
                {
                    if(wined_gk)
                    {

                        item.getChildByName("bkg_current").active = false;
                        item.getChildByName("bkg_lock").active = false;
                        item.getChildByName("bkg_pass").active = true;
        

                    }
                    else
                    {

                        item.getChildByName("bkg_current").active = true;
                        item.getChildByName("bkg_lock").active = false;
                        item.getChildByName("bkg_pass").active = false;
        
                    }

                }
                else{

                    item.getChildByName("bkg_current").active = false;
                    item.getChildByName("bkg_lock").active = true;
                    item.getChildByName("bkg_pass").active = false;
    
                }


            }


           // item.getChildByName("bkg_current").active = lv == this.m_imax_can_enter_gk;
            //item.getChildByName("bkg_lock").active = lv > this.m_imax_can_enter_gk;
           // item.getChildByName("bkg_pass").active = lv < this.m_imax_can_enter_gk;


           // let btn = item.getComponent(cc.Button) as cc.Button;
          //  btn.enabled = lv <= this.m_imax_can_enter_gk;
            let txt_lv = item.getChildByName("txt_lv").getComponent(cc.Label);
            txt_lv.string = (lv) + "";

 
            
            //星星
            let stars = cc.find("bkg_pass/stars", item)
            let star_1 = stars.getChildByName("star_1");
            let star_2 = stars.getChildByName("star_2");
            let star_3 = stars.getChildByName("star_3");
            let star = 3;//GSXC_Game_Mng.GetInstance().levelstar[lv] || 0;
            star_1.children[0].active = star >= 1;
            star_2.children[0].active = star >= 2;
            star_3.children[0].active = star >= 3;
           

            item['lv'] = lv;

            item.off("click");
            item.on("click",this.OnBtnXuangaung.bind(this,lv))
        }

        
    }

    OnBtnFastStart()
    {
        this.RealEnter_GK(this.m_cur_level);

    }
    RealEnter_GK(lv)
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(5,false);

        if(this.m_cb )
        {
            this.m_cb (lv);
        }

        this.node.destroy();
     
    

    }
    OnBtnXuangaung(lv)
    {
        var self=  this;

        var shiping_jiesuoed_gk_list = GlobalData.GetInstance().Get_Shiping_Jiesuoed_GK_List(this.m_isubgametype);
        if(lv <= this.m_imax_can_enter_gk)
        {

            this.RealEnter_GK(lv);

        }else{

            

            var shiping_jiesuoed_gk_list = GlobalData.GetInstance().Get_Shiping_Jiesuoed_GK_List(this.m_isubgametype);

            var shipingjiesuoed  =false;
            var wined_gk = false;


            for(var ff=0;ff<shiping_jiesuoed_gk_list.length;ff++)
            {
                var ff_infp  = shiping_jiesuoed_gk_list[ff];
                if(ff_infp.g == lv)
                {
                    shipingjiesuoed=  true;
                    wined_gk = ff_infp.w;
                }
            }


            if(shipingjiesuoed)
            {

                this.RealEnter_GK(lv);

            }else{


                //视频解锁
                WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node,
                    ()=>
                    {
                        MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);

                    },
                    
                    "视频解锁关卡",(bsuc)=>
                {
                    if(!bsuc)
                    {
                        return;
                    }
                
                    GlobalData.GetInstance().Add_GameType_Shiping_Jiesuoed_GK(self.m_isubgametype,lv);
                    self.refresitems();
                    BaseUIUtils.ShowTipTxtDlg("已解锁该关,点击可进入该关",self.node);

                    
                   /// self.RealEnter_GK(lv);

                });

            }



        }

      

    }
   
 
     
}
