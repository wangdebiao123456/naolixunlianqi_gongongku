import ChouJiangMng from "../comfuncs/ChouJiangMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";

const {ccclass, property} = cc._decorator;

@ccclass
export default class choujiang_left_time_tishi extends cc.Component 
{

   
    
    onLoad () 
    {
        var exitbtn = cc.find("panel/exit",this.node);
        exitbtn.on("click",this.onBtnExit.bind(this));
        
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(181,true);

        this.schedule(this.FD_Timer.bind(this),1);
        this.FD_Timer();
    }

    onBtnExit()
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(181,false);

        this.node.destroy();
    }
    FD_Timer()
    {
        var desc2 = cc.find("panel/desc2",this.node);

        var strtip = ChouJiangMng.GetInstance().Get_Choujiang_Tip();

        desc2.getComponent(cc.Label).string = strtip;
    }

}
