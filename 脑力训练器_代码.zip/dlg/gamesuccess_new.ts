import PlatFormMng from "../PlatForm/PlatFormMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction"; 
import PlatFormType from "../PlatForm/PlatFormType";
import BaseUIUtils from "../comfuncs/BaseUIUtils"; 
import ClientLogUtils from "../comfuncs/ClientLogUtils"; 
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng"; 
import ComFunc from "../comfuncs/ComFunc"; 
import MyLocalStorge from "../WDT/MyLocalStorge"; 
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import ComCodeFuncMng from "../comfuncs/ComCodeFuncMng"; 
import WMap from "../WDT/WMap"; 
import XJS_GameInfoManager from "../manager/XJS_GameInfoManager";
import PlatFormParaMng from "../PlatForm/PlatFormParaMng"; 
import paixuGameMng from "../paixu/paixuGameMng";
import juba_Game_Mng from "../jiubei/mng/juba_Game_Mng";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class gamesuccess_new extends cc.Component {

   
 
    node_ui:cc.Node


    m_i_game_mode = 1;

    m_enter_level = 0;
    m_cb = null;

    m_isubgametype = 1;
    m_star = 0;

    m_gk_jiangli = [];

    m_b_need_shuangbei_Selected=  0;

    m_b_chongwan = false;

    m_tuijianwe_dest_info_map = new WMap();
    m_last_tuijian_change_tick_map = new WMap();

    
    m_last_click_jixuyouxi_tick = 0;

    m_click_jixu_youxi_count = 0;


    
    //1:default menu .2:双倍menu ,3:首先default,点击后边双倍
    m_game_success_dlg_use_default_menu_type = 0;
    m_cur_menu_type = 0;


    m_inandu = 0;

    
    @property(cc.Prefab)
    game_end_lingqu: cc.Prefab = null;

 
    @property(cc.Prefab)
    fanhuidating_queren: cc.Prefab = null;


    onLoad () 
    {

      


        BackGroundSoundUtils.GetInstance().Pause_Background_Music();

        BackGroundSoundUtils.GetInstance().Play_Effect('com/victory');

        this.scheduleOnce(this.FD_StopLuping.bind(this),0.3);
        
      
      
        var btn_share=  cc.find("node_ui/top/btn_share",this.node);
        var btn_next =  cc.find("node_ui/bottom/default_menu/btn_next",this.node);
        var btn_restart=  cc.find("node_ui/top/btn_restart",this.node);

        
        var shungbeilq_gouxuan_btn =  cc.find("node_ui/bottom/default_menu/shungbeilq",this.node);
        shungbeilq_gouxuan_btn.on("click",this.OnBtnShuangbeiGouxuan.bind(this))
 

        btn_share.on("click",this.click_share.bind(this));
        btn_next.on("click",this.OnBtnJixuYouxi.bind(this));
        btn_restart.on("click",this.click_restart.bind(this));
     
      

        var putonglingqu_btn =  cc.find("node_ui/bottom/shuangbei_menu/putonglingqu",this.node);
        putonglingqu_btn.on("click",this.OnBtnPutongLingqu.bind(this));
    

        var shuangbeilqu_btn =  cc.find("node_ui/bottom/shuangbei_menu/shuangbeilqu",this.node);
        shuangbeilqu_btn.on("click",this.OnBtn_Shaungbei_Lingqu.bind(this));
    
       
        

        var guangquan =  cc.find("node_ui/top/guangquan",this.node);
        var pseq = cc.repeatForever(cc.rotateBy(0.1,10))
        guangquan.runAction(pseq);
 
     

        this.Show_All_Btns(false);

        var idealyshowsec = GlobalGameMng.GetInstance().Get_GameSuc_Dlg_Dealy_Show_Btn_Sec();
       
        this.scheduleOnce(this.FD_InitShow.bind(this),idealyshowsec);


        MiddleGamePlatformAction.GetInstance().Check_BK_Create_GameSuc_EndLingqu_Banners();
    
   
         BannerGuangaoMng.GetInstance().CheckShowChaiping();

         this.m_game_success_dlg_use_default_menu_type = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_Use_Default_Menu_Type();
        
         if(this.m_game_success_dlg_use_default_menu_type == 4)
         {
             if(this.m_b_need_shuangbei_Selected)
             {
                 this.m_cur_menu_type = 1;
             }else{
                 this.m_cur_menu_type = 2;
             }
         }
         else if(this.m_game_success_dlg_use_default_menu_type == 2)
         {
             this.m_cur_menu_type = 2;
         }else{
             this.m_cur_menu_type = 1;
         }
         
         this.Refresh_Menu();




    }
    Refresh_Guowai_Version()
    { 

        
    }
    OnBtn_Shaungbei_Lingqu()
    {
        this.click_Shuangbei();
    }


    OnBtnPutongLingqu()
    {
        var self = this;

        /*
        if(!ComCodeFuncMng.Check_Has_Tili_Enter_Subgame_And_Kouchu(this.m_isubgametype,this.node,()=>
            {
                self.Refresh_Info();
            })
        )
        {
            MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);

            return;
        }
        */

        this.Refresh_Info();
        this.click_next() ;
    }



    Refresh_Menu()
    {
        var default_menu = cc.find("node_ui/bottom/default_menu",this.node);
        var shuangbei_menu = cc.find("node_ui/bottom/shuangbei_menu",this.node);

        if(this.m_cur_menu_type == 2)
        {
            shuangbei_menu.active = true;
            default_menu.active = false;

        }else{
            shuangbei_menu.active = false;
            default_menu.active = true;

        }
        
    }
    FD_InitShow()
    {
        this.Show_All_Btns(true);
    }
    Show_All_Btns(bshow)
    {
 



        var btn_share=  cc.find("node_ui/top/btn_share",this.node);
        var btn_next =  cc.find("node_ui/bottom/default_menu/btn_next",this.node);
       
        var btn_restart=  cc.find("node_ui/top/btn_restart",this.node);
     
        var btn_putonglingqu =  cc.find("node_ui/bottom/shuangbei_menu/putonglingqu",this.node);
        var btn_shuangbeilqu =  cc.find("node_ui/bottom/shuangbei_menu/shuangbeilqu",this.node);
 


        

        btn_share.active = bshow;
        btn_next.active = bshow; 
       
        btn_putonglingqu.active = bshow;
        btn_shuangbeilqu.active = bshow;
        btn_restart.active = bshow;
 
       
        this.Refresh_Guowai_Version();
    }
    Init_Top_Tuijian_Guangao()
    {
        var othergame_node = cc.find("node_ui/bottom/othergame",this.node);

 
        var platfroamvcanshow = PlatFormMng.GetInstance().IS_Can_Show_Zidingyi_TuijianWei();

        if(!platfroamvcanshow)
        {
            othergame_node.active = false;
            return;
        }
    

        var pos1 = this.m_isubgametype + 11000 ;
        var pos2 =  this.m_isubgametype + 12000 ;


        var pos_arr = [pos1,pos2];
        ComCodeFuncMng.Init_Com_Two_Guangao(this,this.node,othergame_node,pos_arr);


    }
    OnBtnShuangbeiGouxuan()
    {
        if(this.m_b_need_shuangbei_Selected)
        {
            this.m_b_need_shuangbei_Selected = 0;
        }else{
            this.m_b_need_shuangbei_Selected= 1;
        }

        this.Set_Last_Shuangbei_Gouxuan_V(this.m_b_need_shuangbei_Selected);
        this.Refresh_Gouxuan();

              
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(16, "胜利页面勾选", this.m_b_need_shuangbei_Selected,
             GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype), this.m_isubgametype, "",this.m_enter_level, "");
 
    }
    
    Set_Last_Shuangbei_Gouxuan_V(igouxuaned)
    {
        var obj = {
            gouxuaned:igouxuaned
        }
    
           
        var last_v = "guaishoufangweizhan_gamesuc_dlg_"+this.m_isubgametype+"_gouxuan";
    
        var str = JSON.stringify(obj);
        MyLocalStorge.setItem(last_v,str);
    }

    Get_Last_Shuangbei_Gouxuan_V()
    {
        var last_v = "guaishoufangweizhan_gamesuc_dlg_"+this.m_isubgametype+"_gouxuan";

        var prevstr = MyLocalStorge.getItem(last_v,"");

        if(!prevstr)
        {
            return [0,0];
        }


        var pobj = JSON.parse(prevstr);
        if(!pobj)
        {
            return [0,0];
        }

        var gouxuaned = pobj.gouxuaned;
        if(!gouxuaned)
        {
            gouxuaned = 0;
        }
        return [1,gouxuaned];
    }
    Refresh_Gouxuan()
    {
        var gou_ndoe=  cc.find("node_ui/bottom/default_menu/shungbeilq/gou",this.node);
        gou_ndoe.active =    this.m_b_need_shuangbei_Selected ? true:false;
    }
    FD_StopLuping()
    {
        MiddleGamePlatformAction.GetInstance().Stop_Luping();
    }

    Find_Type_C(gk_jiangli,itype)
    {

        for(var ff=0;ff<gk_jiangli.length;ff++)
        {
            var ff_info = gk_jiangli[ff];

            if(ff_info.t == itype)
            {
                return ff_info.c;
            }
        }

        return 0;
    }
    Refresh_Info()
    {
        
       

    }
    Get_Pos(allcount,i)
    {
        var y = -64;
        if(allcount == 1)
        {
            return new cc.Vec2(0,y)
        }

        if(allcount == 2)
        {
            if(i == 1)
            {
                return new cc.Vec2(-100,y);
            }
            return new cc.Vec2(100,y);
        }

        if(allcount == 3)
        {
            if(i == 1)
            {
                return new cc.Vec2(-150,y);
            }
            if(i == 2)
            {
                return new cc.Vec2(0,y);
            }
            return new cc.Vec2(150,y);
        }


        if(allcount == 4)
        {
            if(i == 1)
            {
                return new cc.Vec2(-225,y);
            }
            if(i == 2)
            {
                return new cc.Vec2(-75,y);
            }
            if(i == 3)
            {
                return new cc.Vec2(75,y);
            }
            return new cc.Vec2(225,y);
        }

        if(allcount == 5)
        {
            if(i == 1)
            {
                return new cc.Vec2(-260,y);
            }
            if(i == 2)
            {
                return new cc.Vec2(-130,y);
            }
            if(i == 3)
            {
                return new cc.Vec2(0,y);
            }
            if(i == 4)
            {
                return new cc.Vec2(130,y);
            }
            return new cc.Vec2(260,y);
        }


        if(allcount == 6)
        {
            if(i == 1)
            {
                return new cc.Vec2(-300,y);
            }
            if(i == 2)
            {
                return new cc.Vec2(-180,y);
            }
            if(i == 3)
            {
                return new cc.Vec2(-60,y);
            }
            if(i == 4)
            {
                return new cc.Vec2(60,y);
            }

            if(i == 5)
            {
                return new cc.Vec2(180,y);
            }
            if(i == 6)
            {
                return new cc.Vec2(300,y);
            }
            return new cc.Vec2(300,y);
        }
        return new cc.Vec2(0,y);

    }
    
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        var isubgametype = paradata.isubgametype;

        this.m_isubgametype = paradata.isubgametype;

        this.m_i_game_mode = paradata.igamemode;

        this.m_enter_level = paradata.ilevel;
        this.m_star = paradata.star;

        this.m_inandu = paradata.inandu;
    
        var bfistwin  = paradata.bfistwin;


        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(2);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(2,true);
 
        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(3);
 
       
 
        this.node_ui = cc.find("node_ui",this.node);
     
        this.node_ui.x=600
        cc.tween(this.node_ui).to(0.25,{x:0},{easing:'backOut'}).start()
  

        var levelinfo = cc.find("node_ui/top/levelinfo",this.node);
        levelinfo.getComponent(cc.Label).string =  "恭喜成功过关第" +this.m_enter_level+ "关";
 
        if(this.m_i_game_mode == 36)
        {
            levelinfo.getComponent(cc.Label).string =   "恭喜成功打出一亿点伤害!!";
        }

        if(this.m_i_game_mode == 61)
        {
            levelinfo.getComponent(cc.Label).string =   "恭喜螺丝排序挑战成功一次!";
        }

        if(this.m_i_game_mode == 62)
        {
            levelinfo.getComponent(cc.Label).string =   "恭喜螺丝合成到目标数字!";
        }

        
        
        var gk_reward_info =  null
        
        
        if(this.m_i_game_mode == 21 || this.m_i_game_mode == 22)
        {
            var com_reward = paixuGameMng.GetInstance().Get_Guoguang_Jiangli_Reward(this.m_i_game_mode-20,this.m_enter_level);
            gk_reward_info = {

                "first":[],
                "common":com_reward
            }
        } 
        else if(this.m_i_game_mode == 11 || this.m_i_game_mode == 12
            || this.m_i_game_mode == 13 || this.m_i_game_mode == 14)
        {
            var com_reward2 =   juba_Game_Mng.GetInstance().Get_Guoguang_Jiangli_Reward(this.m_i_game_mode-10,this.m_enter_level);
     
            gk_reward_info = {

                "first":[],
                "common":com_reward2
            }
        }
        else{
            gk_reward_info = XJS_GameInfoManager.GetInstance().Get_JSGame_Gk_Winned_Jiangli(this.m_i_game_mode,this.m_enter_level,bfistwin);

        }
   
        this.m_gk_jiangli = [];

        var common_jl = gk_reward_info.common;
        var first_jl = gk_reward_info.first;

        var t_c_map = new WMap();

       

        for(var ff=0;ff<first_jl.length;ff++)
        {
            var ff_info =  first_jl[ff];
            var ff_t=  ff_info.t;
            var ff_c=  ff_info.c;

            if(!t_c_map.hasKey(ff_t))
            {
                t_c_map.putData(ff_t,ff_c);
            }else{
                var prevc = t_c_map.getData(ff_t);
                t_c_map.putData(ff_t,ff_c + prevc);
            }
        }



        for(var ff=0;ff<common_jl.length;ff++)
        {
            var ff_info =  common_jl[ff];
            var ff_t=  ff_info.t;
            var ff_c=  ff_info.c;

            if(!t_c_map.hasKey(ff_t))
            {
                t_c_map.putData(ff_t,ff_c);
            }else{
                var prevc = t_c_map.getData(ff_t);
                t_c_map.putData(ff_t,ff_c + prevc);
            }
        }

        for(var ff=0;ff<t_c_map.size();ff++)
        {
            var ff_t=  t_c_map.GetKeyByIndex(ff);
            var ff_c=  t_c_map.GetEntryByIndex(ff);
            this.m_gk_jiangli.push({"t":ff_t,"c":ff_c});
        }

        var gk_jiangli = this.m_gk_jiangli;

        

        this.Refresh_Info(); 


        var gamename_ndoe = cc.find("node_ui/top/gamename",this.node);
       
      
        var smondename =  XJS_GameInfoManager.GetInstance().Get_Game_Type_Name(this.m_i_game_mode,this.m_isubgametype)+" ";



     
        gamename_ndoe.getComponent(cc.Label).string = smondename;
     
       

        for(var ff=1;ff<=6;ff++)
        {
            var ff_node = cc.find("node_ui/bottom/award/"+ff+"",this.node);
            ff_node.active = false;
        }
           
        var iindex = 1;

        for(var ff=0;ff<first_jl.length;ff++)
        {
            var ff_info  = first_jl[ff];
            var ff_t = ff_info.t;
            var ff_c=  ff_info.c;
            var ff_node = cc.find("node_ui/bottom/award/"+iindex+"",this.node);

            if(!ff_node)
            {
                continue;
            }
            var ff_icon_node = cc.find("node_ui/bottom/award/"+iindex+"/icon",this.node);
            var ff_shouci_node = cc.find("node_ui/bottom/award/"+iindex+"/shouci",this.node);

            ff_shouci_node.active = true;
            ff_node.active = true;

             
            var sfilename = GlobalGameMng.GetInstance().Get_Aawrd_Daoju_Icon(ff_t);

            BaseUIUtils.ShowIconNodePicFilename(ff_icon_node,sfilename,{cx:60,cy:60});


            var ff_count_node = cc.find("node_ui/bottom/award/"+iindex+"/c",this.node);
            ff_count_node.getComponent(cc.Label).string  = ""+ff_info.c;

            iindex++;
        }

        for(var ff=0;ff<common_jl.length;ff++)
        {
            var ff_info  = common_jl[ff];
            var ff_t = ff_info.t;
            var ff_c=  ff_info.c;
            var ff_node = cc.find("node_ui/bottom/award/"+iindex+"",this.node);

            if(!ff_node)
            {
                continue;
            }
            var ff_icon_node = cc.find("node_ui/bottom/award/"+iindex+"/icon",this.node);
            var ff_shouci_node = cc.find("node_ui/bottom/award/"+iindex+"/shouci",this.node);

            
            ff_node.active = true;
            ff_shouci_node.active = false;

            var sfilename = GlobalGameMng.GetInstance().Get_Aawrd_Daoju_Icon(ff_t);

            BaseUIUtils.ShowIconNodePicFilename(ff_icon_node,sfilename,{cx:60,cy:60});


            var ff_count_node = cc.find("node_ui/bottom/award/"+iindex+"/c",this.node);
            ff_count_node.getComponent(cc.Label).string  = ""+ff_info.c;

            iindex++;
        }

        
        var allcount = iindex-1;

        for(var ff=1;ff<iindex;ff++)
        {
            var ff_node = cc.find("node_ui/bottom/award/"+ff+"",this.node);

            var pos = this.Get_Pos(allcount,ff);
            ff_node.setPosition(pos);
        }







        var idefault_gouxuan = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_Default_Gouxuan();
        var inext_gouxuan_type = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_Next_Gouxuan_Type();
        var irecheck_need_gk = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_ReCheck_Gouxuan_Need_GK();
        var ifirst_gouxuan_need_min_gk = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_First_Gouxuan_Need_Min_GK();

        var config_need_min_jiange_sec_from_last_watch_video = GlobalGameMng.GetInstance().Get_Game_Suc_Dlg_Minsec_Jiange_From_Last_Watch_Video();

          //距离上次播放视频
          var ieplase_sec_from_last_watch_video = WatchVideoAdveseMng.GetInstance().Get_Jiange_Sec_From_Last_Play_Video();


        var gametype_config = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_Per_Game_Type_GouxuanBtn_Config(this.m_isubgametype);




        if(gametype_config)
        {
            idefault_gouxuan  = gametype_config[1];
            inext_gouxuan_type  = gametype_config[2];
            irecheck_need_gk  = gametype_config[3];
            ifirst_gouxuan_need_min_gk= gametype_config[4];
        }



        var last_gouxuaned_v = this.Get_Last_Shuangbei_Gouxuan_V();


        if(!last_gouxuaned_v[0])
        {

            this.m_b_need_shuangbei_Selected = idefault_gouxuan;
        }
        else
        {
            var last_gouxuan_v = last_gouxuaned_v[1];

            if(inext_gouxuan_type == 1)
            {
                this.m_b_need_shuangbei_Selected = 1;

            }
            else if(inext_gouxuan_type == 2)
            {
                //使用上次的勾选结果
                this.m_b_need_shuangbei_Selected = last_gouxuan_v;

            }
            else if(inext_gouxuan_type == 0)
            {
                this.m_b_need_shuangbei_Selected = 0;
            }
            else if(inext_gouxuan_type == 3)
            {
                //使用上次的勾选结果，但是超过irecheck_need_gk关没有选上后，自动勾选

                if(!last_gouxuan_v)
                {
                    this.Add_gamesuc_dlg_gouxuan_Jiange_GK();

                    //间隔几个关卡
                    var qd_jiange_gk_info = this.GetLast_gamesuc_dlg_gouxuan_Jiange_GK();
                    var ijaingegk = qd_jiange_gk_info[1];
        
                    if(ijaingegk > irecheck_need_gk)
                    {
                        last_gouxuan_v = 1;
                        this.Remove_gamesuc_dlg_gouxuan_jiange_GK();
                    
                    }
                }
                

                  //使用上次的勾选结果,但是间隔几关以后就必须重新勾选上
                  this.m_b_need_shuangbei_Selected = last_gouxuan_v;

                 

            }
            else if(inext_gouxuan_type == 4)
            {
                //从mingk开始，每间隔多少关自动勾选

                if(this.m_enter_level < ifirst_gouxuan_need_min_gk)
                {
                    this.m_b_need_shuangbei_Selected = 0;
                }else if(this.m_enter_level == ifirst_gouxuan_need_min_gk)
                {
                    this.m_b_need_shuangbei_Selected = 1;
                }
                else{

                    var iaddcc = this.m_enter_level - ifirst_gouxuan_need_min_gk;

                    if(iaddcc%irecheck_need_gk == 0)
                    {
                        this.m_b_need_shuangbei_Selected = 1;
                    }else{
                        this.m_b_need_shuangbei_Selected = 0;
                    }

                }


            } 
            else if(inext_gouxuan_type == 5)
            {
                //大于mingk后，每间隔recheck次打勾
                if(this.m_enter_level < ifirst_gouxuan_need_min_gk)
                {
                    this.m_b_need_shuangbei_Selected = 0;
                }else 
                {

                    this.Add_gamesuc_dlg_gouxuan_Jiange_GK();

                    //间隔几个关卡
                    var qd_jiange_gk_info = this.GetLast_gamesuc_dlg_gouxuan_Jiange_GK();
                    var ijaingegk = qd_jiange_gk_info[1];
        
                    if(ijaingegk >= irecheck_need_gk)
                    {
                        this.m_b_need_shuangbei_Selected = 1;
                        this.Remove_gamesuc_dlg_gouxuan_jiange_GK();
                    
                    }
                    else{
                        this.m_b_need_shuangbei_Selected = 0;
                    }

                }

            }
            else{
                this.m_b_need_shuangbei_Selected = last_gouxuan_v;
            }
        }
 
        
        if(config_need_min_jiange_sec_from_last_watch_video > 0 )
        {
            if(config_need_min_jiange_sec_from_last_watch_video > ieplase_sec_from_last_watch_video)
            {
                this.m_b_need_shuangbei_Selected = 0;
            }
        }


        
        this.Set_Last_Shuangbei_Gouxuan_V(this.m_b_need_shuangbei_Selected);

        this.Refresh_Gouxuan();

        var game_success_dlg_use_default_menu_type = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_Use_Default_Menu_Type();

        if(game_success_dlg_use_default_menu_type == 4)
        {

            if(this.m_b_need_shuangbei_Selected)
            {
                this.m_cur_menu_type = 1;
            }else{
                this.m_cur_menu_type = 2;
            }
            this.Refresh_Menu();
        } 

 
    
         GlobalGameMng.GetInstance().On_GameType_GK_Guoguang( this.m_i_game_mode,  this.m_isubgametype,this.m_enter_level);
    

        this.Init_Top_Tuijian_Guangao();

    }
    Add_gamesuc_dlg_gouxuan_Jiange_GK()
    {
        var pinfo = this.GetLast_gamesuc_dlg_gouxuan_Jiange_GK();
        var prevgk = pinfo[1];
        var newgk = prevgk+1;

        var obj = {
            ijiangegk:newgk
        }

        var last_v = "guaishoufangweizhan_gamesuc_"+this.m_isubgametype+"_jiange_gk";
  
        var str = JSON.stringify(obj);
        MyLocalStorge.setItem(last_v,str);
    }

    GetLast_gamesuc_dlg_gouxuan_Jiange_GK()
    {
        var last_v = "guaishoufangweizhan_gamesuc_"+this.m_isubgametype+"_jiange_gk";
  
        var prevstr = MyLocalStorge.getItem(last_v,"");

        if(!prevstr)
        {
            return [0,0];
        }


        var pobj = JSON.parse(prevstr);
        if(!pobj)
        {
            return [0,0];
        }

        var ijiangegk = pobj.ijiangegk;
        if(!ijiangegk)
        {
            ijiangegk = 0;
        }
        return [1,ijiangegk];
    }

    Remove_gamesuc_dlg_gouxuan_jiange_GK()
    {

        var last_v = "guaishoufangweizhan_gamesuc_"+this.m_isubgametype+"_jiange_gk";
        MyLocalStorge.removeItem(last_v);
    }
 



    
     
    Linhqu_Next(ibeishu)
    {
  
      //  MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner();

    
        this.Lingquiangli(ibeishu);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(2,false);

     
 
        this.m_cb(1,this.m_b_chongwan);

     

        this.node.destroy();
    }

     
    click_JixuYouxi()
    {

        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn');

        if(this.m_last_click_jixuyouxi_tick > 0)
        {
            if(Date.now() - this.m_last_click_jixuyouxi_tick < 1000)
            {
                return;
            }
        }

        this.m_last_click_jixuyouxi_tick  = Date.now();

        this.m_click_jixu_youxi_count++;


        if(this.m_b_need_shuangbei_Selected)
        {
            this.click_Shuangbei();

          
            if(this.m_click_jixu_youxi_count >= 2)
            {
                this.m_b_need_shuangbei_Selected = 0;
                this.Refresh_Gouxuan();
            }

            return;
        }


        var self = this;

       

        this.Refresh_Info();
        this.click_next() ;
    }
    OnBtnJixuYouxi()
    {
        this.m_b_chongwan = false;
        this.click_JixuYouxi();

        
        if(this.m_game_success_dlg_use_default_menu_type == 3 || this.m_game_success_dlg_use_default_menu_type == 4)
        {
            if(this.m_click_jixu_youxi_count >= 2)
            {
                this.m_cur_menu_type = 2;
            }
        }
        this.Refresh_Menu();
    }
    OnBtnChongWan()
    {
        this.m_b_chongwan = true;
        this.click_JixuYouxi();
    }
    click_next() {

        this.RealLingqu(1);
     
    //  this.Linhqu_Next(1);

        
    }
    Lingquiangli(ibeishu)
    {
        GlobalGameMng.GetInstance().Common_Add_Award_List(this.m_gk_jiangli,ibeishu);
    
      


      //  GlobalGameMng.GetInstance().Add_DaojuType_Count_List(this.m_gk_jiangli,ibeishu);

        //发送勋章排行数据
        //GlobalGameMng.GetInstance().Send_Server_Xunzhang_Paihangbang();

        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
        
    }
    FD_LignquShuangbei_Success()
    {
       
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0); 


        var ibeishu = 3;
        
        var self = this;

        self.RealLingqu(3);


        //this.Linhqu_Next(3);
    }
    RealLingqu(ibeishu)
    {
        
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
        MiddleGamePlatformAction.GetInstance().Manual_Detroy_Game_End_Tankuang(2);

        this.Show_All_Btns(false);


        this.Lingquiangli(ibeishu);

        
        var icomlqu_needshow_lq_dlg = GlobalGameMng.GetInstance().Get_GameSuc_dlg_Com_Lignqu_Need_Show_GameLingqu_Dlg();

        var bshowlq = false;

        if(icomlqu_needshow_lq_dlg)
        {
            bshowlq = true;
        }else
        {
            if(ibeishu > 1)
            {
                bshowlq = true;
            }
        }

        var self = this;

        if(bshowlq)
        {
            ComFunc.Real_OpenNewDialog(
                this.game_end_lingqu,
                this.node,"preyuzhi/common/game_end_lingqu","game_end_lingqu", 
            {
                daojulist: this.m_gk_jiangli, 
                ibeishu:ibeishu,
                isubgametype:this.m_isubgametype,

                igamemode:this.m_i_game_mode,
                ilevel:this.m_enter_level,


                inandu:this. m_inandu,


                cb:(iret)=>
                {
                    self.On_Real_Lingqu_End(iret);
    
                }
    
            });
        }else{
            self.On_Real_Lingqu_End(0);
        }
        
    }
    On_Real_Lingqu_End(iret)
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(2,false);
        MiddleGamePlatformAction.GetInstance().Manual_Detroy_Game_End_Tankuang(2);


        this.m_cb(iret);

     

        this.node.destroy();
    }

    click_Shuangbei()
    {
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
      
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node, 
            ()=>
            {
                MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0); 
            },
            "游戏胜利双倍",
                (bsuc,arg,  ierrorcode,errordesc)=>
        {
            if(!bsuc)
            {
                console.log("胜利框 !bsuc ierrorcode="+ierrorcode+",errordesc="+errordesc);

                var uncheck_aotu_type =  GlobalGameMng.GetInstance().Get_Game_Suc_Dlg_Auto_Uncheck_Gouxuan_Type();

                if(uncheck_aotu_type == 1)
                {
                    self.m_b_need_shuangbei_Selected = 0;
                    self.Refresh_Gouxuan();
                }
                else if(uncheck_aotu_type == 2)
                {
                    self.m_b_need_shuangbei_Selected = 0;
                    self.m_cur_menu_type = 2;
                    self.Refresh_Gouxuan();
                    self.Refresh_Menu();
                }

                return;
            } 
            
            self.scheduleOnce(this.FD_LignquShuangbei_Success.bind(this),0.1)

            

            ClientLogUtils.GetInstance().Poset_Server_JS_Log(20000+self.m_isubgametype, 
                "游戏双倍日志", self.m_enter_level,
            "第"+self.m_enter_level+"关", 0, "", 0, "");

        }, this.m_isubgametype);


    
    }
    On_Open_Close_FanhuiDating_Queren(bopen)
    {
        if(bopen)
        {
            MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
    
        }
        else{

            MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(2);

        }

    }
    click_restart()
    {
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
      
        var self = this;

        if(GlobalGameMng.GetInstance().IS_Game_Success_Dlg_FanhuiDating_Need_Queren())
        {

            this.On_Open_Close_FanhuiDating_Queren(1)


            ComFunc.Real_OpenNewDialog(this.fanhuidating_queren, this.node,"preab/fanhuidating_queren","fanhuidating_queren",
            {  
                cb:(iselresult)=>
                {
                            
                    if(iselresult > 0)
                    {
                        //返回大厅
                        self.RealFanhuiDating();
                    }
                    else{

                        self.On_Open_Close_FanhuiDating_Queren(0);
                    }
                   
                    
                        
                        
                }}
            );
            
        }else{

            this.RealFanhuiDating();
        }

    }

    RealFanhuiDating()
    { 
      
        MiddleGamePlatformAction.GetInstance().Stop_Luping();
    
    //    MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner();

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(2,false);


        this.Lingquiangli(1);

        this.node.destroy(); 

      //  ComFunc.RealLoadScence("jsdating"); 
     
        cc.director.loadScene("dating")
    }

    Get_Game_Success_Fenxiang_Str()
    {
        var isubgamename = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype);

        return  "我在"+isubgamename+"中第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";
   
      
    }
    Get_Game_Success_Title_Str()
    {
        var isubgamename = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype);
        return  isubgamename+"第"+this.m_enter_level+"关闯关成功啦";
 
        
    }
    click_share()
    {
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
      
        var strfenxiangstr = this.Get_Game_Success_Fenxiang_Str();
        var strtile = this.Get_Game_Success_Title_Str();

        var strtyip =strfenxiangstr;// "我在怪兽消除游戏里，第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";

       
    
        if(PlatFormMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_ByteDance
        
        || PlatFormMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_Kuaishou_Xiaoyouxi)
        {
            var self = this;
            PlatFormMng.GetInstance().Fengxiang_Youxi_Luping(strtile,strtyip,
            (bsuc,errmsg)=>
            {
                if(bsuc)
                {  
                    BaseUIUtils.ShowTipTxtDlg( "分享成功",this.node);
                  //  BaseUIUtils.ShowTipTxtDlg("分享成功",self.node)
                }else{
                    BaseUIUtils.ShowTipTxtDlg(""+ errmsg,this.node);
                    //BaseUIUtils.ShowTipTxtDlg("分享失败",self.node)
                }
                
            });
        }else{
           // PlatFormMng.GetInstance().Share_Msg("超好玩的消除小游戏",strtyip);
           PlatFormMng.GetInstance().Share_Msg(strtile,strtyip);

        }
    }
    click_home() {
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
      
      //  MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner();

       // Core.win.open(GameConst.winPath.MenuWin, null, true)
    }
   
}
