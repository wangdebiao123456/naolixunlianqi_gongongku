 
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import WMap from "../WDT/WMap";
import ComCodeFuncMng from "../comfuncs/ComCodeFuncMng";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
 


const {ccclass, property} = cc._decorator;

@ccclass
export default class gamefail_continue_game extends cc.Component {

  
    m_isubgametype = 0;
    m_cb = null;
    
    m_tuijianwe_dest_info_map = new WMap();
    m_last_tuijian_change_tick_map = new WMap();
    
    onLoad () {


        var btn_queding = cc.find("panel/top/queding",this.node);
        btn_queding.on("click",this.OnBtnQueidng.bind(this));
           
        this.Show_All_Btns(false);

        var idealyshowsec = GlobalGameMng.GetInstance().Get_GameFail_Continue_ChongWan_Dlg_Dealy_Show_Btn_Sec();
        
        this.scheduleOnce(this.FD_InitShow.bind(this),idealyshowsec);


        BannerGuangaoMng.GetInstance().CheckShowChaiping(28);


        MiddleGamePlatformAction.GetInstance().Set_Show_Game_Fail_Continue_Next_Dlg_Banner(true);
    
    }
    OnBtnQueidng()
    {
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_Fail_Continue_Next_Dlg_Banner(false);
   
        if(this.m_cb)
        {
            this.m_cb();
        }

        this.node.destroy();
        
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn');
    }

    Init_Top_Tuijian_Guangao()
    {
        var othergame_node = cc.find("panel/othergame",this.node);

        var bshow = GlobalGameMng.GetInstance().IS_Game_Continue_Fail_Dlg_Tuijianwei_Show();

        if(!bshow)
        {
            othergame_node.active = false;
            return;
        }

        var pos1 = this.m_isubgametype + 41000 ;
        var pos2 =  this.m_isubgametype +42000 ;


        var pos_arr = [pos1,pos2];
        ComCodeFuncMng.Init_Com_Two_Guangao(this,this.node,othergame_node,pos_arr);


    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        var isubgametype = paradata.isubgametype;
        var igk = paradata.igk;

        this.m_isubgametype = isubgametype;

        var gamenode = cc.find("panel/top/gamename",this.node);

        var strname = GlobalGameMng.GetInstance().Get_Game_Type_Name(isubgametype);
        if(!igk)
        {
            igk = 1;
        }

        gamenode.getComponent(cc.Label).string  = "将重新挑战 "+strname+" 第"+igk+"关";

        this.Init_Top_Tuijian_Guangao();
 
    }
    FD_InitShow()
    {
        this.Show_All_Btns(true);

    }
    Show_All_Btns(bshow)
    {
        var btn_queding = cc.find("panel/top/queding",this.node);
        btn_queding.active = bshow;
    }
}
