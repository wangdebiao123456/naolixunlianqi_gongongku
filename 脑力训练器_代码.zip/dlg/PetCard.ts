
const {ccclass, property} = cc._decorator;

@ccclass
export default class PetCard extends cc.Component {

    isFrontSide = true;

 
    
}
