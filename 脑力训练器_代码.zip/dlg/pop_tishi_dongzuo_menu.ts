import ClientLogUtils from "../comfuncs/ClientLogUtils";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import GlobalMng from "../global/GlobalMng";


const {ccclass, property} = cc._decorator;

@ccclass
export default class pop_tishi_dongzuo_menu extends cc.Component {

    m_current_guangka = 0;
    m_isubgametype = 0;
    m_cb = null;
    
    onLoad () 
    {
        var exit_btn = cc.find("node_ui/exit",this.node);
        exit_btn.on("click",this.OnBtnExit.bind(this));

        var i_da_kacount = GlobalMng.GetInstance().GetDaTishiKaCount();
        var i_xiao_kacount = GlobalMng.GetInstance().GetXiaoTishiKaCount();
  
        var zidongtishi_sp = cc.find("node_ui/zidongtishi/sp",this.node);
        var zhubutishi_sp = cc.find("node_ui/zhubutishi/sp",this.node);
   
        
        if(i_da_kacount > 0)
        {
            zhubutishi_sp.active = false;
        }else{
            zhubutishi_sp.active = true;
        }

    
        if(i_xiao_kacount > 0)
        {
            zidongtishi_sp.active = false;
        }else{
            zidongtishi_sp.active = true;
        }



        var zidongtishi_btn = cc.find("node_ui/zidongtishi",this.node);
        var zhubutishi_btn = cc.find("node_ui/zhubutishi",this.node);
   

        zidongtishi_btn.on("click",this.OnBtn_ZidongTishi.bind(this));
        zhubutishi_btn.on("click",this.OnBtn_ZhubuTishi.bind(this));



        
    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;
        this.m_isubgametype = paradata.isubgametype;
        this.m_current_guangka = paradata.igk;

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(91, "弹出使用动作提示", this.m_isubgametype,
        "gametype="+this.m_isubgametype, paradata.igk, "igk:"+paradata.igk, 
         0,"");



    }
    OnBtn_ZhubuTishi()
    {
        var self=  this;

        var i_da_kacount = GlobalMng.GetInstance().GetDaTishiKaCount();

        if(i_da_kacount  >  0)
        {

            if(this.m_cb)
            {
                this.m_cb(4);
            }

            self.node.destroy();

            return;
        } 
   
        var isubgametype = this.m_isubgametype;
        var idaojutype = 100000 + this.m_isubgametype*100 + 4;

       
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node, 
            ()=>
            {

            },
            "弹出弹框购买道具",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }
            GlobalMng.GetInstance().Add_DaTishiKa_Count( 2);
      
            //self.Refresh_Daoju_Count_Info();

            //BaseUIUtils.ShowTipTxtDlg("购买获得2个道具成功",this.node);
            if(self.m_cb)
            {
                self.m_cb(4);
            }
            
            ClientLogUtils.GetInstance().Poset_Server_JS_Log(34, "购买道具成功", idaojutype,
            "道具:逐步提示", isubgametype, "道具:逐步提示", self.m_current_guangka,  "第"+self.m_current_guangka+"关");



            self.node.destroy();

        },this.Get_SubGameType());

    }
    Get_SubGameType()
    {
        return this.m_isubgametype;
    }
    OnBtn_ZidongTishi()
    {
        var self=  this;

        var i_xiao_kacount = GlobalMng.GetInstance().GetXiaoTishiKaCount();

        if(i_xiao_kacount  >  0)
        {

            if(this.m_cb)
            {
                this.m_cb(3);
            }
            self.node.destroy();

            return;
        } 
   
        var isubgametype = this.m_isubgametype;
        var idaojutype = 100000 + this.m_isubgametype*100 + 3;

   
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node,
            ()=>
            {

            },
            "弹出弹框购买道具",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }
            GlobalMng.GetInstance().Add_XiaoTishiKa_Count( 2);
      
            //self.Refresh_Daoju_Count_Info();

            //BaseUIUtils.ShowTipTxtDlg("购买获得2个道具成功",this.node);
            if(self.m_cb)
            {
                self.m_cb(3);
            }
            
            ClientLogUtils.GetInstance().Poset_Server_JS_Log(34, "购买道具成功", idaojutype,
            "道具:逐步提示", isubgametype, "道具:逐步提示", self.m_current_guangka,  "第"+self.m_current_guangka+"关");



            self.node.destroy();

        },this.Get_SubGameType());
    }
    OnBtnExit()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(0);
        }
    }



}
