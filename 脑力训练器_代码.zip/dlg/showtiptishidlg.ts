import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class showtiptishidlg extends cc.Component {
 

    // 
    m_cb=  null;
    onLoad () 
    {
        var confirm_btn = cc.find("panel/confirm",this.node);

        confirm_btn.on("click",this.OnBtnConfirm.bind(this));

         
    }
    

    OnBtnConfirm()
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(206,false);

        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb();
        }
    }
    setInitData(paradata)
    {

        this.m_cb = paradata.cb;

        var title= paradata.title;
        var content= paradata.content;
 
        var title_label = cc.find("panel/title",this.node);
        title_label.getComponent(cc.Label).string = ""+title;

        var content_label = cc.find("panel/content",this.node);
        content_label.getComponent(cc.Label).string = ""+content;
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(206,true);

     
    }
    


}
