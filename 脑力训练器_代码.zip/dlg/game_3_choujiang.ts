import BaseUIUtils from "../comfuncs/BaseUIUtils";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import ComFunc from "../comfuncs/ComFunc";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class game_3_choujiang extends cc.Component {
 
    
    m_pick_index = -1;
    enablePick = false;

    m_itype  = 0;
    m_cb=  null;
    m_isubgametype = 0;
    m_igk=  0;

    m_libao_award_list=  [];

    m_hunlanged = false;
    
    m_chou_one_animate_finished_count = 0;
    m_pic_all_jiangli = 0;
    m_real_award_list = [];


    @property(cc.Node)
    ButtonOk = null;
    
    @property(cc.Node)
    ButtonPickOne = null;

    @property(cc.Node)
    ButtonGetAll = null;

    @property(cc.Node)
    textTitle = null;


    @property(cc.Node)
    textNote = null;




    @property(cc.Node)
    centerPos = null;

    


    @property(cc.Prefab)
    choujiang_per_wuping = null;

    
    m_src_pos_list = [];


    m_CardPos = [];
    
    m_Card_real_node = [];
   
    onLoad () 
    {


        this.ButtonPickOne.on("click",this.onClickPickOne.bind(this));
        this.ButtonGetAll.on("click",this.onClickGetAll.bind(this));
        this.ButtonOk.on("click",this.onClickOK.bind(this));

        BackGroundSoundUtils.GetInstance().Pause_Background_Music();

       for(var ff=1;ff<=5;ff++)
       {
            var wuping_ff = cc.find("panel/wuping/"+ff,this.node);

            this.m_src_pos_list[ff-1]= wuping_ff.position;
            wuping_ff.on("click",this.onClick_Sel_One.bind(this,ff));
       }

       
    }
    onClickOK()
    {
        if(this.m_pick_index < 0)
        {
            return;
        }

        

        var awradlist = this.Get_Choujiang_Award();
        var real_awrd_info = awradlist[this.m_pick_index];

        this.m_real_award_list = [];
        this.m_real_award_list.push(real_awrd_info);

        this.RealLingqu();
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
    
    }
    onClick_Sel_One(findex)
    {
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickcube')
    
        console.log("onClick_Sel_One findex="+findex);

        if(!this.enablePick)
        {
            return;
        }
        this.ButtonOk.active =  true;
        cc.tween(this.ButtonOk).to(.3, {
            opacity: 255
        }).start();

        this.enablePick = !1;
        this.textNote.stopAllActions();
        cc.tween(this.textNote).to(.3, {
            opacity: 0
        }).start();



        var real_card = this.m_Card_real_node[findex-1];


        ComFunc.flip(real_card, 0, !0);

        this.m_pick_index = findex - 1;

        var PetCard =  real_card.getComponent("PetCard");
        PetCard.isFrontSide = true;
         

    }
    AllFlipToFrontSmart(x) 
    {
        void 0 === x && (x = 0);
        for (var c = 0; c < this.m_CardPos.length; c++) {
            var f = this.m_CardPos[c].children[0];
            ComFunc.flip(f, c * x, !0)
        }
    }
    RealLingqu()
    {
        this.ButtonPickOne.active = false;
        this.ButtonGetAll.active = false;
        this.ButtonOk.active = false;

     
        if(this.m_pic_all_jiangli)
        {
            this.AllFlipToFrontSmart(0);
            
      
            var self = this;
            for (var   c = 0; c < self.m_CardPos.length; c++)
             {
                    var f = self.m_CardPos[c];
                  
                    var  e = cc.tween().to(.6,
                    {
                        easing: "sineOut"
                    });
                    var a = cc.tween().to(.6,
                    {
                        easing: "sineIn"
                    });
    
                    var newaction = cc.tween().to(.6, {
                        opacity: 160
                    });
                    cc.tween(f).delay(.6 + .05 * c).parallel(e, a, newaction).start()
                
            }

            this.scheduleOnce(this.FD_Real_GetAll.bind(this),2);

        }else{

            this.scheduleOnce(this.FD_Real_GetAll.bind(this),0.5);

        }
        

       

    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        this.m_itype = paradata.itype;
        this.m_isubgametype = paradata.isubgametype;
        this.m_igk = paradata.igk;

        var reward_list = paradata.reward_list;

        this.m_libao_award_list = this.Get_Default_Award();

        if(reward_list && reward_list.length > 0)
        {
            this.m_libao_award_list = reward_list;
        }

       
        MiddleGamePlatformAction.GetInstance().Set_Game_Libao_Dlg_Gezi_Sgow(false);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(16,true);
        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(2);
     



    }
    FD_Real_GetAll()
    {
        BackGroundSoundUtils.GetInstance().ResumeBkMusic();
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(16,false);
        BackGroundSoundUtils.GetInstance().Play_Effect("com/huoquwuping");

        GlobalGameMng.GetInstance().Common_Add_Award_List(this.m_real_award_list,1);
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(1,this.m_real_award_list,this.m_pic_all_jiangli);
        }
    

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(118, "抽奖礼包领取", this.m_pic_all_jiangli,
        "抽完"+this.m_pic_all_jiangli, this.m_isubgametype, "类型:"+this.m_isubgametype, this.m_igk,  "第"+this.m_igk+"关");

    }
    onClickGetAll() 
    {
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
    
        var self = this;

        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node, 
            ()=>
            {
                MiddleGamePlatformAction.GetInstance().Set_Game_Libao_Dlg_Gezi_Sgow(false);
      
            },
            "抽奖全要",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.m_pic_all_jiangli = 1;

            self.m_real_award_list = self.m_libao_award_list;
            self.RealLingqu();

        });
    }



    start() 
    {

        var CardPos:cc.Node[] = new Array(5);
        this.m_CardPos = CardPos;

        for(var ff=1;ff<=5;ff++)
        {
            var wuping_node_f =  cc.find("panel/wuping/"+ff,this.node);
            CardPos[ff-1] = wuping_node_f;
        }

        var x = this;
        this.ButtonGetAll.opacity = 0,
        this.ButtonPickOne.opacity = 0,
        this.ButtonOk.opacity = 0;
        this.textNote.opacity = 0;

        for (var c = 0; c < CardPos.length; c++) {
            var f = CardPos[c];
            f.getComponent(cc.Sprite).spriteFrame = null,

          //  f.active = false;
            f.scaleX = 1;
            f.skewX = 0;
            f.skewY = 0
        }

        /*
        for (var _ = [9, 10, 4, 6, 7], e = new Array, c = 0; c < 5; c++) {
            var a = _[c]; --a,
            e.push(common.GetInstance().newPet(a, !1))
        }
        this.pets = e,

  */

        var self = this;
        setTimeout(function() {
            self.init()
        },
        1600);
      


        this.textTitle.y = 200,
        this.textTitle.opacity = 0,
        this.textTitle.scale = 4,
        cc.tween(this.textTitle).delay(.2).to(.5, {
            y: 100,
            opacity: 255,
            scale: 1
        },
        {
            easing: "quadIn"
        }).delay(.2).to(1, {
            y: 500
        },
        {
            easing: "quadOut"
        }).start()
    }

    Get_Choujiang_Award()
    {

        return this.m_libao_award_list;
    }
    Get_Default_Award()
    {

        var awrdlist = [];

        for(var gg=1;gg<=1;gg++)
        {
          //  var gg_t = 10+gg;
            var gg_c=  200;
            awrdlist.push({"t":1,"c":gg_c});
        }
        
        for(var gg=2;gg<=5;gg++)
        {
            var gg_t = 10+gg-1;
            var gg_c= 1;
            awrdlist.push({"t":gg_t,"c":gg_c});
        }
        


        return awrdlist;
    }
    genCards () 
    {
        var  awrdlist = this.Get_Choujiang_Award();

        for (var c = 0; c < 5; c++) 
        {
            var awrd_t=  null;
            if(awrdlist.length <= c)
            {
                awrd_t  = {"t":1,"c":100};
            }else{
                awrd_t=  awrdlist[c];
            }
             
            var t =  cc.instantiate(this.choujiang_per_wuping);

            t.opacity = 0;
            this.m_CardPos[c].addChild(t);
            t.y = 300;
            t.scale = 2.5;
            var  _ = cc.tween().to(.15, {
                opacity: 255
            }),
            a = cc.tween().to(.5, {
                y: 0,
                scale: 1
            },
            {
                easing: "sineOut"
            });
            cc.tween(t).delay(.1 * c).parallel(_, a).start();


            this.m_Card_real_node[c] = t;
            var n_node = t.getChildByName("wuping").getChildByName("n");
            var tt_name = GlobalGameMng.GetInstance().Get_DaojuType_Show_Name(awrd_t.t);
            n_node.getComponent(cc.Label).string = tt_name+"x"+awrd_t.c;

            var  FrameSelect = t.getChildByName("FrameSelect");
            FrameSelect.opacity = 0;
             
            var icon_node = t.getChildByName("wuping").getChildByName("icon");
            var sicon = GlobalGameMng.GetInstance().Get_Aawrd_Daoju_Icon(awrd_t.t);

            var  back_node = t.getChildByName("back");
            back_node.opacity = 0;
       
            BaseUIUtils.ShowIconNodePicFilename(icon_node,sicon,{cx:97,cy:102})
        }
    }
    AllFlipToFront () 
    {
        for (var x = 0; x < this.m_CardPos.length; x++) 
        {
            ComFunc.flip(this.m_CardPos[x].children[0], .1 * x, !0)

        }
    }
    init()
    {
        this.genCards();
        this.AllFlipToFront();

        cc.tween(this.ButtonGetAll).delay(1).to(.3, {
            opacity: 255
        }).start();

        cc.tween(this.ButtonPickOne).delay(1).to(.3, {
            opacity: 255
        }).start();
    }
    AllFlipToBack () {
        for (var x = 0; x < this.m_Card_real_node.length; x++)  
        {
            ComFunc.flip(this.m_Card_real_node[x], .1 * x, !1);
        }
    }

    Add_Per_Card_Animate(a)
    {
        
        var self = this;
        var e = self.centerPos.position;
        var x = self.m_CardPos[a];
        var c = x.position.clone();
        var  ff_light = self.m_Card_real_node[a].getChildByName("FrameSelect");
        
            var  _ = Math.round(360 * Math.random());
            cc.tween(x).to(.4 + .05 * a, {
                position: e,
                angle: -180 - _
            }).to(1.1 + .15 * a, {
                angle: -1800
            }).to(.6, {
                position: c,
                angle: -2520
            },
            {
                easing: "quadOut"
            }).to(0, {
                angle: 0
            }).call(function() {
                self.m_chou_one_animate_finished_count++;
                cc.tween(ff_light).repeatForever(cc.tween(ff_light).to(.5, {
                    opacity: 255
                }).to(.5, {
                    opacity: 0
                }).start()).start()
            }).start()
    }
    FD_Chou_One_Animate()
    {
        this.m_chou_one_animate_finished_count = 0;
        var self = this;
        var e = self.centerPos.position;
        for ( var a = 0; a < 5; a++) 
        {
            this.Add_Per_Card_Animate(a);
            
        } 
    }
    Check_Can_Hunlang()
    {
        if(this.m_hunlanged)
        {
            return;
        }
       
        if(this.m_chou_one_animate_finished_count >= 5)
        {
            this.m_hunlanged = true;
            this.HunLangCards();
        }

    }
    HunLangCards()
    {
        var t=  this;
        var src_pos_list = this.m_src_pos_list.slice(0);
 


        for(var ff=0;ff<5;ff++)
        {
            var ff_card = this.m_CardPos[ff];
            
            var left_l = Math.floor(Math.random()*src_pos_list.length);
            if(left_l >= src_pos_list.length || left_l <= 0)
            {
                left_l = 0;
            }
            ff_card.position= src_pos_list[left_l];
            src_pos_list.splice(left_l,1);
        }

        t.enablePick = true;
        t.textNote.opacity = 200;
        cc.tween(t.textNote).repeatForever(cc.tween(t.textNote).to(.3, {
            scale: 1.03
        }).to(.3, {
            scale: 1
        }).to(.3, {
            scale: 1.03
        }).to(.3, {
            scale: 1
        }).delay(2.1).start()).start();
    }
    onClickPickOne () 
    {
        var t = this;
        this.AllFlipToBack();
        this.enablePick = false;




        this.scheduleOnce(this.FD_Chou_One_Animate.bind(this),1.2);

       
 

 


        this.schedule(this.Check_Can_Hunlang.bind(this),0.3);
        this.ButtonPickOne.active = !1; 
        
        BackGroundSoundUtils.GetInstance().Play_Effect('com/huangdong')
    
        


    }
}
