import ComFunc from "../comfuncs/ComFunc";
import shuziHuaRongDaoLogicMng from "../shuzihuarongdao/shuziHuaRongDaoLogicMng";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import BaseUIUtils from "../comfuncs/BaseUIUtils";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class shuzihuarongdao_sel_mode extends cc.Component {

   
    m_parentgame = null;
    m_cb = null;
    
    onLoad () 
    {
        var exit_btn = cc.find("node_ui/exit",this.node);
        exit_btn.on("click",this.OnBtnExit.bind(this));
        

        for(var ff=3;ff<=10;ff++)
        {
            var ff_node=  cc.find("node_ui/mode/"+ff,this.node);
            ff_node.on("click",this.OnBtnSelMode.bind(this,ff))
        }
    
    
        this.Refresh_Jiesuo_Flags();
    }
    OnBtnExit()
    {
        this.node.destroy();
    }
    Refresh_Jiesuo_Flags()
    {
        for(var ff=5;ff<=10;ff++)
        {
            var ff_node=  cc.find("node_ui/mode/"+ff+"/sp",this.node);

            var bjiesuoed = shuziHuaRongDaoLogicMng.GetInstance().IS_ModeType_Jiesuoed(ff);

            if(bjiesuoed)
            {
                ff_node.active = false;
            }else{
                ff_node.active = true;
            }

        }
    }

    SetInitData(paradata)
    {
        this.m_parentgame = paradata.parentgame;
     
        this.m_cb = paradata.cb;

    }
    OnBtnSelMode(imode)
    {

        var bjiesuoed = shuziHuaRongDaoLogicMng.GetInstance().IS_ModeType_Jiesuoed(imode);


        var self=  this;
        if(!bjiesuoed)
        {

            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node,

                ()=>
                {

                },
                
                
                "视频解锁华容道模式",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
                shuziHuaRongDaoLogicMng.GetInstance().Set_ModeType_Jiesuoed(imode);
                BaseUIUtils.ShowTipTxtDlg("模式解锁成功",this.node);

                self.Refresh_Jiesuo_Flags();
            },"");


            return;
        }


        var bneedselgk = true;

        if(imode <= 4)
        {
            var igk = shuziHuaRongDaoLogicMng.GetInstance().Get_Sub_Mode_Max_Can_Enter_GK(imode);
     
            if(igk  <= 1)
            {
                bneedselgk = false;
            }
        }
        bneedselgk = false;

        if(bneedselgk)
        {

            this.m_cb (imode);
        }
        else{
            ComFunc.OpenNewDialog(this.node,"preab/shuzihuarogndao/shuzihuarongdao_confirm_mode","shuzihuarongdao_confirm_mode",{imode:imode});


        }
       
    }

}
