 
import BaseUIUtils from "../comfuncs/BaseUIUtils"; 
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class game_shoukan_libao extends cc.Component {

    @property
    m_b_need_guangao = 0;

  
    m_itype  = 0;
    m_cb=  null;
    m_isubgametype = 0;
    m_igk=  0;

    m_libao_award_list=  [];
    
    onLoad () 
    {
        var exit = cc.find("panel/exit",this.node);
        exit.on("click",this.OnBtnExit.bind(this));
        
        var lignqubtn = cc.find("panel/lignqubtn",this.node);
        lignqubtn.on("click",this.OnBtnLingqu.bind(this));
       
        for(var ff=1;ff<=4;ff++)
        {
            var ff_ndoe = cc.find("panel/wuping/"+ff+"/g",this.node);
            ff_ndoe.runAction(cc.repeatForever(cc.rotateBy(0.3,5)));
        }


        var ff_g2 = cc.find("panel/wuping/"+"g",this.node);
        ff_g2.runAction(cc.repeatForever(cc.rotateBy(0.3,10)));
   

        this.Show_All_Btns(false);

        var idealyshowsec = GlobalGameMng.GetInstance().Get_ShouKan_Libao_Dlg_Dealy_Show_Btn_Sec();
        
        this.scheduleOnce(this.FD_InitShow.bind(this),idealyshowsec);



        BannerGuangaoMng.GetInstance().CheckShowChaiping(7);


       
      

    }
    FD_InitShow()
    {
        this.Show_All_Btns(true);

    }
    Show_All_Btns(bshow)
    {
        var exit = cc.find("panel/exit",this.node);
       
        var lignqubtn = cc.find("panel/lignqubtn",this.node);
      
        exit.active = bshow;
     
        lignqubtn.active = bshow;
      
    }
    OnBtnExit()
    {
        MiddleGamePlatformAction.GetInstance().Set_Game_Libao_Dlg_Gezi_Sgow(false);
      
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(16,false);


        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(0);
        }

    }
    Get_Game_Libao_Award()
    {

        var awrdlist = [];

        for(var gg=1;gg<=4;gg++)
        {
            var gg_t = 10+gg;
            awrdlist.push({"t":gg_t,"c":2});
        }
        /*
        if(this.m_isubgametype == 1 || this.m_isubgametype == 2)
        {

            for(var gg=1;gg<=4;gg++)
            {
                var gg_t = 100*this.m_isubgametype+gg;
                awrdlist.push({"t":gg_t,"c":2});
            }
 
        }
        else{
            for(var gg=1;gg<=3;gg++)
            {
                var gg_t = 100*this.m_isubgametype+gg;
                awrdlist.push({"t":gg_t,"c":2});
            }
        }
        */

 



        return awrdlist;
    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        this.m_itype = paradata.itype;
        this.m_isubgametype = paradata.isubgametype;
        this.m_igk = paradata.igk;


        if(this.m_b_need_guangao)
        {
            MiddleGamePlatformAction.GetInstance().Set_Game_Libao_Dlg_Gezi_Sgow(true);
      
        }else{
            MiddleGamePlatformAction.GetInstance().Set_Game_Libao_Dlg_Gezi_Sgow(false);
      
        }
      
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(16,true);
        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(2);
    

        var awardlist =  this.Get_Game_Libao_Award();
        this.m_libao_award_list = awardlist;

       // var biaoti_label = cc.find("panel/btk/t",this.node);
   
        
        var desc1 = cc.find("panel/desc1",this.node);
        var desc2 = cc.find("panel/desc2",this.node);
       
        if(this.m_itype == 1)
        {
            desc1.active = true;
            desc2.active = false;

           // biaoti_label.getComponent(cc.Label).string = "首玩礼包";

        }else{
            desc1.active = false;
            desc2.active = true;

           // biaoti_label.getComponent(cc.Label).string = "过关礼包";

        }


        for(var ff=1;ff<=4;ff++)
        {
            var ff_node=  cc.find("panel/wuping/"+ff,this.node);
            ff_node.active = false;

            if(awardlist.length == 3 && ff == 3)
            {
                ff_node.x = 0;
            }
        }

        for(var ff=1;ff<=awardlist.length;ff++)
        {
            var ff_node=  cc.find("panel/wuping/"+ff,this.node);
            ff_node.active = true;
            var ff_info = awardlist[ff - 1];

            var ff_t =  ff_info.t;
            var ff_c =  ff_info.c;
            

            var c_label = ff_node.getChildByName("c");
            c_label.getComponent(cc.Label).string = "x"+ff_c;

            var icon_label = ff_node.getChildByName("icon");

          // var sicon = GlobalGameMng.GetInstance().Get_Aawrd_Daoju_Icon(ff_t);

         
      
          //  BaseUIUtils.ShowIconNodePicFilename(icon_label,sicon);


        }



    }

    RealLingqu()
    {
        
        MiddleGamePlatformAction.GetInstance().Set_Game_Libao_Dlg_Gezi_Sgow(false);
      
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(16,false);



        GlobalGameMng.GetInstance().Common_Add_Award_List(this.m_libao_award_list,1);

        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(1,this.m_libao_award_list);
        }
    
    }

    OnBtnLingqu()
    {
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn');
    
        var self = this;


        var sname = "领取首看礼包";
        if(this.m_itype == 1)
        {
            sname = "领取首看礼包";
        }else{
            sname = "领取过关礼包";
        }

        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node, 
            ()=>
            {
                MiddleGamePlatformAction.GetInstance().Set_Game_Libao_Dlg_Gezi_Sgow(false);
      
            },
            sname,(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.RealLingqu();

        });
    }

}
