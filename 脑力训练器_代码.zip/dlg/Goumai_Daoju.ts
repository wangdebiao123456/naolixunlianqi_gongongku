import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction"; 
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng"; 
import BaseUIUtils from "../comfuncs/BaseUIUtils";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";



const {ccclass, property} = cc._decorator;

@ccclass
export default class Goumai_Daoju extends cc.Component {

    m_itype=  0;
    data= null;
    m_bchaonan=  0;

    m_cur_level = 0;

    onLoad () 
    {

        var exitbtn = cc.find("node_ui/exit",this.node);
        exitbtn.on("click",this.OnBtnExit.bind(this));
        
        var cancel = cc.find("node_ui/cancel",this.node);
        cancel.on("click",this.OnBtnExit.bind(this));
        

 
        var goumai = cc.find("node_ui/goumai",this.node);
        goumai.on("click",this.OnBtnGoumai.bind(this));



        var jinbigoumai = cc.find("node_ui/jinbigoumai",this.node);
        jinbigoumai.on("click",this.OnBtnJinbiGoumai.bind(this));


        
        this.Show_All_Btns(false);

        var idealyshowsec = GlobalGameMng.GetInstance().Get_Sanxiaoxiao_GoumaiDaoju_Dlg_Dealy_Show_Btn_Sec();
       
        this.scheduleOnce(this.FD_InitShow.bind(this),idealyshowsec);



      //  MiddleGamePlatformAction.GetInstance().Check_Show_Bottom_Banner();
   

        BannerGuangaoMng.GetInstance().CheckShowChaiping(9);


    }
    FD_InitShow()
    {
        this.Show_All_Btns(true);
    }
    Show_All_Btns(bshow)
    {
        var exitbtn = cc.find("node_ui/exit",this.node);
        var goumai = cc.find("node_ui/goumai",this.node);
        var jinbigoumai = cc.find("node_ui/jinbigoumai",this.node);
    
        exitbtn.active = bshow;
        goumai.active = bshow;
        jinbigoumai.active = bshow;
        
    }
    SetInitData(paradata)
    {
        this.data=paradata;

        this.m_bchaonan = paradata.bchaonan;

        this.m_cur_level = paradata.igk;

        this.UpdateInfo(); 

        MiddleGamePlatformAction.GetInstance().Set_SanXiaoxiao_GoumaiDaouju_Dlg_Gezi_Sgow(true);

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(12,true);
        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(9);
    }
 
    
    Get_Goumai_Daoju_Type_Count(itype)
    {

        var icount = GlobalGameMng.GetInstance().Get_Sanxiaoxiao_Daojutype_Per_Shiping_Goumai_Count(itype);

        return icount;

        /*
        if(itype == 1)
        {
            return 5;
        }
        else if(itype == 2)
        {
            return 1;
        } 
        else if(itype == 3)
        {
            return 5;
        }
        else if(itype == 4)
        {
            return 3;
        }





        return 3;
        */
    }

    UpdateInfo()
    {
        this.m_itype = this.data.itype;

        var tip = cc.find("node_ui/tip",this.node);

        if(this.m_itype == 1)
        {
            tip.getComponent(cc.Label).string = "撤回上一次点击转块\n并放回原位置";

        }
        else if(this.m_itype == 2)
        {
            tip.getComponent(cc.Label).string = "移出三个砖块并把他们\n堆放到旁边";

        }  
         else if(this.m_itype == 3)
        {
            tip.getComponent(cc.Label).string = "获得可以消除砖块的\n一次提示";

        } else if(this.m_itype == 4)
        {
            tip.getComponent(cc.Label).string = "随机打乱未使用的所有砖块";

        }

    
        for(var ff=1;ff<=4;ff++)
        {
            var ff_node = cc.find("node_ui/yuan/"+ff,this.node);
            ff_node.active = false;

            if(ff == this.m_itype)
            {
                ff_node.active = true;
            }
        }


        var desc = cc.find("node_ui/goumai/desc",this.node);
        desc.getComponent(cc.Label).string = "免费获取(+"+this.Get_Goumai_Daoju_Type_Count(this.m_itype)+")";

       

    }
    OnBtnExit()
    {
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn'); 
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(12,false);
         MiddleGamePlatformAction.GetInstance().Set_SanXiaoxiao_GoumaiDaouju_Dlg_Gezi_Sgow(false);
   
       
    //    this.data.callback&&this.data.callback(0)
        this.close()
    }
    RealGoumai(icount)
    {
      
        if(this.m_itype == 1)
        {
            GSXC_Game_Mng.GetInstance().itemUndo += icount;
        } 
        else if(this.m_itype == 2)
        {
            GSXC_Game_Mng.GetInstance().itemYichu += icount;
        } else if(this.m_itype == 3)
        {
            GSXC_Game_Mng.GetInstance().itemHint += icount;
        }else if(this.m_itype == 4)
        {
            GSXC_Game_Mng.GetInstance().itemShuffle += icount;
        }
      
        GSXC_Game_Mng.GetInstance().Save_Game_Basic_Info();


        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(12,false);
        MiddleGamePlatformAction.GetInstance().Set_SanXiaoxiao_GoumaiDaouju_Dlg_Gezi_Sgow(false);
  


        this.data.callback&&this.data.callback();
        this.close();


    }
    OnBtnGoumai()
    {

      


        var self = this;
        var isubgametype=  this.m_bchaonan ? 9:1;
        var idaojutype = 100000 + isubgametype*100 + this.m_itype;




        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node, 
            ()=>
            {
                MiddleGamePlatformAction.GetInstance().Set_SanXiaoxiao_GoumaiDaouju_Dlg_Gezi_Sgow(false);
 
            },
            "购买三消消道具",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }

            var icount = this.Get_Goumai_Daoju_Type_Count(self.m_itype);

            self.RealGoumai(icount);


            
         
            ClientLogUtils.GetInstance().Poset_Server_JS_Log(34, "购买道具成功", idaojutype,
            "道具:三消消"+this.m_itype, isubgametype,  "道具:三消消"+this.m_itype, 
            self.m_cur_level,  "第"+self.m_cur_level+"关");



        }, self.m_bchaonan ? 9:1, self.m_itype);
    }
    OnBtnJinbiGoumai()
    {
        var imoney = GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(1);

        if(imoney < 200)
        {
            BaseUIUtils.ShowTipTxtDlg("金币不足,无法购买!",this.node);
            return;
        }

        GlobalGameMng.GetInstance().Change_Self_DaojuType_Count(1,-200);
        this.RealGoumai(1);


        ClientLogUtils.GetInstance().Poset_Server_JS_Log(61, "三消消金币购买道具", this.m_itype,
        this.m_itype+"", 0, "", 0, "");
    }

    close()
    {
        this.node.destroy();
    }
}
