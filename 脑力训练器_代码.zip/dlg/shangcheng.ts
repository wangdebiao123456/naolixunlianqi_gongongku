import BaseUIUtils from "../comfuncs/BaseUIUtils";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import ComFunc from "../comfuncs/ComFunc";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import MyLocalStorge from "../WDT/MyLocalStorge";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class shangcheng extends cc.Component {

   

    
    m_cb = null;
    onLoad () 
    {
        var btn_exit = cc.find("panel/exit",this.node);
        btn_exit.on("click",this.OnBtnExit.bind(this));



        for(var ff=1;ff<=4;ff++)
        {
       
            var ff_btn = cc.find("panel/wuping/"+ff+"/gooumai",this.node);
            ff_btn.on("click",this.OnBtnGoumai.bind(this,ff));


            var ff_shiping = cc.find("panel/wuping/"+ff+"/shiping",this.node);
            ff_shiping.on("click",this.OnBtnShiping.bind(this,ff));

 
        }
        
        BannerGuangaoMng.GetInstance().CheckShowChaiping(14);

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(19,true);
        MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);
    
        this.Refresh_All_Daoju_Count();

        var shangchrngtip = GlobalGameMng.GetInstance().Get_Shangcheng_Bottom_Tip();

        var bottomdesc=  cc.find("panel/bottomdesc",this.node);
        bottomdesc.getComponent(cc.Label).string = ""+shangchrngtip;
        
        this.schedule(this.FD_Timer.bind(this),10);
    }

    OnBtnExit()
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(19,false);
      
        this.node.destroy();
       
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn');

        if(this.m_cb)
        {
            this.m_cb();

        }
     
    }
    FD_Timer()
    {
        this.Refresh_All_Daoju_Count();
    }


    Add_Daoju_CurDay_Lianxu_Goumai_Count(idoajutype,iaddcount)
    {
        var prevc = this.Get_Daoju_CurDay_Lianxu_Goumai_Count(idoajutype);
        var strdaiju_info = "shnm_sc_daoju_"+idoajutype+"_lianxu_goumai_info";
        var icurdayunion  = ComFunc.GetCurDayUnion();

        var inewcc = prevc + iaddcount;

        var pinfo ={
            iLastSaveDay:icurdayunion,
            dayGoumaiCount:inewcc
        };

        MyLocalStorge.setItem(strdaiju_info,JSON.stringify(pinfo));

    }
    Get_Daoju_CurDay_Lianxu_Goumai_Count(idoajutype)
    {
        var strdaiju_info = "shnm_sc_daoju_"+idoajutype+"_lianxu_goumai_info";

        var sinfo = MyLocalStorge.getItem(strdaiju_info);

        if(!sinfo)
        {
            return 0;
        }

        var pobj  = JSON.parse(sinfo);
        if(!pobj)
        {
            return 0;
        }

        var iLastSaveDay = pobj.iLastSaveDay ;
        var icurdayunion  = ComFunc.GetCurDayUnion();

        if(icurdayunion != iLastSaveDay)
        {
            return 0;
        }

        var dayGoumaiCount = pobj.dayGoumaiCount;

        if(!dayGoumaiCount)
        {
            return 0;
        }

        return dayGoumaiCount;
    }
    Refresh_All_Daoju_Count()
    {
        var jinb_c = cc.find("panel/jinbi/c",this.node);
        jinb_c.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(1);


        for(var ff=1;ff<=4;ff++)
        {
            var ff_c_node = cc.find("panel/wuping/"+ff+"/c",this.node);
            ff_c_node.getComponent(cc.Label).string = "现有:"+GlobalGameMng.GetInstance().Common_Get_Daoju_Count(ff+10);


            var ff_lianxu_node = cc.find("panel/wuping/"+ff+"/lianxuc",this.node);
            var idoajutype = 10+ff;
 
            var icount_ff = this.Get_Daoju_CurDay_Lianxu_Goumai_Count(idoajutype);

            if(icount_ff == 0)
            {
                ff_lianxu_node.getComponent(cc.Label).string = "";
            }else{
                ff_lianxu_node.getComponent(cc.Label).string = "今日连续购买:"+icount_ff;
            }
        }
        
    }

    SetInitData(pdata)
    {


        this.m_cb = pdata.cb;
    }
    OnBtnGoumai(iindex)
    {
        var ijinbicopunt = GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(1);
        if(ijinbicopunt < 200)
        {
            BaseUIUtils.ShowTipTxtDlg("金币不足200",this.node);
            return;
        }
      
        var idoajutype = 10+iindex;
        var awrad = [{"t":idoajutype,"c":1}];
    
        GlobalGameMng.GetInstance().Common_Add_Award_List(awrad,1);
        GlobalGameMng.GetInstance().Change_Self_DaojuType_Count(1,-200);
       // BaseUIUtils.ShowTipTxtDlg("购买道具成功",this.node);
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrad, 1,null);

        this.Refresh_All_Daoju_Count();


        ClientLogUtils.GetInstance().Poset_Server_JS_Log(41, "商城金币购买道具", idoajutype,
          GlobalGameMng.GetInstance().Get_DaojuType_Show_Name(idoajutype), 0, "", 0, "");
    }

    On_Shiping_Real_Goumai_Daoju(idoajutype)
    {

        this.Add_Daoju_CurDay_Lianxu_Goumai_Count(idoajutype,1);

        //判断
        var idaoju_lianxu_count = this.Get_Daoju_CurDay_Lianxu_Goumai_Count(idoajutype);

        var ijianglic = GlobalGameMng.GetInstance().Get_Shangcheng_Lianxu_Shiping_Goumai_Count_Need_Jiangli_C(idaoju_lianxu_count);


     

        var inewbeishu   = 1 + ijianglic;


        var awrad = [{"t":idoajutype,"c":2}];
        GlobalGameMng.GetInstance().Common_Add_Award_List(awrad,inewbeishu); 
       // BaseUIUtils.ShowTipTxtDlg("视频购买道具成功",this.node);
     
        this.Refresh_All_Daoju_Count();
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrad, inewbeishu ,null);

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(42, "商城视频购买道具", idoajutype,
          GlobalGameMng.GetInstance().Get_DaojuType_Show_Name(idoajutype), 0, "", 0, "");


          if(ijianglic > 0)
          {
              BaseUIUtils.ShowTipTxtDlg("连续视频购买"+idaoju_lianxu_count+"次,获得奖励"+ijianglic+"次",this.node,new cc.Vec2(0,400),5,100);
  
              
              ClientLogUtils.GetInstance().Poset_Server_JS_Log(43, "商城连续视频额外奖励", idoajutype,
              GlobalGameMng.GetInstance().Get_DaojuType_Show_Name(idoajutype), ijianglic, ijianglic+"次", 0, "");
          }
    }
    OnBtnShiping(iindex)
    {
        var idoajutype = 10+iindex;
      
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node, 
            ()=>
            {
                MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);
  
            },
            "商城购买道具",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }

            self.On_Shiping_Real_Goumai_Daoju(idoajutype);

        });
    }
}
