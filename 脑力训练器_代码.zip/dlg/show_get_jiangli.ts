 
import BaseUIUtils from "../comfuncs/BaseUIUtils";
import BundleLoadUtils from "../comfuncs/BundleLoadUtils";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class show_get_jiangli extends cc.Component {

   
    m_callback = null;

    onLoad () 
    {
        var lq = cc.find("panel/lq",this.node);
        lq.on("click",this.OnBtnExit.bind(this));

        BackGroundSoundUtils.GetInstance().Play_Effect("com/huoquwuping");
    }
    Get_Node_Pos(alllen,i)
    {
        if(alllen == 1)
        {
            return new cc.Vec2(0,0);
        }

        if(alllen == 2)
        {
            if(i == 0)
            {
                return new cc.Vec2(-100,0);
            }
            return new cc.Vec2(100,0);
        }


        if(alllen == 3)
        {
            if(i == 0)
            {
                return new cc.Vec2(-200,0);
            }
            if(i == 2)
            {
                return new cc.Vec2(200,0);
            }
            return new cc.Vec2(0,95);
        }


        if(alllen == 4)
        {
            if(i == 0)
            {
                return new cc.Vec2(-100,95);
            }
            else if(i == 1)
            {
                return new cc.Vec2(100,95);
            }
            else if(i == 2)
            {
                return new cc.Vec2(-100,-130);
            }
            return new cc.Vec2(100,-130);
        }
        
        if(alllen == 5)
        {
            if(i == 0)
            {
                return new cc.Vec2(-100,95);
            }
            else if(i == 1)
            {
                return new cc.Vec2(100,95);
            }
            else if(i == 2)
            {
                return new cc.Vec2(-200,-130);
            } else if(i == 3)
            {
                return new cc.Vec2(0,-130);
            }else if(i == 4)
            {
                return new cc.Vec2(200,-130);
            }
            return new cc.Vec2(100,-130);
        }
        
        if(alllen >= 6)
        {
            if(i == 0)
            {
                return new cc.Vec2(-200,95);
            }
            else if(i == 1)
            {
                return new cc.Vec2(0,95);
            }
            else if(i == 2)
            {
                return new cc.Vec2(200,95);
            } else if(i == 3)
            {
                return new cc.Vec2(-200,-130);
            }else if(i == 4)
            {
                return new cc.Vec2(0,-130);
            }
            return new cc.Vec2(200,-130);
        }
        
    }
    SetAward(daojulist, multiple)
    {
        
        for (let i = 1; i <= 6; i++) 
        { 

            var ff_ndoe = cc.find("panel/wuping/"+i,this.node);
            ff_ndoe.active = false;
        }
        for (let i = 0; i < daojulist.length; i++) 
        {
            var t = daojulist[i].t;
            var c = multiple*daojulist[i].c;


            var ff_ndoe = cc.find("panel/wuping/"+(i+1),this.node);
            if(!ff_ndoe)
            {
                continue;
            }  
            ff_ndoe.active = true;
            var name_ndoe = ff_ndoe.getChildByName("name");
            
            name_ndoe.getComponent(cc.Label).string = GlobalGameMng.GetInstance().Get_DaojuType_Show_Name(t);
                 
            var reward_ndoe = ff_ndoe.getChildByName("reward");
            reward_ndoe.getComponent(cc.Label).string =  ""+c;

            var sicon = GlobalGameMng.GetInstance().Get_Aawrd_Daoju_Icon(t);
            
            var zs_ndoe = ff_ndoe.getChildByName("zs");
    

            BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",zs_ndoe,sicon,{width:70,height:70});
 

            var newpos = this.Get_Node_Pos(daojulist.length,i)
            ff_ndoe.setPosition(newpos);
        }

        var lq_node = cc.find("panel/lq",this.node);
        if(daojulist.length > 3)
        {
            lq_node.y = -300;
        }else{
            lq_node.y = -200;
        }
    }

    SetCallbackData(callback)
    {

        this.m_callback = callback;
    }

    OnBtnExit()
    {
        this.node.destroy();

        if(this.m_callback)
        {
            this.m_callback();
        }

    }
}
