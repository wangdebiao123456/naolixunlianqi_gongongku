import ClientLogUtils from "../comfuncs/ClientLogUtils"; 
import BannerGuangaoMng from "../WDT/BannerGuangaoMng"; 
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import ComFunc from "../comfuncs/ComFunc";
import GlobalGameMng from "../comfuncs/GlobalGameMng";

 
var DEFAULT_VOLUME = 0.5;

const {ccclass, property} = cc._decorator;

@ccclass
export default class pausedlg extends cc.Component {

    m_cb = null;
    node_ui:cc.Node;
    btn_sound:cc.Button ;
    m_shangcheng_cb = null;
    m_close_cb = null;
    m_tiaoguo_gk_cb = null;
    m_isubgametype = 0;
    m_igk = 0;
    m_last_btn_click_tick = 0;
    m_paihangbang_cb = null;

    m_b_show_tiaoguo_gk = false;


    m_b_hide_shangcheng = false;
  
    onLoad () 
    {
        this.node_ui = cc.find("node_ui",this.node);
        this.btn_sound = cc.find("node_ui/btn_sound",this.node).getComponent(cc.Button);


        
        this.refreshBtns();
   
        this.node_ui.scale = 0.6
        this.node_ui.opacity=0
        cc.tween(this.node_ui).to(0.25, { scale: 1,opacity:255 }, { easing: 'sineOut' }).start()


        var btn_close = cc.find("node_ui/btn_close",this.node);
        btn_close.on("click",this.OnBtnExit.bind(this));
        
  
        var btn_level = cc.find("node_ui/btn_level",this.node);
        btn_level.on("click",this.OnBtnLevel.bind(this));
        
        var btn_shangcheng = cc.find("node_ui/shangcheng",this.node);
        btn_shangcheng.on("click",this.OnBtnShangcheng.bind(this));
      

        var btn_paihang = cc.find("node_ui/paihang",this.node);
        btn_paihang.on("click",this.OnBtnPaihangBang.bind(this));
        
        

        var btn_tiaoguoguangka = cc.find("node_ui/tiaoguoguangka",this.node);
    
        btn_tiaoguoguangka.on("click",this.OnBtnTiaoguoGk.bind(this));
    
       
        var btn_restart = cc.find("node_ui/btn_restart",this.node);
    
        btn_restart.on("click",this.OnBtnFanhuiDating.bind(this));
     
        
        
        var slider_sound = cc.find("node_ui/yliang/slider_sound",this.node);
        slider_sound.on('slide', this.OnSliderSound, this);
        slider_sound.getComponent(cc.Slider).progress = BackGroundSoundUtils.GetInstance().GetEffectSoundVolum();


        
        var prig1 = cc.find("node_ui/yliang/slider_sound/progressBar",this.node);
        prig1.getComponent(cc.ProgressBar).progress = BackGroundSoundUtils.GetInstance().GetEffectSoundVolum()
          

        var slider_music = cc.find("node_ui/yliang/slidermusic",this.node);
        slider_music.on('slide', this.OnSliderMusic, this);
        slider_music.getComponent(cc.Slider).progress = BackGroundSoundUtils.GetInstance().GetBackGroundMusicVolum();

        var prig = cc.find("node_ui/yliang/slidermusic/progressBar",this.node);
        prig.getComponent(cc.ProgressBar).progress = BackGroundSoundUtils.GetInstance().GetBackGroundMusicVolum();


      //  var leftt_node =  cc.find("node_ui/tiaoguoguangka/leftt",this.node);
      //  leftt_node.active = false;
     //   this.schedule(this.FD_Timer.bind(this),0.5);
         
        BannerGuangaoMng.GetInstance().CheckShowChaiping(41);
        
        
    
        
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
    }

    FD_Timer()
    {
        /*
        var leftt_node =  cc.find("node_ui/tiaoguoguangka/leftt",this.node);
        var ilefsec = GlobalGameMng.GetInstance().Get_Tiaoguo_Gk_Action_Need_Left_Sec();

        if(ilefsec > 0)
        {
            leftt_node.active = true;
                
            var iminute = Math.floor(ilefsec/60);
            var irelsec=  ilefsec - 60*iminute;

            var strmin = ""+iminute;
            if(iminute < 10)
            {
                strmin = "0"+iminute;
            }

            var strsec = ""+irelsec;
            if(irelsec < 10)
            {
                strsec = "0"+irelsec;
            }

            leftt_node.getComponent(cc.Label).string = "剩"+strmin+":"+strsec;

        }else{

            leftt_node.active  = false;
        }
        
        */
    }
    SetInitData(paradata)
    {
        this.m_cb =paradata.cb;

        this.m_isubgametype = paradata.isubgametype;

        this.m_paihangbang_cb = paradata.paihangbang_cb;

        this.m_shangcheng_cb = paradata.shangcheng_cb

        this.m_b_hide_shangcheng = paradata.b_hide_shangcheng;


        this.m_igk = paradata.igk;

        var btn_shangcheng = cc.find("node_ui/shangcheng",this.node);
      
        if(this.m_b_hide_shangcheng )
        {
            btn_shangcheng.active = false;
        }

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(1,true);

        MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(true);

        MiddleGamePlatformAction.GetInstance().Ensure_Create_Bk_Tuichu_Queren_Banner();


        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(1)


       // if(paradata.bshowtiaoguogk)
      //  {
            //this.m_b_show_tiaoguo_gk = paradata.bshowtiaoguogk;
       // }
      //  var hidePaihangBang =  paradata.hidePaihangBang;

       // var btn_paihang = cc.find("node_ui/paihang",this.node);

      //  if(hidePaihangBang)
       // {
          //  btn_paihang.active = false;
       // }
        
        var hidexuanguang =  paradata.hidexuanguang;

        var btn_restart = cc.find("node_ui/btn_restart",this.node);

        var btn_level = cc.find("node_ui/btn_level",this.node);


        if(hidexuanguang)
        {
            btn_level.active = false;
            btn_restart.active = true;
            btn_restart.y = -100;

        }else{
            btn_level.active = true;
            btn_restart.active = true;
        }

      //  var btn_tiaoguoguangka = cc.find("node_ui/tiaoguoguangka",this.node);
    //    btn_tiaoguoguangka.active  = this.m_b_show_tiaoguo_gk;
        
 
        this.m_close_cb = paradata.close_cb;

        this.m_tiaoguo_gk_cb = paradata.tiaoguo_gk_cb;

      //  this.FD_Timer();
    }

    RealTiaoGuoGK()
    {
        

    }
    OnBtnTiaoguoGk()
    {
       
    }
    OnSliderMusic(tg){
        //this.pro_music.progress = tg.progress;
      //  this.m_SoundMgr.SetBackGroundMusicVolum(tg.progress);

        var iprogress = Number(tg.progress);
        var prig = cc.find("node_ui/yliang/slidermusic/progressBar",this.node);
        prig.getComponent(cc.ProgressBar).progress = iprogress;
        
        BackGroundSoundUtils.GetInstance().SetBackGroundMusicVolum(iprogress);
    }
    Get_SubGameType()
    {
        return this.m_isubgametype;
    }
    OnSliderSound(tg)
    {
       // this.pro_sound.progress = tg.progress;
        //this.m_SoundMgr.SetEffectSoundVolum(tg.progress);
            var iprogress = Number(tg.progress);
            var prig = cc.find("node_ui/yliang/slider_sound/progressBar",this.node);
            prig.getComponent(cc.ProgressBar).progress = iprogress;
            
            BackGroundSoundUtils.GetInstance().SetEffectSoundVolum(iprogress);

    }
 
    OnBtnLevel()
    {
        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
      
       // MiddleGamePlatformAction.GetInstance().Stop_Luping();
       MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(1,false);
       MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);


        this.node.destroy();


        if(this.m_cb)
        {
            this.m_cb();
        }
      //  cc.director.loadScene("selectGK");
    }
    refreshBtns() {
     //   let v = SoundManager.GetInstance().m_effect_sound_volum;
       // this.btn_sound.node.getChildByName("volume_on").active = v != 0;
       // this.btn_sound.node.getChildByName("volume_off").active = v == 0;

  
    }
  

    OnBtnExit()
    {
        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
      
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(1,false);
        MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);

        this.node.destroy();

        if(this.m_close_cb )
        {
            this.m_close_cb ();
        }
    }

    OnBtnSound()
    {
      //  let v = SoundManager.GetInstance().m_effect_sound_volum;

       // SoundManager.GetInstance().SetBackGroundMusicVolum(v == 0 ?  DEFAULT_VOLUME : 0)
       // SoundManager.GetInstance().SetEffectSoundVolum(v == 0 ?  DEFAULT_VOLUME : 0)
    

       // this.refreshBtns();
    }

    On_Open_Close_FanhuiDating_Queren(bopen)
    {
        if(bopen)
        {
            MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);

        }
        else{

            MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(true);

        }

    }
     
    Check_Btn_Enough_Tick()
    {
        if(this.m_last_btn_click_tick > 0)
        {
            if(Date.now() - this.m_last_btn_click_tick < 1000)
            {
                return false;
            }
        }
        this.m_last_btn_click_tick = Date.now();
        return true;
    }
    OnBtnFanhuiDating()
    { 
        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
      
        var self = this;

        if(GlobalGameMng.GetInstance().IS_Game_Pause_Dlg_FanhuiDating_Need_Queren())
        {

            this.On_Open_Close_FanhuiDating_Queren(1)


            ComFunc.OpenNewDialog(this.node,"preab/fanhuidating_queren","fanhuidating_queren",
            {  
                cb:(iselresult)=>
                {
                            
                    if(iselresult > 0)
                    {
                        //返回大厅
                        self.RealFanhuiDating();
                    }
                    else{

                        self.On_Open_Close_FanhuiDating_Queren(0);
                    }
                   
                    
                        
                        
                }}
            );
            
        }else{

            this.RealFanhuiDating();
        }
      
     
 
    }

    RealFanhuiDating()
    {
        MiddleGamePlatformAction.GetInstance().Stop_Luping();
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(1,false);
        MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);


        var isubgametype = this.m_isubgametype;
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(17000+isubgametype, "退出游戏", this.m_igk,
        "第"+this.m_igk+"返回大厅", 0, "", 0, "");
    
        cc.director.loadScene("dating");
    }

    OnBtnShangcheng()
    {
        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(1,false);
        MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);

        this.node.destroy();
        if(this.m_shangcheng_cb)
        {
            this.m_shangcheng_cb();
        }

    }
    OnBtnPaihangBang()
    { 
        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }
        BackGroundSoundUtils.GetInstance().Play_Effect('com/clickbtn')
      
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(1,false);
        MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);

        this.node.destroy();
        if(this.m_paihangbang_cb)
        {
            this.m_paihangbang_cb();
        }
       // this.OnSelectPaihangbangType(this.m_isubgametype)
    }
    OnSelectPaihangbangType(iseltype)
    {

        if(iseltype == 0)
        {
            return;
        }
        var self = this;
    
       
        ComFunc.OpenNewDialog(this.node,"preab/dlg/paihangbang","paihangbang", 
         { 
            iseltype:iseltype,
            cb:(chooseother)=>
            {

                if(chooseother > 0)
                {
                    self.OnSelectOtherPaihangbangType();
                }else{

                    self.On_Paihangbang_Dlg_Close();
                }
                 
            
            }});
    }
    OnSelectOtherPaihangbangType()
    {
        
        var self = this;
    
        ComFunc.OpenNewDialog(this.node,"preab/dlg/select_paihang_type","select_paihang_type", 
         { 
            cb:(iseltype)=>
            {

                self.OnSelectPaihangbangType(iseltype);
                
            }});

    }
    On_Paihangbang_Dlg_Close()
    {
        
    }





}
