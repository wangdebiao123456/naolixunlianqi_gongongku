import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
 
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import BaseUIUtils from "../comfuncs/BaseUIUtils";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class continue_prev_game_confirm extends cc.Component {

  
    m_cb = null;
    
    onLoad () 
    {
        var startnewgame = cc.find("startnewgame",this.node);
        startnewgame.on("click",this.OnBtnStartNewGame.bind(this))

        var jixuyouxi = cc.find("jixuyouxi",this.node);
        jixuyouxi.on("click",this.OnBtnJixuYouxi.bind(this))


        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(7,true);

      
        this.RefreshInfo();

    }

    RefreshInfo()
    {
     //   var ileftcount = GlobalGameMng.GetInstance().Get_Continue_Prev_Game_Left_Count();

        var sp_node = cc.find("jixuyouxi/sp",this.node);
        var tip_node = cc.find("jixuyouxi/tip",this.node);
        sp_node.active = false;
        tip_node.active = false;

        /*
        if(ileftcount > 0)
        {
            sp_node.active = false;
            tip_node.getComponent(cc.Label).string = "剩余"+ileftcount+"次";

        }
        else{

            sp_node.active = true;
            tip_node.getComponent(cc.Label).string = "看视频获5次";

        }
        */
    }
    SetInitData(paradata)
    {
        this.m_cb  = paradata.cb;
      

    }
    OnBtnStartNewGame()
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(7,false);
        if(this.m_cb)
        {
            this.m_cb(0);
        }

        this.node.destroy();
    }

    Real_Jixu_Youxi()
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(7,false);
        if(this.m_cb)
        {
            this.m_cb(1);
        }

        this.node.destroy();
    }
    OnBtnJixuYouxi()
    {
        this.Real_Jixu_Youxi();
        
       
    }


}
