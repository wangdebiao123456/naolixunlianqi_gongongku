import BaseUIUtils from "../comfuncs/BaseUIUtils";
import ComFunc from "../comfuncs/ComFunc";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import GlobalMng from "../global/GlobalMng";
import hmk_tishi_graphic from "../huamukuai/hmk_tishi_graphic";
import GlobalData from "../main/GlobalData";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
import MySprite from "../WDT/MySprite";
import shuziHuaRongDaoLogicMng from "./shuziHuaRongDaoLogicMng";
import WMap from "../WDT/WMap";
import ComCodeFuncMng from "../comfuncs/ComCodeFuncMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import YDActionMng from "../PlayerGuide/YDActionMng";
import PlatFormMng from "../PlatForm/PlatFormMng";
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";
import PlatFormType from "../PlatForm/PlatFormType";
import ChouJiangMng from "../comfuncs/ChouJiangMng";

const {ccclass, property} = cc._decorator;

@ccclass
export default class shuziHuaRongDaoGame extends cc.Component {

   
    m_cur_mode_type=  0;
    m_current_level = 0;



    m_suiji_step_list= [ ];

    m_src_digit_arr = [];
    m_current_digit_arr = [];

    @property(cc.Prefab)
    game_shuzi_perfk = null;


    @property(cc.Prefab)
    help_gametype = null;



    @property(cc.Prefab)
    shouzhiZhiyingDlg: cc.Prefab = null;
    
    

    @property(cc.Prefab)
    gamesuccess_new: cc.Prefab = null;


    @property(cc.Prefab)
    game_end_animate: cc.Prefab = null;

    @property(cc.SpriteFrame)
    shoushi_sprite_frame: cc.SpriteFrame = null;


    m_all_digit_node_list = [];

    m_panzi:cc.Node = null;

    m_step_count = 0;

    m_b_in_playing_steps = false;
    m_playing_steps_list = [];
    m_game_finished = false;


    
    m_b_in_tishi = false;
    m_b_is_auto_tishi = false;

    m_tishi_user_action_move_step =  null;
    m_b_in_tishi_user_action = false;

    m_cur_tishi_jt_node:cc.Node = null;

    m_tishi_jiantou_parent_node =  null;

    m_tishi_grapgic:hmk_tishi_graphic = null;


    
    m_last_tuijian_change_tick = 0;
    m_tuijianwe_dest_info_map=  new WMap();

    m_game_banner_arr = [];


    m_b_inited = false;

    onLoad () 
    {

        var imodetype = shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_mode_type;
        var select_shuzihuarongdao_gk = shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_gk;

        this.m_cur_mode_type=  imodetype;
        this.m_current_level = select_shuzihuarongdao_gk;


        var mubiao_label = cc.find("actionnode/mubiao",this.node);
        mubiao_label.getComponent(cc.Label).string = imodetype+ "x"+imodetype+"模式";

        this.m_panzi = cc.find("actionnode/all_panzi/panzi",this.node);
    
        var leveltip = cc.find("actionnode/bushu/leveltip",this.node);
        leveltip.getComponent(cc.Label).string =  "第"+this.m_current_level +"关";

        var fanhui = cc.find("actionnode/topmenu/fanhui",this.node);
        fanhui.on("click",this.OnBtnBackToHall.bind(this));


        var bangzhu = cc.find("actionnode/topmenu/bangzhu",this.node);
        bangzhu.on("click",this.OnBtnBangzhu.bind(this));

        var tiaoguo = cc.find("actionnode/bottom/tiaoguo",this.node);
        tiaoguo.on("click",this.OnBtnTiaoguo.bind(this));


        var zidongtishi = cc.find("actionnode/bottom/zidongtishi",this.node);
        zidongtishi.on("click",this.OnBtnZidongTishi.bind(this));

        var tishi = cc.find("actionnode/bottom/tishi",this.node);
        tishi.on("click",this.OnBtnTishi.bind(this));

  
        var restart = cc.find("actionnode/bottom/restart",this.node);
        restart.on("click",this.OnBtnChongWan.bind(this));


        var tuijian_new = cc.find("actionnode/bottom/tuijian_new",this.node);
        tuijian_new.on("click",this.OnBtnMoreGame.bind(this));

        
        var com_quanping_gezi_show = PlatFormMng.GetInstance().IS_Dating_Game_Quanping_Gezi_Btn_Show();

        if(!com_quanping_gezi_show)
        {
            tuijian_new.active = false;
        }


        var shangcheng_btn = cc.find("actionnode/bottom/shangcheng",this.node);
        shangcheng_btn.on("click",this.OnBtn_Open_Shangcheng.bind(this));
 
        var chouka_node = cc.find("actionnode/bottom/chouka",this.node);
        chouka_node.on("click",this.OnBtnChouJiang.bind(this));


        var tipnode = cc.find("actionnode/tishitipnode",this.node);
        tipnode.active = false;


        var tishi_grapgic_node = cc.find("actionnode/all_panzi/tishi_grapgic",this.node);
        this.m_tishi_grapgic = tishi_grapgic_node.getComponent("hmk_tishi_graphic");

        this.m_tishi_jiantou_parent_node = cc.find("actionnode/all_panzi/tishi_jt",this.node);


      

        BackGroundSoundUtils.GetInstance().playBackgroundMusic("com/bj") ;
    
      
        this.Refresh_Bushu();

        this.Refresh_Daoju_Count_Info();
              

        this.InitShowChnageScenceTip();
   
        this.schedule(this.FD_Play_Steps.bind(this), 1.5);



        this.scheduleOnce(this.FD_Init.bind(this),0.01);



        

        
        var ibanner_mng_time = GlobalGameMng.GetInstance().Get_Game_Banner_Mng_Time_Config(this.Get_SubGameType());
  
        this.schedule(this.FD_Banner_Mng_Timer.bind(this),ibanner_mng_time);
       
        var bchaogaoping = ComFunc.ISChaoGaoPing();

        var bpugaoping = ComFunc.ISPuGaoPing();

        var in_subgame_jiaoti_gezi_arr = [];



        var bchaogaoping_need_juzhen = GlobalGameMng.GetInstance().Get_GameBottom_ChaogaoPing_Need_Show_Juzhen_Gezi();

        var bshow_bottom_game_juzhen_gezi = false;
        if(bchaogaoping_need_juzhen && bchaogaoping)
        {
            bshow_bottom_game_juzhen_gezi = true;
        }


 
        var bannerarr = [];
       //  if(bpugaoping)
        {
            var i_need_bannertype = GlobalGameMng.GetInstance().Get_Game_Scence_Next_Bottom_Banner_Type(this.Get_SubGameType());
 
            if(i_need_bannertype == 1)
            {
                //banner
                bannerarr = [ 112]
            } 
            else if(i_need_bannertype == 2)
            {
                //格子

                if(bshow_bottom_game_juzhen_gezi)
                {
                    bannerarr = [ 40]
                }else{
                    bannerarr = [ 113]
                }


              
            }
            else if(i_need_bannertype == 3)
            {

                if(bshow_bottom_game_juzhen_gezi)
                {
                    //交替出现
                    bannerarr = [112,40];
                    
                    in_subgame_jiaoti_gezi_arr =  [40,112];
                }
                else{
                    //交替出现
                    bannerarr = [112,113];
                    
                    in_subgame_jiaoti_gezi_arr =  [113,112];

                }
               
            }else if(i_need_bannertype == 5)
            {
                bannerarr = MiddleGamePlatformAction.GetInstance().Get_Game_Bottom_DanGezi_Arr();
            }
            else{
 
                //格子

                if(bshow_bottom_game_juzhen_gezi)
                {
                    bannerarr = [ 40]
                }
                else{
                    bannerarr = [ 113]
                }
                
            }
            
        }
  
        this.m_game_banner_arr = bannerarr;
 
 
        MiddleGamePlatformAction.GetInstance().Set_In_Subgame_Valid_Gezi_Guangao_Bannerindex_Arr_Info(true,
            this.Get_SubGameType(),this.m_game_banner_arr);
 
            
        this.Init_Top_Tuijian_Guangao();
       
 
        this.Check_Show_Gezi_Guanggao();
        MiddleGamePlatformAction.GetInstance().Set_In_Subgame_Bottom_Jiaoti_Show_Gezi_List(in_subgame_jiaoti_gezi_arr);
           
        this.On_Game_Enter();

        MiddleGamePlatformAction.GetInstance().Start_Luping();
       
        GlobalGameMng.GetInstance().m_dating_last_from_subgame_type =  this.Get_SubGameType();
        GlobalGameMng.GetInstance().m_dating_last_from_subgame_level =  this.Get_Level();


        this.schedule(this.FD_Refresh_Time_And_Step_Tip.bind(this), 1);
        this.FD_Refresh_Time_And_Step_Tip();

      
        var isubgametype = this.Get_SubGameType();
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(11000 + isubgametype, "进入游戏子玩法", this.m_current_level,
             "第"+this.m_current_level+"关", 0, "", 0, "");


             
        this.OnGame_Started();
    }
    Get_Level()
    {
        return this.m_current_level;
    }
    On_Game_Enter()
    {
         ComCodeFuncMng.On_Game_Enter(this.Get_SubGameType(),this,this.node);
    }
    Check_Show_Fuli_Or_Quanping_Gezi()
    {
        var self= this;
        var bpop_fuli = ComCodeFuncMng.Check_Show_Shoukan_Fuli(this,this.node,this.Get_SubGameType(),this.m_current_level,
                ()=>
                {
                    self.Refresh_Daoju_Count_Info();
                }
        );


        if(bpop_fuli)
        {
            return;
        }

        BannerGuangaoMng.GetInstance().Check_Show_Quanping_Chaiping_Gezi(2,this.Get_SubGameType(),this.m_current_level)
    }
    FD_Check_Need_Show_Shoukan()
    {

        if(this.m_current_level <= 2)
        {
            return;
        }

       
        this.Check_Show_Fuli_Or_Quanping_Gezi();
    }
    OnGame_Started()
    {
        var idealysec = GlobalGameMng.GetInstance().Get_GameType_Shouci_Libao_Delay_Pop_Sec(5);

        this.scheduleOnce(this.FD_Check_Need_Show_Shoukan.bind(this),idealysec);
    }
    Clear_Last_Save_Ju()
    {
        GlobalGameMng.GetInstance().Delete_GameType_Prev_Save_Data(this.Get_SubGameType());
    }
    Real_Init()
    {
        this.Clear_Last_Save_Ju();
        var rand_info = shuziHuaRongDaoLogicMng.GetInstance().Get_Gk_Src_Digit_Arr(this.m_cur_mode_type,this.m_current_level);
     
        this.m_src_digit_arr = rand_info[0];
        this.m_suiji_step_list = rand_info[1];
        console.log("this.m_suiji_step_list="+JSON.stringify(this.m_suiji_step_list))

        this.m_current_digit_arr = this.m_src_digit_arr.slice(0);
        this.InitCreate_All_Digit_Node_List();


        if(this.m_current_level == 1 && this.m_cur_mode_type <= 4)
        {
           // this.scheduleOnce(this.Start_First_GK_Tishi.bind(this),0.1); 
           this.scheduleOnce(this.FD_First_Yingdao.bind(this),0.01);
         
                
        }

    }

    FD_First_Yingdao()
    {
        var hmk_need_finger_yingdao = GlobalGameMng.GetInstance().IS_HMK_Need_Finger_Yingdao();

        if(hmk_need_finger_yingdao)
        {
            this.Start_Yindao_Finger_To_Menu();
        }
        else
        {
            this.scheduleOnce(this.Start_First_GK_Tishi.bind(this),0.1); 
        }
    }
    Start_Yindao_Finger_To_Menu()
    {
        var tishi_btn = cc.find("actionnode/bottom/tishi",this.node);

        var self = this;
        YDActionMng.getInstance().ShowShouzhiYingdao_P(this.shouzhiZhiyingDlg,this.node,tishi_btn,()=>
        {
            self.Start_First_GK_Tishi();
        })
    }
    On_Select_Jixu_Prev_Game(ijixu)
    {
        if(!ijixu)
        {
            this.Real_Init();
            return;
        }

        var prev_game_save_data = GlobalGameMng.GetInstance().Get_Prev_Save_Game_Data(this.Get_SubGameType());
        if(!prev_game_save_data)
        {
            this.Real_Init();
            return;
        }
        var igk = prev_game_save_data.igk;
        if(!igk)
        {
            this.Real_Init();
            return;
        }
        if(igk > 0)
        {
            this.m_current_level =igk; 
            shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_gk = this.m_current_level;
            
        
            var rand_info = shuziHuaRongDaoLogicMng.GetInstance().Get_Gk_Src_Digit_Arr(this.m_cur_mode_type,this.m_current_level);
     
            this.m_src_digit_arr = rand_info[0];
            this.m_suiji_step_list = rand_info[1];
           // console.log("this.m_suiji_step_list="+JSON.stringify(this.m_suiji_step_list));


            var digit_arr= prev_game_save_data.digit_arr;

            this.m_current_digit_arr = digit_arr.slice(0);
            this.InitCreate_All_Digit_Node_List();
    
        }

        this.Refresh_Bushu();
        
        var leveltip = cc.find("actionnode/bushu/leveltip",this.node);
        leveltip.getComponent(cc.Label).string =  "第"+this.m_current_level +"关";

   
    }
    Check_Read_Prev_Save_Game_Data()
    {
        var prev_game_save_data = GlobalGameMng.GetInstance().Get_Prev_Save_Game_Data(this.Get_SubGameType());

        if(!prev_game_save_data)
        {

            //没有保存的数据
            this.Real_Init();
        }
        else{
            //弹出弹框让用户选择

            var self = this;
            ComFunc.OpenNewDialog(this.node,"preab/continue_prev_game_confirm","continue_prev_game_confirm", {parentgame:this,
                
                cb:(ijixu)=>
                {
                    self.On_Select_Jixu_Prev_Game(ijixu);
               
               
             }});
    
    
            

        }
    }
    FD_Init()
    {
        this.Check_Read_Prev_Save_Game_Data();


    }
    Check_Show_Gezi_Guanggao()
    {
        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
 
        var banerid_map = new WMap();
        banerid_map.putData(112,1);
        banerid_map.putData(113,2); 
        banerid_map.putData(40,2); 
         
        var dangezi_arr = MiddleGamePlatformAction.GetInstance().Get_Game_Bottom_DanGezi_Arr();
        for(var hh=0;hh<dangezi_arr.length;hh++)
        {
            var hh_id = dangezi_arr[hh];
            banerid_map.putData(hh_id,2); 
      
        }


        for(var ff=0;ff<this.m_game_banner_arr.length;ff++)
        {
            var ff_bannerid = this.m_game_banner_arr[ff];
 
            if(!banerid_map.hasKey(ff_bannerid))
            {

                continue;
            }

            var ibanenrtype = banerid_map.getData(ff_bannerid);

            MiddleGamePlatformAction.GetInstance().Check_Create_Common_Banner(ff_bannerid,ibanenrtype);
            MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(ff_bannerid,1);
    
        }
     
 
       
        this.FD_Banner_Mng_Timer();
    }
    FD_Banner_Mng_Timer()
    {
        MiddleGamePlatformAction.GetInstance().FD_Banner_Mng_Timer(this.node);

    }
    OnBtnMoreGame()
    {
        MiddleGamePlatformAction.GetInstance().Show_InGame_MoreGame_Quanping_Gezi(); 
    }
    Init_Top_Tuijian_Guangao()
    { 
         
        //var othergame_node = cc.find("actionnode/othergame",this.node);

        //ComCodeFuncMng.Init_Top_Tuijian_Guangao(this,this.node,othergame_node);
        var othergame_node = cc.find("actionnode/othergame",this.node);

        var pos1 = this.Get_SubGameType() + 51000 ; 
        var pos2 = this.Get_SubGameType() + 52000 ; 


        var pos_arr = [pos1,pos2];
        ComCodeFuncMng.Init_Com_Two_Guangao(this,this.node,othergame_node,pos_arr);
 
    }
    Start_First_GK_Tishi()
    {
        this.Real_Start_Da_Tishi();

        var tishitipnode = cc.find("actionnode/tishitipnode/t",this.node);
      
        tishitipnode.getComponent(cc.Label).string = "请按照箭头指示点击相应的木块";
      
    }

    OnBtnBangzhu()
    {
        let pnode =  cc.instantiate(this.help_gametype);
        pnode.setPosition(0,0);
        var help_gametype = pnode.getComponent("help_gametype");
        help_gametype.setFromGameType(5);
        this.node.addChild(pnode,90);
    }
    Refresh_Bushu()
    {
          
        var bushu_tip = cc.find("actionnode/xingxing/bushu",this.node);
        bushu_tip.getComponent(cc.Label).string = "歩数:"+this.m_step_count;
    }
    Change_Digit_Node_Show(pndoe,ff_d)
    {
        var mu = pndoe.getChildByName("mu");

        if(ff_d > 0)
        {
            mu.active = true;
        }else{
            mu.active = false;
        }


        var mu_c = mu.getChildByName("c");
        mu_c.getComponent(cc.Label).string = ""+ff_d;
    }



    Get_Row_Col_Index(row,col)
    {
        var iindex = this.m_cur_mode_type*row + col;
        return iindex;
    }

    Get_Index_Row_Col(iindex)
    {

        var ir = Math.floor(iindex/this.m_cur_mode_type);
        var il = iindex - ir*this.m_cur_mode_type;


        return [ir,il];

    }

    OnBtnClickItem(iindex)
    {
        if(this.m_b_in_tishi)
        {
            if(this.m_b_is_auto_tishi)
            {
                return;
            }


            if(!this.m_b_in_tishi_user_action)
            {
                return;
            }

            if(this.m_tishi_user_action_move_step != iindex)
            {
                return;
            }


           
           
            this.Notify_User_TishiNode_Touch_End_Move_Step_Finish();


            return;

        }

        this.RealClickItem(iindex);
    }
    Swap_Digit_Arr(empty_row_col,cur_row_col)
    {
        if(empty_row_col[0] == cur_row_col[0])
        {
            var irow = empty_row_col[0];

            if(empty_row_col[1]  >  cur_row_col[1])
            {
                for(var ff = empty_row_col[1];ff> cur_row_col[1];ff--)
                {
                    var ff_index1 = this.Get_Row_Col_Index(irow,ff);
                    var ff_index2 = this.Get_Row_Col_Index(irow,ff-1);

                    var src_d = this.m_current_digit_arr[ff_index2];
                    this.m_current_digit_arr[ff_index1] = src_d;
                 
                }

                var last_index= this.Get_Row_Col_Index(irow,cur_row_col[1]);
                this.m_current_digit_arr[last_index] = 0;
               
            }
            else{

                for(var ff = empty_row_col[1];ff< cur_row_col[1];ff++)
                {
                    var ff_index1 = this.Get_Row_Col_Index(irow,ff);
                    var ff_index2 = this.Get_Row_Col_Index(irow,ff+1);

                    var src_d = this.m_current_digit_arr[ff_index2];
                    this.m_current_digit_arr[ff_index1] = src_d;
                 
                }

                var last_index= this.Get_Row_Col_Index(irow,cur_row_col[1]);
                this.m_current_digit_arr[last_index] = 0;

            }


        }
        else{

            var icol = empty_row_col[1];

            if(empty_row_col[0]  >  cur_row_col[0])
            {
                for(var ff = empty_row_col[0];ff> cur_row_col[0];ff--)
                {
                    var ff_index1 = this.Get_Row_Col_Index(ff,icol);
                    var ff_index2 = this.Get_Row_Col_Index(ff-1,icol);

                    var src_d = this.m_current_digit_arr[ff_index2];
                    this.m_current_digit_arr[ff_index1] = src_d;
                 
                }

                var last_index= this.Get_Row_Col_Index(cur_row_col[0],icol);
                this.m_current_digit_arr[last_index] = 0;
               
            }
            else{

                for(var ff = empty_row_col[0];ff< cur_row_col[0];ff++)
                {
                    var ff_index1 = this.Get_Row_Col_Index(ff,icol);
                    var ff_index2 = this.Get_Row_Col_Index(ff+1,icol);

                    var src_d = this.m_current_digit_arr[ff_index2];
                    this.m_current_digit_arr[ff_index1] = src_d;
                 
                }

                var last_index= this.Get_Row_Col_Index(cur_row_col[0],icol);
                this.m_current_digit_arr[last_index] = 0;

            }


        }
    }
    RealClickItem(iindex)
    {

      
        if(this.m_game_finished)
        {
            return;
        }


        var emprty_index = -1;

        for(var ff=0;ff<this.m_current_digit_arr.length;ff++)
        {
            var ff_d = this.m_current_digit_arr[ff];

            if(ff_d == 0)
            {
                emprty_index = ff;
            }
        }

        if(emprty_index == iindex)
        {
            return;
        }

        var empty_row_col =this.Get_Index_Row_Col(emprty_index);
        var cur_row_col =this.Get_Index_Row_Col(iindex);

        var bfujin = false;

        if(empty_row_col[0] == cur_row_col[0])
        {

            var ichaju = Math.abs(empty_row_col[1] - cur_row_col[1]);
          //  if(ichaju == 1)
            {
                bfujin = true;
            }
        }
        if(empty_row_col[1] == cur_row_col[1])
        {

            var ichaju = Math.abs(empty_row_col[0] - cur_row_col[0]);
           // if(ichaju == 1)
            {
                bfujin = true;
            }
        }


        if(!bfujin)
        {
            return;
        }

        //同一条线的全部移动起来


        this.m_step_count++;

        this.Swap_Digit_Arr(empty_row_col,cur_row_col);


        /*
        var src_d = this.m_current_digit_arr[iindex];
        this.m_current_digit_arr[emprty_index] = src_d;
        this.m_current_digit_arr[iindex] = 0;

        */
 

        this.Refresh_All_Digit_Node_Show();
        this.Refresh_Bushu();


        this.Save_Local_Data();



        BackGroundSoundUtils.GetInstance().Play_Effect("com/pushbox");


        this.Check_IS_Game_Over();
        //console.log("点击:"+iindex);

    }

    Save_Local_Data()
    {

        if(this.m_current_level == 1 && this.m_cur_mode_type <= 4)
        {
            return;
        }
        var digit_arr=  this.m_current_digit_arr.slice(0);


        var obj = {
            bvalid:1,
            igk:this.m_current_level,
            digit_arr:digit_arr
        }
        

        GlobalGameMng.GetInstance().Change_GameType_Prev_Save_Data(this.Get_SubGameType(),obj);

    }
    FD_Pop_GameEnd_Animate()
    {
        var pnode = cc.instantiate(this.game_end_animate);
        this.node.addChild(pnode,70);
        
        BackGroundSoundUtils.GetInstance().Play_Effect("com/game_win_effect")
   
    }
    Check_IS_Game_Over()
    {
        var iall_d = this.m_current_digit_arr.length -1;
     
        var ballfuhe=  true;
        for(var ff=0;ff<iall_d;ff++)
        {
            var ff_d = this.m_current_digit_arr[ff];

            if(ff_d != ff+1)
            {
                ballfuhe=  false;
            }

        }


        if(ballfuhe)
        {
           // this.m_game_finished = true;
           // this.scheduleOnce(this.On_Game_Success_Dlg.bind(this),1.5);


            var isubgametype = this.Get_SubGameType();
            var isec = GlobalGameMng.GetInstance().GameEnd_Pop_SuccessDlg_Delay_Sec(isubgametype);
    
            if(GlobalGameMng.GetInstance().IS_GameEnd_Need_Pop_Animate(isubgametype))
            {
                //this.Pop_Win_Qiu_Anim();
    
              //  var pnode = cc.instantiate(this.game_end_animate);
              //  this.node.addChild(pnode,70);
                
                var game_end_animate_d_sec = GlobalGameMng.GetInstance().Get_Game_End_Aniamte_Dealy_Sec();
                this.scheduleOnce(this.FD_Pop_GameEnd_Animate.bind(this),game_end_animate_d_sec)
    
            }else{
    
            }
    
            this.m_game_finished = true;
            
            this.scheduleOnce(this.On_Game_Success_Dlg.bind(this),isec);
           // BackGroundSoundUtils.GetInstance().Play_Effect("com/game_win_effect")
        }
    }
    InitCreate_All_Digit_Node_List()
    {
        var iallwidth = 680;

        var istartx = -1*680/2;
        var istarty = 680/2 + 5;


        var iperw = Math.floor(iallwidth/this.m_cur_mode_type);

        for(var ff=0;ff<this.m_current_digit_arr.length;ff++)
        {
            var ff_d=  this.m_current_digit_arr[ff];
            var pndoe = cc.instantiate(this.game_shuzi_perfk);



            var news = iperw/226;
            pndoe.scale = news;

            this.m_panzi.addChild(pndoe,10);

            var ir = Math.floor(ff/this.m_cur_mode_type);
            var il = ff - ir*this.m_cur_mode_type;

            this.m_all_digit_node_list[ff] = pndoe; 

            this.Change_Digit_Node_Show(pndoe,ff_d);

            
            var ix = istartx +iperw/2  + il*iperw;
            var iy = istarty -iperw/2  - ir*iperw;
            pndoe.setPosition(ix,iy);


            var bk_btn = pndoe.getChildByName("bk");
            bk_btn.on("click",this.OnBtnClickItem.bind(this,ff))
        }

    }

    Refresh_All_Digit_Node_Show()
    {
        for(var ff=0;ff<this.m_current_digit_arr.length;ff++)
        {
            var ff_d=  this.m_current_digit_arr[ff];
            var ff_node = this.m_all_digit_node_list[ff];
            this.Change_Digit_Node_Show(ff_node,ff_d);


        }
    }
    Get_SubGameType()
    {
        return shuziHuaRongDaoLogicMng.GetInstance().Get_Mode_GameType(this.m_cur_mode_type)
    }

    OnBtn_PaihangBang()
    {

    }
    ReStartGame()
    {
        cc.director.loadScene("shuzihuarongdao");
    }
    GoToLevel(lv)
    {
        shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_gk = lv;
        

        this.ReStartGame()
    }
    OnBtnSelGK()
    {
        var isubgametype = this.Get_SubGameType();
        var igk = this.m_current_level;
        var imax_can_enter_gk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(this.Get_SubGameType());

        var self = this;
        ComFunc.OpenNewDialog(this.node,"preab/selectgk","selectgk", { parentgame:this,
            imax_can_enter_gk:imax_can_enter_gk,
            isubgametype:isubgametype,igk:igk,
            cb:(lv)=>
        {
            
            self.Clear_Last_Save_Ju()
            self.GoToLevel(lv);
              //cc.director.loadScene("game");
            
           // self.OnBtnSelGK();
        }}); 
    }
    OnBtn_Open_Shangcheng()
    {
        if(this.m_game_finished)
        {
            return;
        }
        var self = this;
        ComCodeFuncMng.OnBtn_Open_Shangcheng(this.node,()=>
        {
            self.Refresh_Daoju_Count_Info();
        })
    }
    OnBtnBackToHall()
    {
        var isubgametype = this.Get_SubGameType();
        var igk = this.m_current_level;
 
 
 
         var self = this;
         ComFunc.OpenNewDialog(this.node,"preab/pausedlg","pausedlg", 
         { parentgame:this,
            isubgametype:isubgametype,igk:igk,
             cb:()=>
             {
 
                 self.OnBtnSelGK();
             },
             paihangbang_cb:()=>
             {
                 self.OnBtn_PaihangBang();
             },
             shangcheng_cb:()=>
             {
                 self.OnBtn_Open_Shangcheng();
             }
         
         
        });
 
    }
    Refresh_Daoju_Count_Info()
    {
        var itishikacount = GlobalMng.GetInstance().GetDaTishiKaCount();;
        var itiaguokacount =  GlobalMng.GetInstance().GetTiaoGuangKaCount();
        var xiaotishikacount =  GlobalMng.GetInstance().GetXiaoTishiKaCount();
        var chongwan_ka_count =  GlobalMng.GetInstance().Get_Chongwan_Ka_Count();

        
        var tiaoguo_c_node=  cc.find("actionnode/bottom/tiaoguo/left/circle/c",this.node);
        var tiaoguo_digit_node=  cc.find("actionnode/bottom/tiaoguo/left",this.node);
        var tiaoguo_sp_node=  cc.find("actionnode/bottom/tiaoguo/sp",this.node);

        
        tiaoguo_c_node.getComponent(cc.Label).string = ""+itiaguokacount;

        if(itiaguokacount > 0)
        {
            tiaoguo_digit_node.active = true;
            tiaoguo_sp_node.active = false;
        }else{
            tiaoguo_digit_node.active = false;
            tiaoguo_sp_node.active = true;
        }



        var tishi_c_node=  cc.find("actionnode/bottom/tishi/left/circle/c",this.node);
        var tishi_digit_node=  cc.find("actionnode/bottom/tishi/left",this.node);
        var tishi_sp_node=  cc.find("actionnode/bottom/tishi/sp",this.node);

        tishi_c_node.getComponent(cc.Label).string = ""+itishikacount;

        if(itishikacount > 0)
        {
            tishi_digit_node.active = true;
            tishi_sp_node.active = false;
        }else{
            tishi_digit_node.active = false;
            tishi_sp_node.active = true;

        }


        
        var xiao_tishi_c_node=  cc.find("actionnode/bottom/zidongtishi/left/circle/c",this.node);
        var xiao_tishi_digit_node=  cc.find("actionnode/bottom/zidongtishi/left",this.node);
        var xiao_tishi_sp_node=  cc.find("actionnode/bottom/zidongtishi/sp",this.node);

        xiao_tishi_c_node.getComponent(cc.Label).string = ""+xiaotishikacount;

        if(xiaotishikacount > 0)
        {
            xiao_tishi_digit_node.active = true;
            xiao_tishi_sp_node.active = false;
        }else{
            xiao_tishi_digit_node.active = false;
            xiao_tishi_sp_node.active = true;

        }
        


 
        var restart_c_node=  cc.find("actionnode/bottom/restart/left/circle/c",this.node);
        var restart_digit_node=  cc.find("actionnode/bottom/restart/left",this.node);
        var restart_sp_node=  cc.find("actionnode/bottom/restart/sp",this.node);

        restart_c_node.getComponent(cc.Label).string = ""+chongwan_ka_count;

        if(chongwan_ka_count > 0)
        {
            restart_digit_node.active = true;
            restart_sp_node.active = false;
        }else{
            restart_digit_node.active = false;
            restart_sp_node.active = true;

        }
        
    }
    GotoNextLevel(bchognwan = null)
    {
        if(!bchognwan)
        {
            shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_gk =   GlobalData.GetInstance().Get_SubGametype_Next_Level(this.Get_SubGameType(),this.m_current_level);
       
        }
       

        this.ReStartGame();
    }
    On_Game_Success_Dlg()
    {
        var self=  this;
        var isubgametype  = this.Get_SubGameType();

        this.Clear_Last_Save_Ju();

        GlobalData.GetInstance().On_SubGametype_Winned_GK(this.Get_SubGameType(),  this.m_current_level  );
        
       // GlobalData.GetInstance().On_HMK_JieSuo_New_Level(this.m_current_guangka + 1);
        
        ComFunc.Real_OpenNewDialog(this.gamesuccess_new, self.node,"preab/gamesuccess_new","gamesuccess_new", {parentgame:self,
            star:3,  
            igamemode:5,
            isubgametype:self.Get_SubGameType(),ilevel:self.m_current_level,
            cb:(iret,bchognwan)=>
            {

                self.GotoNextLevel(bchognwan);
                
            }});
            
            
    
    }
    RealTiaoguoGk()
    {

        this.On_Game_Success_Dlg();
    }

    InitShowChnageScenceTip()
    {
        if(GlobalData.GetInstance().m_global_change_scence_tip)
        {
            BaseUIUtils.ShowTipTxtDlg(GlobalData.GetInstance().m_global_change_scence_tip,this.node);
            GlobalData.GetInstance().m_global_change_scence_tip=  "";
        }
    }
    RealChongWan()
    {
        this.Clear_Last_Save_Ju();
        GlobalData.GetInstance().m_global_change_scence_tip = "使用重玩成功,关卡成功重置为初始状态";
        this.ReStartGame();
     
         
    }
    OnBtnChongWan()
    {
        if(this.m_game_finished)
        {
            return;
        }
        if(this.m_b_in_tishi)
        {
            return;
        }

      
        var self=  this;
      
        var kacount = GlobalMng.GetInstance().Get_Chongwan_Ka_Count();
        var isubgametype = this.Get_SubGameType();

        var idaojutype = 100000 + isubgametype*100 + 2;


        if(kacount > 0)
        {
            if(this.m_step_count == 0)
            {
                
                BaseUIUtils.ShowTipTxtDlg("尚未移动过",this.node)
                return;
            }
    
            GlobalMng.GetInstance().Change_ChongwanKa_Count( -1);
            
            this.RealChongWan();
            this.Refresh_Daoju_Count_Info();


               
               
            ClientLogUtils.GetInstance().Poset_Server_JS_Log(33, "使用道具", idaojutype,
            "道具:重玩", isubgametype, "道具:重玩", this.m_current_level,  "第"+this.m_current_level+"关");


        }else{


            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node, 
                ()=>{},
                "购买道具",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
                GlobalMng.GetInstance().Change_ChongwanKa_Count( 2);
          
                self.Refresh_Daoju_Count_Info();

                BaseUIUtils.ShowTipTxtDlg("购买获得2个道具成功",this.node);

                ClientLogUtils.GetInstance().Poset_Server_JS_Log(34, "购买道具成功", idaojutype,
                "道具:重玩", isubgametype, "道具:重玩", self.m_current_level,  "第"+self.m_current_level+"关");
            },this.Get_SubGameType());

        }

 

    }
    OnBtnTiaoguo()
    {

        if(this.m_game_finished)
        {
            return;
        }
        if(this.m_b_in_tishi)
        {
            return;
        }
        var self=  this;
      
        var itoaguoka = GlobalMng.GetInstance().GetTiaoGuangKaCount();

        var isubgametype = this.Get_SubGameType();
        var idaojutype = 100000 + isubgametype*100 + 1;


        if(itoaguoka > 0)
        {
            GlobalMng.GetInstance().Add_TiaoGuangKa_Count( -1);
            
            this.RealTiaoguoGk();
            this.Refresh_Daoju_Count_Info();

            ClientLogUtils.GetInstance().Poset_Server_JS_Log(33, "使用道具", idaojutype,
            "道具:跳过关卡", isubgametype, "道具:跳过关卡", this.m_current_level,  "第"+this.m_current_level+"关");

        }else{


            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node,
                ()=>{},
                "购买道具",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
                GlobalMng.GetInstance().Add_TiaoGuangKa_Count( 2);
          
                self.Refresh_Daoju_Count_Info();

                BaseUIUtils.ShowTipTxtDlg("购买获得2个道具成功",this.node);

                ClientLogUtils.GetInstance().Poset_Server_JS_Log(34, "购买道具成功", idaojutype,
                "道具:跳过关卡", isubgametype, "道具:跳过关卡", self.m_current_level,  "第"+self.m_current_level+"关");
            },this.Get_SubGameType());

        }

        
    }

    OnBtnTishi()
    {
        if(this.m_game_finished)
        {
            return;
        }
        if(this.m_b_in_tishi)
        {
            return;
        }
        var self = this;
        var ikacount = GlobalMng.GetInstance().GetDaTishiKaCount();

        var isubgametype = this.Get_SubGameType();
        var idaojutype = 100000 + isubgametype*100 + 4;

        if(ikacount > 0)
        {
            GlobalMng.GetInstance().Add_DaTishiKa_Count( -1);
            
            this.Real_Start_Da_Tishi();
            this.Refresh_Daoju_Count_Info();



            ClientLogUtils.GetInstance().Poset_Server_JS_Log(33, "使用道具", idaojutype,
            "道具:逐步提示", isubgametype, "道具:逐步提示", this.m_current_level,  "第"+this.m_current_level+"关");



        }else{


            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node, 
                ()=>{},
                "购买道具",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
                GlobalMng.GetInstance().Add_DaTishiKa_Count( 2);
          
                self.Refresh_Daoju_Count_Info();

                BaseUIUtils.ShowTipTxtDlg("购买获得2个道具成功",this.node);

                
                ClientLogUtils.GetInstance().Poset_Server_JS_Log(34, "购买道具成功", idaojutype,
                "道具:逐步提示", isubgametype, "道具:逐步提示", self.m_current_level,  "第"+self.m_current_level+"关");
            },this.Get_SubGameType());

        }
    }
    OnBtnZidongTishi()
    {
        if(this.m_game_finished)
        {
            return;
        }
        if(this.m_b_in_tishi)
        {
            return;
        }
        var self = this;
        var ikacount = GlobalMng.GetInstance().GetXiaoTishiKaCount();

        var isubgametype = this.Get_SubGameType();

        var idaojutype = 100000 + isubgametype*100 + 3;

        if(ikacount > 0)
        {
            GlobalMng.GetInstance().Add_XiaoTishiKa_Count( -1);
            var tipnode = cc.find("actionnode/tishitipnode",this.node);
            tipnode.active = true;
    
    
            var tishitipnode = cc.find("actionnode/tishitipnode/t",this.node);
          
            tishitipnode.getComponent(cc.Label).string = "正在计算移动路径中,请耐心等待";
    
    
            var bottomnode = cc.find("actionnode/bottom",this.node);
            bottomnode.active = false;

            this.scheduleOnce(this.Real_Start_Xiao_Tishi.bind(this),0.1) 
            this.Refresh_Daoju_Count_Info();


            ClientLogUtils.GetInstance().Poset_Server_JS_Log(33, "使用道具", idaojutype,
            "道具:自动提示", isubgametype, "道具:逐步提示", this.m_current_level,  "第"+this.m_current_level+"关");


        }else{


            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node, 
                ()=>{},
                "购买道具",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
                GlobalMng.GetInstance().Add_XiaoTishiKa_Count( 2);
          
                self.Refresh_Daoju_Count_Info();

                BaseUIUtils.ShowTipTxtDlg("购买获得2个道具成功",this.node);

                ClientLogUtils.GetInstance().Poset_Server_JS_Log(34, "购买道具成功", idaojutype,
                "道具:逐步提示", isubgametype, "道具:逐步提示", self.m_current_level,  "第"+self.m_current_level+"关");
            },this.Get_SubGameType());

        }

    }
    OnBtn_Tishi_Restart()
    {
        this.m_current_digit_arr = this.m_src_digit_arr.slice(0);
        this.Refresh_All_Digit_Node_Show();
    }

    Real_Start_Da_Tishi()
    {
        this.OnBtn_Tishi_Restart();
  
        var steps_list =  this.m_suiji_step_list.slice(0);
        steps_list = steps_list.reverse();


        
       this.m_b_in_tishi = true;
       this.m_b_is_auto_tishi = false;
 
       this.m_b_in_playing_steps = false;
       this.m_playing_steps_list = steps_list;
 

        this.m_b_in_tishi_user_action = true;

        this.m_tishi_user_action_move_step = this.m_playing_steps_list [0];



        var tishitipnode = cc.find("actionnode/tishitipnode",this.node);
        tishitipnode.active = true;
 
        var bottomnode = cc.find("actionnode/bottom",this.node);
        bottomnode.active = false;


        var tishitipnode = cc.find("actionnode/tishitipnode/t",this.node);
      
        tishitipnode.getComponent(cc.Label).string = "请点击箭头对应的方块";

        
        var action_rc = this.Get_User_Action_Tishi_RC(this.m_tishi_user_action_move_step );

        this.m_tishi_grapgic.Set_User_Action_Tishi_RC(action_rc);
 
       this.Ensure_New_Create_Jaintou_Tishi(action_rc);
    }
    ClearJiantou_Nodr()
    {

        if(this.m_cur_tishi_jt_node)
        {
            this.m_cur_tishi_jt_node.destroy();
            this.m_cur_tishi_jt_node =  null;
        }

    }

    Ensure_New_Create_Jaintou_Tishi(action_rc:cc.Rect)
    {
        var centet = action_rc.center;

        this.ClearJiantou_Nodr();


        

        var simg_sprtieframe:cc.SpriteFrame =  this.shoushi_sprite_frame


        this.m_cur_tishi_jt_node = new cc.Node();
        this.m_cur_tishi_jt_node.addComponent(cc.Sprite)
        this.m_cur_tishi_jt_node.getComponent(cc.Sprite).spriteFrame = simg_sprtieframe;


        
        this.m_tishi_jiantou_parent_node.addChild(this.m_cur_tishi_jt_node ,10)
        this.m_cur_tishi_jt_node.setScale(0.3);
        this.m_cur_tishi_jt_node.setPosition(centet.x,centet.y)

        this.m_cur_tishi_jt_node.runAction(cc.repeatForever(cc.sequence(cc.moveBy(0.2,0,8),cc.moveBy(0.2,0,-8))))
    }

    Get_User_Action_Tishi_RC(iindex )
    {
        var pnode=  this.m_all_digit_node_list[iindex];

        var center_pt = pnode.getPosition();
        var iallwidth = 680;

        

        var iperw = Math.floor(iallwidth/this.m_cur_mode_type);

        var newrc=  new cc.Rect(center_pt.x - iperw/2,center_pt.y- iperw/2,iperw,iperw);

        return newrc;


    }


    Real_Start_Xiao_Tishi()
    {
       // var all_digit_arr =  this.m_current_digit_arr.slice(0);
        //shuziHuaRongDaoLogicMng.GetInstance().Caculate_All_Steps(this.m_cur_mode_type, all_digit_arr);
        this.OnBtn_Tishi_Restart();
  
        var steps_list =  this.m_suiji_step_list.slice(0);
        steps_list = steps_list.reverse();


        
       this.m_b_in_tishi = true;
       this.m_b_is_auto_tishi = true;
 
       this.m_b_in_playing_steps = true;
       this.m_playing_steps_list = steps_list;
 

        this.m_b_in_tishi_user_action = false;




        var tishitipnode = cc.find("actionnode/tishitipnode",this.node);
        tishitipnode.active = true;
 
        var bottomnode = cc.find("actionnode/bottom",this.node);
        bottomnode.active = false;


        var tishitipnode = cc.find("actionnode/tishitipnode/t",this.node);
      
        tishitipnode.getComponent(cc.Label).string = "正在自动播放完整的过关步骤";
        
    }
    Notify_User_TishiNode_Touch_End_Move_Step_Finish()
    {
        if(!this.m_b_in_tishi_user_action)
        {
            return;
        }

        this.m_b_in_tishi_user_action = false;
        this.m_b_in_playing_steps = true;
   

        var click_index = this.m_tishi_user_action_move_step;

        this.m_playing_steps_list.splice(0,1);

        this.RealClickItem(click_index);
 
        
        this.Refresh_All_Digit_Node_Show();


        if(this.m_playing_steps_list.length == 0)
        {
            this.ClearJiantou_Nodr();

            this.m_tishi_grapgic.ClearAll();
            return;
        }



        this.m_b_in_tishi_user_action = true;
        this.m_b_in_playing_steps = false;
   
        this.m_tishi_user_action_move_step = this.m_playing_steps_list[0];

        var action_rc = this.Get_User_Action_Tishi_RC(this.m_tishi_user_action_move_step );

        this.m_tishi_grapgic.Set_User_Action_Tishi_RC(action_rc);
 
       this.Ensure_New_Create_Jaintou_Tishi(action_rc);

    }
    FD_Play_Steps()
    {
        if(!this.m_b_in_tishi)
        {
            return;
        }

        if(!this.m_b_is_auto_tishi)
        {
            return;
        }
 
     
        if(!this.m_b_in_playing_steps)
        {
            return;
        }

        if(this.m_playing_steps_list.length == 0)
        {
            this.m_b_in_playing_steps = false;
            return;
        }

        var click_index = this.m_playing_steps_list[0];
       
        this.m_playing_steps_list.splice(0,1);

        this.RealClickItem(click_index);

        
        
        this.Refresh_All_Digit_Node_Show();
        

    }

    OnBtnChouJiang()
    {
        var choujianginfo = ChouJiangMng.GetInstance().Get_Choujiang_Info();
        var bhaschoujiang = choujianginfo[0];
        var ileft_sec = choujianginfo[1];
        var self = this;
        if(!bhaschoujiang || ileft_sec > 0)
        {
          
            ComFunc.OpenNewDialog(
             
                this.node,"preab/common/choujiang_left_time_tishi","choujiang_left_time_tishi", {parentgame:self ,
                cb:()=>
                {
                    self.Refresh_Daoju_Count_Info();
                    
                }});
            return;
        };
 
        

        ComCodeFuncMng.Common_Choujiang(this.node,
            ()=>
            {
                self.Refresh_Daoju_Count_Info();
                 
            });
        
    }
    FD_Refresh_Time_And_Step_Tip()
    {
      
        
        this.Refresh_Choujiang_Info();


    }
    Refresh_Choujiang_Info()
    {
        var chouka_node = cc.find("actionnode/bottom/chouka",this.node);

        ComCodeFuncMng.Refresh_Choujiang_Info(this,chouka_node);
        
    }
    update(dt: number) 
    {
        if(dt > 1)
        {
            return;
        }
        
        ComCodeFuncMng.On_Choujiang_Update_Dt(dt);
    }
}
