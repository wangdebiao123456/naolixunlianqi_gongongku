 
import juba_Config_Mng from "../jiubei/mng/juba_Config_Mng";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
import paixuGameMng from "./paixuGameMng";
import Paixu_Tishi_Logic from "./Paixu_Tishi_Logic";

 
 
const {ccclass, property} = cc._decorator;

@ccclass
export default class loadingto_paixigame extends cc.Component {

 
     

 
    @property(cc.JsonAsset)
    lv_water__mode_1: cc.JsonAsset = null;


    @property(cc.JsonAsset)
    lv_water__mode_2: cc.JsonAsset = null;

    @property(cc.JsonAsset)
    gameinfo: cc.JsonAsset = null;


    @property(cc.JsonAsset)
    game_yd_info: cc.JsonAsset = null;


    m_b_in_progress = false;
  
    m_progress_start_tick = 0;
    m_prog=  null;
    m_b_inited = 0;

    onLoad () 
    {

     //   cc.director.preloadScene("paixuGame");
     this.m_b_in_progress = true;
     this.m_progress_start_tick = Date.now();
     this.m_prog=  cc.find("bottom/progress",this.node);
     this.m_b_inited = 1;



        paixuGameMng.GetInstance().Set_Mode_Config(1,this.lv_water__mode_1.json)
        paixuGameMng.GetInstance().Set_Mode_Config(2,this.lv_water__mode_2.json)
       
         

        juba_Config_Mng.GetInstance().Set_GameInfo_Config(this.gameinfo.json)
        juba_Config_Mng.GetInstance().Set_Game_Yingdao_Info_Config(this.game_yd_info.json)
      
        this.scheduleOnce(this.FD_Change_To_Game.bind(this),1)

        
        BackGroundSoundUtils.GetInstance().Play_Effect("com/snd_talk_gogo")
 
 
    }
    
    Aotu_Create_GK_Arr(in_dao_c)
    {
        var iall_dao_c = in_dao_c;// 7+Math.floor(Math.random()*3.6);
        var empty_dao = 2;


        var all_d_list = [];
        for(var ff=0;ff<iall_dao_c;ff++)
        {
            var ff_d= ff+1;
            all_d_list.push(ff_d);
            all_d_list.push(ff_d)
            all_d_list.push(ff_d)
            all_d_list.push(ff_d)
        }

        var all_arr_list = [];


        for(var tt=0;tt<all_d_list.length;tt++)
        {
            var tt_rand = Math.floor(Math.random()*all_d_list.length);
            var f1 = all_d_list[tt];
            var f2 = all_d_list[tt_rand];
            all_d_list[tt] = f2;
            all_d_list[tt_rand] = f1;
        }

        for(var ff=0;ff<iall_dao_c;ff++)
        {
            var front_arr = all_d_list.slice(0,4);
            all_arr_list.push(front_arr);
            all_d_list.splice(0,4);
        }

        all_arr_list.push([]);
        all_arr_list.push([]);
        
        return all_arr_list;
    }
    
    FD_Change_To_Game()
    { 
        cc.director.loadScene("paixuGame")
    }
    update()
    {
 
        if(!this.m_b_inited)
        {
            return;
        }


    

        var self = this;
        
 
        if(this.m_b_in_progress){
            var ieplasetick = Date.now() - this.m_progress_start_tick ;
            var iprogress = Math.min(ieplasetick/30000,1);
            if(ieplasetick > 30000)
            {
                 this.m_progress_start_tick =  Date.now();
            }

            if(iprogress >= 0.95)
            {
             //   iprogress = 0.95;
            }
            this.m_prog.getComponent(cc.ProgressBar).progress  = iprogress;


            var prolb = cc.find("bottom/prolb",this.node);

            prolb.getComponent(cc.Label).string = "正在加载进入游戏场资源..";

           
        }
    }
}
