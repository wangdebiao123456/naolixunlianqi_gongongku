import PlatFormMng from "../PlatForm/PlatFormMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class help extends cc.Component {

    onLoad () {
        let fanhui = this.node.getChildByName("guanbi");
        fanhui.on("click",this.OnBtnExit.bind(this));


        let gzh = this.node.getChildByName("gzh");
     
        gzh.active = PlatFormMng.GetInstance().IS_Zhanghuan_Gongzhanghao_Info_Show();


    }

   
    OnBtnExit()
    {
        this.node.destroy();


        

    }
}
