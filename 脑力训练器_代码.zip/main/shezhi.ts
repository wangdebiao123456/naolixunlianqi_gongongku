import PlatFormMng from "../PlatForm/PlatFormMng";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils"; 
 
const {ccclass, property} = cc._decorator;

@ccclass
export default class shezhi extends cc.Component {

    onLoad () {
        let fanhui = this.node.getChildByName("guanbi");
        fanhui.on("click",this.OnBtnExit.bind(this));


        var ll1 = this.node.getChildByName("ll1");
        ll1.active = PlatFormMng.GetInstance().IS_Zhanghuan_Gongzhanghao_Info_Show();

        const music = BackGroundSoundUtils.GetInstance().GetBackGroundMusicVolum();
        const sound = BackGroundSoundUtils.GetInstance().GetEffectSoundVolum();

        var shengxiao = this.node.getChildByName('shengxiao');
        var shengxiao_move = shengxiao.getChildByName('sz-jd1').getComponent(cc.Slider);
        var shengxiao_fill = shengxiao.getChildByName('sz-jd1').getComponent(cc.Sprite);

        shengxiao_move.progress = music; 
        shengxiao_fill.fillRange = music;

        shengxiao_move.node.on("slide", () => {
            shengxiao_fill.fillRange = shengxiao_move.progress;

            var imsuicvloum = shengxiao_move.progress;
            if(imsuicvloum < 0.08)
            {
                imsuicvloum = 0;
            }
            BackGroundSoundUtils.GetInstance().SetBackGroundMusicVolum(imsuicvloum);
        });




        var yingxiao = this.node.getChildByName('yingxiao');
        var yingxiao_move = yingxiao.getChildByName('sz-jd1').getComponent(cc.Slider);
        var yingxiao_fill = yingxiao.getChildByName('sz-jd1').getComponent(cc.Sprite);
 
        yingxiao_move.progress = sound; 
        yingxiao_fill.fillRange = sound;

        yingxiao_move.node.on("slide", () => {
            yingxiao_fill.fillRange = yingxiao_move.progress;
            BackGroundSoundUtils.GetInstance().SetEffectSoundVolum(yingxiao_fill.fillRange);
        });



         
    }
    
    OnBtnExit()
    {
        this.node.destroy();


        

    }
}
