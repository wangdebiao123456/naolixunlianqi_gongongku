import PlatFormMng from "../PlatForm/PlatFormMng";
import PlatFormType from "../PlatForm/PlatFormType";
import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng";
import HutuiAppInfoMng from "../PlatForm/HutuiAppInfoMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import ComFunc from "../comfuncs/ComFunc";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import HMK_GK_Mng from "../huamukuai/HMK_GK_Mng"; 
import PreLoadResMng from "../comfuncs/PreLoadResMng";
import BundleLoadUtils from "../comfuncs/BundleLoadUtils";
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";
import LeoGameInfoMng from "../WDT/LeoGameInfoMng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class loading extends cc.Component
 {

    @property(cc.JsonAsset)
    ori_preload_json:cc.JsonAsset = null;
 
        
    @property(cc.JsonAsset)
    local_common_config: cc.JsonAsset = null;

    @property(cc.JsonAsset)
    local_tuijian_wx: cc.JsonAsset = null;



    m_b_in_progress = false;
    m_progress_start_tick = 0;
    m_prog=  null;


    m_b_first_enter_game =  false;
    

    //m_b_config_loaded = false;
    m_b_loaded_game  = false;
 



    m_preloadfile_config_inited = false;


    m_load_start_tick = 0;

    m_bk_loading_info_successed=  0;

    onLoad () 
    {

        this.m_b_in_progress = true;
        this.m_progress_start_tick = Date.now();
        this.m_prog=  cc.find("progress",this.node);

        this.m_load_start_tick = Date.now();


        var self = this;
        /*
        GSXC_Game_Mng.GetInstance().InitReadConfig(()=>
        {
            GSXC_Game_Mng.GetInstance().InitLoadTiles(()=>
            {
                //self.m_b_config_loaded = true;
            })
            
        });
        
 
        */
       

        cc.director.preloadScene("dating");

       
       
        HMK_GK_Mng.GetInstance().Init_Load_All_Data();

        HutuiAppInfoMng.GetInstance().LoadRemoteConfig(()=>{});

        GlobalGameMng.GetInstance().Load_Game_Common_Config(()=>{});


        HutuiAppInfoMng.GetInstance().Set_Default_Config(this.local_tuijian_wx.json);
        GlobalGameMng.GetInstance().Set_Default_Config(this.local_common_config.json);
      
    
        GlobalGameMng.GetInstance().Get_Self_Reg_Day();
        GlobalGameMng.GetInstance().Get_Self_Reg_Tick();

        var strguid = PlatFormMng.GetInstance().Get_Saved_GUID();
 
        var self = this;
        

        this.scheduleOnce(this.FD_Check_Must_To_Main.bind(this),0.5);
       // this.scheduleOnce(this.FD_Check_Must_To_Main.bind(this),20);
    
        PlatFormMng.GetInstance().Check_WX_Login_Read_OpenId(()=>{

            LeoGameInfoMng.GetIns().Check_WX_Load_From_Openid();
            ClientLogUtils.GetInstance().Poset_Server_JS_Log(1, "初始页面", 1,
            "初始化load", 0, "", 0, "");
        });
     

        LeoGameInfoMng.GetIns().Check_Tongbu_WX_ID();
         
       // LeoGameInfoMng.GetIns().Check_Post_Read_OpenId();


        LeoGameInfoMng.GetIns().Check_WX_Load_From_Openid();


        this.Check_WX_Update();
        
        var vlabel =  cc.find("v",this.node);
        vlabel.getComponent(cc.Label).string = ""+PlatFormParaMng.GetInstance().m_cur_version;

    }

     

    InitChangeToMain()
    {
        
        console.log("InitChangeToMain");
  
        this.FD_Change_To_Main();
      //  this.schedule(this.FD_Change_To_Main.bind(this), 0.5);

    }
    FD_Check_Must_To_Main()
    {
        console.log("FD_Check_Must_To_Main");
        this.InitChangeToMain();
    }
    FD_Check_LoadFile_Toolong()
    {
        
    }
     
    Check_WX_Update()
    {
        
        if(PlatFormMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            //return;
        }

        PlatFormMng.GetInstance().Check_Update();


        
    }
 

     
    FD_Change_To_Main()
    {
        if(this.m_b_loaded_game)
        {
            return;
        }
       

       
        this.m_b_loaded_game = true;

        cc.director.loadScene("dating");

        var usertick = Date.now() - this.m_load_start_tick;
        var ise_sec = Math.floor(usertick/1000);
        var preloadfile_config = PreLoadResMng.GetInstance().Get_Cur_Valid_Server_PreloadFile_Config();

        var config_readed = 0;
       
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(81, "加载进入大厅",
        this.m_bk_loading_info_successed,"成功加载:"+this.m_bk_loading_info_successed,ise_sec, "用时:"+ise_sec+"秒",
            config_readed, "读取到配置:"+config_readed);

        

    }

    update(){
 
        var self = this;
        

        if(this.m_b_in_progress){
            var ieplasetick = Date.now() - this.m_progress_start_tick ;
            var iprogress = Math.min(ieplasetick/30000,1);
            if(ieplasetick > 10000)
            {
                 //this.m_progress_start_tick =  Date.now();
            }

            if(iprogress >= 0.95)
            {
                iprogress = 0.95;
            }
            this.m_prog.getComponent(cc.ProgressBar).progress  = iprogress;


            var prob_c = Math.floor(iprogress*100);

            var prolb = cc.find("prolb",this.node);
            prolb.getComponent(cc.Label).string = "正在加载资源("+prob_c+"%)..";

        }
    }
    




}
