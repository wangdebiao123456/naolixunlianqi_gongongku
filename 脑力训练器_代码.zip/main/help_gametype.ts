

const {ccclass, property} = cc._decorator;

@ccclass
export default class help_gametype extends cc.Component {

    onLoad () {
        let fanhui = this.node.getChildByName("guanbi");
        fanhui.on("click",this.OnBtnExit.bind(this));


    },
    setFromGameType(igametype)
    {

        for(var ff=1;ff<=5;ff++)
        {
            var gametip = this.node.getChildByName("gametip"+ff);

            if(gametip)
            {
                gametip.active = false;
            }
        }
        var gametipigametype = this.node.getChildByName("gametip"+igametype);

        if(gametipigametype)
        {
            gametipigametype.active = true;
        }
    },
   
    OnBtnExit()
    {
        this.node.destroy();


        

    }
}
