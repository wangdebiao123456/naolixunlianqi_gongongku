import ComFunc from "../comfuncs/ComFunc";
import WMap from "../WDT/WMap";



 

export default class GlobalData
{
    
    static _instance:GlobalData = null;
    static GetInstance() 
    {
        if (!GlobalData._instance) {
            // doSomething
            GlobalData._instance = new GlobalData();
             
        }
        return GlobalData._instance;
    }

    m_morewafa_last_opend_type = 0;

    m_subgametype_max_win_gk_map = new WMap();

    m_select_enter_txz_gk = 0;
    m_select_enter_huarongdao_gk = 0;

    
    m_select_enter_hmk_nandu = 1;
    m_select_enter_hmk_gk = 0;
    m_b_first_enter_game = 1;
   // m_hmk_last_kaiqi_guanka = 0;
   


    m_txz_last_kaiqi_guanka = 0;
    

    m_select_enter_yixiangzz_gk = 1;
    m_yixiangzi_last_kaiqi_guanka = 0;

   

    m_global_change_scence_tip = "";
   


    m_from_sub_game_to_hall = 0;
    m_hongrongdao_last_kaiqi_guanka = 0;



    m_gametype_shipingjiesuoed_hklist_map = new WMap();

    constructor() 
    { 
        this.m_b_first_enter_game = 1;
       // this.m_hmk_last_kaiqi_guanka = 0;
       // this.InitLoad_HMK_Guanka();



      //  this.m_txz_last_kaiqi_guanka = 0;
       // this.InitLoad_TXZ_Guanka();


        this.m_select_enter_yixiangzz_gk = 1;
       // this.m_yixiangzi_last_kaiqi_guanka = 0;

        //this.InitLoad_Yixiangzi_Guanka();


        this.m_from_sub_game_to_hall = 0;
       // this.m_hongrongdao_last_kaiqi_guanka = 0;
       // this.InitLoad_HuaRongdao_Guanka()


        this.InitLoad_All_Game_Winned_Guanka()



    }


    Get_SubGametype_Next_Level(isubgametype,igk)
    {
       var imaxgk = this.Get_SubGametype_Max_Can_Enter_GK(isubgametype);

       if(igk + 1 < imaxgk )
       {
            return igk+1;
       }

       return imaxgk;
    }

    Get_SubGametype_Max_Can_Enter_GK(isubgametype)
    {
      

        var maxwingk = this.Get_SubGametype_Max_Win_GK(isubgametype);

        var imaxcanentergk = maxwingk+1;
        return imaxcanentergk;
    }

    Get_SubGametype_Max_Win_GK(isubgametype)
    {
        if(!this.m_subgametype_max_win_gk_map.hasKey(isubgametype))
        {
            return 0;
        }

        var imaxwingamegk = this.m_subgametype_max_win_gk_map.getData(isubgametype);
        return imaxwingamegk;
    }



    Get_Shiping_Jiesuoed_GK_List(isubgametype)
    {
        if(!this.m_gametype_shipingjiesuoed_hklist_map.hasKey(isubgametype))
        {
            this.InitLoad_Game_Shiping_Jiesuo_GK_Map(isubgametype);
        }

        if(!this.m_gametype_shipingjiesuoed_hklist_map.hasKey(isubgametype))
        {
            var arr1 = [];
            this.m_gametype_shipingjiesuoed_hklist_map.putData(isubgametype,arr1);
        }


        var allarr = this.m_gametype_shipingjiesuoed_hklist_map.getData(isubgametype);

        return allarr;

    }
    Add_GameType_Shiping_Jiesuoed_GK(isubgametype,lv)
    {
        if(!this.m_gametype_shipingjiesuoed_hklist_map.hasKey(isubgametype))
        {
            var arr1 = [];
            this.m_gametype_shipingjiesuoed_hklist_map.putData(isubgametype,arr1);
        }


        var allarr = this.m_gametype_shipingjiesuoed_hklist_map.getData(isubgametype);
        allarr.push({g:lv,w:0});

       this.m_gametype_shipingjiesuoed_hklist_map.putData(isubgametype,allarr);
  
       this.Save_Game_Shiping_Jiesuo_GK_Map(isubgametype);
    }
    Save_Game_Shiping_Jiesuo_GK_Map(isubgametype)
    {
        if(!this.m_gametype_shipingjiesuoed_hklist_map.hasKey(isubgametype))
        {
            var arr1 = [];
            this.m_gametype_shipingjiesuoed_hklist_map.putData(isubgametype,arr1);
        }


        var allarr = this.m_gametype_shipingjiesuoed_hklist_map.getData(isubgametype);


        cc.sys.localStorage.setItem("shaonaomukuai_game_"+isubgametype+"_shiping_jiesuo_gk_list",JSON.stringify(allarr));

    }
    InitLoad_Game_Shiping_Jiesuo_GK_Map(isubgametype)
    {
        var str = cc.sys.localStorage.getItem("shaonaomukuai_game_"+isubgametype+"_shiping_jiesuo_gk_list");

        if(!str)
        {
            return;
        }

        var pobj = JSON.parse(str);

        if(!pobj)
        {
            return;
        }


        var all_arr = [];
        for(var ff=0;ff<pobj.length;ff++)
        {
            var ff_info = pobj[ff];
            var igk = ff_info.g ;
            var wined = ff_info.w ;

            all_arr.push({g:igk,w:wined});
        }

        this.m_gametype_shipingjiesuoed_hklist_map.putData(isubgametype,all_arr);
    }
    InitLoad_HuaRongdao_Guanka()
    {
        var igk = cc.sys.localStorage.getItem("last_kaiqi_huarongdao_guanka");
    
        if(igk != "" && igk)
        {
            var ig = parseInt(igk);

            if(ig > 0 && ig < 400 && !isNaN(ig))
            {
                this.m_hongrongdao_last_kaiqi_guanka = ig;
            }
        }


        if(!this.m_hongrongdao_last_kaiqi_guanka)
        {
            this.m_hongrongdao_last_kaiqi_guanka = 1;
        }
    }
    InitLoad_Yixiangzi_Guanka()
    {
       
        var igk = cc.sys.localStorage.getItem("last_kaiqi_yixiangzi_guanka");
    
        if(igk != "" && igk)
        {
            var ig = parseInt(igk);

            if(ig > 0 && ig < 400 && !isNaN(ig))
            {
                this.m_yixiangzi_last_kaiqi_guanka = ig;
            }
        }
       
        if(!this.m_yixiangzi_last_kaiqi_guanka)
        {
            this.m_yixiangzi_last_kaiqi_guanka = 1;
        }
       
    }

    On_Yixiangzi_JieSuo_New_Level(iguangka)
    {
        if(this.m_yixiangzi_last_kaiqi_guanka < iguangka)
        {
            this.m_yixiangzi_last_kaiqi_guanka = iguangka;
            cc.sys.localStorage.setItem("last_kaiqi_yixiangzi_guanka",iguangka);
        }
    }

    InitLoad_TXZ_Guanka()
    {
       
        var igk = cc.sys.localStorage.getItem("last_kaiqi_txz_guanka");
    
        if(igk != "" && igk)
        {
            var ig = parseInt(igk);

            if(ig > 0 && ig < 400 && !isNaN(ig))
            {
                this.m_txz_last_kaiqi_guanka = ig;
            }
        }
      
        if(!this.m_txz_last_kaiqi_guanka)
        {
            this.m_txz_last_kaiqi_guanka = 1;
        }
    }

    On_TXZ_JieSuo_New_Level(iguangka)
    {
        if(this.m_txz_last_kaiqi_guanka < iguangka)
        {
            this.m_txz_last_kaiqi_guanka = iguangka;
            cc.sys.localStorage.setItem("last_kaiqi_txz_guanka",iguangka);
        }
    }
 

    On_HuaRongdao_JieSuo_New_Level(iguangka)
    {
        if(this.m_hongrongdao_last_kaiqi_guanka < iguangka)
        {
            this.m_hongrongdao_last_kaiqi_guanka = iguangka;
            cc.sys.localStorage.setItem("last_kaiqi_huarongdao_guanka",iguangka);
        }
       
    }




    On_SubGametype_Winned_GK(isubgametype, iguangka)
    {
        var imax_wined_gk = this.Get_SubGametype_Max_Win_GK(isubgametype);

        var all_dayu_prev_max_gk_winned_gk_map = new WMap();
        all_dayu_prev_max_gk_winned_gk_map.putData(imax_wined_gk,1);
        all_dayu_prev_max_gk_winned_gk_map.putData(iguangka,1);


        //视频解锁关卡信息
        var all_jiesuoed_gk_info = this.Get_Shiping_Jiesuoed_GK_List(isubgametype);
 
        for(var ff=0;ff<all_jiesuoed_gk_info.length;ff++)
        {
            var ff_info = all_jiesuoed_gk_info[ff];
            var ff_g =  ff_info.g;
            var ff_w =  ff_info.w;

            if(iguangka == ff_g)
            {
                ff_info.w = 1;
                all_jiesuoed_gk_info[ff] = ff_info;
            }

            if(ff_info.w)
            {
                all_dayu_prev_max_gk_winned_gk_map.putData(ff_g,1);
            }
        }
        this.m_gametype_shipingjiesuoed_hklist_map.putData(isubgametype,all_jiesuoed_gk_info);
        this.Save_Game_Shiping_Jiesuo_GK_Map(isubgametype)

      

        //调整
        var icur_max_can_enter_gk = imax_wined_gk +1;

        while(true)
        {

            if(!all_dayu_prev_max_gk_winned_gk_map.hasKey(icur_max_can_enter_gk))
            {
                break;
            }
            icur_max_can_enter_gk++;
        }

        var inew_max_win_gk = icur_max_can_enter_gk - 1;

        this.m_subgametype_max_win_gk_map.putData(isubgametype,inew_max_win_gk);


        this.Save_All_Game_Winned_Guanka();

    }

    Save_All_Game_Winned_Guanka()
    {
        var all_arr = [];
        for(var ff=0;ff<this.m_subgametype_max_win_gk_map.size();ff++)
        {
            var ff_gametype =   this.m_subgametype_max_win_gk_map.GetKeyByIndex(ff);
            var ff_wingk =  this.m_subgametype_max_win_gk_map.GetEntryByIndex(ff);

            all_arr.push({t:ff_gametype,gk:ff_wingk})
        }
        cc.sys.localStorage.setItem("shaonaomukuai_game_winned_max_gk_info",JSON.stringify(all_arr));

    }
    InitLoad_All_Game_Winned_Guanka()
    {
        var str = cc.sys.localStorage.getItem("shaonaomukuai_game_winned_max_gk_info");
        if(!str)
        {
            return;
        }

        var pobj = JSON.parse(str);

        if(!pobj)
        {
            return;
        }
    

        for(var ff=0;ff<pobj.length;ff++)
        {
            var ff_info =  pobj[ff];
            var ff_game_type = ff_info.t;
            var max_win_gk = ComFunc.Check_Read_Number(ff_info.gk) ;

            this.m_subgametype_max_win_gk_map.putData(ff_game_type,max_win_gk);

        }
    }

    Get_Nandu_Str(inandu)
    {
        if(inandu == 1)
        {
            return "简单";
        }

        if(inandu == 2)
        {
            return "普通";
        }
        if(inandu == 3)
        {
            return "中等";
        }


        if(inandu == 4)
        {
            return "困难";
        }

        if(inandu == 5)
        {
            return "特难";
        }

        return "";
    }
    InitLoad_HMK_Guanka()
    {
       /*
        var igk = cc.sys.localStorage.getItem("last_kaiqi_hmk_guanka");
    
        if(igk != "" && igk)
        {
            var ig = parseInt(igk);

            if(ig > 0 && ig < 400 && !isNaN(ig))
            {
                this.m_hmk_last_kaiqi_guanka = ig;
            }
        }

        if(!this.m_hmk_last_kaiqi_guanka)
        {
            this.m_hmk_last_kaiqi_guanka = 1;
        }
        */
  
    }
 
}