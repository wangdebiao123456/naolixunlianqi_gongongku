 
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import Luosi_Game_Mng from "../luosi/Luosi_Game_Mng";
import Yingdao_Mng from "../luosi/Yingdao_Mng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
 

const {ccclass, property} = cc._decorator;

@ccclass
export default class loadingtogame extends cc.Component {

    m_b_in_progress = false;
  
    m_progress_start_tick = 0;
    m_prog=  null;
    

    m_b_pre_loadinged = false;

    m_b_loadined = false;

    m_start_tick = 0;

    m_b_inited = false;
    
    m_loading_scence_name = "";

    m_loading_to_scence_index = 0;

    
    m_loadinto_game_scence_max_tick = 1000;
    m_loadinto_game_scence_min_tick = 2000;

    
    @property(cc.JsonAsset)
    luosi_unit_config: cc.JsonAsset = null;
  
    @property(cc.JsonAsset)
    yingdao_step_info_define_config: cc.JsonAsset = null;
  


    @property(cc.JsonAsset)
    daluosi_config: cc.JsonAsset = null;
  


    onLoad () 
    {

        this.m_b_in_progress = true;
        this.m_progress_start_tick = Date.now();
        this.m_prog=  cc.find("bottom/progress",this.node);

        this.m_start_tick = Date.now();
        this.m_b_inited = true;
        this.m_loading_scence_name = GlobalGameMng.GetInstance().m_loading_to_game_scence_name;

       
        Luosi_Game_Mng.GetInstance().Set_Luosi_Common_Config(this.daluosi_config.json);
        //  Luosi_Game_Mng.GetInstance().Set_Luosi_Unit_Config(this.luosi_unit_config.json);
         // Luosi_Game_Mng.GetInstance().Check_Load_All_Unit_Preab();
  
         Yingdao_Mng.GetInstance().Set_Yingdao_Step_Info_Config(this.yingdao_step_info_define_config.json)

        MiddleGamePlatformAction.GetInstance().Hide_Dating_Gezi_Show();
        
        MiddleGamePlatformAction.GetInstance().Set_In_Subgame_Valid_Gezi_Guangao_Bannerindex_Arr_Info(false,0,[]);
 

        /*
        if(this.m_loading_scence_name == "dating")
        {
            this.m_loadinto_game_scence_max_tick = GlobalGameMng.GetInstance().Get_LoadingTo_Dating_Scence_Max_Tick();
            this.m_loadinto_game_scence_min_tick = GlobalGameMng.GetInstance().Get_LoadingTo_Dating_Scence_Min_Tick();
    
        }else{
            this.m_loadinto_game_scence_max_tick = GlobalGameMng.GetInstance().Get_LoadingTogame_Scence_Max_Tick();
            this.m_loadinto_game_scence_min_tick = GlobalGameMng.GetInstance().Get_LoadingTogame_Scence_Min_Tick();
    
        }
        */
       

        var self = this;
        cc.director.preloadScene(this.m_loading_scence_name,()=>
        {
            self.m_b_pre_loadinged = true;
          //  self.On_Loadingto_Game();
        });
    
        this.scheduleOnce(this.FD_Change_To_Game.bind(this),1)

    }
    FD_Change_To_Game()
    { 
        cc.director.loadScene(this.m_loading_scence_name);
    }
    On_Loadingto_Game()
    {

      //  MiddleGamePlatformAction.GetInstance().Show_LoadingToGame_Scence_Banners(false);

    

    }

    update()
    {
 
        if(!this.m_b_inited)
        {
            return;
        }


    

        var self = this;
        

        /*
        if(!this.m_b_loadined && this.m_start_tick > 0)
        {
            if(Date.now() - this.m_start_tick > this.m_loadinto_game_scence_max_tick )
            {
    
                this.On_Loadingto_Game();
                return;
            }

            if(Date.now() - this.m_start_tick > this.m_loadinto_game_scence_min_tick)
            {
                if(this.m_b_pre_loadinged)
                {
                    this.On_Loadingto_Game();
                    return;
                }
            }
        }
       
        */

        if(this.m_b_in_progress){
            var ieplasetick = Date.now() - this.m_progress_start_tick ;
            var iprogress = Math.min(ieplasetick/30000,1);
            if(ieplasetick > 30000)
            {
                 this.m_progress_start_tick =  Date.now();
            }

            if(iprogress >= 0.95)
            {
             //   iprogress = 0.95;
            }
            this.m_prog.getComponent(cc.ProgressBar).progress  = iprogress;


            var prolb = cc.find("bottom/prolb",this.node);

            if(this.m_loading_scence_name == "dating")
            {
                prolb.getComponent(cc.Label).string = "正在加载大厅资源..";

            }
            else if(this.m_loading_scence_name == "zhuangxiu")
            {
                prolb.getComponent(cc.Label).string = "正在加载装修资源..";

            }else{
                prolb.getComponent(cc.Label).string = "正在加载进入游戏场资源..";

            }
           
        }
    }

}
