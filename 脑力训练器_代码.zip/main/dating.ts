import ComFunc from "../comfuncs/ComFunc";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import PlatFormMng from "../PlatForm/PlatFormMng";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import GlobalData from "./GlobalData";
import HMK_Create_GK from "../huamukuai/HMK_Create_GK";
import ComCodeFuncMng from "../comfuncs/ComCodeFuncMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import WMap from "../WDT/WMap";
import HutuiAppInfoMng from "../PlatForm/HutuiAppInfoMng";
import BaseUIUtils from "../comfuncs/BaseUIUtils";
import PlatFormType from "../PlatForm/PlatFormType";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import MyLocalStorge from "../WDT/MyLocalStorge";
import shuziHuaRongDaoLogicMng from "../shuzihuarongdao/shuziHuaRongDaoLogicMng";
import HuaMuKuaiMng from "../huamukuai/HuaMuKuaiMng";
import HMK_GK_Mng from "../huamukuai/HMK_GK_Mng";
import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng";
import MishiTaoTouMng from "../mishitaotou/MishiTaoTouMng"; 
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";
import ChouJiangMng from "../comfuncs/ChouJiangMng";
import GlobalConfig from "../pingpinggame/GlobalConfig";
import LeoGameInfoMng from "../WDT/LeoGameInfoMng";
import Juba_Beijing_Gedan_Mng from "../jiubei/utils/Juba_Beijing_Gedan_Mng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class dating extends cc.Component {

   
 
   
    @property(cc.Prefab)
    qiandaoSign:cc.Prefab = null;
   
    @property(cc.Prefab)
    yonghuxieyi:cc.Prefab = null;
   

    @property(cc.Prefab)
    yaoqing_dlg:cc.Prefab = null;
   
 

    @property(cc.Prefab)
    more_wanfa_dlg:cc.Prefab = null;
   
    
    

    
    m_last_tuijian_change_tick = 0;
    m_tuijianwe_dest_info_map = new WMap();

    m_process_gamebtn_caidan_mode = 1;

    m_b_config_loaded = false;
    
    m_last_enter_game_btn_click_tick = 0;


    m_dating_last_from_subgame_type  = 0;
    m_dating_last_from_subgame_level  = 0;

    onLoad ()
    {
        var menu = this.node.getChildByName("menu");


        /*
        var huamukuai1 = cc.find("menu/dating1/huamukuai",this.node);
        huamukuai1.on("click",this.OnBtnHuaMuKuai.bind(this));


        var huamukuai2 = cc.find("menu/dating2/huamukuai",this.node);
        huamukuai2.on("click",this.OnBtnHuaMuKuai.bind(this));

        var huamukuai3 = cc.find("menu/dating3/huamukuai",this.node);
        huamukuai3.on("click",this.OnBtnHuaMuKuai.bind(this));


        
        var tuixiangzi1 = cc.find("menu/dating1/tuixiangzi",this.node);
        tuixiangzi1.on("click",this.OnBtnTuiXiangzi.bind(this));


        var tuixiangzi2 = cc.find("menu/dating2/tuixiangzi",this.node);
        tuixiangzi2.on("click",this.OnBtnTuiXiangzi.bind(this));


        var mushitaowang1 = cc.find("menu/dating1/mushitaowang",this.node);
        mushitaowang1.on("click",this.OnBtnMoxiTaowang.bind(this));

        var mushitaowang2 = cc.find("menu/dating2/mushitaowang",this.node);
        mushitaowang2.on("click",this.OnBtnMoxiTaowang.bind(this));


        var shuzihuarongdao1 = cc.find("menu/dating1/shuzihuarongdao",this.node);
        shuzihuarongdao1.on("click",this.OnBtnShuziHuaRongDao.bind(this));
 
        var shuzihuarongdao2 = cc.find("menu/dating2/shuzihuarongdao",this.node);
        shuzihuarongdao2.on("click",this.OnBtnShuziHuaRongDao.bind(this));
 
        var yixiangzi1 = cc.find("menu/dating1/yixiangzi",this.node); 
        yixiangzi1.on("click",this.OnBtnYiXiangzi.bind(this));

        var yixiangzi2 = cc.find("menu/dating2/yixiangzi",this.node); 
        yixiangzi2.on("click",this.OnBtnYiXiangzi.bind(this));



        var huaduoxiaoxiao = cc.find("menu/dating2/huaduoxiaoxiao",this.node); 
        huaduoxiaoxiao.on("click",this.OnBtn_HuaduoXiaoxiao.bind(this));

 
        var sanxiaoxiao = cc.find("menu/dating2/sanxiaoxiao",this.node); 
        sanxiaoxiao.on("click",this.OnBtnSanXiaoxiao.bind(this));


        var mishitaotuo = cc.find("menu/dating2/mishitaotuo",this.node); 
        mishitaotuo.on("click",this.OnBtnMishiTaotou.bind(this));

        */

         
      //  var fenxiang = cc.find("uimenus/fenxiang",this.node);
       // fenxiang.on("click",this.OnBtnFenXiang.bind(this));

        

       // fenxiang.active = PlatFormMng.GetInstance().IS_Fenxiang_Btn_Show();


        var tuijian_new = cc.find("uimenus/tuijian_new",this.node);
        tuijian_new.on("click",this.OnBtnShowDatingQaunpingGeziGuanggao.bind(this));

 
        var com_quanping_gezi_show = PlatFormMng.GetInstance().IS_Dating_Game_Quanping_Gezi_Btn_Show();

        if(!com_quanping_gezi_show)
        {
            tuijian_new.active = false;
        }

 
        var huamukuai = cc.find("menu/huamukuai",this.node);
        huamukuai.on("click",this.OnBtnHaumuXunlian.bind(this))

 
        
        var luosixunlian = cc.find("menu/luosixunlian",this.node);
        luosixunlian.on("click",this.OnBtnLuosiXunlian.bind(this))

 
  
        var jiubeixunlian = cc.find("menu/jiubeixunlian",this.node);
        jiubeixunlian.on("click",this.OnBtnJubaXunlian.bind(this))

 

        var guaishouxunlian = cc.find("menu/guaishouxunlian",this.node);
        guaishouxunlian.on("click",this.OnBtnGuaishouXunlian.bind(this))

 
        var yidianshanghai = cc.find("menu/yidianshanghai",this.node);
        yidianshanghai.on("click",this.OnBtnYiyiShanghaiXunlian.bind(this))

 

        
        
        var qiandao = cc.find("uimenus/qiandao",this.node);
        qiandao.on("click",this.OnBtnQiandao.bind(this))

 

        var yaoqing_node = cc.find("uimenus/yaoqing",this.node);
        yaoqing_node.on("click",this.OnBtnYaoqing.bind(this));
 

 
        this.m_dating_last_from_subgame_type = GlobalGameMng.GetInstance().m_dating_last_from_subgame_type ;
        this.m_dating_last_from_subgame_level = GlobalGameMng.GetInstance().m_dating_last_from_subgame_level ;

 
        GlobalGameMng.GetInstance().m_dating_last_from_subgame_type  = 0 ;
       GlobalGameMng.GetInstance().m_dating_last_from_subgame_level = 0 ;


        GlobalGameMng.GetInstance().Start_CountDown_Add_Tili();
        this.schedule(this.FD_Count_Tili.bind(this),0.3);

        
 
       // var fxhy = menu.getChildByName("fxhy");
      //  fxhy.on("click",this.OnBtnFenXiang.bind(this));
       // fxhy.active = PlatFormMng.GetInstance().IS_Fenxiang_Btn_Show();

     //   let shezhi = menu.getChildByName("shezhi");
      //  shezhi.on("click",this.OnBtnShezhi.bind(this));

      //  let help = menu.getChildByName("bangzhu");
      //  help.on("click",this.OnBtnHelp.bind(this));


        this.Refresh_Money();

         

      //  var bshow_yongyhuxieyi = PlatFormMng.GetInstance().Check_Show_YonghuXieyi();
       // xieyi_btn.active = bshow_yongyhuxieyi;
        

       HutuiAppInfoMng.GetInstance().LoadRemoteConfig(()=>{


       });
        ComFunc.Check_Init_Load_All_Preab();

        var self=  this;
       GlobalGameMng.GetInstance().Load_Game_Common_Config(()=>{
        //  self.Refresh_On_Common_Config_Loaded();
    

       });

      // 
        if(GlobalData.GetInstance().m_b_first_enter_game)
        {
            GlobalData.GetInstance().m_b_first_enter_game = 0;
            var starttip = this.node.getChildByName("starttip");
            starttip.active = false;
          

            HMK_GK_Mng.GetInstance().Init_Load_All_Data();

            var bshow_xieyi = this.FD_Show_Xiei();

            if(!bshow_xieyi)
            {
                this.scheduleOnce(this.Check_Show_Pop_Qiandao_And_Gezi.bind(this),0.2);

            }

        }else{
            
  
            if(GlobalData.GetInstance().m_morewafa_last_opend_type  == 0 )
            {
                 this.scheduleOnce(this.Check_Show_Pop_Qiandao_And_Gezi.bind(this),0.2);

            }
       
        }
        BackGroundSoundUtils.GetInstance().playBackgroundMusic("com/datingbk") ; 
          //  this.scheduleOnce(this.FD_Show_Xiei.bind(this),0.1);
        
      
        this.Init_Top_Tuijian_Guangao();
        this.scheduleOnce(this.OnGameStarted.bind(this),0.1);
 

      BannerGuangaoMng.GetInstance().LoadRemoteConfig(()=>{}); 
     
        var banner_arr = [ ];
        MiddleGamePlatformAction.GetInstance().Set_In_Subgame_Valid_Gezi_Guangao_Bannerindex_Arr_Info(false,0,banner_arr);

        var ibanner_mng_time = GlobalGameMng.GetInstance().Get_Game_Banner_Mng_Time_Config(0);
  
        this.schedule(this.FD_Banner_Mng_Timer.bind(this),ibanner_mng_time);

       

        this.InitGuanggao();
 

        this.Init_Read_Sanxiaoxiao_Data();
  

        if(GlobalData.GetInstance().m_morewafa_last_opend_type > 0 )
        {
            this.OpenMoreWanfaDlf(GlobalData.GetInstance().m_morewafa_last_opend_type );
 
        }
 

        if(!LeoGameInfoMng.GetIns().m_yaoqing_info_posted
               && LeoGameInfoMng.GetIns().m_enter_from_other_user_openid     )
        {
            LeoGameInfoMng.GetIns().Check_Post_Read_OpenId();
            LeoGameInfoMng.GetIns().Check_WX_Load_From_Openid();

          //  BaseUIUtils.ShowTipTxtDlg("重新,lasttick="+LeoGameInfoMng.GetIns().m_last_post_yaoqing_tick ,this.node,new cc.Vec2(0,200),14)
      


        }

        /*
  BaseUIUtils.ShowTipTxtDlg("error_response="+LeoGameInfoMng.GetIns().m_last_error_response  ,this.node,new cc.Vec2(0,400),14)
      
        var strinfo = "自己ID:"+LeoGameInfoMng.GetIns().m_wx_openid+",fromID="+LeoGameInfoMng.GetIns().m_enter_from_other_user_openid;

        BaseUIUtils.ShowTipTxtDlg(strinfo,this.node,new cc.Vec2(0,0),14)
     
        */


        PlatFormMng.GetInstance().Check_WX_Login_Read_OpenId(()=>{

            
            ClientLogUtils.GetInstance().Poset_Server_JS_Log(2, "进入大厅", 1,
            "大厅界面", 0, "", 0, "");
        });
        
      
 
        Juba_Beijing_Gedan_Mng.GetInstance().Stop_All_Game_Bj_Music();

    }
    OpenMoreWanfaDlf(itype)
    {
        var self = this;
        var pndoe = cc.instantiate(this.more_wanfa_dlg);
        var more_wanfa_dlg = pndoe.getComponent("more_wanfa_dlg");
        more_wanfa_dlg.SetInfo(

            {
                itype:itype,
                cb:()=>
                {
                    self.Refresh_Money(); 
                    self.Check_Show_Pop_Qiandao_And_Gezi();
                }
            }
        )
        this.node.addChild(pndoe,100);
    }
    OnBtnYiyiShanghaiXunlian()
    {
        this.OpenMoreWanfaDlf(5)
    }
    OnBtnGuaishouXunlian()
    {
        this.OpenMoreWanfaDlf(4)
    }
    OnBtnJubaXunlian()
    {
        this.OpenMoreWanfaDlf(3)
    }
    OnBtnLuosiXunlian()
    {
        this.OpenMoreWanfaDlf(2)

    }
    OnBtnHaumuXunlian()
    {
        this.OpenMoreWanfaDlf(1)
    }
    OnBtnYaoqing()
    {
        
        var self = this;
        var pndoe = cc.instantiate(this.yaoqing_dlg);
        var yaoqing_dlg = pndoe.getComponent("yaoqing_dlg");
        yaoqing_dlg.SetInfo(

            {
                callback:()=>
                {
                    self.Refresh_Money();
                }
            }
        )
        this.node.addChild(pndoe,100);
    }
    OnBtnChouJiang()
    {
        var self = this;

        var choujianginfo = ChouJiangMng.GetInstance().Get_Choujiang_Info();
        var bhaschoujiang = choujianginfo[0];
        var ileft_sec = choujianginfo[1];
        if(!bhaschoujiang || ileft_sec > 0)
        {
       
            ComFunc.OpenNewDialog(
             
                this.node,"preab/common/choujiang_left_time_tishi","choujiang_left_time_tishi", {parentgame:self ,
                cb:()=>
                {
                    self.Refresh_Money();
                    
                }});
            return;
        };
 
        

        ComCodeFuncMng.Common_Choujiang(this.node,()=>
        {
            self.Refresh_Money();
            
        });
        
    }
   
     
    Init_Read_Sanxiaoxiao_Data()
    {
        /*

        var self = this;
        GSXC_Game_Mng.GetInstance().InitReadConfig(()=>
        {
            GSXC_Game_Mng.GetInstance().InitLoadTiles(()=>
            {
                self.m_b_config_loaded = true;
            })
            
        });
        
        */

    }
     
    IS_First_Dating_Enter()
    {
        var strshaonaomukuai_first_enter_dating = "strshaonaomukuai_first_enter_dating";
        var strsave = MyLocalStorge.getItem(strshaonaomukuai_first_enter_dating);

        if(strsave && strsave == "1")
        {
            return false;
        }

        MyLocalStorge.setItem(strshaonaomukuai_first_enter_dating,"1");

        return true;
    }

    Check_Show_Pop_Qiandao_And_Gezi()
    {

        var bhas = this.Check_Show_Pop_Qiandao_Or_Choujiang_Dlg();
        if(bhas)
        {
            return;
        }

        

       
        BannerGuangaoMng.GetInstance().Check_Show_Quanping_Chaiping_Gezi(1,this.m_dating_last_from_subgame_type ,this.m_dating_last_from_subgame_level);
 
    }



    Check_Show_Pop_Qiandao_Or_Choujiang_Dlg()
    {
        var bhas = this.Check_Show_Pop_Qiandao_Dlg();
        if(bhas)
        {
            return true;
        }

        //判断是否抽奖
        return false;

        /*
        var max_gk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(1);


        var show_choujiang = ComCodeFuncMng.Check_Show_ChouJiang_Libao(this,this.node,0,max_gk)


        return show_choujiang;
        */
    }

    Check_Show_Pop_Qiandao_Dlg()
    {

 
 
        if(this.IS_First_Dating_Enter())
        {
            if(GlobalGameMng.GetInstance().IS_First_Enter_Dating_Hide_Qiandao())
            {
                return false;
            }
        }
       
         
        //接下来判断需要不需要再弹出来签到弹框

        var sign_unlinged = ComFunc.Check_Sign_Has_UnLingqued();
        if(!sign_unlinged)
        {
            return false;
        }


        var dlg_tanchu_type = GlobalGameMng.GetInstance().Get_Qiandao_Dlg_Tachu_Type();
        var itanchu_per_gk = GlobalGameMng.GetInstance().Get_Qiandao_Dlg_Tachu_Per_GK();


        if(!GlobalGameMng.GetInstance().m_b_first_sign_dlg_poped  )
        {

        }else{
            if(dlg_tanchu_type == 0)
            {
                var poped = GlobalGameMng.GetInstance().m_b_first_sign_dlg_poped ;
                if(poped)
                {
                    return false;
                }
            }
            else if(dlg_tanchu_type == 1)
            {
    
            }else if(dlg_tanchu_type == 2)
            {
                this.Add_Qiandao_dlg_tanchu_Jiange_GK();
    
                //间隔几个关卡
                var qd_jiange_gk_info = this.GetLast_Qiandao_dlg_tanchu_Jiange_GK();
                var ijaingegk = qd_jiange_gk_info[1];
    
    
                if(ijaingegk <= itanchu_per_gk)
                {
                    return false;
                }
    
                var last_v = "shaonaomukuai_qiandao_tanchu_dlg_jiange_gk";
                MyLocalStorge.removeItem(last_v);
            }
    
        }


       
       
        GlobalGameMng.GetInstance().m_b_first_sign_dlg_poped = true;
        this.OnBtnQiandao();

        return true;
    }


    OnBtnShancheng()
    {
        var self  = this;
        ComFunc.OpenNewDialog(this.node,"preab/shangcheng","shangcheng",{cb:()=>
        {
            self.Refresh_Money();
        }});
 
    }
    OnBtnQiandao()
    {
        var pndoe = cc.instantiate(this.qiandaoSign);
        var qiandaoSign=  pndoe.getComponent("qiandaoSign");
        qiandaoSign.SetInitData({});
        this.node.addChild(pndoe,15);

    }
    GetLast_Qiandao_dlg_tanchu_Jiange_GK()
    {
        var last_v = "shaonaomukuai_qiandao_tanchu_dlg_jiange_gk";

        var prevstr = MyLocalStorge.getItem(last_v,"");

        if(!prevstr)
        {
            return [0,0];
        }


        var pobj = JSON.parse(prevstr);
        if(!pobj)
        {
            return [0,0];
        }

        var ijiangegk = pobj.ijiangegk;
        if(!ijiangegk)
        {
            ijiangegk = 0;
        }
        return [1,ijiangegk];
    }
    Add_Qiandao_dlg_tanchu_Jiange_GK()
    {
        var pinfo = this.GetLast_Qiandao_dlg_tanchu_Jiange_GK();
        var prevgk = pinfo[1];
        var newgk = prevgk+1;

        var obj = {
            ijiangegk:newgk
        }


        var last_v = "shaonaomukuai_qiandao_tanchu_dlg_jiange_gk";

        var str = JSON.stringify(obj);
        MyLocalStorge.setItem(last_v,str);
    }

    Check_Show_Gezi_Guanggao()
    {
        if(PlatFormParaMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_WX)
        {
            MiddleGamePlatformAction.GetInstance().Set_In_Subgame_Valid_Gezi_Guangao_Bannerindex_Arr_Info(false,
                0,[ ]);
    
    
    
            
         
            // /大厅两个格子序号:101,102
           // MiddleGamePlatformAction.GetInstance().Check_Create_Common_Banner(101,2);
            //MiddleGamePlatformAction.GetInstance().Check_Create_Common_Banner(102,2);
           // MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(101,true);
           // MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(102,true);
        }
        
      




    }
    OnBtnShowDatingQaunpingGeziGuanggao()
    {
        MiddleGamePlatformAction.GetInstance().Check_Create_Common_Banner(18,2);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(18,2);
    }

    InitGuanggao()
    {
        
        MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(82,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(83,false);


        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(88,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(89,false);


        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(72,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(73,false);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(92,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(93,false);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(112,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(113,false);




         
        MiddleGamePlatformAction.GetInstance().Set_Game_Libao_Dlg_Gezi_Sgow(false);
        MiddleGamePlatformAction.GetInstance().Show_Qiandao_Banners(false);
    }

    FD_Banner_Mng_Timer()
    { 
        MiddleGamePlatformAction.GetInstance().FD_Banner_Mng_Timer(this.node);

    }
   

    OnBtnGoumaiTili()
    {
        var self = this;
        ComCodeFuncMng.Show_Goumai_Tili_Dlg(2,this.node,(bsuc)=>
        { 
            self.Refresh_Money();
        });
    }
    FD_Count_Tili()
    {
        GlobalGameMng.GetInstance().Count_Down_Add_Tili(); 

        this.Refresh_Money();

 

    }
    Refresh_Money()
    {
        var jinbi_c_label = cc.find("top/jinbi/c",this.node);

        var imoney = GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(1);
        jinbi_c_label.getComponent(cc.Label).string = ""+imoney;


        var zuanshi_c_label = cc.find("top/zuanshi/c",this.node);

        var izs = GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(2);
        zuanshi_c_label.getComponent(cc.Label).string = ""+izs;




        var enter_cishu_nei_bukou_tili = GlobalGameMng.GetInstance().Get_Per_Game_First_Enter_Cishu_Nei_Bukou_Tili();

     
        var tili_node = cc.find("top/tili",this.node);
    
        var tili_c_label = cc.find("top/tili/c",this.node);
        var itili = GlobalGameMng.GetInstance().Get_Tili();
        var imaxtili = GlobalGameMng.GetInstance().Get_Max_Tili();
        tili_c_label.getComponent(cc.Label).string = ""+itili+"/"+imaxtili;

        var is_tili_hide = GlobalGameMng.GetInstance().IS_All_Tili_Hide();

        if(is_tili_hide)
        { 
            tili_node.active = false;
        }
        else{ 
            tili_node.active = true;
        }


        var tili_lefttime_label = cc.find("top/tili/lefttime",this.node);
        var tili_countdown_start_Left_count =  GlobalGameMng.GetInstance().m_tili_countdown_start_Left_count;

        var ieplsetick = Date.now() - GlobalGameMng.GetInstance().m_tili_countdown_start_tick;
        var isec=  Math.floor(ieplsetick/1000);

        var left_sec = Math.floor(tili_countdown_start_Left_count - isec) ;

        if(left_sec <= 0)
        {
            left_sec = 0;
        }

        
        if(tili_countdown_start_Left_count > 0)
        {
            tili_lefttime_label.active = true;
            tili_lefttime_label.getComponent(cc.Label).string = ""+ComFunc.FormatLeftSecStr(left_sec);
        }else{
            tili_lefttime_label.active = false;

        }
    }
    FD_Show_Xiei()
    {
        return false;
        /*
        if(!PlatFormMng.GetInstance().Check_Show_YonghuXieyi())
        {
            return false;
        }
        var xieyiqianshued = cc.sys.localStorage.getItem("shaonaomukuai_xieyiqianshued");
        if(xieyiqianshued == "1")
        {
            return false;
        }else{
           this.OnBtn_Xieyi(100);

           return true;
        }

        return false;
        */
    }
    OnBtn_Xieyi(idata)
    {
        
        var bfist = false;
        if(idata == 100)
        {
            bfist=  true;
        }
        var pnode = cc.instantiate(this.yonghuxieyi);
        this.node.addChild(pnode,30);
        var yonghuxieyi = pnode.getComponent("yonghuxieyi");
        yonghuxieyi.SetInitData(this.OnYonghuXieyiConfirm.bind(this),bfist);
       
    }
    OnYonghuXieyiConfirm()
    {
        cc.sys.localStorage.setItem("shaonaomukuai_xieyiqianshued","1");
     
    }
    OnBtnHelp()
    {
      //  let pnode =  cc.instantiate(this.helpdlg);
     //   pnode.setPosition(0,0);
    
     //   this.node.addChild(pnode,100);

       
    }
    OnBtnShezhi()
    {//
       // let pnode =  cc.instantiate(this.shezhidlg);
       // pnode.setPosition(0,0);
    
      //  this.node.addChild(pnode,100);

    }
    OnBtnFenXiang()
    {
        PlatFormMng.GetInstance().Dating_Fenxiang();
     
    }
    OnGameStarted()
    {
        var ineesec = 0.1;
        var starttip = this.node.getChildByName("starttip");
       // var bneed =  false;
        if(starttip.active)
        {
          //  bneed =  true;

            ineesec+=1;
        }

        starttip.active = false;
      
       

         
       // if(bneed)
        { 
          //  this.scheduleOnce(this.Check_Show_Pop_Qiandao_Dlg.bind(this),0.2);

        }
       
        
        this.Check_Show_Gezi_Guanggao();
    
        this.m_process_gamebtn_caidan_mode = GlobalGameMng.GetInstance().Get_Cur_Process_Dating_Show_GameBtn_Caidan_Mode();
         
       // this.Check_WX_Update();


    }
    Check_WX_Update()
    {
        
        if(PlatFormMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            //return;
        }

        PlatFormMng.GetInstance().Check_Update();


        
    }


    OnBtn_Select_Subgame_Nandu(igametype)
    {


        var self = this;
        ComFunc.OpenNewDialog(this.node,"preab/common/com_sel_nandu","com_sel_nandu", { parentgame:this, 
            isubgametype:igametype ,
            cb:(inandu,bxuanguang)=>
        {
           
            self.On_Select_Subgame_Nandu(igametype,inandu,bxuanguang);
            //self.GoToLevel(isubgametype,lv);

        

        }});
          
        
    }

    On_Select_Subgame_Nandu(igametype,inandu,bxuanguang)
    {
        var irealsubgametype = igametype;

        if(igametype == 1)
        {
            irealsubgametype = HMK_GK_Mng.GetInstance().Get_Mode_GameType(inandu);
        }


        var imax_can_enter_gk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(irealsubgametype);
        var igk = imax_can_enter_gk;

        if(bxuanguang)
        {
            this.OnBtn_Select_SubgAme_GK(irealsubgametype);
        }else{
            this.Real_Start_Goto_Game(irealsubgametype,igk);
    
        }

         // 

 
    }
    OnBtn_Select_SubgAme_GK(isubgametype)
    { 
      
        var imax_can_enter_gk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(isubgametype);
        var igk = imax_can_enter_gk;
    
        var self = this;
        ComFunc.OpenNewDialog(this.node,"preab/selectgk","selectgk", { parentgame:this,
            imax_can_enter_gk:imax_can_enter_gk,
            isubgametype:isubgametype,igk:igk,
            cb:(lv)=>
        {
           
            self.GoToLevel(isubgametype,lv);
          
        }}); 

    }


    GoToLevel(isubgametype,lv)
    {
       // if(isubgametype == 2)
        {
            this.Real_Start_Goto_Game(isubgametype,lv);
        }
    }


    Real_Start_Goto_Game(isubgametype,igk)
    {
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(isubgametype))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        if(isubgametype == 1)
        {
            GlobalData.GetInstance().m_select_enter_hmk_nandu = 1;
            GlobalData.GetInstance().m_select_enter_hmk_gk = igk;
            cc.director.loadScene("huamukuai");
           
        }
        else if(isubgametype == 2)
        {

            GlobalData.GetInstance().m_select_enter_yixiangzz_gk = igk;
            cc.director.loadScene("YiXiangzi");
        }
        else if(isubgametype == 3)
        {


            GlobalData.GetInstance().m_select_enter_txz_gk = igk;
            cc.director.loadScene("Tuixiangzi");
        }
        else if(isubgametype == 4)
        {


            GlobalData.GetInstance().m_select_enter_huarongdao_gk = igk;
            cc.director.loadScene("huarongdao");
        }
        else if(isubgametype  > 100 && isubgametype < 120)
        {

            var imode = isubgametype - 100;
            shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_mode_type =  imode;
            shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_gk =    igk;
    
            cc.director.loadScene("shuzihuarongdao");

        }  
        else if(isubgametype  > 130 && isubgametype < 140)
        {

            GlobalData.GetInstance().m_select_enter_hmk_nandu = isubgametype - 130;
            GlobalData.GetInstance().m_select_enter_hmk_gk = igk;
            cc.director.loadScene("huamukuai");
        }
    }
    Check_Enter_Game_Btn_Enough_Tick()
    {
        if(this.m_last_enter_game_btn_click_tick > 0)
        {
            if(Date.now() - this.m_last_enter_game_btn_click_tick < 1000)
            {
                return false;
            }
        }
        this.m_last_enter_game_btn_click_tick = Date.now();
        return true;
    }

    OnBtn_HuaduoXiaoxiao()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(6))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show(); 
        GlobalConfig.GetIns().Set_Show_WupingType(2);
        GlobalConfig.GetIns().Enter_Game_Mode(2);
        ComFunc.RealLoadScence("huaduo_xiaoxiao" );
    }
    OnBtnMishiTaotou()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(3))
        {
            return;
        }

        this.Hide_Dating_Gezi_Show();
        MishiTaoTouMng.GetInstance().SetFromDatingEnetr(true);
        cc.director.loadScene("mishitaotougame");
    }

    OnBtnSanXiaoxiao()
    {
        if(!this.m_b_config_loaded)
        {

            BaseUIUtils.ShowTipTxtDlg("暂未加载完配置文件，请稍后再试",this.node);
            return;
        }
        
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(1))
        {
            return;
        }

        this.Hide_Dating_Gezi_Show();

        GSXC_Game_Mng.GetInstance().m_enter_xiaochu_chaonan_moshi = false;
        GSXC_Game_Mng.GetInstance().selectedLevel  = GSXC_Game_Mng.GetInstance().Get_Max_Can_Enter_GK();
        cc.director.loadScene("sanxiaoxiaoGame" );
    }
    OnBtnYiXiangzi()
    {
        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(2);
   

        if(igk >= 3)
        {
            //第三关后，点击开始选关

          //  this.OnBtn_Select_SubgAme_GK(2);


          

           // return;
        }
      
        this.Real_Start_Goto_Game(2,igk);

        /*
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(2))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
        GlobalData.GetInstance().m_select_enter_yixiangzz_gk = igk;
        cc.director.loadScene("YiXiangzi");

 
        */
    }
    Hide_Dating_Gezi_Show()
    {
        MiddleGamePlatformAction.GetInstance().Hide_Dating_Gezi_Show();
       

 
  



    }

    Check_Has_Tili_Enter_Subgame_And_Kouchu(isbugametype)
    {


        var bsuc = ComCodeFuncMng.Check_Has_Tili_Enter_Subgame_And_Kouchu(isbugametype,this.node);
        this.Refresh_Money();

        return bsuc;
    }


    On_Select_ShuziHuarongDao_Xuanguan(imode)
    {
        var isubgametype = shuziHuaRongDaoLogicMng.GetInstance().Get_Mode_GameType(imode);
        this.OnBtn_Select_SubgAme_GK(isubgametype);


    }

    OnBtnShuziHuaRongDao()
    {
        ComFunc.OpenNewDialog(this.node,"preab/shuzihuarogndao/shuzihuarongdao_sel_mode","shuzihuarongdao_sel_mode",{
            parentgame:this,cb:this.On_Select_ShuziHuarongDao_Xuanguan.bind(this)

        });
    }
    OnBtnMoxiTaowang()
    {
        /*
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(4))
        {
            return;
        }

        this.Hide_Dating_Gezi_Show();

        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(4);
        GlobalData.GetInstance().m_select_enter_huarongdao_gk = igk;
        cc.director.loadScene("huarongdao");

*/


        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(4);
   

        if(igk >= 3)
        {
            //第三关后，点击开始选关

           // this.OnBtn_Select_SubgAme_GK(4);


          

            //return;
        }
      
        this.Real_Start_Goto_Game(4,igk);
        
    }
    OnBtnHuaMuKuai()
    {

        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(1);
        if(igk >= 3)
        {
            //第三关后，点击开始选关

         //   this.OnBtn_Select_SubgAme_GK(1);

            //首先，选择难度
 
            this.OnBtn_Select_Subgame_Nandu(1);

            return;
        }
      
        this.Real_Start_Goto_Game(1,igk);

        /*
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(1))
        {
            return;
        }

        this.Hide_Dating_Gezi_Show();

        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(1);
        GlobalData.GetInstance().m_select_enter_hmk_gk = igk;
        cc.director.loadScene("huamukuai");
 
        */
    }

    OnBtnTuiXiangzi()
    {
        /*
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(3))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(3);
        GlobalData.GetInstance().m_select_enter_txz_gk = igk;
        cc.director.loadScene("Tuixiangzi");

        */


        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(3);
   

        if(igk >= 3)
        {
            //第三关后，点击开始选关

           // this.OnBtn_Select_SubgAme_GK(3);
 

           // return;
        }
      
        this.Real_Start_Goto_Game(3,igk);
 
    }

    m_b_scduel=  false;
    m_all_test_list =[];
    m_all_need_mk_info_list=  null;


    FD_Cacualete()
    {

        for(var ff=0;ff<10;ff++)
        {
            this.CauOne();
        }

    }
    CauOne()
    {

        if(this.m_all_test_list.length == 0)
        {
            return;
        }

        var front_arr = this.m_all_test_list[0];
        this.m_all_test_list.splice(0,1);

        HMK_Create_GK.GetInstance().Check_Find_HM_Save_C( front_arr);

        console.log("处理了一个 this.m_all_need_mk_info_list.len="+this.m_all_test_list.length)
 
    }

    
    OnBtnTiaozhuanTuijian(ituijianwei)
    {
        if(!this.m_tuijianwe_dest_info_map.hasKey(ituijianwei))
        {
            var defaultappid = HutuiAppInfoMng.GetInstance().Get_Default_Tuiguan_Appid(ituijianwei);
            PlatFormMng.GetInstance().Tiaozhuan_Tuijian_AppID(defaultappid);

            return null;
        }

        var tuijian_info = this.m_tuijianwe_dest_info_map.getData(ituijianwei);

        console.log("OnBtnTiaozhuanTuijian ituijianwei="+ituijianwei+",tuijian_info="+tuijian_info);

        if(!tuijian_info)
        {
            var defaultappid = HutuiAppInfoMng.GetInstance().Get_Default_Tuiguan_Appid(ituijianwei);
            PlatFormMng.GetInstance().Tiaozhuan_Tuijian_AppID(defaultappid);

            /*
            if(ituijianwei == 2)
            {
                PlatFormMng.GetInstance().Tiaozhuan_Tuijian_AppID("wx553ebd44ec20a9af");
            }else{
                PlatFormMng.GetInstance().Tiaozhuan_Tuijian_AppID("wx61653cb69e41c1dc");
            }
            */
            
        }else{
            PlatFormMng.GetInstance().Jump_To_App_Game_By_Data(tuijian_info);
        }

    }
    Init_Top_Tuijian_Guangao()
    { 
        var tuijaing_game1_node = cc.find("node_top/left/othergame/game3",this.node);
        var tuijaing_game2_node = cc.find("node_top/left/othergame/game4",this.node);

        var left_node = cc.find("node_top/left",this.node);

        
        if(!MiddleGamePlatformAction.GetInstance().IS_Show_Zidingyi_TuijianWei())
        {
            tuijaing_game1_node.active = false;
            tuijaing_game2_node.active = false;
            left_node.active = false;
            return;
        }
    
        tuijaing_game1_node.on("click",this.OnBtnTiaozhuanTuijian.bind(this,3))

        var self = this;


        tuijaing_game1_node.runAction(cc.repeatForever(

            cc.sequence(cc.rotateTo(0.1,7),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),
            
               
            cc.callFunc(()=>
            {
 
            }),
            cc.delayTime(3))

        ));

         tuijaing_game2_node.on("click",this.OnBtnTiaozhuanTuijian.bind(this,4))

        tuijaing_game2_node.runAction(cc.repeatForever(

            cc.sequence(cc.rotateTo(0.1,7),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),
            
               
            cc.callFunc(()=>
            {

                self.Check_Update_Tuijian_Icon_Info();
            }),
            cc.delayTime(3))

        ));


        this.Check_Update_Tuijian_Icon_Info();



    }
    Update_Tuijian_Icon(ituijianwei)
    {
        var last_tuiijian_app_info =  HutuiAppInfoMng.GetInstance().Get_InnerGame_Show_App_Icon_Info(ituijianwei);
 
        if(!last_tuiijian_app_info)
        {
            return;
        }

        var name_node = cc.find("node_top/left/othergame/game"+ituijianwei+"/name",this.node);
        name_node.getComponent(cc.Label).string = ""+last_tuiijian_app_info.toName;
        
        

        var icon_node = cc.find("node_top/left/othergame/game"+ituijianwei+"/icon",this.node);
   
        var simgurl = last_tuiijian_app_info.icon;

        var texture = HutuiAppInfoMng.GetInstance().GetFilePathTexture(simgurl);

        var size_w = HutuiAppInfoMng.GetInstance().Get_Hutui_Gezi_Size();
       
        if(texture)
        {
            var psrite = icon_node.getComponent(cc.Sprite);

            psrite.spriteFrame = new cc.SpriteFrame(texture);

            icon_node.width = size_w.cx;
            icon_node.height = size_w.cy;
           // iconnode.getComponent(cc.Sprite)
        }else
        {
            BaseUIUtils.ShowIconNodePicFilename(icon_node,"resources/game/default",{cx:size_w.cx,cy:size_w.cy});
        }

        this.m_tuijianwe_dest_info_map.putData(ituijianwei,last_tuiijian_app_info);
    }
    Check_Update_Tuijian_Icon_Info()
    {
        if(this.m_last_tuijian_change_tick == 0)
        {
            this.m_last_tuijian_change_tick = Date.now();

            this.Update_Tuijian_Icon(3);
            this.Update_Tuijian_Icon(4);
        
        }
        else{

            if(Date.now() - this.m_last_tuijian_change_tick > HutuiAppInfoMng.GetInstance().Get_Hutui_Update_Tick())
            {
                this.m_last_tuijian_change_tick = Date.now();

                this.Update_Tuijian_Icon(3);
                this.Update_Tuijian_Icon(4);
            }
          
        }
    }


    update(dt: number) 
    {
        if(dt > 1)
        {
            return;
        }
        
        ComCodeFuncMng.On_Choujiang_Update_Dt(dt);
    }
}
