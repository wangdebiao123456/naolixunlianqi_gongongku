import PlatFormMng from "../PlatForm/PlatFormMng";
import PlatFormType from "../PlatForm/PlatFormType";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import { Utils } from "../WDT/Utils";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class hmk_jiesuan extends cc.Component {

    m_i_show_type = 2;
    m_iguank_index=  0;
    m_sfromgangname = "";
    m_moved_step = 0;
    m_p_lisnter = null;

    onLoad ()
    {
        var guanbi = this.node.getChildByName("guanbi");
        guanbi.on("click",this.OnBtnExit.bind(this));

     
        var restartgame = this.node.getChildByName("restartgame");
        restartgame.on("click",this.OnBtnRestartGame.bind(this));
        
       
        var xuanyao = this.node.getChildByName("xuanyao");
        xuanyao.on("click",this.OnBtnXuanyao.bind(this));
        
         
        var nextlevel = this.node.getChildByName("nextlevel");
        nextlevel.on("click",this.OnBtnNextLevel.bind(this));


        var bshow_xuanyao = PlatFormMng.GetInstance().IS_Game_End_Xuanyao_Btn_Show();

        if(!bshow_xuanyao)
        {
            xuanyao.active = false;

            nextlevel.x = 100;
            restartgame.x = -100;

        }else{

        }

       
        BackGroundSoundUtils.GetInstance().Play_Effect("com/win");


        BannerGuangaoMng.GetInstance(). CheckShowChaiping(15);

        

        this.scheduleOnce(this.FD_Stop_Luping.bind(this),0.2)
    }

    FD_Stop_Luping()
    {

        PlatFormMng.GetInstance().Stop_Luping();

        var xuanyao = this.node.getChildByName("xuanyao");
         
    }
    OnBtnNextLevel()
    {
        this.node.destroy();

        if(this.m_p_lisnter)
        {
          
            this.m_p_lisnter.Check_Jiesuan_End_From_Dlg(1);
            this.m_p_lisnter.OnBtnNextLevel();
        }
    }
    OnBtnXuanyao()
    {

        var strtyip = "我在"+this.m_sfromgangname+"游戏里，闯第"+this.m_iguank_index+"关"+"成功,仅用了"+
        this.m_moved_step+"步,真是太厉害啦，你也来试试吧";

        if(this.m_i_show_type == 1)
        {
            strtyip = "我在"+this.m_sfromgangname+"游戏里，闯第"+this.m_iguank_index+"关"+"成功,真是太厉害啦，你也来试试吧";

        }

    
        if( PlatFormMng.GetInstance().IS_Game_End_Xuanyao_Luping_Shiping())
        {
            var self = this;
            PlatFormMng.GetInstance().Fengxiang_Youxi_Luping("烧脑木块闯关成功啦",strtyip,
            (bsuc,errmsg)=>
            {
                if(bsuc)
                {  
                    Utils.ShowTipsTxt("分享成功",self.node);
                  //  BaseUIUtils.ShowTipTxtDlg("分享成功",self.node)
                }else{
                    Utils.ShowTipsTxt(""+errmsg,self.node);
                    //BaseUIUtils.ShowTipTxtDlg("分享失败",self.node)
                }
                
            });
        }else{
            PlatFormMng.GetInstance().Share_Msg("超好玩的烧脑小游戏",strtyip);

        }

      
    }
    OnBtnRestartGame()
    {
      
        this.node.destroy();

        if(this.m_p_lisnter)
        {
            this.m_p_lisnter.Check_Jiesuan_End_From_Dlg(1);
            this.m_p_lisnter.OnBtnRestart();
            
        }
      

       
    
    }
    SetFinishTip(sfromgangname, igkindex,strtip,pp)
    {
        this.m_i_show_type = 1;
        this.m_iguank_index=  igkindex;
        this.m_sfromgangname = sfromgangname;
        var tip = this.node.getChildByName("tip");
        tip.getComponent(cc.Label).string = strtip;


        var gkindex = this.node.getChildByName("gkindex");
        gkindex.getComponent(cc.Label).string =  "第"+igkindex+"关";
    
        
    
        this.m_p_lisnter = pp;
    }
    SetFinishUseStep(sfromgangname, igkindex, moved_step,pp)
    {
        this.m_i_show_type = 2;
        this.m_iguank_index=  igkindex;
        this.m_sfromgangname = sfromgangname;
        this.m_moved_step = moved_step;
        var tip = this.node.getChildByName("tip");
        tip.getComponent(cc.Label).string =  "步数:"+moved_step;
    

        var gkindex = this.node.getChildByName("gkindex");
        gkindex.getComponent(cc.Label).string =  "第"+igkindex+"关";
    

        
        this.m_p_lisnter = pp;
    }
    OnBtnExit()
    {
        this.node.destroy();
 

    }
   
}
