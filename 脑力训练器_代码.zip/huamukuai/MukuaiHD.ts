
export default  class MukuaiHD 
{


    m_id = 0;
    m_itype = 0;
    m_ifangxiang = 0;
    m_iwidth = 0;
    x = 0;
    y = 0;

    offsetx = 0;
    offsety = 0;
    //ifangxiang:1:横向，2：竖向,
    //iwidth:占用几格
    ////type,方向，宽度，最左下x,y
   // [0,1,2,1,4],
	Init(id, infoarr) 
    {
        this.m_id = id;
        this.m_itype = infoarr[0];
        this.m_ifangxiang = infoarr[1];
        this.m_iwidth = infoarr[2];
        this.x = infoarr[3];
        this.y = infoarr[4];

         this.offsetx = 0;
         this.offsety = 0;
         
    }

    constructor() 
    {

    }

    ToAarry()
    {
        var arr = [];

        arr[0] = this.m_itype;
        arr[1] = this.m_ifangxiang;
        arr[2] = this.m_iwidth;
        arr[3] = this.x;
        arr[4] = this.y; 

 
        return arr;
    }
    GetID()
    {
        return this.m_id;
    }
    Copy()
    {
        var copyd = new MukuaiHD();
        copyd.m_id = this.m_id;
        copyd.m_itype = this.m_itype;
        copyd.m_ifangxiang = this.m_ifangxiang;
        copyd.m_iwidth = this.m_iwidth;
        copyd.x = this.x;
        copyd.y = this.y;


        return copyd;

    }
    MoveStep(offset_step)
    {
        if(this.m_ifangxiang ==1)
        {
            this.x += offset_step;
        }else{
            this.y += offset_step;
        }
    }
    SetOffetPtXY(x,y)
    {
        this.offsetx = x;
        this.offsety = y;
    }

    GetGridCenterPt(x,y)
    {
        var starx = 0- 107*2-107/2;
        var xxpt = starx + (x-1)*107;

        var stary = 0- 107*2-107/2;
        var yypt = stary + (y-1)*107;

        var centex = xxpt + this.offsetx;
        var centey = yypt + this.offsety;
 

        return {x:centex,y:centey};
    }

    GetRect()
    {
        var centerpt = this.GetCenterPt();
        if(this.m_ifangxiang == 1)
        {
            var ptleft_x = centerpt.x - this.m_iwidth*107/2;
            var ptleft_y = centerpt.y -  107/2;
            var ptright_x = centerpt.x + this.m_iwidth*107/2;
            var ptright_y = centerpt.y +  107/2;

            return new cc.Rect(ptleft_x,ptleft_y,this.m_iwidth*107,107);
        }
        

        var ptleft_x = centerpt.x -  107/2;
        var ptleft_y = centerpt.y -  this.m_iwidth*107/2;
        var ptright_x = centerpt.x + 107/2;
        var ptright_y = centerpt.y +  this.m_iwidth*107/2;

        return new cc.Rect(ptleft_x,ptleft_y,107,this.m_iwidth*107);
    }


    Get_Move_To_Rect(ifx,istep)
    {
        var newx=  this.x;
        var newy=  this.y;

        if(ifx == 1)
        {
            newx += istep;
        }else{
            newy += istep;
        }

        return this.Get_New_RC(newx,newy);

    }

    Get_Add_Move_Step_Center_PT(ifx,istep)
    {
        var newx=  this.x;
        var newy=  this.y;

        if(ifx == 1)
        {
            newx += istep;
        }else{
            newy += istep;
        }
        var centerpt = this.Get_New_Center_PT(newx,newy);
   
        return centerpt;
    }

    Get_New_RC(newx,newy)
    {

        var iw = 104;

        var centerpt = this.Get_New_Center_PT(newx,newy);
        if(this.m_ifangxiang == 1)
        {
            var ptleft_x = centerpt.x - this.m_iwidth*iw/2;
            var ptleft_y = centerpt.y -  iw/2;
            var ptright_x = centerpt.x + this.m_iwidth*iw/2;
            var ptright_y = centerpt.y +  iw/2;

            return new cc.Rect(ptleft_x,ptleft_y,this.m_iwidth*iw,iw);
        }
        

        var ptleft_x = centerpt.x -  iw/2;
        var ptleft_y = centerpt.y -  this.m_iwidth*iw/2;
        var ptright_x = centerpt.x + iw/2;
        var ptright_y = centerpt.y +  this.m_iwidth*iw/2;

        return new cc.Rect(ptleft_x,ptleft_y,iw,this.m_iwidth*iw);
    }
    Get_New_Center_PT(newx,newy)
    {
        if(this.m_ifangxiang == 1)
        {
            var istartx = newx;
            var iendx = newx + this.m_iwidth - 1;
            

            var startpt = this.GetGridCenterPt(istartx,newy);
            var endpt = this.GetGridCenterPt(iendx,newy);

            var centex = Math.floor(startpt.x+endpt.x)/2;
            var centery = Math.floor(startpt.y+endpt.y)/2;

            return {x:centex,y:centery};

        }
        else
        {
            var istarty = newy;
            var iendy = newy + this.m_iwidth - 1;
            

            var startpt = this.GetGridCenterPt(newx,istarty);
            var endpt =this. GetGridCenterPt(newx,iendy);

            var centex = Math.floor(startpt.x+endpt.x)/2;
            var centery = Math.floor(startpt.y+endpt.y)/2;

            return {x:centex,y:centery};
        }

        return {x:0,y:0};
    }
    GetCenterPt()
    {
        if(this.m_ifangxiang == 1)
        {
            var istartx = this.x;
            var iendx = this.x + this.m_iwidth - 1;
            

            var startpt = this.GetGridCenterPt(istartx,this.y);
            var endpt = this.GetGridCenterPt(iendx,this.y);

            var centex = Math.floor(startpt.x+endpt.x)/2;
            var centery = Math.floor(startpt.y+endpt.y)/2;

            return {x:centex,y:centery};

        }
        else
        {
            var istarty = this.y;
            var iendy = this.y + this.m_iwidth - 1;
            

            var startpt = this.GetGridCenterPt(this.x,istarty);
            var endpt =this. GetGridCenterPt(this.x,iendy);

            var centex = Math.floor(startpt.x+endpt.x)/2;
            var centery = Math.floor(startpt.y+endpt.y)/2;

            return {x:centex,y:centery};
        }

        return {x:0,y:0};
    }

    GetImageFrameIndex()
    {
        if(this.m_itype == 0)
        {
            if(this.m_iwidth  == 3)
            {
                return 5;
            }
            return 0;
        }


        if(this.m_ifangxiang == 1)
        {
            if(this.m_iwidth  == 3)
            {
                return 2;
            }
            return 1;
        }else{
            if(this.m_iwidth  == 3)
            {
                return 4;
            }
            return 3;
        }

    }
}