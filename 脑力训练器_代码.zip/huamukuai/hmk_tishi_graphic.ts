 

const {ccclass, property} = cc._decorator;

@ccclass
export default class hmk_tishi_graphic extends cc.Component {

    graphics:cc.Graphics = null;

    m_parent_game = null;
    
    onLoad () {

        this.graphics= this.node.getComponent(cc.Graphics);


    }
    SetParentGame(parentgame)
    {
        this.m_parent_game = parentgame;

    }
    ClearAll()
    {
        this.graphics.clear(true);
    }
    DrawLine(sttartpt,nextpt)
    {
        this.graphics.strokeColor = cc.color(255,255,255);
     
        this.graphics.moveTo(sttartpt.x,sttartpt.y);
        this.graphics.lineTo(nextpt.x,nextpt.y);
        this.graphics.stroke();

    }
    Set_User_Action_Tishi_RC(action_rc:cc.Rect)
    {
        this.ClearAll();

        this.graphics.rect(action_rc.x,action_rc.y,action_rc.width,action_rc.height);
        this.graphics.stroke();

    
    }

}
