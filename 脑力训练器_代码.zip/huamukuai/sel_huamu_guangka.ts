import HuaMuKuaiMng from "./HuaMuKuaiMng";
import GlobalData from "../main/GlobalData";
import TuiXiangziGameMng from "../TuiXiangzi/TuiXiangziGameMng";
import HuaRongDaoMng from "../huarongdao/HuaRongDaoMng";
import YiXiangZiLogicMng from "../YiXiangzi/YiXiangZiLogicMng"; 
const {ccclass, property} = cc._decorator;

@ccclass
export default class sel_huamu_guangka extends cc.Component {

    m_igame_type = 0;
    m_itotalGuangkaCount = 0;

    m_ipage_index = 1;
    m_itotalpage = 0;
   

    m_hmk_last_kaiqi_guanka = 0;

    onLoad () 
    { 
        /*
        var fanhui = this.node.getChildByName("guanbi");
        fanhui.on("click",this.OnBtnExit.bind(this));



        var prevpage = this.node.getChildByName("prevpage");
        prevpage.on("click",this.OnBtnPrev.bind(this));

        var nextpage = this.node.getChildByName("nextpage");
        nextpage.on("click",this.OnBtnNext.bind(this));

        

        var itotalGuangkaCount = 0;
        if(this.m_igame_type == 1)
        {
            itotalGuangkaCount = HuaMuKuaiMng.GetTotalGuangkaCount();
        }
        else if(this.m_igame_type == 2)
        {
            itotalGuangkaCount = TuiXiangziGameMng.GetInstance().GetTotalGuangkaCount();
        } else if(this.m_igame_type == 3)
        {
            itotalGuangkaCount = HuaRongDaoMng.GetInstance().GetTotalGuangkaCount();
        }else if(this.m_igame_type == 4)
        {
            itotalGuangkaCount = YiXiangZiLogicMng.GetTotalGuangkaCount();
        }
        
        var itotalpage = Math.floor(itotalGuangkaCount/12) ;
        if(itotalGuangkaCount - itotalpage*12 > 0)
        {
            itotalpage++;
        }


        this.m_itotalGuangkaCount = itotalGuangkaCount;

        this.m_ipage_index = 1;
        this.m_itotalpage = itotalpage;
       

        this.m_hmk_last_kaiqi_guanka = 0;
        if(this.m_igame_type == 1)
        {
            this.m_hmk_last_kaiqi_guanka = GlobalData.GetInstance().m_hmk_last_kaiqi_guanka;
            if(this.m_hmk_last_kaiqi_guanka < 1)
            {
                this.m_hmk_last_kaiqi_guanka = 1;
            }
        }
        else if(this.m_igame_type == 2)
        {
            this.m_hmk_last_kaiqi_guanka = GlobalData.GetInstance().m_txz_last_kaiqi_guanka;

            if(this.m_hmk_last_kaiqi_guanka < 1)
            {
                this.m_hmk_last_kaiqi_guanka = 1;
            }
 
        }
        else if(this.m_igame_type == 3)
        {
            //华容道全开
            this.m_hmk_last_kaiqi_guanka = GlobalData.GetInstance().m_hongrongdao_last_kaiqi_guanka;//HuaRongDaoMng.GetInstance().GetTotalGuangkaCount();
        
            if(this.m_hmk_last_kaiqi_guanka < 1)
            {
                this.m_hmk_last_kaiqi_guanka= 1;
            }
        }
        else if(this.m_igame_type == 4)
        {
            this.m_hmk_last_kaiqi_guanka = GlobalData.GetInstance().m_yixiangzi_last_kaiqi_guanka;

            if(this.m_hmk_last_kaiqi_guanka < 1)
            {
                this.m_hmk_last_kaiqi_guanka= 1;
            }
        }



        var ipage = 1;

        if(this.m_hmk_last_kaiqi_guanka > 12)
        {
            var icc  = Math.floor((this.m_hmk_last_kaiqi_guanka -1)/12) +1;
            ipage = icc;
        }

       
        this.m_ipage_index = ipage;
        if(this.m_ipage_index >= this.m_itotalpage)
        {
            this.m_ipage_index = this.m_itotalpage;
        }
        this.RefreshGKTip();
 

        */
    }
    SetFromGameType(igametype)
    {
        this.m_igame_type = igametype;


        for(let ff=1;ff<=4;ff++)
        {
            var nodeff = this.node.getChildByName("game"+ff);
            if(!nodeff)
            {
                continue;
            }
            if(ff == igametype)
            {
                nodeff.active = true;
            }else{
                nodeff.active = false;
            }
        }
    }
    OnBtnNext()
    {
        this.m_ipage_index++;
        if(this.m_ipage_index >= this.m_itotalpage)
        {
            this.m_ipage_index = this.m_itotalpage;
        }
        this.RefreshGKTip();
    }
    OnBtnPrev()
    {
        this.m_ipage_index--;
        if(this.m_ipage_index <= 1)
        {
            this.m_ipage_index=  1;
        }
        this.RefreshGKTip();
    }
    OnBtnEnter(igk)
    {
        if(this.m_igame_type == 1)
        {
            GlobalData.GetInstance().m_select_enter_hmk_gk = igk;
            cc.director.loadScene("huamukuai");

        }
        else if(this.m_igame_type == 2)
        {
            GlobalData.GetInstance().m_select_enter_txz_gk = igk;
            cc.director.loadScene("Tuixiangzi");
        }
        else if(this.m_igame_type == 3)
        {
            GlobalData.GetInstance().m_select_enter_huarongdao_gk = igk;
            cc.director.loadScene("huarongdao");
        }
        else if(this.m_igame_type == 4)
        {
            GlobalData.GetInstance().m_select_enter_yixiangzz_gk = igk;
            cc.director.loadScene("YiXiangzi");
        }


    }
    RefreshGKTip()
    {
        var gktip = this.node.getChildByName("gktip");
        gktip.getComponent(cc.Label).string = this.m_ipage_index +"/"+this.m_itotalpage;

        var guangka = this.node.getChildByName("guangka");

        var iguankai_start = (this.m_ipage_index - 1)*12+1;
        var igunkaend = iguankai_start+12;

        if(igunkaend > this.m_itotalGuangkaCount)
        {
            igunkaend = this.m_itotalGuangkaCount;
        }
      
        for(var ff=1;ff<=12;ff++)
        {
            var nodeff = guangka.getChildByName(""+ff);
            var ff_shoiw_gk = iguankai_start+ff-1; 
            var needshowcom = false;
            if(ff_shoiw_gk <= 1)
            {
                needshowcom = true;
            }else{
                if(ff_shoiw_gk <= this.m_hmk_last_kaiqi_guanka )
                {
                    needshowcom = true;
                }else{
                    needshowcom = false;
                }
            }

            if(ff_shoiw_gk > this.m_itotalGuangkaCount)
            {
                nodeff.active = false;
            }else{
                nodeff.active = true;
            }

            var tttip = nodeff.getChildByName("com").getChildByName("tip")
            tttip.getComponent(cc.Label).string = ""+ff_shoiw_gk;
         //   tttip.color = cc.color(79,59,46);
            tttip.x=  -5;
            tttip.color = cc.color(67,171,148);

            nodeff.getChildByName("com").on("click",this.OnBtnEnter.bind(this,ff_shoiw_gk));

            if(needshowcom)
            {
                nodeff.getChildByName("com").active = true;
                nodeff.getChildByName("suo").active = false;
            }else{
                nodeff.getChildByName("com").active = false;
                nodeff.getChildByName("suo").active = true;
            }

        }

    }

    OnBtnExit()
    {
        this.node.destroy();
 

    }
  
}
