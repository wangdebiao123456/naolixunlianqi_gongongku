import WMap from "../WDT/WMap";
import MyLocalStorge from "../WDT/MyLocalStorge";



export default  class HMK_NanduMode_GK_Info
{

      
    m_remote_hk_index_data_map = new WMap();


    m_local_hk_index_data_map = new WMap();


    m_inandu = 1;
    constructor(inandu)
    {
        this.m_inandu =  inandu;

        

        this.Load_Local_Config(0);
        this.Load_Local_Config(1);


        this.Load_Server_Config(0,()=>{});
      
    }

    Load_Server_Config(subfileindex,callback)
    {
        var irand11 = Math.floor(Math.random()*1000) ;
        var config_json = "https://outercoms.zfgame123.com/config/shaonaomukuai/hmk/nandumd/mode_"+this.m_inandu
            +"/hk_"+subfileindex+".json?r="+irand11;
 
        var self = this;
 
     
        cc.assetManager.loadRemote(config_json, (err, jobj:cc.JsonAsset) =>  
        {
            if(err)
            {
                callback(false);
                return;
            }
             var remote_obj   =  jobj.json;
           
             if(remote_obj && remote_obj.length && remote_obj.length > 10)
             {
                self.m_remote_hk_index_data_map.putData(subfileindex,remote_obj);

                self.Save_Readed_Local_HK_Config(subfileindex,remote_obj);

                callback(true);
       
             }else{
                callback(false);
             }
         
        });
    }


    Find_GK_Real_Data(ilevel)
    {
        var irealindex = ilevel ;

        var subfileindex = Math.floor(irealindex/100);
        var in_file_index = irealindex - subfileindex*100;

        var sfilename = "conf/hmk/hk_"+subfileindex;

        var findd_data = null;


        if(this.m_remote_hk_index_data_map.hasKey(subfileindex))
        {
            var remotedata  = this.m_remote_hk_index_data_map.getData(subfileindex);

            if(remotedata.length > 0 && remotedata.length >= in_file_index +1)
            {

                var r_sub_data =  remotedata[in_file_index];
                findd_data = r_sub_data.a;

            }


            if(findd_data)
            {
                console.log("ilevel="+ilevel+",使用remote");
                return findd_data;
            }
        }

       
        return findd_data;
    }

    Real_Get_Gk_Data(ilevel,callback)
    {
        var self= this;
        var irealindex = ilevel ;
        var subfileindex = Math.floor(irealindex/100);
        var in_file_index = irealindex - subfileindex*100;


        var findd_data = this.Find_GK_Real_Data(ilevel);
        if(findd_data)
        {
            callback(true,findd_data)
            return true;
        }

        return false;
    }
    Save_Readed_Local_HK_Config(subfileindex,remote_obj)
    {
        var saved_prev_local_str = "hmk_mode_"+this.m_inandu+"_subf_"+subfileindex+"_mk";

        MyLocalStorge.setItem(saved_prev_local_str,JSON.stringify(remote_obj));
    }
    Read_Gk_Data_From_Local_Storege(ilevel,callback)
    {
        var self= this;
        var irealindex = ilevel ;
        var subfileindex = Math.floor(irealindex/100);
        var in_file_index = irealindex - subfileindex*100;

        var saved_prev_local_str = "hmk_mode_"+this.m_inandu+"_subf_"+subfileindex+"_mk";
        var jstr1 = MyLocalStorge.getItem(saved_prev_local_str);

        if(!jstr1)
        {
            return false;
        }

        var saved_obj = JSON.parse(jstr1);

        if(saved_obj && saved_obj.length && saved_obj.length > 0 && saved_obj.length > in_file_index )
        {
            var r_sub_data =  saved_obj[in_file_index];
            var  findd_data = r_sub_data.a;

            callback(true,findd_data);
            return true;

        }else{
           // callback(false);
            return false;
        }
        return false;
    }
    Load_Local_Config(subfileindex)
    {
        var self=  this;

        var sfilename = "conf/hmk/mode_"+this.m_inandu+"/hk_"+subfileindex;
        cc.resources.load(sfilename,cc.JsonAsset,  (err, asserts:cc.JsonAsset)=>
        {
            if(!asserts)
            {
              
                return;
            }

            var jsonobj = asserts.json;

            self.m_local_hk_index_data_map.putData(subfileindex,jsonobj);
          
        });
    }
    Check_Load_Local_Config(ilevel,callback)
    {
        var irealindex = ilevel ;
        var subfileindex = Math.floor(irealindex/100);
        var in_file_index = irealindex - subfileindex*100;

        if(this.m_local_hk_index_data_map.hasKey(subfileindex))
        {
            var localdata  = this.m_local_hk_index_data_map.getData(subfileindex);

            if(localdata.length > 0 && localdata.length > in_file_index )
            {

                var sub_data =  localdata[in_file_index];
                var  findd_data = sub_data.a;
                callback(true,findd_data)

                return true;
            }
        }


        return false;
    }
    Check_Load_Scence_Level_Config(ilevel,in_config_file,callback)
    {
        var irealindex = ilevel ;
        var subfileindex = Math.floor(irealindex/100);
        var in_file_index = irealindex - subfileindex*100;

        if(in_config_file && in_config_file.length && in_config_file.length > 0 && in_config_file.length > in_file_index )
        {

            var sub_data =  in_config_file[in_file_index];
            var  findd_data = sub_data.a;

            if(findd_data)
            {
                callback(true,findd_data)

                return true;
            }
            
        }

        return false;
    }
    Get_GK_Str_A1(mode_index_config_list,ilevel,callback)
    {

        var bsuc1=  this.Real_Get_Gk_Data(ilevel,callback);
        if(bsuc1)
        {
            return;
        }

        var irealindex = ilevel ;
        var subfileindex = Math.floor(irealindex/100);

        //暂时还没有数据，远程获取先
        var self = this;
        this.Load_Server_Config(subfileindex,(bsuc)=>
        {

        });

        var read_remote_local = self.Read_Gk_Data_From_Local_Storege(ilevel,
                (bsuc,pdata)=>
                {
                    if(bsuc)
                    {
                        callback(true,pdata);
                    }
        });

        if(read_remote_local)
        {
            return;
        }

        var localsuc =  self.Check_Load_Local_Config(ilevel,callback);
        if(localsuc)
        {
             return;
        }

        var in_config_file = null;

        for(var ff=0;ff<mode_index_config_list.length;ff++)
        {
            var ff_arr = mode_index_config_list[ff];

            if(ff_arr[0] == this.m_inandu && ff_arr[1] == subfileindex)
            {
                in_config_file = ff_arr[2];
                break;
            }
        }



        //存在保存的配置文件
        if(in_config_file)
        {
            var in_config_suc1 =  self.Check_Load_Scence_Level_Config(ilevel,in_config_file,callback);
            if(in_config_suc1)
            {
                return;
            }
    
        }


        callback(false);

        /*
        var self = this;
        this.Load_Server_Config(subfileindex,(bsuc)=>
        {
            if(!bsuc)
            {
                var read_local = self.Read_Gk_Data_From_Local_Storege(ilevel,callback);

                if(!read_local)
                {
                    self.Check_Load_Local_Config(ilevel,callback);
                }
                return;
            }
            self.Real_Get_Gk_Data(ilevel,callback);
        });

        */



    }

}