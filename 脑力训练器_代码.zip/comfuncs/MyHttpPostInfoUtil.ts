 

var TimeOut=15000;
export default class MyHttpPostInfoUtil 
{
    /**
     * 延迟多久没回复就返回False
     *
     * @type {number}
     * @memberof DriveManager
     */

    

    /**
     * GET请求
     *
     * @static
     * @param {*} url
     * @param {object} [params={}]
     * @param {*} callback
     * @memberof HttpUtil
     */
     static GET(url, params = {}, callback) 
     {
        let dataStr = '';
        Object.keys(params).forEach(key => {
            dataStr += key + '=' + encodeURIComponent(params[key]) + '&';
        })
        if (dataStr !== '') {
            dataStr = dataStr.substr(0, dataStr.lastIndexOf('&'));
            url = url + '?' + dataStr;
        }
        // url = HttpUtil.baseUrl + url;

        let xhr = cc.loader.getXMLHttpRequest();
        xhr.open("GET", url, true);
        xhr.setRequestHeader("Content-Type", "text/plain;charset=UTF-8");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                let response = xhr.responseText;
                if (xhr.status >= 200 && xhr.status < 300) {
                    let httpStatus = xhr.statusText;
                    // callback(true, JSON.parse(response));

                    if(callback)
                    {
                        callback(true, response);
                    }
                  
                } else {
                    if(callback)
                    {
                        callback(false, response);
                    }
                }
            }
        };
        xhr.timeout = TimeOut;
        xhr.send();
    }
    
    /**
     * POST请求
     *
     * @static
     * @param {*} url
     * @param {object} [param={}]
     * @param {*} callback
     * @memberof HttpUtil
     */
     static POST(url, param = {}, callback) 
     {
        // url = HttpUtil.baseUrl + url;

        try{
            var xhr = cc.loader.getXMLHttpRequest();
            let dataStr = '';
            Object.keys(param).forEach(key => {
                dataStr += key + '=' + encodeURIComponent(param[key]) + '&';
            })
            if (dataStr !== '') {
                dataStr = dataStr.substr(0, dataStr.lastIndexOf('&'));
            }
            xhr.open("POST", url, true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
           // xhr.setRequestHeader("Access-Control-Allow-Origin", "*");

 
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    let response = xhr.responseText;
                    if (xhr.status >= 200 && xhr.status < 300) {
                        let httpStatus = xhr.statusText;
                        // callback(true, JSON.parse(response));
                        console.log("response="+response);

                        if(callback)
                        {
                            callback(true, response);
                        }
                        
    
                    } else {
                        if(callback)
                        {
                             callback(false, response);
                        }
                    }
                }
            };
            xhr.timeout = TimeOut;
            xhr.send(dataStr);
        }
        catch(e)
        {

        }

      
    }
  

    static POSTData_Json(url, jsonstr, callback) 
     {
        // url = HttpUtil.baseUrl + url;

        

        try{
            var xhr = cc.loader.getXMLHttpRequest();
            
            xhr.timeout = 5000;
            xhr.open("POST", url, true);
            
           xhr.setRequestHeader("Content-Type", "application/json");
   
 
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    let response = xhr.responseText;
                    if (xhr.status >= 200 && xhr.status < 400) {
                        let httpStatus = xhr.statusText;
                        // callback(true, JSON.parse(response));
                       // console.log("response="+response);

                       if(callback)
                       {
                            callback(true, response);
                       }
                        
    
                    } else {
                        if(callback)
                        {
                            callback(false, response);
                        }
                    }
                }
            };
            xhr.send(jsonstr);
        }
        catch(e)
        {

        }

      
    }
    static POSTData(url, dataStr, callback) 
     {
        // url = HttpUtil.baseUrl + url;

        

        try{
            var xhr = cc.loader.getXMLHttpRequest();
            
            xhr.timeout = TimeOut;
            xhr.open("POST", url, true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
           // xhr.setRequestHeader("Access-Control-Allow-Origin", "*");

 
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    let response = xhr.responseText;
                    if (xhr.status >= 200 && xhr.status < 400) {
                        let httpStatus = xhr.statusText;
                        // callback(true, JSON.parse(response));
                       // console.log("response="+response);

                       if(callback)
                       {
                        callback(true, response);
                       }
                        
    
                    } else {
                        if(callback)
                        {
                            callback(false, response);
                        }
                    }
                }
            };
            xhr.send(dataStr);
        }
        catch(e)
        {

        }

      
    }
}
