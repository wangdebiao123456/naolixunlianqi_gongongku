import BaseUIUtils from "../comfuncs/BaseUIUtils";
import ComFunc from "../comfuncs/ComFunc";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import GlobalGameMng from "./GlobalGameMng";
import MyLocalStorge from "../WDT/MyLocalStorge";
import HutuiAppInfoMng from "../PlatForm/HutuiAppInfoMng";
import PlatFormMng from "../PlatForm/PlatFormMng"; 
import WMap from "../WDT/WMap";
import ChouJiangMng from "./ChouJiangMng";

export default class ComCodeFuncMng
{

    
    static Get_Para_Count(strpara)
    {
        var last_v = strpara;

        var prevstr = MyLocalStorge.getItem(last_v,"");

        if(!prevstr)
        {
            return [0,0];
        }


        var pobj = JSON.parse(prevstr);
        if(!pobj)
        {
            return [0,0];
        }

        var ijiangegk = pobj.ijiangegk;
        if(!ijiangegk)
        {
            ijiangegk = 0;
        }
        return [1,ijiangegk];
    }
    static Add_Para_Count(strpara)
    {
        var pinfo = ComCodeFuncMng.Get_Para_Count(strpara);
        var prevgk = pinfo[1];
        var newgk = prevgk+1;

        var obj = {
            ijiangegk:newgk
        }


        var last_v = strpara;

        var str = JSON.stringify(obj);
        MyLocalStorge.setItem(last_v,str);
    }

    static Remove_Para_Count(strpara)
    {
        MyLocalStorge.removeItem(strpara);
    }

    

    static On_Choujiang_Update_Dt(dt)
    {
        ChouJiangMng.GetInstance().On_Choujiang_Update_Dt(dt);

    }


    static OnBtn_PaihangBang(pgame,pgamenode,isubgametype)
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(isubgametype,true);
        ComCodeFuncMng.OnSelectPaihangbangType(pgame,pgamenode,isubgametype,isubgametype)
    }
    static OnSelectOtherPaihangbangType(pgame,pgamenode,isubgametype)
    {
        var self = pgame;
    
        ComFunc.OpenNewDialog(self.node,"preab/dlg/select_paihang_type","select_paihang_type", 
         { 
            cb:(iseltype)=>
            {
                if(iseltype == 0)
                {
                    ComCodeFuncMng.On_Paihangbang_Dlg_Close(pgame,pgamenode,isubgametype);
                    return;
                }

                ComCodeFuncMng.OnSelectPaihangbangType(pgame,pgamenode,isubgametype,iseltype);
                
            }});
    }
    static  On_Paihangbang_Dlg_Close(pgame,pgamenode,isubgametype)
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(isubgametype,false);

        if(pgame.On_Paihangbang_Dlg_Close)
        {
            pgame.On_Paihangbang_Dlg_Close();
        }
    }
    static OnSelectPaihangbangType(pgame,pgamenode,isubgametype,iseltype)
    {

        if(iseltype == 0)
        {
            return;
        }
        var self = pgame;
    
       
        ComFunc.OpenNewDialog(self.node,"preab/dlg/paihangbang","paihangbang", 
         { 
            iseltype:iseltype,
            cb:(chooseother)=>
            {

                if(chooseother > 0)
                {
                    ComCodeFuncMng.OnSelectOtherPaihangbangType(pgame,pgamenode,isubgametype);
                }else{

                    ComCodeFuncMng.On_Paihangbang_Dlg_Close(pgame,pgamenode,isubgametype);
                }
                 
            
            }});
    }

    //itype:1-体力不足，2：购买体力
    static Show_Goumai_Tili_Dlg(itype, pndoe,callback)
    {

        var ishow_tili_dlg_type = GlobalGameMng.GetInstance().Get_Dating_Tili_Show_Goumai_Dlg_Type();

        /*
        var spreabname = "preab/goumai_tili";

        if(ishow_tili_dlg_type == 2)
        {
            spreabname = "preab/goumai_tili_all";
        }

        */
        var spreabname = "preab/goumai_tili_all";
   
        var self = this;
        ComFunc.OpenNewDialog(pndoe,spreabname,"goumai_tili", {  
            itype:itype,
            cb:(iret)=>
            {

                if(callback)
                {
                    callback(iret);
                }
            }
        });
       
    }
   
    static Check_Has_Tili_Enter_Subgame_And_Kouchu(isbugametype:number,pnode:cc.Node,callback=null)
    {
        //首先，判断是否要全部取消体力
        var allhide_tili = GlobalGameMng.GetInstance().IS_All_Tili_Hide();
        if(allhide_tili)
        {
            GlobalGameMng.GetInstance().Add_Subgametype_Enterd_Cishu(isbugametype,1);
            if(callback)
            {
                callback(true);
            }
            return true;
        }

        //前面几次不扣体力
        var first_enter_cishunei_bukou_tili = GlobalGameMng.GetInstance().Get_Per_Game_First_Enter_Cishu_Nei_Bukou_Tili();

        //游戏玩法进入的次数
        var iprev_enterd_game_cishu = GlobalGameMng.GetInstance().Get_Subgametype_Enterd_Cishu(isbugametype);

        //今日进入游戏次数
        var curday_enterd_game_cishu = GlobalGameMng.GetInstance().Get_Subgametype_CurDay_Enterd_Cishu(isbugametype);

        //单个游戏每日几次内不扣体力
        var pergame_perday_first_enter_cishunei_bukou_tili = GlobalGameMng.GetInstance().Get_Per_Game_PerDay_First_Enter_Cishu_Nei_Bukou_Tili();

        
        //小于这天注册的用户不扣体力
        var regday_unoin_xiaoyu_dest_day_bukou_tili = GlobalGameMng.GetInstance().Get_Reg_Day_Xiaoyu_Dest_Day_Bukou_Tili();

        var cur_reg_Day = GlobalGameMng.GetInstance().Get_Self_Reg_Day();

        var itilinow = GlobalGameMng.GetInstance().Get_Tili();

        //进入游戏一次扣除体力数
        var enter_game_perci_sub_tili = GlobalGameMng.GetInstance().Get_Enter_Game_PerCi_Sub_Tili();
        var ileft_wuxian_tili_sec = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_Tili_Left_Sec();


        var ileft_wuxian_48huor_tili_sec = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_48huor_Tili_Left_Sec();
 
        //是否需要扣体力
        var bneed_koutili = true;
  
        if(iprev_enterd_game_cishu < first_enter_cishunei_bukou_tili)
        {
            bneed_koutili = false;
        }


        //今日几次内不扣体力
        if(curday_enterd_game_cishu < pergame_perday_first_enter_cishunei_bukou_tili)
        {
            bneed_koutili = false;
        }

        console.log("curday_enterd_game_cishu="+curday_enterd_game_cishu+",pergame_perday_first_enter_cishunei_bukou_tili="+pergame_perday_first_enter_cishunei_bukou_tili);


        if(enter_game_perci_sub_tili == 0)
        {
            bneed_koutili = false;
        }

        if(regday_unoin_xiaoyu_dest_day_bukou_tili && regday_unoin_xiaoyu_dest_day_bukou_tili > 0)
        {
            if( cur_reg_Day < regday_unoin_xiaoyu_dest_day_bukou_tili)
            {
                bneed_koutili = false;
            }
        }
        



        //无限体力时间内
        if(ileft_wuxian_tili_sec > 0)
        {
            bneed_koutili = false;
        }
 
        if(ileft_wuxian_48huor_tili_sec > 0)
        {
            bneed_koutili = false;
        }
 


        //不需要扣体力
        if(!bneed_koutili)
        {
            GlobalGameMng.GetInstance().Add_Subgametype_Enterd_Cishu(isbugametype,1);
       
            if(callback)
            {
                callback(true);
            }
            return true;
        }

        if(itilinow < enter_game_perci_sub_tili)
        {
            //体力不足,弹出购买体力框

            ComCodeFuncMng.Show_Goumai_Tili_Dlg(1,pnode,(bsuc)=>
            {
               // BaseUIUtils.ShowTipTxtDlg("购买体力成功",pnode);

                if(callback)
                {
                    callback(bsuc);
                }

            });

            return false;
        }

        //扣体力
        GlobalGameMng.GetInstance().Add_Tili( -1*enter_game_perci_sub_tili);

        GlobalGameMng.GetInstance().Add_Subgametype_Enterd_Cishu(isbugametype,1);
        if(callback)
        {
            callback(true);
        }
        return true;
    }

    static  Get_Choujiang_Libao_AllJiangli_Lingqued_Count(isubgametype)
    {
        var str = "shaonaomukuai_choujianglibao_game_"+isubgametype+"_all_jiangli_lingqued";

       return ComCodeFuncMng.Get_Lingqued_Count(str);
    }
    static Get_Choujiang_Libao_Lingqued_Count(isubgametype)
    {
        var str = "shaonaomukuai_choujianglibao_game_"+isubgametype+"_lingqued";
        var savedstr = MyLocalStorge.getItem(str);

        if(!savedstr)
        {
            return 0;
        }
        var obj  = JSON.parse(savedstr);
        if(!obj)
        {
            return 0;
        }

        var lingqued =  obj.lingqued;

        if(!lingqued)
        {
            return 0;
        }

        var comc = ComFunc.Check_Read_Number(lingqued);

        return comc;
    }
    static Get_Shoukan_Fuli_Lingqued_Count(isubgametype)
    {
        var str = "shaonaomukuai_shoukan_game_"+isubgametype+"_lingqued";
        var savedstr = MyLocalStorge.getItem(str);

        if(!savedstr)
        {
            return 0;
        }
        var obj  = JSON.parse(savedstr);
        if(!obj)
        {
            return 0;
        }

        var lingqued =  ComFunc.Check_Read_Number(obj.lingqued) ;

        if(!lingqued)
        {
            return 0;
        }

        return lingqued;
    }

    static  On_Shoukan_Lingqued(gamenode,isubgametype,igk,libaolist = null)
    {
        var lingqued_count = ComCodeFuncMng.Get_Shoukan_Fuli_Lingqued_Count(isubgametype);

        if(!lingqued_count)
        {
            lingqued_count = 0;
        }
   
        var str = "shaonaomukuai_shoukan_game_"+isubgametype+"_lingqued";

        var newcc = lingqued_count + 1;
        var obj = {lingqued:newcc};
        var savedstr = JSON.stringify(obj);

        
        MyLocalStorge.setItem(str,savedstr);

        if(libaolist)
        {
            ComFunc.Open_Get_Daoju_Award_Dlg(gamenode, libaolist, 1,null);
  
        }
     
    }
    static Get_Lingqued_Count(str)
    {
        var savedstr = MyLocalStorge.getItem(str);

        if(!savedstr)
        {
            return 0;
        }
        var obj  = JSON.parse(savedstr);
        if(!obj)
        {
            return 0;
        }

        var lingqued =  obj.lingqued;

        if(!lingqued)
        {
            return 0;
        }

        var comc = ComFunc.Check_Read_Number(lingqued);

        return comc;
    }
    static Add_Lingqued_Count(str,icc)
    {
        var lingquedcount = ComCodeFuncMng.Get_Lingqued_Count(str);
        if(!lingquedcount || lingquedcount < 0)
        {
            lingquedcount = 0;
        }
     
    
        var newcc  =  1 + lingquedcount;
       
        var obj = {lingqued:newcc};
        var savedstr = JSON.stringify(obj);

        MyLocalStorge.setItem(str,savedstr);
    }
    static  On_ChouJiang_Lingqued(choujiang_all,gamenode,isubgametype,igk,libaolist = null)
    {

        var str = "shaonaomukuai_choujianglibao_game_"+isubgametype+"_lingqued";

        ComCodeFuncMng.Add_Lingqued_Count(str,1);


        if(choujiang_all)
        {
            var str_all = "shaonaomukuai_choujianglibao_game_"+isubgametype+"_all_jiangli_lingqued";

            ComCodeFuncMng.Add_Lingqued_Count(str_all,1);
        }
    


        /*
        var lingquedcount = ComCodeFuncMng.Get_Choujiang_Libao_Lingqued_Count(isubgametype);
        if(!lingquedcount || lingquedcount < 0)
        {
            lingquedcount = 0;
        }
     
    
        var newcc  =  1 + lingquedcount;
       
        var obj = {lingqued:newcc};
        var savedstr = JSON.stringify(obj);

        MyLocalStorge.setItem(str,savedstr);

*/



        if(libaolist)
        {
            ComFunc.Open_Get_Daoju_Award_Dlg(gamenode, libaolist, 1,null);
  
        }
     
    }
    


    //过关奖励
    static  Game_Suc_Show_Guoguang_Fuli(game,gamenode:cc.Node,isubgametype,igk,callback = null)
    {

        var strpara = "shaonaomukuai_guoguang_libao_game_"+isubgametype+"_gk_"+igk+"_lqed";

        var lingqued = ComCodeFuncMng.Get_Para_Count(strpara);
        var iguoguangedcount = lingqued[1];

        if(iguoguangedcount > 0)
        {
            if(callback)
            {
                callback();
            }
            return;
        }

        ComFunc.OpenNewDialog(gamenode,"preab/game_shoukan_libao","game_shoukan_libao",
        {parentgame:game,
            
            itype:2,
            isubgametype:isubgametype,
            igk:igk,
            
            cb: (iret,libaolist)=>
        {
            if(iret == 0)
            {
                if(callback)
                {
                    callback();
                }
                return;
            }

            ComCodeFuncMng.Add_Para_Count(strpara);
            ComFunc.Open_Get_Daoju_Award_Dlg(gamenode, libaolist, 1,callback);
  

        }});
    }

    
    static Check_Show_ChouJiang_Libao(game,gamenode:cc.Node,isubgametype,igk,callback = null)
    {
        var lingquedcount = ComCodeFuncMng.Get_Choujiang_Libao_Lingqued_Count(isubgametype);
        var all_jiangli_lingqued_count = ComCodeFuncMng.Get_Choujiang_Libao_AllJiangli_Lingqued_Count(isubgametype);
       

        var str_showed = "shaonaomukuai_choujianglibao_game_"+isubgametype+"_gk_"+igk+"_showed";
        var gk_show_count = ComCodeFuncMng.Get_Lingqued_Count(str_showed);
        if(gk_show_count > 0)
        {
            return false;
        }

        //关卡第二关后每关都提示下
        if(igk <= 1)
        {
            return false;
        }


        if(GlobalGameMng.GetInstance().In_Shenhe())
        {
            return false;
        }

        var bopend_other_dlg = MiddleGamePlatformAction.GetInstance().Is_Subgame_Gezi_Dlg_Has_One_Show();
        if(bopend_other_dlg)
        {
            //打开了其他比如暂停等弹框,就先不弹出
            return false;
        }

        var ishowcount =  GlobalGameMng.GetInstance().Get_CurProcess_GameType_Choujiang_Libao_Show_Count(isubgametype);
     

        var shoukan_libao_config = GlobalGameMng.GetInstance().Get_Shouci_Libao_Config();
        if(!shoukan_libao_config)
        {
            return false;
        }

        var same_ok_type = 0;
        for(var ff=0;ff<shoukan_libao_config.length;ff++)
        {
            var ff_per_info  = shoukan_libao_config[ff];
            var ff_gt = ff_per_info.gt;

            if(!ComFunc.Is_In_Arr_Range_Arr(ff_gt,isubgametype))
            {
                continue;
            }
            var ff_libaotype = ff_per_info.libaotype;

            if(ff_libaotype != 3)
            {
                continue;
            }

            var ff_show_type = ff_per_info.show_type;
            var ff_startgk = ff_per_info.startgk;
           // var ff_jianggegk = ff_per_info.jianggegk;
            var ff_endgk = ff_per_info.endgk;

            var ff_canmulcount = ff_per_info.canmulcount;
            var ff_muljiangegk = ff_per_info.muljiangegk;
            var ff_com_jianggegk = ff_per_info.jianggegk;

            var ff_all_jiangli_can_mul_count = ff_per_info.all_jiangli_can_mul_count;
         
            

            if(!ff_all_jiangli_can_mul_count)
            {
                ff_all_jiangli_can_mul_count = 0;
            }

            if(!ff_canmulcount)
            {
                ff_canmulcount = 0;
            }
            
            if(!ff_muljiangegk)
            {
                ff_muljiangegk = ff_com_jianggegk;
            }

            if(igk < ff_startgk)
            {
                continue;
            }

            if(ff_endgk && ff_endgk > 0)
            {
                if(igk > ff_endgk)
                {
                    continue;
                }
            }

            if(ff_show_type == 99 || ff_show_type == 0)
            {
                continue;
            }

            if(lingquedcount > 0 && lingquedcount > ff_canmulcount)
            {
                continue;
            }

            if(all_jiangli_lingqued_count > 0 && all_jiangli_lingqued_count > ff_all_jiangli_can_mul_count)
            {
                continue;
            }
            var ff_jianggegk = ff_com_jianggegk;
            if(lingquedcount > 0)
            {
                ff_jianggegk = ff_muljiangegk;
            }

            var shouci_libao_show_type = ff_show_type;

            var bfuhe = false;

            //每关都弹出来
            if(shouci_libao_show_type == 1)
            {
                bfuhe = true;
            }  
            else if(shouci_libao_show_type == 5)
            {
                //只弹出一次
                if(ishowcount >= 1)
                {
                    bfuhe = false;
                }else{
                    bfuhe = true;
                }
            }
            else if(shouci_libao_show_type == 2)
            {
                //首次弹出，另外，接下来，关卡在%3
                if(ishowcount >= 1)
                {
                    var strpara = "shaonaomukuai_choujiang_libao_game_"+isubgametype+"_notshow_jiange_cishu";

                    var jiange_cishu_info = ComCodeFuncMng.Get_Para_Count(strpara);
                    var ijiange_cishu = jiange_cishu_info[1];

                    if(ijiange_cishu >= ff_jianggegk)
                    {
                        ComCodeFuncMng.Remove_Para_Count(strpara);
                        bfuhe = true;
                    }else
                    {
                        ComCodeFuncMng.Add_Para_Count(strpara);
                        bfuhe = false;
                    }

                }
            }else if(shouci_libao_show_type == 4)
            {
                var chajugk = igk - ff_startgk;

                if(ff_jianggegk > 0 )
                {
                    if(chajugk%ff_jianggegk == 0)
                    {
                        bfuhe = true;
                    }
                  
                }

            }


            if(bfuhe)
            {
                same_ok_type = ff_libaotype;
                break;
            }
        }

        if(same_ok_type  == 0)
        {

            return false;
        }

        GlobalGameMng.GetInstance().Add_CurProcess_GameType_Choujiang_Libao_Show_Count(isubgametype);
        ComCodeFuncMng.Add_Lingqued_Count(str_showed,1);


        var preabname = "preab/common/game_3_choujiang";
        var scriptenaem = "game_3_choujiang";
 
        ComFunc.OpenNewDialog(gamenode,preabname,scriptenaem,
        {parentgame:game,
            
            itype:1,
            isubgametype:isubgametype,
            igk:igk,
            
            cb: (iret,libaolist,choujiang_all)=>
        {
            if(iret == 0)
            {
                return;
            }

            ComCodeFuncMng.On_ChouJiang_Lingqued(choujiang_all,gamenode,isubgametype,igk,libaolist);

            if(callback)
            {
                callback();
            }
            

        }});
 

        return true;
    }

    static Common_Choujiang(gamenode,callback)
    {
        var reward_list = ChouJiangMng.GetInstance().Get_Choujiang_Jiangli();
        if(!reward_list || reward_list.length == 0)
        {
            return;
        }
        ChouJiangMng.GetInstance().Common_Choujiang();

        
        var preabname = "preab/common/game_3_choujiang";
        var scriptenaem = "game_3_choujiang";
 
        ComFunc.OpenNewDialog(gamenode,preabname,scriptenaem,
        { 
            
            reward_list:reward_list,
            cb: (iret,libaolist,choujiang_all)=>
        {
            ComFunc.Open_Get_Daoju_Award_Dlg(gamenode, libaolist, 1,null);
            callback();
            

        }});
 


    }
    static Check_Show_Shouci_Com_Libao(game,gamenode:cc.Node,isubgametype,igk,callback = null)
    {
        var lingquedcount = ComCodeFuncMng.Get_Shoukan_Fuli_Lingqued_Count(isubgametype);
       // if(blingqued)
        {
           // return  false;
        }

        var str_showed = "shaonaomukuai_shoukan_libao_game_"+isubgametype+"_gk_"+igk+"_showed";
        var gk_show_count = ComCodeFuncMng.Get_Lingqued_Count(str_showed);
        if(gk_show_count > 0)
        {
            return false;
        }

        //关卡第二关后每关都提示下
        if(igk <= 1)
        {
            return false;
        }

        var bopend_other_dlg = MiddleGamePlatformAction.GetInstance().Is_Subgame_Gezi_Dlg_Has_One_Show();
        if(bopend_other_dlg)
        {
            //打开了其他比如暂停等弹框,就先不弹出
            return false;
        }
        var ishowcount =  GlobalGameMng.GetInstance().Get_CurProcess_GameType_Shouci_Libao_Show_Count(isubgametype);
     

        var shoukan_libao_config = GlobalGameMng.GetInstance().Get_Shouci_Libao_Config();
        if(!shoukan_libao_config)
        {
            return false;
        }

        var same_ok_type = 0;
        for(var ff=0;ff<shoukan_libao_config.length;ff++)
        {
            var ff_per_info  = shoukan_libao_config[ff];
            var ff_gt = ff_per_info.gt;

            if(!ComFunc.Is_In_Arr_Range_Arr(ff_gt,isubgametype))
            {
                continue;
            }
            var ff_libaotype = ff_per_info.libaotype;

            if(ff_libaotype != 1 && ff_libaotype != 2)
            {
                continue;
            }

            var ff_show_type = ff_per_info.show_type;
            var ff_startgk = ff_per_info.startgk;
           //var ff_jianggegk = ff_per_info.jianggegk;
            var ff_endgk = ff_per_info.endgk;

            var ff_canmulcount = ff_per_info.canmulcount;
            var ff_muljiangegk = ff_per_info.muljiangegk;
            var ff_com_jianggegk = ff_per_info.jianggegk;

            if(!ff_canmulcount)
            {
                ff_canmulcount = 0;
            }
            
            if(!ff_muljiangegk)
            {
                ff_muljiangegk = ff_com_jianggegk;
            }




            if(igk < ff_startgk)
            {
                continue;
            }

            if(ff_endgk && ff_endgk > 0)
            {
                if(igk > ff_endgk)
                {
                    continue;
                }
            }

            
            if(lingquedcount > 0 && lingquedcount > ff_canmulcount)
            {
                continue;
            }

            var ff_jianggegk = ff_com_jianggegk;
            if(lingquedcount > 0)
            {
                ff_jianggegk = ff_muljiangegk;
            }

            if(ff_show_type == 99 || ff_show_type == 0)
            {
                continue;
            }

            var shouci_libao_show_type = ff_show_type;

            var bfuhe = false;

            //每关都弹出来
            if(shouci_libao_show_type == 1)
            {
                bfuhe = true;
            }  
            else if(shouci_libao_show_type == 5)
            {
                //只弹出一次
                if(ishowcount >= 1)
                {
                    bfuhe = false;
                }else{
                    bfuhe = true;
                }
            }
            else if(shouci_libao_show_type == 2)
            {
                //首次弹出，另外，接下来，关卡在%3
                if(ishowcount >= 1)
                {
                    var strpara = "shaonaomukuai_shouci_libao_game_"+isubgametype+"_notshow_jiange_cishu";

                    var jiange_cishu_info = ComCodeFuncMng.Get_Para_Count(strpara);
                    var ijiange_cishu = jiange_cishu_info[1];

                    if(ijiange_cishu >= ff_jianggegk)
                    {
                        ComCodeFuncMng.Remove_Para_Count(strpara);
                        bfuhe = true;
                    }else
                    {
                        ComCodeFuncMng.Add_Para_Count(strpara);
                        bfuhe = false;
                    }

                }
            }else if(shouci_libao_show_type == 4)
            {
                var chajugk = igk - ff_startgk;

                if(ff_jianggegk > 0 && chajugk % ff_jianggegk == 0)
                {
                    bfuhe = true;
                }

            }


            if(bfuhe)
            {
                same_ok_type = ff_libaotype;
                break;
            }
        }

        if(same_ok_type  == 0)
        {

            return false;
        }

        GlobalGameMng.GetInstance().Add_CurProcess_GameType_Shouci_Libao_Show_Count(isubgametype);
        ComCodeFuncMng.Add_Lingqued_Count(str_showed,1);

        var preabname = "preab/common/game_shoukan_libao";
        var scriptenaem = "game_shoukan_libao";

        if(same_ok_type == 2)
        {
            preabname = "preab/common/game_libao_2_xinshou";
             scriptenaem = "game_shoukan_libao";
        }else{
            preabname = "preab/common/game_shoukan_libao";
            scriptenaem = "game_shoukan_libao";
        }

        ComFunc.OpenNewDialog(gamenode,preabname,scriptenaem,
        {parentgame:game,
            
            itype:1,
            isubgametype:isubgametype,
            igk:igk,
            
            cb: (iret,libaolist)=>
        {
            if(iret == 0)
            {
                return;
            }

            ComCodeFuncMng.On_Shoukan_Lingqued(gamenode,isubgametype,igk,libaolist);

            if(callback)
            {
                callback();
            }
            

        }});
 

        return true;

    }

    //弹出首看福利
    static Check_Show_Shoukan_Fuli(game,gamenode:cc.Node,isubgametype,igk,callback = null)
    {
        if(GlobalGameMng.GetInstance().In_Shenhe())
        {
            return false;
        }

        var check_show_comon_shouci_libao = ComCodeFuncMng.Check_Show_Shouci_Com_Libao(game,gamenode,isubgametype,igk,callback )

        if(check_show_comon_shouci_libao)
        {
            return true;
        }

        var check_show_choujiang_libao = ComCodeFuncMng.Check_Show_ChouJiang_Libao(game,gamenode,isubgametype,igk,callback )

        if(check_show_choujiang_libao)
        {
            return true;
        }
        return false;
   

    }

 
    static OnBtnTiaozhuanTuijian(ituijianwei,parentgame,parent_node,othergame_node)
    {
        if(!parentgame.m_tuijianwe_dest_info_map.hasKey(ituijianwei))
        {
            var defaultappid = HutuiAppInfoMng.GetInstance().Get_Default_Tuiguan_Appid(ituijianwei);
            PlatFormMng.GetInstance().Tiaozhuan_Tuijian_AppID(defaultappid);

            return null;
        }

        var tuijian_info = parentgame.m_tuijianwe_dest_info_map.getData(ituijianwei);

        console.log("OnBtnTiaozhuanTuijian ituijianwei="+ituijianwei+",tuijian_info="+tuijian_info);

        if(!tuijian_info)
        {
            var defaultappid = HutuiAppInfoMng.GetInstance().Get_Default_Tuiguan_Appid(ituijianwei);
            PlatFormMng.GetInstance().Tiaozhuan_Tuijian_AppID(defaultappid);

          
            
        }else{
            PlatFormMng.GetInstance().Jump_To_App_Game_By_Data(tuijian_info);
        }
    }

    static Update_Tuijian_Icon_By_Pos(ipos, ituijianwei, parentgame,parent_node,othergame_node)
    {
        var last_tuiijian_app_info =  HutuiAppInfoMng.GetInstance().Get_InnerGame_Show_App_Icon_Info(ituijianwei);
 
        if(!last_tuiijian_app_info)
        {
            return;
        }

        var name_node = cc.find("game"+ipos+"/name",othergame_node);
        name_node.getComponent(cc.Label).string = ""+last_tuiijian_app_info.toName;
        
        

        var icon_node = cc.find("game"+ipos+"/icon",othergame_node);
   
        var simgurl = last_tuiijian_app_info.icon;

        var texture = HutuiAppInfoMng.GetInstance().GetFilePathTexture(simgurl);
        var size_w = HutuiAppInfoMng.GetInstance().Get_Hutui_Gezi_Size();
       
        if(texture)
        {
            var psrite = icon_node.getComponent(cc.Sprite);

            psrite.spriteFrame = new cc.SpriteFrame(texture);

            icon_node.width = size_w.cx;
            icon_node.height = size_w.cy;
           // iconnode.getComponent(cc.Sprite)
        }else
        {
            BaseUIUtils.ShowIconNodePicFilename(icon_node,"resources/game/default",{cx:size_w.cx,cy:size_w.cy});
        }

        parentgame.m_tuijianwe_dest_info_map.putData(ituijianwei,last_tuiijian_app_info);
    }
    static Update_Tuijian_Icon(ituijianwei, parentgame,parent_node,othergame_node)
    {
        var last_tuiijian_app_info =  HutuiAppInfoMng.GetInstance().Get_InnerGame_Show_App_Icon_Info(ituijianwei);
 
        if(!last_tuiijian_app_info)
        {
            return;
        }

        var name_node = cc.find("game"+ituijianwei+"/name",othergame_node);
        name_node.getComponent(cc.Label).string = ""+last_tuiijian_app_info.toName;
        
        

        var icon_node = cc.find("game"+ituijianwei+"/icon",othergame_node);
   
        var simgurl = last_tuiijian_app_info.icon;

        var texture = HutuiAppInfoMng.GetInstance().GetFilePathTexture(simgurl);
        var size_w = HutuiAppInfoMng.GetInstance().Get_Hutui_Gezi_Size();
       
        if(texture)
        {
            var psrite = icon_node.getComponent(cc.Sprite);

            psrite.spriteFrame = new cc.SpriteFrame(texture);

            icon_node.width = size_w.cx;
            icon_node.height = size_w.cy;
           // iconnode.getComponent(cc.Sprite)
        }else
        {
            BaseUIUtils.ShowIconNodePicFilename(icon_node,"resources/game/default",{cx:size_w.cx,cy:size_w.cy});
        }

        parentgame.m_tuijianwe_dest_info_map.putData(ituijianwei,last_tuiijian_app_info);
    }

    static Check_Update_Tuijian_Icon_Info_By_Pos(ipos,ituijianwei, parentgame,parent_node,othergame_node)
    {

        if(!parentgame.m_last_tuijian_change_tick_map.hasKey(ipos)  )
        {
            parentgame.m_last_tuijian_change_tick_map.putData(ipos,Date.now());
 
            ComCodeFuncMng.Update_Tuijian_Icon_By_Pos(ipos,ituijianwei ,parentgame,parent_node,othergame_node);
        
        }
        else{

            var lasttitck  =parentgame.m_last_tuijian_change_tick_map.getData(ipos);

            if(Date.now() - lasttitck > HutuiAppInfoMng.GetInstance().Get_Hutui_Update_Tick())
            {
                parentgame.m_last_tuijian_change_tick_map.putData(ipos,Date.now());
 
                ComCodeFuncMng.Update_Tuijian_Icon_By_Pos(ipos,ituijianwei,parentgame,parent_node,othergame_node);
            }
          
        }
    }
    static Check_Update_Tuijian_Icon_Info(parentgame,parent_node,othergame_node)
    {
        if(parentgame.m_last_tuijian_change_tick == 0)
        {
            parentgame.m_last_tuijian_change_tick = Date.now();
 
            ComCodeFuncMng.Update_Tuijian_Icon(2,parentgame,parent_node,othergame_node);
        
        }
        else{

            if(Date.now() - parentgame.m_last_tuijian_change_tick > HutuiAppInfoMng.GetInstance().Get_Hutui_Update_Tick())
            {
                parentgame.m_last_tuijian_change_tick = Date.now();
 
                ComCodeFuncMng.Update_Tuijian_Icon(2,parentgame,parent_node,othergame_node);
            }
          
        }
    }

    static  Check_Update_Tuijian_Icon_Info_Index(itiojianwei_list, parentgame,parent_node,othergame_node)
    {
        if(parentgame.m_last_tuijian_change_tick == 0)
        {
            parentgame.m_last_tuijian_change_tick = Date.now();
 

            for(var ff=0;ff<itiojianwei_list.length;ff++)
            {
                var ff_index = itiojianwei_list[ff];
                ComCodeFuncMng.Update_Tuijian_Icon(ff_index,parentgame,parent_node,othergame_node);
        
            }
         
        }
        else{

            if(Date.now() - parentgame.m_last_tuijian_change_tick > HutuiAppInfoMng.GetInstance().Get_Hutui_Update_Tick())
            {
                parentgame.m_last_tuijian_change_tick = Date.now();
                for(var ff=0;ff<itiojianwei_list.length;ff++)
                {
                    var ff_index = itiojianwei_list[ff];
                    ComCodeFuncMng.Update_Tuijian_Icon(ff_index,parentgame,parent_node,othergame_node);
            
                } 
            }
          
        }
    }

    static OnBtn_Open_Shangcheng(pnode,callback)
    {
        ComFunc.OpenNewDialog(pnode,"preab/shangcheng","shangcheng",{cb:callback});
 
    }
    static Init_SelGK_Tuijian_Guangao(parentgame,parent_node,othergame_node)
    {
        var tuijaing_game5_node = cc.find("game5",othergame_node);

        tuijaing_game5_node.on("click",

        ()=>
        {
            ComCodeFuncMng.OnBtnTiaozhuanTuijian(5,parentgame,parent_node,othergame_node);
        }
        );


        var tuijaing_game6_node = cc.find("game6",othergame_node);

        tuijaing_game6_node.on("click",

        ()=>
        {
            ComCodeFuncMng.OnBtnTiaozhuanTuijian(6,parentgame,parent_node,othergame_node);
        }
        );
    
     
        tuijaing_game5_node.runAction(cc.repeatForever(

            cc.sequence(cc.rotateTo(0.1,7),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),
            
            
            cc.callFunc(()=>
            {

                ComCodeFuncMng.Check_Update_Tuijian_Icon_Info_Index([5,6], parentgame,parent_node,othergame_node);
            }),
            cc.delayTime(3))

        ));

        tuijaing_game6_node.runAction(cc.repeatForever(

            cc.sequence(cc.rotateTo(0.1,7),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),
            
            
            cc.callFunc(()=>
            {
 
            }),
            cc.delayTime(3))

        ));

        ComCodeFuncMng.Check_Update_Tuijian_Icon_Info_Index([5,6],parentgame,parent_node,othergame_node);

    }

    static Init_Com_Two_Guangao_Pos(parentgame,parent_node,othergame_node,ipos,ituijianwei)
    {
        
        var tuijaing_game_node = cc.find("game"+ipos,othergame_node);

        tuijaing_game_node.on("click",

            ()=>
            {
                ComCodeFuncMng.OnBtnTiaozhuanTuijian(ituijianwei,parentgame,parent_node,othergame_node);
            }
         );
    
     
         tuijaing_game_node.runAction(cc.repeatForever(

            cc.sequence(cc.rotateTo(0.1,7),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),
            
            
            cc.callFunc(()=>
            {

                ComCodeFuncMng.Check_Update_Tuijian_Icon_Info_By_Pos(ipos,ituijianwei,parentgame,parent_node,othergame_node);
            }),
            cc.delayTime(3))

        ));
        ComCodeFuncMng.Check_Update_Tuijian_Icon_Info_By_Pos(ipos,ituijianwei,parentgame,parent_node,othergame_node);
    }
    static Init_Com_Two_Guangao(parentgame,parent_node,othergame_node,posarr)
    {
        if(!MiddleGamePlatformAction.GetInstance().IS_Show_Zidingyi_TuijianWei())
        { 
            othergame_node.active = false;
            return;
        }

        othergame_node.active = true;
        if(!parentgame.m_last_tuijian_change_tick_map)
        {
            parentgame.m_last_tuijian_change_tick_map = new WMap();
        }
        if(!parentgame.m_tuijianwe_dest_info_map)
        {
            parentgame.m_tuijianwe_dest_info_map = new WMap();
        }
        for(var ff=0;ff<posarr.length;ff++)
        {
            var ff_index = ff+1;
            var f_tuijianwei = posarr[ff];

            console.log("Init_Com_Two_Guangao ,ff_index="+ff_index+",tuijianwei="+f_tuijianwei);

            ComCodeFuncMng.Init_Com_Two_Guangao_Pos(parentgame,parent_node,othergame_node,ff_index,f_tuijianwei)
        }

      

        
    }
    static Init_Top_Tuijian_Guangao(parentgame,parent_node,othergame_node)
    {
        if(!MiddleGamePlatformAction.GetInstance().IS_Show_Zidingyi_TuijianWei())
        { 
            othergame_node.active = false;
            return;
        }
      //  var self = parentgame;

        var tuijaing_game2_node = cc.find("game2",othergame_node);

        
        if(!MiddleGamePlatformAction.GetInstance().IS_Show_Zidingyi_TuijianWei())
        { 
            tuijaing_game2_node.active = false;
            
            return;
        }
        tuijaing_game2_node.on("click",

            ()=>
            {
                ComCodeFuncMng.OnBtnTiaozhuanTuijian(2,parentgame,parent_node,othergame_node);
            }
        );
        
         
        tuijaing_game2_node.runAction(cc.repeatForever(

            cc.sequence(cc.rotateTo(0.1,7),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),
            
               
            cc.callFunc(()=>
            {

                ComCodeFuncMng.Check_Update_Tuijian_Icon_Info(parentgame,parent_node,othergame_node);
            }),
            cc.delayTime(3))

        ));


        ComCodeFuncMng.Check_Update_Tuijian_Icon_Info(parentgame,parent_node,othergame_node);
    }

    static  On_Game_Enter(isubgametype,pgame,pnode)
    {
        
        

        var gezilist = GlobalGameMng.GetInstance().Get_Enter_Game_Bk_Create_Gezi_List(isubgametype);
        
       
        MiddleGamePlatformAction.GetInstance().Check_Create_Bk_Gezi_List(gezilist);
      
        console.log("On_Game_Enter 创建bk 格子:"+JSON.stringify(gezilist));
        
        MiddleGamePlatformAction.GetInstance().Show_Qiandao_Banners(false);


        GlobalGameMng.GetInstance().On_Game_Enter(isubgametype,pgame,pnode);

    }


    static Check_Watch_Fail_Dlg(i_watch_type,pnode,calback)
    {
        var need_show_video_Fail_dlg = GlobalGameMng.GetInstance().IS_Watch_Video_Fail_Need_Show_Error_Lingqu_Dlg(i_watch_type);

        if(need_show_video_Fail_dlg)
        {
            ComFunc.OpenNewDialog(pnode,"preab/common/watch_video_fail","watch_video_fail",
                { 
                    i_watch_type:i_watch_type,
                    cb:(iret)=>
                    {
                        calback(iret);
                    } 
                }
            );
        }
    }
    

    static  Refresh_Choujiang_Info(pgame,chouka_node)
    {
      
    }
}