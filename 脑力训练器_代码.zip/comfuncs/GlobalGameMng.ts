import GlobalMng from "../global/GlobalMng";
import GlobalData from "../main/GlobalData";
import HutuiAppInfoMng from "../PlatForm/HutuiAppInfoMng";
import PlatFormMng from "../PlatForm/PlatFormMng";
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";
import MyLocalStorge from "../WDT/MyLocalStorge";
import WMap from "../WDT/WMap";
import ClientLogUtils from "./ClientLogUtils";
import ComFunc from "./ComFunc";


class PerDayWanfaEnterCishu
{
    public ienterdayunion:number = 0;
    public ienterdaycishu:number = 0;
}


export default class GlobalGameMng
{
    static _instance:GlobalGameMng = null;
    static GetInstance() 
    {
        if (!GlobalGameMng._instance) {
            // doSomething
            GlobalGameMng._instance = new GlobalGameMng();
             
        }
        return GlobalGameMng._instance;
    }

    m_b_first_sign_dlg_poped = false;
    m_loading_to_game_scence_name = "";
    
    m_all_in_bag_daoju_type_leftcount_map = new WMap();

    m_readed_game_common_config_remote_json = null;
    m_last_save_valid_common_config_remote_json = null;


    //各个玩法总共进入的次数
    m_subgametype_enter_gamed_cishu_map = new WMap();

    //各个玩法当日进入游戏的次数
    m_subgametype_perday_entered_gamed_cishu_map = new WMap();
    
    
    //最后一次跳过时间
    m_last_tiaoguo_gk_tick = 0;

    m_first_tili_inited_countdowned = false;

    //继续上次游戏存档剩余
    m_continue_prev_game_left_count = 5;


    //连续观看获得无限体力数目
    m_lianxu_guangkan_wuxian_tili_video_count = 0;
    //连续观看获得无限体力24小时开始时间
    m_lianxu_guangkan_wuxian_tili_tick = 0;



    m_lianxu_guangkan_wuxian_48huor_tili_video_count = 0;

    //连续观看获得无限体力48小时开始时间
    m_lianxu_guangkan_wuxian_tili_48_huor_tick = 0;

    m_cur_process_dating_show_caidan_mode = 0;

    m_subgametype_last_show_banner_type_map = new WMap();

    m_gametype_shouci_libao_show_count_map = new WMap();

    m_gametype_choujiang_libao_show_count_map = new WMap();



    //体力开始计时tick
    m_tili_countdown_start_tick = 0;
    m_tili_countdown_start_Left_count = 0;

    m_cur_process_fanhuidating_queren_dlg_mode = 0;
 
    m_gametype_last_save_game_prev_play_data_map = new WMap();


    m_dating_last_from_subgame_type  = 0;
    m_dating_last_from_subgame_level  = 0;
    m_default_config = null;


    m_last_game_config_json_refresh_tick = 0;

    constructor()
    {

        this.InitRead_Last_Save_Common_Server_Config();
        this.InitRead_Game_Basic_Info();


        //this.Test();
    }
    Set_Default_Config(default_config)
    {
        this.m_default_config = default_config;
    }
    On_Game_Enter(isubgametype,pgame,pnode)
    {
        if(Date.now() - this.m_last_game_config_json_refresh_tick < 30000)
        {
            return;
        }
        this.m_last_game_config_json_refresh_tick = Date.now();

        HutuiAppInfoMng.GetInstance().LoadRemoteConfig(()=>{


        }); 
 
  
        GlobalGameMng.GetInstance().Load_Game_Common_Config(()=>{
        
 
        });

    }

    Read_GameType_Prev_Save_Data(igametype)
    {
        var str1= MyLocalStorge.getItem("shaonaomukuai_gametype_"+igametype+"_last_game_play_data");
        if(str1)
        {
            var basic_obj1 = JSON.parse(str1);

            if(basic_obj1 && basic_obj1.bvalid)
            {
                return  basic_obj1;
            }
        }

        return null;
    }
    Delete_GameType_Prev_Save_Data(igametype)
    {
        this.m_gametype_last_save_game_prev_play_data_map.RemoveKey(igametype);
        var str1= "shaonaomukuai_gametype_"+igametype+"_last_game_play_data";
        MyLocalStorge.removeItem(str1);
    }

    Change_GameType_Prev_Save_Data(igametype,pnewobj)
    {
        this.m_gametype_last_save_game_prev_play_data_map.putData(igametype,pnewobj);
        var str1= "shaonaomukuai_gametype_"+igametype+"_last_game_play_data";
        MyLocalStorge.setItem(str1,JSON.stringify(pnewobj));
    }

    Get_Prev_Save_Game_Data(igametype)
    {

        if(this.m_gametype_last_save_game_prev_play_data_map.hasKey(igametype))
        {
            var pobj = this.m_gametype_last_save_game_prev_play_data_map.getData(igametype);
            return pobj;
        }
        var pinfo = this.Read_GameType_Prev_Save_Data(igametype);
        this.m_gametype_last_save_game_prev_play_data_map.putData(igametype,pinfo);
        return pinfo;
    }
    Get_Fuhuo_Dlg_End_Show_Cancel_Btn_Per_Game_Type_Config(igametype)
    {
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return null;
        }

        var fuhuo_dlg_gametype_show_cancel_btn_sec_conf =  cur_valid_config.fuhuo_dlg_gametype_show_cancel_btn_sec_conf;

        for(var ff=0;ff<fuhuo_dlg_gametype_show_cancel_btn_sec_conf.length;ff++)
        {
            var ff_info_arr = fuhuo_dlg_gametype_show_cancel_btn_sec_conf[ff];
            if(ff_info_arr[0] == igametype && ff_info_arr.length >= 3)
            {
                return ff_info_arr;
            }
        }
        return null;

    }
 
    Get_Fuhuo_Dlg_End_Show_Cancel_Btn()
    {
        var idefaultv = 1;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }
         

        var fuhuo_dlg_daojishi_end_show_cancel_btn = cur_valid_config.fuhuo_dlg_daojishi_end_show_cancel_btn;
        return fuhuo_dlg_daojishi_end_show_cancel_btn;
    }
    Get_Fuhuo_Dlg_Daojishi_All_Sec()
    {
        var idefaultv = 6;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }
        if(!cur_valid_config.fuhuo_dlg_daojishi_all_sec)
        {
            return idefaultv;
        }

        var iallsec = cur_valid_config.fuhuo_dlg_daojishi_all_sec;
        return iallsec;

    }
     //游戏胜利返回大厅是否需要确定弹框--默认情况下都是bu需要的
     IS_Game_Success_Dlg_FanhuiDating_Need_Queren()
     {
        
         var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
         if(!cur_valid_config)
         {
             return 1;
         }
         if(cur_valid_config.game_suc_dlg_need_fanhuidating_confirm  == 0)
         {
             return 0;
         }
 
         return 1;
     }
    Add_DaojuType_Count_List(awarddaoju,ibeishu = 1)
    { 
        for(var ff=0;ff<awarddaoju.length;ff++){
            var ff_info =  awarddaoju[ff];
            var ff_t = ff_info.t;
            var ff_c = ff_info.c * ibeishu;
            // cc.log('ff_T' + ff_t);
            // cc.log('ff_C' + ff_c);
 
            if(!this.m_all_in_bag_daoju_type_leftcount_map.hasKey(ff_t)){
                this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_t,ff_c);
            }else{
                var iprevc = this.m_all_in_bag_daoju_type_leftcount_map.getData(ff_t);
                this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_t,ff_c + iprevc);
            }
        }
        this.Save_Game_Basic_Info();
    }

    Add_CurProcess_GameType_Shouci_Libao_Show_Count(igametype)
    {
        if(!this.m_gametype_shouci_libao_show_count_map.hasKey(igametype))
        {
            this.m_gametype_shouci_libao_show_count_map.putData(igametype,1);
        }else{
            var icc = this.m_gametype_shouci_libao_show_count_map.getData(igametype);
            this.m_gametype_shouci_libao_show_count_map.putData(igametype,1 + icc);
  
        }
    }
   
    Get_CurProcess_GameType_Shouci_Libao_Show_Count(igametype)
    {
        if(!this.m_gametype_shouci_libao_show_count_map.hasKey(igametype))
        {
            return 0;
        }

        var icc = this.m_gametype_shouci_libao_show_count_map.getData(igametype);
        return icc;
    }
    Add_CurProcess_GameType_Choujiang_Libao_Show_Count(igametype)
    {
        if(!this.m_gametype_choujiang_libao_show_count_map.hasKey(igametype))
        {
            this.m_gametype_choujiang_libao_show_count_map.putData(igametype,1);
        }else{
            var icc = this.m_gametype_choujiang_libao_show_count_map.getData(igametype);
            this.m_gametype_choujiang_libao_show_count_map.putData(igametype,1 + icc);
  
        }
    }
    Get_CurProcess_GameType_Choujiang_Libao_Show_Count(igametype)
    {
        if(!this.m_gametype_choujiang_libao_show_count_map.hasKey(igametype))
        {
            return 0;
        }

        var icc = this.m_gametype_choujiang_libao_show_count_map.getData(igametype);
        return icc;
    }
    
    //每到这个关卡，就必须出现
    Get_GameType_Shouci_Libao_show_gk_Jiange(isubgametype)
    {
        var idesfaultvalue = 3;
    
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idesfaultvalue;
        }

        var game_shouci_libao_show_gk_jiange = cur_valid_config.game_shouci_libao_show_gk_jiange;
        
        var per_gametype_shouci_libao_show_type = cur_valid_config.per_gametype_shouci_libao_show_type;
    
        if(per_gametype_shouci_libao_show_type)
        {
            for(var ff=0;ff<per_gametype_shouci_libao_show_type.length;ff++)
            {
                var ff_arr = per_gametype_shouci_libao_show_type[ff];
                if(ff_arr[0] == isubgametype && ff_arr.length >= 3)
                {
                    return ff_arr[2];
                }
            }
        }

        if(game_shouci_libao_show_gk_jiange == undefined)
        {
            return idesfaultvalue;
        }
    

        return game_shouci_libao_show_gk_jiange;
    } 
    Get_GameType_Shouci_Libao_ShowType(isubgametype)
    {
 
        var idesfaultvalue = 99;
       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idesfaultvalue;
        }
        if(this.In_Shenhe())
        {
            return 99;
        }

        var game_shouci_libao_show_type = cur_valid_config.game_shouci_libao_show_type;
        
        var per_gametype_shouci_libao_show_type = cur_valid_config.per_gametype_shouci_libao_show_type;
       
        if(per_gametype_shouci_libao_show_type)
        {
            for(var ff=0;ff<per_gametype_shouci_libao_show_type.length;ff++)
            {
                var ff_arr = per_gametype_shouci_libao_show_type[ff];
                if(ff_arr[0] == isubgametype && ff_arr.length >= 3)
                {
                    return ff_arr[1];
                }
            }
    
        }

        if(game_shouci_libao_show_type == undefined)
        {
            return idesfaultvalue;
        }
        
        return game_shouci_libao_show_type;
    }
    Change_Self_DaojuType_Count(idaojutype,icount){
        var ff_t = idaojutype;
        var ff_c = icount;
        if(!this.m_all_in_bag_daoju_type_leftcount_map.hasKey(ff_t)){



            if(ff_c < 0)
            {
                ff_c=  0;
            }
            this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_t,ff_c);
        }else{
            var iprevc = this.m_all_in_bag_daoju_type_leftcount_map.getData(ff_t);

            var inewc = ff_c + iprevc;
            if(inewc <= 0)
            {
                inewc = 0;
            }
            this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_t,inewc);
        }

     
        this.Save_Game_Basic_Info();
      
    }

    Add_Tili(icount)
    {
        this.Change_Self_DaojuType_Count(3,icount);
        //做数据校验
        var icurtili = this.Get_Tili();
        if(icurtili > this.Get_Max_Tili())
        {
            icurtili = this.Get_Max_Tili();
            this.m_all_in_bag_daoju_type_leftcount_map.putData(3,icurtili);
            this.Save_Game_Basic_Info();
        }else if(icurtili <= 0)
        {
            icurtili=  0;
            this.m_all_in_bag_daoju_type_leftcount_map.putData(3,icurtili);
            this.Save_Game_Basic_Info();
        }

       
    }

    Get_Lianxu_Video_Wuxian_48huor_Tili_Left_Sec()
    {
        if(this.m_lianxu_guangkan_wuxian_tili_48_huor_tick == 0)
        {
            return 0;
        }

        var wuxiansecd = 48*3600 ;
       // var wuxiansecd = 30;

        var ieplasetick = Date.now() - this.m_lianxu_guangkan_wuxian_tili_48_huor_tick;

        var ileftsec = Math.floor(wuxiansecd - ieplasetick/1000);
        if(ileftsec <= 0)
        {
            ileftsec=  0;
            this.m_lianxu_guangkan_wuxian_tili_48_huor_tick  = 0;
            this.Save_Game_Basic_Info();
        }

        return ileftsec;
    }

    //连续观看无限体力剩余时间
    Get_Lianxu_Video_Wuxian_Tili_Left_Sec()
    {

        if(this.m_lianxu_guangkan_wuxian_tili_tick == 0)
        {
            return 0;
        }

        var wuxiansecd = 24*3600 ;
    // var wuxiansecd = 30;

        var ieplasetick = Date.now() - this.m_lianxu_guangkan_wuxian_tili_tick;

        var ileftsec = Math.floor(wuxiansecd - ieplasetick/1000);
        if(ileftsec <= 0)
        {
            ileftsec=  0;
            this.m_lianxu_guangkan_wuxian_tili_tick  = 0;
            this.Save_Game_Basic_Info();
        }

        return ileftsec;
        
    }

    //进入游戏一次扣除体力数目，一般都是1
    Get_Enter_Game_PerCi_Sub_Tili()
    {
        var idefaultv = 0;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var enter_game_perci_sub_tili = cur_valid_config.enter_game_perci_sub_tili;
        if(enter_game_perci_sub_tili == undefined)
        {
            return idefaultv;
        }

        if(enter_game_perci_sub_tili >= 0 && enter_game_perci_sub_tili<20)
        {
            return enter_game_perci_sub_tili;
        }

        return idefaultv;
    }
    IS_Watch_Video_Guanggao_Qufen_Mingxi()
    {
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var watch_video_guangao_qufen_mingxi = cur_valid_config.watch_video_guangao_qufen_mingxi;
        if(watch_video_guangao_qufen_mingxi == undefined)
        {
            return idefaultv;
        }

     

        return watch_video_guangao_qufen_mingxi;
    }
    IS_Watch_Video_Guanggao_Not_Same_Unionid_Need_Destroy_Prev()
    {
        var idefaultv = 0;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var watch_video_not_same_need_destroy_prev = cur_valid_config.watch_video_not_same_need_destroy_prev;
        if(watch_video_not_same_need_destroy_prev == undefined)
        {
            return idefaultv;
        }

     

        return watch_video_not_same_need_destroy_prev;
    }
    Check_Save_First_Reg_Day_Info()
    {
        

        var icurdayuinon = ComFunc.GetCurDayUnion();
        var self_reg_day = icurdayuinon;

        var bprevsaved = false;
        var prev_reg_day = 0;
        var reg_day_info = MyLocalStorge.getItem("shaonaomukuai_reg_day");
        var jobj = null;
        if(reg_day_info)
        {
            try{
                jobj = JSON.parse(reg_day_info);
            }catch(e)
            {}
            
            if(jobj)
            {
                var reg_day_uinon = jobj.reg_day_uinon;
                if(reg_day_uinon && reg_day_uinon > 0 )
                {
                    bprevsaved = true;
                    prev_reg_day = reg_day_uinon;
                    self_reg_day = reg_day_uinon;;
                }
            }
        }

        if(!bprevsaved)
        {
            var obj = {reg_day_uinon:icurdayuinon};
            

            MyLocalStorge.setItem("shaonaomukuai_reg_day",JSON.stringify(obj));
        }else{

            console.log("prev_reg_day="+prev_reg_day);

        }

      
        return self_reg_day;
    }
    Get_Self_Reg_Day()
    {

        return this.Check_Save_First_Reg_Day_Info();
    }

    Get_After_Start_Reg_Sec()
    {
        var eplasetick = Date.now()  - this.Get_Self_Reg_Tick();

        var isec = Math.floor(eplasetick/1000);

        return isec;
    }

    Get_After_Start_Reg_Tick()
    {
        var eplasetick = Date.now()  - this.Get_Self_Reg_Tick();

        return eplasetick;
    }

    
    //小于这天注册的用户不扣体力
    Get_Reg_Day_Xiaoyu_Dest_Day_Bukou_Tili()
    {
        var idesfaultvalue = 0;
    

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idesfaultvalue;
        }


        var regday_unoin_xiaoyu_dest_day_bukou_tili = cur_valid_config.regday_unoin_xiaoyu_dest_day_bukou_tili;
        if(!regday_unoin_xiaoyu_dest_day_bukou_tili)
        {
            return idesfaultvalue;
        }

        if(regday_unoin_xiaoyu_dest_day_bukou_tili > 0 )
        {
            return regday_unoin_xiaoyu_dest_day_bukou_tili;
        }

        return idesfaultvalue;
    }
    Get_Per_Game_PerDay_First_Enter_Cishu_Nei_Bukou_Tili()
    {
        var idesfaultvalue = 2;
       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idesfaultvalue;
        }

        var per_game_perday_first_enter_cishu_nei_bukou_tili = cur_valid_config.per_game_perday_first_enter_cishu_nei_bukou_tili;
        if(per_game_perday_first_enter_cishu_nei_bukou_tili == undefined)
        {
            return idesfaultvalue;
        }

        return per_game_perday_first_enter_cishu_nei_bukou_tili;
    }
    


    Get_Subgametype_CurDay_Enterd_Cishu(isbugametype)
    {

        var cur_day_union = ComFunc.GetCurDayUnion();

        if(this.m_subgametype_perday_entered_gamed_cishu_map.hasKey(isbugametype))
        {
            var prevdata:PerDayWanfaEnterCishu = this.m_subgametype_perday_entered_gamed_cishu_map.getData(isbugametype);
          
          
            if(prevdata.ienterdayunion == cur_day_union)
            {
                return  prevdata.ienterdaycishu;
            }
          
            return 0;
        }

        return 0;
    }
    Get_Subgametype_Enterd_Cishu(isbugametype)
    {
        if(this.m_subgametype_enter_gamed_cishu_map.hasKey(isbugametype))
        {
            var icishu = this.m_subgametype_enter_gamed_cishu_map.getData(isbugametype);
            return icishu;
        }

        return 0;
    }
    Save_Game_Basic_Info()
    {

       

        var basicinfo = {m_last_tiaoguo_gk_tick:this.m_last_tiaoguo_gk_tick,  daoju_count_list:[] ,
            enter_subgame_count_list:[] ,perday_enter_subgame_count_list:[],
            m_continue_prev_game_left_count:this.m_continue_prev_game_left_count ,
            m_lianxu_guangkan_wuxian_tili_video_count:this.m_lianxu_guangkan_wuxian_tili_video_count ,
            m_lianxu_guangkan_wuxian_tili_tick:this.m_lianxu_guangkan_wuxian_tili_tick ,
            m_lianxu_guangkan_wuxian_48huor_tili_video_count:this.m_lianxu_guangkan_wuxian_48huor_tili_video_count,
            m_lianxu_guangkan_wuxian_tili_48_huor_tick:this.m_lianxu_guangkan_wuxian_tili_48_huor_tick
        };

       

        var daoju_count_list = [];
        for(var ff=0;ff<this.m_all_in_bag_daoju_type_leftcount_map.size();ff++)
        {
            var ff_type = this.m_all_in_bag_daoju_type_leftcount_map.GetKeyByIndex(ff);
            var ff_count = this.m_all_in_bag_daoju_type_leftcount_map.GetEntryByIndex(ff);
           
            daoju_count_list.push({itype:ff_type,c:ff_count});
           
        }
        basicinfo.daoju_count_list = daoju_count_list;
       

        var enter_subgame_count_list = [];
        for(var ff=0;ff<this.m_subgametype_enter_gamed_cishu_map.size();ff++)
        {
            var ff_type = this.m_subgametype_enter_gamed_cishu_map.GetKeyByIndex(ff);
            var ff_count = this.m_subgametype_enter_gamed_cishu_map.GetEntryByIndex(ff);
           
            enter_subgame_count_list.push({itype:ff_type,c:ff_count});
           
        }

        basicinfo.enter_subgame_count_list = enter_subgame_count_list;
        
 
        var perday_enter_subgame_count_list = [];
        for(var ff=0;ff<this.m_subgametype_perday_entered_gamed_cishu_map.size();ff++)
        {
            var ff_type = this.m_subgametype_perday_entered_gamed_cishu_map.GetKeyByIndex(ff);
            var ff_perday:PerDayWanfaEnterCishu = this.m_subgametype_perday_entered_gamed_cishu_map.GetEntryByIndex(ff);
           
            perday_enter_subgame_count_list.push({itype:ff_type,c:ff_perday.ienterdaycishu,d:ff_perday.ienterdayunion});
           
        }

        basicinfo.perday_enter_subgame_count_list = perday_enter_subgame_count_list;
        
 


        MyLocalStorge.setItem("shaonaomukuai_global_basic_info",JSON.stringify(basicinfo));

    }

    
    //每次购买的体力
    Get_PerCi_Goumai_Tili()
    {
        var idefaultv = 30;
       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var goumai_tili_per_ci = cur_valid_config.goumai_tili_per_ci;
        if(goumai_tili_per_ci == undefined)
        {
            return idefaultv;
        }

        if(goumai_tili_per_ci > 0 && goumai_tili_per_ci < 100)
        {
            return goumai_tili_per_ci;
        }

        return idefaultv;
    }
    On_Watch_Lianxu_Wuxian_48huor_Tili_Video_Suc()
    {
        this.m_lianxu_guangkan_wuxian_48huor_tili_video_count++;

        if(this.m_lianxu_guangkan_wuxian_48huor_tili_video_count >= 5)
        {
            this.m_lianxu_guangkan_wuxian_48huor_tili_video_count = 0;
            this.Add_Tili(this.Get_Max_Tili());
            this.m_lianxu_guangkan_wuxian_tili_48_huor_tick= Date.now();
        }

        this.Save_Game_Basic_Info();
    }

    InitRead_Game_Basic_Info()
    { 
        var str= MyLocalStorge.getItem("shaonaomukuai_global_basic_info");
        if(!str)
        {
            return;
        }

        var basic_obj = JSON.parse(str);
        if(!basic_obj)
        {
            return;
        }


        var daoju_count_list=  basic_obj.daoju_count_list;
        if(!daoju_count_list)
        {
            daoju_count_list = [];
        }

        for(var ff=0;ff<daoju_count_list.length;ff++)
        {
            var ff_info = daoju_count_list[ff];
            var ff_itype = ff_info.itype;
            var ff_c= ff_info.c;
            if(ff_c >= 0)
            {
                this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_itype,ff_c);

            }
        }
      
            // /体力初始化
        if(!this.m_all_in_bag_daoju_type_leftcount_map.hasKey(3))
        {
            
            this.m_all_in_bag_daoju_type_leftcount_map.putData(3,this.Get_Max_Tili());

        }



        var enter_subgame_count_list=  basic_obj.enter_subgame_count_list;
        if(!enter_subgame_count_list)
        {
            enter_subgame_count_list = [];
        }
        for(var ff=0;ff<enter_subgame_count_list.length;ff++)
        {
            var ff_info = enter_subgame_count_list[ff];
            var ff_itype = ff_info.itype;
            var ff_c= ff_info.c;
            if(ff_c >= 0)
            {
                this.m_subgametype_enter_gamed_cishu_map.putData(ff_itype,ff_c);

            }
        }

 
        
        var perday_enter_subgame_count_list=  basic_obj.perday_enter_subgame_count_list;
        if(!perday_enter_subgame_count_list)
        {
            perday_enter_subgame_count_list = [];
        }



        var curday_union = ComFunc.GetCurDayUnion();

        for(var ff=0;ff<perday_enter_subgame_count_list.length;ff++)
        {
            var ff_info = perday_enter_subgame_count_list[ff];
            var ff_itype = ff_info.itype;
            var ff_c= ff_info.c;
            var ff_d= ff_info.d;


            if(curday_union == ff_d && ff_c > 0)
            {
                var ff_perday:PerDayWanfaEnterCishu = new PerDayWanfaEnterCishu();
                ff_perday.ienterdayunion = ff_d;
                ff_perday.ienterdaycishu = ff_c;

                this.m_subgametype_perday_entered_gamed_cishu_map.putData(ff_itype,ff_perday);
            }
            
        }
 
 


        this.m_last_tiaoguo_gk_tick = ComFunc.Check_Read_Number(basic_obj.m_last_tiaoguo_gk_tick);
        if(this.m_last_tiaoguo_gk_tick > Date.now())
        {
            this.m_last_tiaoguo_gk_tick = 0;
        }
 

        if(basic_obj.m_continue_prev_game_left_count == undefined)
        {
            basic_obj.m_continue_prev_game_left_count = 5;
        }
        this.m_continue_prev_game_left_count = ComFunc.Check_Read_Number(basic_obj.m_continue_prev_game_left_count);
        if(this.m_continue_prev_game_left_count <= 0)
        {
            this.m_continue_prev_game_left_count = 0;
        }
  

        this.m_continue_prev_game_left_count = ComFunc.Check_Read_Number(basic_obj.m_continue_prev_game_left_count);
   
        this.m_lianxu_guangkan_wuxian_tili_video_count = ComFunc.Check_Read_Number(basic_obj.m_lianxu_guangkan_wuxian_tili_video_count);
        this.m_lianxu_guangkan_wuxian_tili_tick = ComFunc.Check_Read_Number(basic_obj.m_lianxu_guangkan_wuxian_tili_tick);
   
        this.m_lianxu_guangkan_wuxian_tili_48_huor_tick = ComFunc.Check_Read_Number(basic_obj.m_lianxu_guangkan_wuxian_tili_48_huor_tick);
        this.m_lianxu_guangkan_wuxian_48huor_tili_video_count = ComFunc.Check_Read_Number(basic_obj.m_lianxu_guangkan_wuxian_48huor_tili_video_count);
   

    }
    InitRead_Last_Save_Common_Server_Config()
    {
        
        var str = MyLocalStorge.getItem("shaonaomukuai_last_save_server_common_config", "");

        if(!str)
        {
            return;
        }
    
        var basic_obj = JSON.parse(str);
        if(!basic_obj)
        {
            return;
        }

        if(!basic_obj.bvalid)
        {
            return;
        }

        this.m_last_save_valid_common_config_remote_json = basic_obj;
       // console.log("m_last_save_valid_common_config_remote_json="+str);
    }
  
    Get_Cur_Valid_Server_Common_Config()
    {
        if(this.m_readed_game_common_config_remote_json)
        {
            if(this.m_readed_game_common_config_remote_json.bvalid)
            {
                return this.m_readed_game_common_config_remote_json;
            }
        }

        if(this.m_last_save_valid_common_config_remote_json)
        {
            if(this.m_last_save_valid_common_config_remote_json.bvalid)
            {
                return this.m_last_save_valid_common_config_remote_json;
            }
        }
        if(this.m_default_config)
        {
            return this.m_default_config;
        }
        return null;
    }

    On_Loaded_Server_Remote_Common_Config(remoteobj)
    {
        if(!remoteobj)
        {
            return;
        }

        var min_Valid_version = 1;
        if(remoteobj.min_valid_version )
        {
            min_Valid_version = remoteobj.min_valid_version;
        }

        if(min_Valid_version > PlatFormParaMng.GetInstance().Get_Cur_Version())
        {
            return;
        }

        var self = this;
        self.m_readed_game_common_config_remote_json =  remoteobj;

        if(self.m_readed_game_common_config_remote_json)
        {
            if(self.m_readed_game_common_config_remote_json.bvalid)
            {
                MyLocalStorge.setItem("shaonaomukuai_last_save_server_common_config",JSON.stringify(self.m_readed_game_common_config_remote_json))
            }
        }
    }


    Get_Global_Config_Server_Path()
    {
          
        var  config_json = PlatFormMng.GetInstance().Get_Global_Config_Server_Path();

        if(!config_json)
        {
            var irand11 = Math.floor(Math.random()*1000) ;
            config_json = "https://outercoms.zfgame123.com/config/naoli_heji/wx/naoli_heji_common_config.json?r="+irand11;

        }
  
        return config_json;
    }

    Load_Game_Common_Config(callback)
    {
       
        var irand11 = Math.floor(Math.random()*1000) ;
       // var config_json = "https://outercoms.zfgame123.com/config/shaonaomukuai/wx/shaonaomukuai_common_config.json?r="+irand11;

       var  config_json = this.Get_Global_Config_Server_Path();
 
        var self = this;
 
     
        cc.assetManager.loadRemote(config_json, (err, jobj:cc.JsonAsset) =>  
        {
            if(err)
            {
                self.m_readed_game_common_config_remote_json = null;
                callback();
                console.log("加载配置错误:"+err)
                return;
            }

            if(jobj.json)
            {
                self.On_Loaded_Server_Remote_Common_Config(jobj.json);

            }
         
         
           
            callback();
        });
      
    }


    Get_Game_Gk_Winned_Jiangli(igametype,igk,bfirstwin,igkwinnedcount)
    {
        var ijinbiadd = 5;
        var ixuanzhangadd = 0;
        if(bfirstwin)
        {
            ijinbiadd = 10;
            ixuanzhangadd = 5;

            if(igk%4 == 0   )
            {
                ijinbiadd += 10;
                ixuanzhangadd += 5;
            }
        }

        if(igkwinnedcount >= 5)
        {
            ijinbiadd = 1;
        
        }

        if(ixuanzhangadd > 0)
        {
           // return [{"t":1,"c":ijinbiadd},{"t":4,"c":ixuanzhangadd}];
        }

        return [{"t":1,"c":ijinbiadd}];

    }
    Get_GameType_GK_Guoguang_Count(isubgametype, ilevel)
    {
        var str = "shaonaomukuai_game_"+isubgametype+"_gk_"+ilevel+"_suc_c";
        var prevstr = MyLocalStorge.getItem(str,"");
        var ipevc = 0;
        if(prevstr)
        {
            ipevc = ComFunc.Check_Read_Number(prevstr);
        }
        return ipevc;
    }

    Add_Subgametype_Enterd_Cishu(isbugametype,iaddcc)
    {
        var prevcc = 0;
        if(this.m_subgametype_enter_gamed_cishu_map.hasKey(isbugametype))
        {
            prevcc = this.m_subgametype_enter_gamed_cishu_map.getData(isbugametype);
        }

        this.m_subgametype_enter_gamed_cishu_map.putData(isbugametype,prevcc + 1);

        
        var curdayuinon = ComFunc.GetCurDayUnion();


    //    console.log("Add_Subgametype_Enterd_Cishu curdayuinon ="+curdayuinon);

        var prev_day_enter_data:PerDayWanfaEnterCishu =  null;

        if(this.m_subgametype_perday_entered_gamed_cishu_map.hasKey(isbugametype))
        {
            var previnfo:PerDayWanfaEnterCishu = this.m_subgametype_perday_entered_gamed_cishu_map.getData(isbugametype);

            if(previnfo.ienterdayunion == curdayuinon)
            {
                prev_day_enter_data = previnfo;
            }
        }

        if(prev_day_enter_data)
        {
            prev_day_enter_data.ienterdaycishu++;
        }
        else{
            prev_day_enter_data = new PerDayWanfaEnterCishu();
            prev_day_enter_data.ienterdaycishu = 1;
            prev_day_enter_data.ienterdayunion = curdayuinon;

        }

        this.m_subgametype_perday_entered_gamed_cishu_map.putData(isbugametype,prev_day_enter_data);

        this.Save_Game_Basic_Info();
    }



    //获得配置的每个玩法最开始几次内不扣体力
    Get_Per_Game_First_Enter_Cishu_Nei_Bukou_Tili()
    {
        var idesfaultvalue = 3;
       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idesfaultvalue;
        }

        var per_game_first_enter_cishu_nei_bukou_tili = cur_valid_config.per_game_first_enter_cishu_nei_bukou_tili;
        if(!per_game_first_enter_cishu_nei_bukou_tili)
        {
            return idesfaultvalue;
        }

        if(per_game_first_enter_cishu_nei_bukou_tili > 0 && per_game_first_enter_cishu_nei_bukou_tili < 200)
        {
            return per_game_first_enter_cishu_nei_bukou_tili;
        }

        return idesfaultvalue;
    }



    Get_Max_Tili()
    {
        var idefaultv = 60;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var dating_tili_max = cur_valid_config.dating_tili_max;
        if(!dating_tili_max)
        {
            return idefaultv;
        }

        if(dating_tili_max > 0)
        {
            return dating_tili_max;
        }

        return idefaultv;
    }
    Get_Self_DestType_Daoju_Count(itype){
        
        var inewcc = 0;
        if(this.m_all_in_bag_daoju_type_leftcount_map.hasKey(itype)){
            var icc = this.m_all_in_bag_daoju_type_leftcount_map.getData(itype);
            return icc;
        }
        else{

         
            if(itype == 3)
            {
                //体力
                inewcc = this.Get_Max_Tili();
            }

            this.m_all_in_bag_daoju_type_leftcount_map.putData(itype,inewcc);
        }



        return inewcc;
    }
    Get_GameSuc_Dlg_Dealy_Show_Btn_Sec()
    { 
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_delay_show_btn_sec = cur_valid_config.gamesuc_dlg_delay_show_btn_sec;
        if(gamesuc_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_delay_show_btn_sec;
    }

    IS_All_Paihangbang_Hide()
    {

        var idefaultv = 1;
       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var all_paihangbang_hide = cur_valid_config.all_paihangbang_hide;
        if(all_paihangbang_hide == undefined)
        {
            return idefaultv;
        }

        return all_paihangbang_hide;
    }
    IS_All_Tili_Hide()
    { 
     
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return false;
        }
        var dating_tili_hide_all = cur_valid_config.dating_tili_hide_all;

        if(dating_tili_hide_all == undefined)
        {
            return false;
        }

        if(dating_tili_hide_all > 0)
        {
            return true;
        }

        return false;
    }

    Get_Tili()
    {
        return this.Get_Self_DestType_Daoju_Count(3);
    }

    Get_Game_Type_Name(igametype)
    {
        if(igametype == 1)
        {
            return  "滑木块 简单模式";
        }
        
        
        if(igametype == 2)
        {
            return  "移箱子";
        }
     
        if(igametype == 3)
        {
            return  "推箱子";
        }
        

        if(igametype == 4)
        {
            return  "木室逃亡";
        }


        if(igametype == 5)
        {
            return  "数字华容道";
        }

        if(igametype == 21)
        {
            return  "三消消";
        }

        if(igametype == 23)
        {
            return  "密室逃脱";
        }
        
        if(igametype == 61)
        {
            return  "螺丝排序";
        }
        

        if(igametype == 62)
        {
            return  "螺丝合成";
        }
        

        if(igametype == 63)
        {
            return  "打螺丝";
        }
        


        if(igametype >30 && igametype < 40)
        {
            return  "花朵消消";
        }

        if(igametype >100 && igametype < 120)
        {
            return  "数字华容道";
        }


        if(igametype >130 && igametype < 150)
        {
            var inandu = igametype- 130;
            return  "滑木块 "+GlobalData.GetInstance().Get_Nandu_Str(inandu)+"模式";
        }


        return "";
    }
    //观看获得无限体力视频一次
    On_Watch_Lianxu_Wuxian_Tili_Video_Suc()
    {
        this.m_lianxu_guangkan_wuxian_tili_video_count++;

        if(this.m_lianxu_guangkan_wuxian_tili_video_count >= 3)
        {
            this.m_lianxu_guangkan_wuxian_tili_video_count = 0;
            this.Add_Tili(this.Get_Max_Tili());
            this.m_lianxu_guangkan_wuxian_tili_tick = Date.now();
        }

        this.Save_Game_Basic_Info();
    }



    Get_Gamesuc_Dlg_Default_Gouxuan()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }
            return idefaultv;
        }
        if(this.In_Shenhe())
        {
            return 0;
        }
        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;

        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }
   
        var gamesuc_dlg_default_gouxuan = gamesuc_dlg_video_config.gamesuc_dlg_default_gouxuan;
        if(gamesuc_dlg_default_gouxuan == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_default_gouxuan;
    }

    Get_Gamesuc_Dlg_Use_Default_Menu_Type()
    {
        var idefaultv = 2;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }
            return idefaultv;
        }

        if(this.In_Shenhe())
        {
            return 2;  
        }
        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;
        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }



        var gamesuc_dlg_default_use_menu_type = gamesuc_dlg_video_config.gamesuc_dlg_default_use_menu_type;
        if(gamesuc_dlg_default_use_menu_type == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_default_use_menu_type;
    }

     //得到服务器配置游戏场底部应该显示的banenr还是格子
     Get_Game_Scence_Next_Bottom_Banner_Type(isubgametypw)
     {
         //默认显示格子
          
 
         var idefaultv = 2;
 
         var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
         if(!cur_valid_config)
         {
             return idefaultv;
         }
 
         var game_inner_bottom_show_banner_or_gezi_type =  cur_valid_config.game_inner_bottom_show_banner_or_gezi_type;
 
         if(game_inner_bottom_show_banner_or_gezi_type == 1)
         {
             return 1;
         }
 
         if(game_inner_bottom_show_banner_or_gezi_type == 2)
         {
             return 2;
         }
 
         //3:格子和banner交替出现
         if(game_inner_bottom_show_banner_or_gezi_type == 3)
         {
             return 3;
         }
 
 
         //随机切换
         var prevtype=  0;
         if(this.m_subgametype_last_show_banner_type_map.hasKey(isubgametypw))
         {
             prevtype=  this.m_subgametype_last_show_banner_type_map.getData(isubgametypw);
         }
 
         if(prevtype == 2)
         {
             this.m_subgametype_last_show_banner_type_map.putData(isubgametypw,1);
             return 1;
         }
 
         this.m_subgametype_last_show_banner_type_map.putData(isubgametypw,2);
         return 2;
     }
    Get_LongTime_Not_Play_Can_Add_Max_Tili()
    {
        var idefaultv = 60;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var longtime_not_play_can_add_max_tili = cur_valid_config.longtime_not_play_can_add_max_tili;

        console.log("longtime_not_play_can_add_max_tili = "+longtime_not_play_can_add_max_tili)
        if(longtime_not_play_can_add_max_tili == undefined)
        {
            return idefaultv;
        }

        if(longtime_not_play_can_add_max_tili > 0)
        {
            return longtime_not_play_can_add_max_tili;
        }

        return idefaultv;
    }

    IS_Game_Fail_Dlg_FanhuiDating_Need_Queren()
    { 
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return 1;
        }

        if(cur_valid_config.game_fail_dlg_need_fanhuidating_confirm  == 0)
        {
            return 0;
        }

        return 1;
    }
    Start_CountDown_Add_Tili()
    {

        if(this.m_first_tili_inited_countdowned)
        {
            return;
        }

        this.m_first_tili_inited_countdowned  = true;
        var last_tili_info = MyLocalStorge.getItem("shaonaomukuai_last_save_tili_info");
        if(!last_tili_info)
        {
            return;
        }
        var obj = JSON.parse(last_tili_info);

        if(!obj)
        {
            return;
        }

        var last_count_down_tili_tick = ComFunc.Check_Read_Number(obj.last_count_down_tili_tick) ;
   
        if(last_count_down_tili_tick == 0 ||   isNaN(last_count_down_tili_tick))
        {
            return;
        }
        var iepalsetick = Date.now() - last_count_down_tili_tick;
        var permintue_tick = 60*1000;

        if(iepalsetick > permintue_tick)
        {
            var ieplase_min = Math.floor(iepalsetick/permintue_tick);

          
            if(ieplase_min <= 0)
            {
                ieplase_min = 0;
            }

            var ineedaddtili = ieplase_min;

            var config_can_add_tili_max=  this.Get_LongTime_Not_Play_Can_Add_Max_Tili();
            if(ineedaddtili > config_can_add_tili_max && config_can_add_tili_max > 0)
            {
                ineedaddtili = config_can_add_tili_max;
            }
         
            this.Add_Tili(ineedaddtili);

            this.Save_Til_iInfo();

            this.Save_Game_Basic_Info();

            console.log("Start_CountDown_Add_Tili ieplase_min = "+ieplase_min+",config_can_add_tili_max="+config_can_add_tili_max+",ineedaddtili="+ineedaddtili)

        }

    }
    Record_User_Stay_In_Subgame_Sec(prev_gametype,istaysec)
    {
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(25 , "记录游戏玩法停留时长", prev_gametype,
        "", istaysec, istaysec+"秒", 0, "",   null);
    }
    Get_Game_Inner_Bottom_Gezi_Or_banner_Type3_Change_Sec()
    {
        var idefaultv = 35;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var game_inner_bottom_gezi_or_banner_type3_change_sec = cur_valid_config.game_inner_bottom_gezi_or_banner_type3_change_sec;
        if(!game_inner_bottom_gezi_or_banner_type3_change_sec)
        {
            return idefaultv;
        }

        if(game_inner_bottom_gezi_or_banner_type3_change_sec > 0)
        {
            return game_inner_bottom_gezi_or_banner_type3_change_sec;
        }

        return idefaultv;
    }
    IS_InGamePlay_Time_Can_Add_Tili()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var ingame_play_time_can_add_tili = cur_valid_config.ingame_play_time_can_add_tili;
        if(ingame_play_time_can_add_tili == undefined)
        {
            return idefaultv;
        }

     
        return ingame_play_time_can_add_tili;
    }
    //判断服务器配置游戏场内格子或者banner是否应该挨着底部
    IS_Game_Scence_Bottom_Banner_Align_Bottom(ibannertype)
    {
        

        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        if(ibannertype == 1)
        {
            //banner
            var game_inner_bottom_banner_pos_align_bottom = cur_valid_config.game_inner_bottom_banner_pos_align_bottom;

            if(game_inner_bottom_banner_pos_align_bottom == 1)
            {
                return 1;
            }

            return game_inner_bottom_banner_pos_align_bottom;
        }else{
            //格子

            var game_inner_bottom_gezi_pos_align_bottom = cur_valid_config.game_inner_bottom_gezi_pos_align_bottom;

            if(game_inner_bottom_gezi_pos_align_bottom == 1)
            {
                return 1;
            }

            return game_inner_bottom_gezi_pos_align_bottom;
        }

    

        return 0;
    }
    //明确控制banner是否自动刷新
    IS_Server_JingQue_Kongzhi_Banner_Need_Auto_Shuaxin(ibannerindex)
    {

        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return  [0,0];
        }

         //直接id配置是否需要刷新
         var banner_id_autoshuaxin = cur_valid_config.banner_id_autoshuaxin;

         if(!banner_id_autoshuaxin)
         {
            return [0,0];
         }
         if(banner_id_autoshuaxin && banner_id_autoshuaxin.length > 0)
         {
             for(var ff=0;ff<banner_id_autoshuaxin.length;ff++)
             {
                 var ff_sub_arr = banner_id_autoshuaxin[ff];
                 if(ff_sub_arr.length == 2)
                 {
                     var ff_bannerid = ff_sub_arr[0];
                     var ff_banner_need_auto_shuaxin = ff_sub_arr[1];
 
                     if(ff_bannerid == ibannerindex)
                     {
                        return [1, ff_banner_need_auto_shuaxin];
                     }
                 }
             }
         }
 
         return [0,0];
    }
    //banner是否需要自动刷新
    Check_Banner_Need_Zidong_Shuaxin(ibannerindex,ibanenrtype)
    {

       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return  false;
        }

       

        if(ibanenrtype == 2)
        {
            var gezi_need_zidong_shuaxin = cur_valid_config.gezi_need_zidong_shuaxin;

            if(!gezi_need_zidong_shuaxin)
            {
                gezi_need_zidong_shuaxin = 0;
            }

            return gezi_need_zidong_shuaxin;
        }

        var banner_need_zidong_shuaxin = cur_valid_config.banner_need_zidong_shuaxin;

        if(!banner_need_zidong_shuaxin)
        {
            banner_need_zidong_shuaxin = 0;
        }

        return banner_need_zidong_shuaxin;
    }

    Save_Til_iInfo()
    {
        var obj  = {
            m_tili_countdown_start_tick:this.m_tili_countdown_start_tick,
            m_tili_countdown_start_Left_count:this.m_tili_countdown_start_Left_count,
            last_count_down_tili_tick:Date.now()
        };


        MyLocalStorge.setItem("shaonaomukuai_last_save_tili_info",JSON.stringify(obj));
    }
    Get_Continue_Prev_Game_Left_Count()
    {
        return this.m_continue_prev_game_left_count;
    }

    Change_Continue_Prev_Game_Left_Count(ichangecount)
    {
        this.m_continue_prev_game_left_count += ichangecount;

        if(this.m_continue_prev_game_left_count <= 0)
        {
            this.m_continue_prev_game_left_count  = 0;
        }
        this.Save_Game_Basic_Info();
    }
   
    Count_Down_Add_Tili()
    {
        var itili = this.Get_Tili();
        var imaxtili = this.Get_Max_Tili();
        if(itili >= imaxtili)
        {
            if(this.m_tili_countdown_start_tick > 0)
            {
             
                MyLocalStorge.removeItem("shaonaomukuai_last_save_tili_info");
            }

            this.m_tili_countdown_start_tick = 0;
            this.m_tili_countdown_start_Left_count = 0;

        }
        else{

            if(this.m_tili_countdown_start_tick  == 0)
            {
                this.m_tili_countdown_start_tick  = Date.now();
                this.m_tili_countdown_start_Left_count = 60;

                this.Save_Til_iInfo();
            }

            var ieplsetick = Date.now() - this.m_tili_countdown_start_tick;
            var isec=  Math.floor(ieplsetick/1000);
            var ileftsec = this.m_tili_countdown_start_Left_count - isec;

            if(ileftsec <= 0)
            {
                this.m_tili_countdown_start_tick  = Date.now();
                this.m_tili_countdown_start_Left_count = 60;
                this.Add_Tili(1);

                this.Save_Til_iInfo();
                this.Save_Game_Basic_Info();
            }

        }

    }
    //游戏暂停弹框返回大厅是否需要确定弹框--默认情况下都是需要的
    IS_Game_Pause_Dlg_FanhuiDating_Need_Queren()
    {
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return 1;
        }
    

        if(cur_valid_config.game_pause_dlg_need_fanhuidating_confirm  == 0)
        {
            return 0;
        }

        return 1;
    }
    Get_Gamesuc_Dlg_First_Gouxuan_Need_Min_GK()
    {
        var idefaultv = 4;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;

        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }

    
        var gamesuc_dlg_first_check_min_gk = gamesuc_dlg_video_config.gamesuc_dlg_first_check_min_gk;
        if(gamesuc_dlg_first_check_min_gk == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_first_check_min_gk;
    }
    Get_Game_Suc_Dlg_Auto_Uncheck_Gouxuan_Type()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        if(this.In_Shenhe())
        {
            return 0;
        }

        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;

        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }

    
        var aotu_uncheck_gouxuan_type = gamesuc_dlg_video_config.aotu_uncheck_gouxuan_type;
        if(aotu_uncheck_gouxuan_type == undefined)
        {
            return idefaultv;
        }

        return aotu_uncheck_gouxuan_type;
    }
    Get_Game_Suc_Dlg_Minsec_Jiange_From_Last_Watch_Video()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;

        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }

    
        var minsec_jiange_from_last_watch_video_default_check = gamesuc_dlg_video_config.minsec_jiange_from_last_watch_video_default_check;
        if(minsec_jiange_from_last_watch_video_default_check == undefined)
        {
            return idefaultv;
        }

        return minsec_jiange_from_last_watch_video_default_check;
    }
    Get_GameFail_Dlg_Need_Show_Continue_Next_Dlg()
    {
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamefail_dlg_need_show_continue_next_dlg = cur_valid_config.gamefail_dlg_need_show_continue_next_dlg;
        if(gamefail_dlg_need_show_continue_next_dlg == undefined)
        {
            return idefaultv;
        }

        return gamefail_dlg_need_show_continue_next_dlg;
    }
    Get_GameBottom_ChaogaoPing_Need_Show_Juzhen_Gezi()
    {
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var all_game_bottom_chaogaoping_show_juzhen_gezi = cur_valid_config.all_game_bottom_chaogaoping_show_juzhen_gezi;
        if(all_game_bottom_chaogaoping_show_juzhen_gezi == undefined)
        {
            return idefaultv;
        }

        return all_game_bottom_chaogaoping_show_juzhen_gezi;
    }
    Get_Gamesuc_Dlg_Next_Gouxuan_Type()
    {
        var idefaultv = 2;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }

            return idefaultv;
        }
        if(this.In_Shenhe())
        {
            return 0;
        }
        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;
      
        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }



        var gamesuc_dlg_next_gouxuan_type = gamesuc_dlg_video_config.gamesuc_dlg_next_gouxuan_type;
        if(gamesuc_dlg_next_gouxuan_type == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_next_gouxuan_type;
    }

    

    //2:有全部购买48小时的,其他默认只有普通购买体力
    Get_Dating_Tili_Show_Goumai_Dlg_Type()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var dating_tili_show_goumai_dlg_type = cur_valid_config.dating_tili_show_goumai_dlg_type;
        if(dating_tili_show_goumai_dlg_type == undefined)
        {
            return idefaultv;
        }

        return dating_tili_show_goumai_dlg_type;
    }

    Get_Gamesuc_Dlg_ReCheck_Gouxuan_Need_GK()
    {
        var idefaultv = 3;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;

        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }
    
        var gamesuc_dlg_recheck_gouxuan_need_jiange_gk = gamesuc_dlg_video_config.gamesuc_dlg_recheck_gouxuan_need_jiange_gk;
        if(gamesuc_dlg_recheck_gouxuan_need_jiange_gk == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_recheck_gouxuan_need_jiange_gk;
    }
    Get_GameSuc_dlg_Com_Lignqu_Need_Show_GameLingqu_Dlg()
    {
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_com_lingqu_need_show_gamelingqu_dlg = cur_valid_config.gamesuc_dlg_com_lingqu_need_show_gamelingqu_dlg;
        if(gamesuc_dlg_com_lingqu_need_show_gamelingqu_dlg == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_com_lingqu_need_show_gamelingqu_dlg;
    }
      
    /*
    On_GameType_GK_Guoguang(isubgametype, ilevel)
    {
        var ipevc = this.Get_GameType_GK_Guoguang_Count(isubgametype, ilevel)
        var str = "shaonaomukuai_game_"+isubgametype+"_gk_"+ilevel+"_suc_c";
   
        ipevc +=1;
        MyLocalStorge.setItem(str,""+ipevc);
    }
    */
    On_GameType_GK_Guoguang(imode, isubgametype, ilevel)
    {
        var ipevc = this.Get_GameType_GK_Guoguang_Count(isubgametype, ilevel)
        var str = "shaonaomukuai_game_"+isubgametype+"_gk_"+ilevel+"_suc_c";
   
        ipevc +=1;
        MyLocalStorge.setItem(str,""+ipevc);
    }

    Get_Gamesuc_Dlg_Per_Game_Type_GouxuanBtn_Config(igametype)
    {
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return null;
        }

        var gamesuc_dlg_video_config =  cur_valid_config.gamesuc_dlg_video_config;

        if(!gamesuc_dlg_video_config)
        {
            return null;
        }

        if(this.In_Shenhe())
        {
            return null;
        }

        var gametype_rang_gouxuan_btn_conf =  gamesuc_dlg_video_config.gametype_rang_gouxuan_btn_conf;

        for(var ff=0;ff<gametype_rang_gouxuan_btn_conf.length;ff++)
        {
            var ff_info_arr = gametype_rang_gouxuan_btn_conf[ff];
            var ff_gamettpye_range = ff_info_arr[0];

            
            if(ff_info_arr.length >= 5  && ff_gamettpye_range.length == 2  )
            {
                var cmincx =  ff_gamettpye_range[0];
                var cmaxcx =  ff_gamettpye_range[1];


                if(cmincx <= igametype && igametype <= cmaxcx)
                {
                    return ff_info_arr;
                }
              
            }
        }
        return null;
    }

    Get_DaojuType_Show_Name(iawrdtype)
    {

        if(iawrdtype == 1)
        {
            return "金币";
        }

        if(iawrdtype ==3)
        {
            return "体力";
        }
        if(iawrdtype == 4)
        {
            return "勋章";
        }




        if(iawrdtype == 11)
        {
            return "重玩卡";
        }
        if(iawrdtype == 12)
        {
            return "跳关卡";
        }

        if(iawrdtype == 13)
        {
            return "自动提示卡";
        }
        if(iawrdtype == 14)
        {
            return "逐歩提示卡";
        }


        
        if(iawrdtype == 21)
        {
            return "提示";
        }
        if(iawrdtype == 22)
        {
            return "刷子";
        }

        if(iawrdtype == 23)
        {
            return "冰冻";
        }
        if(iawrdtype == 24)
        {
            return "刷新";
        }


        if(iawrdtype == 41)
        {
            return "伤害金币";
        }

        if(iawrdtype == 42)
        {
            return "伤害水晶";
        }


        if(iawrdtype == 61)
        {
            return "加孔位";
        }


 
        if(iawrdtype == 62)
        {
            return "砸玻璃";
        }


 
        if(iawrdtype == 63)
        {
            return "清空孔位";
        }
 
        if(iawrdtype == 66)
        {
            return "排序回撤";
        }


 
        if(iawrdtype == 67)
        {
            return "排序刷新";
        }


 
        if(iawrdtype == 68)
        {
            return "排序调整";
        }


 
    
        return "物品";
    }

    Get_Chaping_Min_Jiange_Sec()
    {
        var idefaultv = 30;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var chaping_min_show_jiange_sec = cur_valid_config.chaping_min_show_jiange_sec;
        if(chaping_min_show_jiange_sec == undefined)
        {
            return idefaultv;
        }

        return chaping_min_show_jiange_sec;
    }
    Get_Aawrd_Daoju_Icon(iawrdtype)
    {
        if(iawrdtype < 20)
        {
            return "daoju/com/"+iawrdtype;
        }

    
        if(iawrdtype >= 21 && iawrdtype <= 24 )
        {
            return "daoju/com/"+iawrdtype;
        }



        return "daoju/com/"+iawrdtype;
    }
    Get_GameSuc_LingquWuping_Dlg_Dealy_Show_Btn_Sec()
    { 
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_lingquwuping_dlg_delay_show_btn_sec = cur_valid_config.gamesuc_lingquwuping_dlg_delay_show_btn_sec;
        if(gamesuc_lingquwuping_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return gamesuc_lingquwuping_dlg_delay_show_btn_sec;
    }
    Get_Qiandao_Default_Gouxuan()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }
            return idefaultv;
        }

         
        if(this.In_Shenhe())
        {
            return 0;
        }


        var qiandao_dlg_default_gouxuan = cur_valid_config.qiandao_dlg_default_gouxuan;
        if(qiandao_dlg_default_gouxuan == undefined)
        {
            return idefaultv;
        }

        return qiandao_dlg_default_gouxuan;
    }


    //0:进程内弹出一次，1：每次都要弹出，2：在间隔gk后弹出
    Get_Qiandao_Dlg_Tachu_Type()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }
            return idefaultv;
        }


        var qiandao_dlg_tanchu_type = cur_valid_config.qiandao_dlg_tanchu_type;
        if(qiandao_dlg_tanchu_type == undefined)
        {
            return idefaultv;
        }

        return qiandao_dlg_tanchu_type;
    }
    
    Get_Shangcheng_Lianxu_Shiping_Goumai_Count_Need_Jiangli_C(idaoju_lianxu_count)
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var shangcheng_config = cur_valid_config.shangcheng_config;
        if(shangcheng_config == undefined)
        {
            return idefaultv;
        }
        var lianxureward = shangcheng_config.lianxureward;

        if(!lianxureward)
        {
            return idefaultv;
        }



        for(var ff=0;ff<lianxureward.length;ff++)
        {
            var ff_info = lianxureward[ff];
            var ff_t =  ff_info.t;
            var ff_c =  ff_info.c;

            if(ff_t == idaoju_lianxu_count)
            {
                return ff_c;
            }
        }

        return 0;
    }
    Get_Shangcheng_Bottom_Tip()
    {
        var idefaultv = "";
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var shangcheng_config = cur_valid_config.shangcheng_config;
        if(shangcheng_config == undefined)
        {
            return idefaultv;
        }


        var bottomtip = shangcheng_config.bottomtip;

        if(!bottomtip)
        {
            return idefaultv;
        }

        return bottomtip;
    }
    Get_ShouKan_Libao_Dlg_Dealy_Show_Btn_Sec()
    {
        var idefaultv = 1.2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var shoukanfuli_libao_dlg_delay_show_btn_sec = cur_valid_config.shoukanfuli_libao_dlg_delay_show_btn_sec;
        if(shoukanfuli_libao_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return shoukanfuli_libao_dlg_delay_show_btn_sec;
    }
    Get_FanhuiDating_Queren_Dlg_Dealy_Show_Btn_Sec()
    {
        var idefaultv = 1.2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var fanhuidating_queren_dlg_delay_show_btn_sec = cur_valid_config.fanhuidating_queren_dlg_delay_show_btn_sec;
        if(fanhuidating_queren_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return fanhuidating_queren_dlg_delay_show_btn_sec;
    }
    Get_Qiandao_Next_Gouxuan_Type()
    {
        var idefaultv = 2;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }

            return idefaultv;
        }
   
        if(this.In_Shenhe())
        {
            return 0;
        }


        var qiandao_dlg_next_gouxuan_type = cur_valid_config.qiandao_dlg_next_gouxuan_type;
        if(qiandao_dlg_next_gouxuan_type == undefined)
        {
            return idefaultv;
        }

        return qiandao_dlg_next_gouxuan_type;
    }
    //间隔几关
    Get_Qiandao_Dlg_Tachu_Per_GK()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var qiandao_dlg_tanchu_per_guangka = cur_valid_config.qiandao_dlg_tanchu_per_guangka;
        if(qiandao_dlg_tanchu_per_guangka == undefined)
        {
            return idefaultv;
        }

        return qiandao_dlg_tanchu_per_guangka;
    }
    Get_GameFail_Continue_ChongWan_Dlg_Dealy_Show_Btn_Sec()
    {
        var idefaultv = 1.2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamefail_continue_chongwan_dlg_delay_show_btn_sec = cur_valid_config.gamefail_continue_chongwan_dlg_delay_show_btn_sec;
        if(gamefail_continue_chongwan_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return gamefail_continue_chongwan_dlg_delay_show_btn_sec;
    }

    Get_GameFail_Dlg_Dealy_Show_Btn_Sec()
    { 
        var idefaultv = 2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamefail_dlg_delay_show_btn_sec = cur_valid_config.gamefail_dlg_delay_show_btn_sec;
        if(gamefail_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return gamefail_dlg_delay_show_btn_sec;
    }
    Get_Qiandao_Menu_Type()
    {
        var idefaultv = 2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }

            return idefaultv;
        }

        if(this.In_Shenhe())
        {
            return 2;
        }

        var qiandao_menu_type = cur_valid_config.qiandao_menu_type;
        if(qiandao_menu_type == undefined)
        {
            return idefaultv;
        }

        return qiandao_menu_type;
    }
    IS_GameSuc_Dlg_Tuijianwei_Show()
    {
        var idefaultv = 1;
  
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_tuijianwei_show = cur_valid_config.gamesuc_dlg_tuijianwei_show;
        if(gamesuc_dlg_tuijianwei_show == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_tuijianwei_show;
    }
    IS_GameFail_Dlg_Tuijianwei_Show()
    {
        var idefaultv = 1;
  
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamefail_dlg_tuijianwei_show = cur_valid_config.gamefail_dlg_tuijianwei_show;
        if(gamefail_dlg_tuijianwei_show == undefined)
        {
            return idefaultv;
        }

        return gamefail_dlg_tuijianwei_show;
    }
    IS_Game_Continue_Fail_Dlg_Tuijianwei_Show()
    {
        var idefaultv = 1;
  
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var game_continue_fail_dlg_tuijianwei_show = cur_valid_config.game_continue_fail_dlg_tuijianwei_show;
        if(game_continue_fail_dlg_tuijianwei_show == undefined)
        {
            return idefaultv;
        }

        return game_continue_fail_dlg_tuijianwei_show;
    }
    IS_Game_End_Lingqu_Dlg_Tuijianwei_Show()
    {
        var idefaultv = 1;
  
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var game_end_lingqu_dlg_tuijianwei_show = cur_valid_config.game_end_lingqu_dlg_tuijianwei_show;
        if(game_end_lingqu_dlg_tuijianwei_show == undefined)
        {
            return idefaultv;
        }

        return game_end_lingqu_dlg_tuijianwei_show;
    }
    //滑木块使用预定义关卡数目
    Get_Huamukuai_First_Use_Yudingyi_GK()
    {
        var idefaultv = 8;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var huamukuai_first_use_yudingyi_gk_c = cur_valid_config.huamukuai_first_use_yudingyi_gk_c;
        if(huamukuai_first_use_yudingyi_gk_c == undefined)
        {
            return idefaultv;
        }

        return huamukuai_first_use_yudingyi_gk_c;
    }
    Get_Sanxiaoxiao_GameFuhuo_Dlg_Dealy_Show_Btn_Sec()
    {
        var idefaultv = 1.2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var sanxiaoxiao_gamefuhuo_dlg_delay_show_btn_sec = cur_valid_config.sanxiaoxiao_gamefuhuo_dlg_delay_show_btn_sec;
        if(sanxiaoxiao_gamefuhuo_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return sanxiaoxiao_gamefuhuo_dlg_delay_show_btn_sec;
    }
    Get_Config_Process_FanhuiDating_Queren_Dlg_Mode()
    {
        var idefaultv = 2;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var fanhuidating_queren_dlg_mode = cur_valid_config.fanhuidating_queren_dlg_mode;
        if(fanhuidating_queren_dlg_mode == undefined)
        {
            return idefaultv;
        }
 

        return fanhuidating_queren_dlg_mode;
    }
    Get_Sanxiaoxiao_GoumaiDaoju_Dlg_Dealy_Show_Btn_Sec()
    {
        var idefaultv = 1.2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var sanxiaoxiao_goumaidaoju_dlg_delay_show_btn_sec = cur_valid_config.sanxiaoxiao_goumaidaoju_dlg_delay_show_btn_sec;
        if(sanxiaoxiao_goumaidaoju_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return sanxiaoxiao_goumaidaoju_dlg_delay_show_btn_sec;
    }
    Get_Cur_Process_FanhuiDating_Queren_Dlg_Mode()
    {
        if(this.m_cur_process_fanhuidating_queren_dlg_mode > 0)
        {
            return this.m_cur_process_fanhuidating_queren_dlg_mode;
        }
        var config_caidan_mode = this.Get_Config_Process_FanhuiDating_Queren_Dlg_Mode();

        if(!config_caidan_mode)
        {
            config_caidan_mode = 1;
        }
        this.m_cur_process_fanhuidating_queren_dlg_mode = config_caidan_mode;
        
        return this.m_cur_process_fanhuidating_queren_dlg_mode;
    }
    //判断是否应该屏蔽对应的格子
    Check_Banner_Index_Need_Pingbi(ibannerindex)
    {
        var idefaultv = 0;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var banner_gezi_need_pingbi_id_list = cur_valid_config.banner_gezi_need_pingbi_id_list;
        if(banner_gezi_need_pingbi_id_list == undefined)
        {
            return idefaultv;
        }


        for(var ff=0;ff<banner_gezi_need_pingbi_id_list.length;ff++)
        {
            var ff_id = banner_gezi_need_pingbi_id_list[ff];
            if(ff_id == ibannerindex)
            {
                return 1;
            }
        }

        return idefaultv;
    }
    Get_Self_Reg_Tick()
    {

        return this.Check_Save_First_Reg_Tick();
    }
    Check_Save_First_Reg_Tick()
    {
        

         var self_reg_tick = Date.now();

        var bprevsaved = false;
        var prev_reg_day = 0;
        var reg_day_info = MyLocalStorge.getItem("shaonaomukuai_reg_tick");
        var jobj = null;
        if(reg_day_info)
        {
            try{
                jobj = JSON.parse(reg_day_info);
            }catch(e)
            {}
            
            if(jobj)
            {
                var reg_day_tick =  jobj.reg_day_tick;
                if(reg_day_tick && reg_day_tick > 0 )
                {
                    bprevsaved = true;
                 
                    self_reg_tick = reg_day_tick;
                }
            }
        }

        if(!bprevsaved)
        {
            var obj = {reg_day_tick:self_reg_tick};
            

            MyLocalStorge.setItem("shaonaomukuai_reg_tick",JSON.stringify(obj));
        }else{
 

        }

      
        return self_reg_tick;
    }


    Common_Add_Award_List(awarddaoju,ibeishu)
    {
        for(var ff=0;ff<awarddaoju.length;ff++){
            var ff_info =  awarddaoju[ff];
            var ff_t = ff_info.t;
            var ff_c = ff_info.c  ;
             var icount=  ff_c*ibeishu;

            if(ff_t < 10)
            {
                this.Change_Self_DaojuType_Count(ff_t,icount);
                this.Save_Game_Basic_Info();

            }
            else  
            {
                //

                if(ff_t == 11)
                {
                    GlobalMng.GetInstance().Change_ChongwanKa_Count(icount);
                } 
                else if(ff_t == 12)
                {
                    GlobalMng.GetInstance().Add_TiaoGuangKa_Count(icount);
                }else if(ff_t == 13)
                {
                    GlobalMng.GetInstance().Add_XiaoTishiKa_Count(icount);
                }else if(ff_t == 14)
                {
                    GlobalMng.GetInstance().Add_DaTishiKa_Count(icount);
                }

                

            }




        }
    }

    Common_Get_Daoju_Count(itype)
    {
        
        if(itype == 11)
        {
            return GlobalMng.GetInstance().Get_Chongwan_Ka_Count();
        }

        if(itype == 12)
        {
            return GlobalMng.GetInstance().GetTiaoGuangKaCount();
        }

        if(itype == 13)
        {
            return GlobalMng.GetInstance().GetXiaoTishiKaCount();
        }


        if(itype == 14)
        {
            return GlobalMng.GetInstance().GetDaTishiKaCount();
        }



         return this.Get_Self_DestType_Daoju_Count(itype);
       
    }

    Get_GameType_Shouci_Libao_Delay_Pop_Sec(isubgametype)
    {
        var idesfaultvalue = 1;
       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idesfaultvalue;
        }

        
        var range_gametype_shouci_libao_pop_delay_sec = cur_valid_config.range_gametype_shouci_libao_pop_delay_sec;


        for(var ff=0;ff<range_gametype_shouci_libao_pop_delay_sec.length;ff++)
        {
            var ff_info_arr  = range_gametype_shouci_libao_pop_delay_sec[ff];

            var gfametype_range = ff_info_arr[0] ;

            if(gfametype_range.length == 2 && ff_info_arr.length >= 2)
            {
                if(gfametype_range[0] <= isubgametype && isubgametype <= gfametype_range[1])
                {
                    return ff_info_arr[1];
                }
            }
        }

        var per_gametype_shouci_libao_pop_delay_sec = cur_valid_config.per_gametype_shouci_libao_pop_delay_sec;


        for(var ff=0;ff<per_gametype_shouci_libao_pop_delay_sec.length;ff++)
        {
            var ff_info_arr  = per_gametype_shouci_libao_pop_delay_sec[ff];

            if(ff_info_arr[0] == isubgametype && ff_info_arr.length >= 2)
            {
                return ff_info_arr[1];
            }
        }
        return idesfaultvalue;
    }

    Get_Qiandao_Dlg_Dealy_Show_Btn_Sec()
    { 
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var qiandao_dlg_delay_show_btn_sec = cur_valid_config.qiandao_dlg_delay_show_btn_sec;
        if(qiandao_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return qiandao_dlg_delay_show_btn_sec;
    }
    IS_HMK_Need_Finger_Yingdao()
    {
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var hmk_need_finger_yingdao = cur_valid_config.hmk_need_finger_yingdao;
        if(hmk_need_finger_yingdao == undefined)
        {
            return idefaultv;
        }

        return hmk_need_finger_yingdao;
    }
    Get_Banner_Manual_Destroy_Config()
    {
        var idefaultv = [];
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var banner_manual_destroy_config = cur_valid_config.banner_manual_destroy_config;
        if(banner_manual_destroy_config == undefined)
        {
            return idefaultv;
        }

        return banner_manual_destroy_config;
    }
    Get_All_Banner_Gezi_Default_Shuaxin_Sec()
    {
        var idefaultv = 0;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var banner_gezi_all_default_shuaxin_sec = cur_valid_config.banner_gezi_all_default_shuaxin_sec;
        if(banner_gezi_all_default_shuaxin_sec == undefined)
        {
            return idefaultv;
        }

        return banner_gezi_all_default_shuaxin_sec;
    }
    Get_Huamukuai_Jiesuo_Nandu_Need_Shiping()
    {
        var idefaultv = 0;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var huamukuai_jiesuo_nandu_need_shiping = cur_valid_config.huamukuai_jiesuo_nandu_need_shiping;
        if(huamukuai_jiesuo_nandu_need_shiping == undefined)
        {
            return idefaultv;
        }

        return huamukuai_jiesuo_nandu_need_shiping;
    }
   
    Get_Config_Dating_Show_GameBtn_Caidan_Mode()
    {
        var idefaultv = 2;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var special_dating_gamebtn_caidan = cur_valid_config.special_dating_gamebtn_caidan;
   
        var cur_reg_day = this.Get_Self_Reg_Day();


        for(var ff=0;ff<special_dating_gamebtn_caidan.length;ff++)
        {
            var ff_info = special_dating_gamebtn_caidan[ff];

            if(ff_info.startday <= cur_reg_day && cur_reg_day <= ff_info.endday)
            {
                var ff_mdoe = ff_info.mode;

                return ff_mdoe;
            }
        }


        var dating_show_gamebtn_caidan_mode = cur_valid_config.dating_show_gamebtn_caidan_mode;
        if(dating_show_gamebtn_caidan_mode == undefined)
        {
            return idefaultv;
        }
 

        return dating_show_gamebtn_caidan_mode;
    }

    Get_Sanxiaoxiao_Daojutype_Per_Shiping_Goumai_Count(itype)
    {
        var idefaultv = 3;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var sanxiaoxiao_daojutype_pershiping_goumai_count = cur_valid_config.sanxiaoxiao_daojutype_pershiping_goumai_count;
        if(!sanxiaoxiao_daojutype_pershiping_goumai_count)
        {
            return idefaultv;
        }

        var icc  = 3;
        for(var ff=0;ff<sanxiaoxiao_daojutype_pershiping_goumai_count.length;ff++)
        {
            var ff_info = sanxiaoxiao_daojutype_pershiping_goumai_count[ff];

            var ff_t = ff_info.t;
            var ff_c = ff_info.c;

            if(ff_t == itype)
            {
                return ff_c;
            }

            if(ff_t == 0)
            {
                icc = ff_c;
            }
        }

        if(!icc)
        {
            icc = 3;
        }

        return icc;
    }
    Get_Cur_Process_Dating_Show_GameBtn_Caidan_Mode()
    {

        if(this.m_cur_process_dating_show_caidan_mode > 0)
        {
            return this.m_cur_process_dating_show_caidan_mode;
        }

        var config_caidan_mode = this.Get_Config_Dating_Show_GameBtn_Caidan_Mode();

       // var config_caidan_mode = this.Get_Config_Dating_Show_GameBtn_Caidan_Mode();

        if(!config_caidan_mode)
        {
            config_caidan_mode = 2;
        }
        this.m_cur_process_dating_show_caidan_mode = config_caidan_mode;
        
        return this.m_cur_process_dating_show_caidan_mode;
    }

    IS_First_Enter_Dating_Hide_Qiandao()
    {
        var idefaultv = 0;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }
        var first_enter_dating_hide_qiandao = cur_valid_config.first_enter_dating_hide_qiandao;
        if(!first_enter_dating_hide_qiandao)
        {
            first_enter_dating_hide_qiandao = 0;
        }

        return first_enter_dating_hide_qiandao;
    }
    Get_Game_Banner_Mng_Time_Config(igametype)
    {
        var idefaultv = 0.5;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        /*
        var speical_game_banner_mng_time_sec = cur_valid_config.speical_game_banner_mng_time_sec;

        if(speical_game_banner_mng_time_sec)
        {
            for(var ff=0;ff<speical_game_banner_mng_time_sec.length;ff++)
            {
                var ff_info  = speical_game_banner_mng_time_sec[ff];

                if(ff_info.i == igametype)
                {
                    var sec = ff_info.s;

                    if(sec && sec > 0)
                    {
                        return sec;
                    }
                }
            }
        }
  
        var all_game_banner_mng_time_sec_default = cur_valid_config.all_game_banner_mng_time_sec_default;
        if(all_game_banner_mng_time_sec_default == undefined)
        {
            return idefaultv;
        }
        */
       
        return idefaultv;
    }


    IS_ChaiPing_Type_Valid(ichaipingtype)
    {
        var idefaultv = 1;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var chaiping_valid_type_list = cur_valid_config.chaiping_valid_type_list;
        if(!chaiping_valid_type_list)
        {
            return idefaultv;
        }


        for(var ff=0;ff<chaiping_valid_type_list.length;ff++)
        {
            var ff_info = chaiping_valid_type_list[ff];
            var tarr = ff_info.tarr;
            var trange = ff_info.trange;
            var ff_c = ff_info.c;

            if(tarr && tarr.length > 0)
            {
                if(ComFunc.arrayShuzuContain(tarr,ichaipingtype))
                {
                    return ff_c;
                }
            }

            if(trange && trange.length >= 2)
            {
                var tr1 = trange[0];
                var tr2 = trange[1];

                if(tr1 <= ichaipingtype && ichaipingtype <= tr2)
                {
                    return ff_c;
                }
            }
        }

        return idefaultv;
    }

    Get_Enter_Game_Bk_Create_Gezi_List(isubgametype)
    {
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return [];
        }

        var enter_game_bk_create_gezi_list = cur_valid_config.enter_game_bk_create_gezi_list;
  

        var default_list = [];
        for(var ff=0;ff<enter_game_bk_create_gezi_list.length;ff++)
        {
            var ff_info  = enter_game_bk_create_gezi_list[ff];

            var ff_t = ff_info.t;
            var ff_l = ff_info.l;

            if(ff_t == isubgametype)
            {
                return ff_l;
            }

            if(ff_t == 0)
            {
                default_list = ff_l;
            }
        }

        if(!default_list)
        {
            default_list = [];
        }


        return default_list;
    }
    IS_Quanping_Gezi_Cahiping_Manual_Destroy_Need_Auto_ReCreate()
    {
        var idefaultv = 0;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var quanping_gezi_chaiping_config = cur_valid_config.quanping_gezi_chaiping_config;
        if(!quanping_gezi_chaiping_config == undefined )
        {
            return idefaultv;
        }

        var manual_deatroy_need_auto_recreate = quanping_gezi_chaiping_config.manual_deatroy_need_auto_recreate;
        if(manual_deatroy_need_auto_recreate == undefined)
        {
            return idefaultv;
        }

        return manual_deatroy_need_auto_recreate;
    }
    Get_Quanping_Gezi_Chaiping_Config()
    {
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return null;
        }
        var quanping_gezi_chaiping_config = cur_valid_config.quanping_gezi_chaiping_config;
  
        return quanping_gezi_chaiping_config;
    }

    In_Shenhe()
    {
        var idefaultv = 1;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }
        var in_shenhe_kg = cur_valid_config.in_shenhe_kg;
        if(in_shenhe_kg == 1)
        {
            return 1;
        }

        return 0;
    }
    IS_Watch_Video_Fail_Need_Show_Error_Lingqu_Dlg(i_watch_type)
    {
        var idefaultv = 0;
        /*
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        //审核开关打开，正在审核，不弹出
        if(this.In_Shenhe())
        {
            return 0;
        }

        var watch_video_fail_dlg = cur_valid_config.watch_video_fail_dlg;
        if(!watch_video_fail_dlg)
        {
            return idefaultv;
        }

        for(var ff=0;ff<watch_video_fail_dlg.length;ff++)
        {
            var ff_info  = watch_video_fail_dlg[ff];
            var ff_ntype = ff_info.ntype;

            if(ComFunc.Is_In_Arr_Range_Arr(ff_ntype,i_watch_type))
            {
                return 1;
            }
        }

        */
        return idefaultv;
    }
    Get_Watch_Video_Fail_Need_Show_Error_Lingqu_Dlg_Left_Sec(i_watch_type)
    {
        var idefaultv = 20;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var watch_video_fail_dlg = cur_valid_config.watch_video_fail_dlg;
        if(!watch_video_fail_dlg)
        {
            return idefaultv;
        }

        for(var ff=0;ff<watch_video_fail_dlg.length;ff++)
        {
            var ff_info  = watch_video_fail_dlg[ff];
            var ff_ntype = ff_info.ntype;
            var ff_sec = ff_info.sec;

            if(ComFunc.Is_In_Arr_Range_Arr(ff_ntype,i_watch_type))
            {
                return ff_sec;
            }
        }

        return idefaultv;

    }
    Is_Gametype_GK_Step_Need_Pop_Tishi_Dlg(isubgametype,ilevel,istep )
    { 
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        //审核开关打开，正在审核，不弹出 
        if(this.In_Shenhe())
        {
            return 0;
        }

        

        var auto_pop_use_step_tishi = cur_valid_config.auto_pop_use_step_tishi;
        if(!auto_pop_use_step_tishi)
        {
            return idefaultv;
        }





        for(var ff=0;ff<auto_pop_use_step_tishi.length;ff++)
        {
            var ff_info  = auto_pop_use_step_tishi[ff];

            var gtype_arr = ff_info.gtype;
            var gk_arr = ff_info.gk;

            var step_arr = ff_info.step;

            if(!ComFunc.Is_In_Arr_Range_Arr(gtype_arr,isubgametype))
            {
                continue;
            }

            if(!ComFunc.Is_In_Arr_Range_Arr(gk_arr,ilevel))
            {
                continue;
            }

            if(ComFunc.arrayShuzuContain(step_arr,istep))
            {
                return 1;
            }
        }
        return idefaultv;
    }
    Get_BannerIndex_Shuaxin_Sec(ibannerindex)
    { 

        var idefaultv = this.Get_All_Banner_Gezi_Default_Shuaxin_Sec();
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var banner_gezi_id_shuaxin_sec_list = cur_valid_config.banner_gezi_id_shuaxin_sec_list;
        if(banner_gezi_id_shuaxin_sec_list  )
        {
            for(var ff=0;ff<banner_gezi_id_shuaxin_sec_list.length;ff++)
            {
                var ff_arr = banner_gezi_id_shuaxin_sec_list[ff];
    
                if(ff_arr.length < 2)
                {
                    continue;
                }
    
                if(ff_arr[0] == ibannerindex)
                {
                    return ff_arr[1]
                }
            }
        }

         

        var banner_gezi_shuaxin_sec_list = cur_valid_config.banner_gezi_shuaxin_sec_list;
     
        if(banner_gezi_shuaxin_sec_list )
        {
            for(var ff=0;ff<banner_gezi_shuaxin_sec_list.length;ff++)
            {
                var ff_info  = banner_gezi_shuaxin_sec_list[ff];

                var ff_i = ff_info.i;
                var ff_s = ff_info.s;
            
             
                if(ComFunc.arrayShuzuContain(ff_i,ibannerindex))
                {
                   // console.log("ibannerindex="+ibannerindex+",ff_i="+ff_i+",ff_s="+ff_s);
                    return ff_s;
                }
            }
        }

        return idefaultv;
    }


    GameEnd_Pop_SuccessDlg_Delay_Sec(isubgametype)
    {
        var idefaultv = 4;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;
        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }

        var game_end_pop_success_dlg_dealy_sec = gamesuc_dlg_video_config.game_end_pop_success_dlg_dealy_sec;
        if(!game_end_pop_success_dlg_dealy_sec)
        {
            return idefaultv;
        }
        return game_end_pop_success_dlg_dealy_sec;

    }

    Get_Shouci_Libao_Config()
    {
        var idefaultv =  null;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var shoukan_libao_config = cur_valid_config.shoukan_libao_config;
        if(!shoukan_libao_config)
        {
            return idefaultv;
        }

        return shoukan_libao_config;
    }
    IS_GameEnd_Need_Pop_Animate(isubgametype)
    {
        var idefaultv = 1;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;
        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }

        var game_end_need_pop_animate = gamesuc_dlg_video_config.game_end_need_pop_animate;
        if(!game_end_need_pop_animate)
        {
            return idefaultv;
        }
        return game_end_need_pop_animate;
    }
    Get_Game_End_Aniamte_Dealy_Sec()
    {
        return 0.5;
    }

    
    Check_Chaoguo_Shenhe_Riqi()
    {
        var curdayuinn = ComFunc.GetCurDayUnion();

      //  console.log("Check_Chaoguo_Shenhe_Riqi curdayuinn="+curdayuinn)
        if(curdayuinn > PlatFormParaMng.GetInstance().m_xianding_tishen_fangkai_day)
        {
            console.log("过期 curdayuinn="+curdayuinn)
            return true;
        }

        return false;
    }

    Get_Choujiang_Config()
    {
        var defaultconfig =
        [ 
            {
                "sec":300,
                "jl":
                [
                {"t":11,"c":1}, {"t":12,"c":1}, {"t":13,"c":1}, {"t":14,"c":1}, {"t":1,"c":200}
                ]
            },
            {
                "sec":1200,
                "jl":
                [
                {"t":11,"c":1}, {"t":12,"c":1}, {"t":13,"c":1}, {"t":14,"c":1}, {"t":1,"c":200}
                ]
            }

         ]
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return defaultconfig;
        }

        var choujiang_config = cur_valid_config.choujiang_config;

        if(!choujiang_config)
        {
            return defaultconfig;
        }

        return choujiang_config;
    }
}