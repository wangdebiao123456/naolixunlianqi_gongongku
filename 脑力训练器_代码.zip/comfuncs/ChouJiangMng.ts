import MyLocalStorge from "../WDT/MyLocalStorge";
import ComFunc from "./ComFunc";
import GlobalGameMng from "./GlobalGameMng";

export default class ChouJiangMng
{
    static _instance:ChouJiangMng = null;
 
    static GetInstance() 
    {
        if (!ChouJiangMng._instance) {
            // doSomething
            ChouJiangMng._instance = new ChouJiangMng();
             
        }
        return ChouJiangMng._instance;
    }

    m_last_choujiang_day = 0;
    m_last_choujiang_day_choujiang_cihsu = 0;

    m_update_eplse_last_choujiang_sec = 0;


    m_last_save_tick = 0;

    constructor()
    {

        this.InitRead_Last_Choujiang_Info();
    }

    Common_Choujiang()
    {
        
        if(this.m_last_choujiang_day != ComFunc.GetCurDayUnion())
        {
            this.m_last_choujiang_day = ComFunc.GetCurDayUnion();
            this.m_last_choujiang_day_choujiang_cihsu = 0;
        }

        this.m_last_choujiang_day_choujiang_cihsu++;
        this.m_update_eplse_last_choujiang_sec= 0 ;
        this.Save_Choujiang_Info();

    }
    Save_Choujiang_Info()
    {
        var pobj = 
        {
            cjday:this.m_last_choujiang_day,
            cishu:this.m_last_choujiang_day_choujiang_cihsu,
            elapse_sec:this.m_update_eplse_last_choujiang_sec
        };

        MyLocalStorge.setItem("shaonaomukuai_choujiang_info",JSON.stringify(pobj));
        
    }
    InitRead_Last_Choujiang_Info()
    {
        var str =  MyLocalStorge.getItem("shaonaomukuai_choujiang_info");

        if(!str)
        {
            return;
        }

        var pobj = JSON.parse(str);
        if(!pobj)
        {
            return;
        }
         

        var cjday = pobj.cjday;

        
        var cishu = pobj.cishu;
        var elapse_sec = pobj.elapse_sec;
        
        this.m_last_choujiang_day = cjday;
        this.m_last_choujiang_day_choujiang_cihsu = cishu;
        this.m_update_eplse_last_choujiang_sec = elapse_sec;


    }
    On_Choujiang_Update_Dt(dt)
    {
        this.m_update_eplse_last_choujiang_sec += dt;

        if(Date.now() - this.m_last_save_tick > 1000)
        {
            this.m_last_save_tick = Date.now();
            this.Save_Choujiang_Info();
        }
    }
    Get_Choujiang_Jiangli()
    {
        var choujiang_info_config = GlobalGameMng.GetInstance().Get_Choujiang_Config();
        if(!choujiang_info_config)
        {
            return []
        }

        if(choujiang_info_config.length == 0)
        {
            return [];
        }
        var ilen = choujiang_info_config.length;

        if(this.m_last_choujiang_day != ComFunc.GetCurDayUnion())
        {
            this.m_last_choujiang_day = ComFunc.GetCurDayUnion();
            this.m_last_choujiang_day_choujiang_cihsu = 0;
        }

        var curday_choujiang_cishu = this.m_last_choujiang_day_choujiang_cihsu ;

        if(curday_choujiang_cishu >= ilen)
        {
            return [];
        }

        var dest_info = choujiang_info_config[curday_choujiang_cishu];

        if(!dest_info || !dest_info.sec)
        {
            return [];
        }

        var jl = dest_info.jl;

        return jl;

    }
    //返回[剩余抽奖次数,抽奖剩余时间]
    Get_Choujiang_Info()
    {
        var choujiang_info_config = GlobalGameMng.GetInstance().Get_Choujiang_Config();
        if(!choujiang_info_config)
        {
            return [0,0]
        }

        if(choujiang_info_config.length == 0)
        {
            return [0,0];
        }

        var ilen = choujiang_info_config.length;

        if(this.m_last_choujiang_day != ComFunc.GetCurDayUnion())
        {
            this.m_last_choujiang_day = ComFunc.GetCurDayUnion();
            this.m_last_choujiang_day_choujiang_cihsu = 0;
        }

        var curday_choujiang_cishu = this.m_last_choujiang_day_choujiang_cihsu ;

        if(curday_choujiang_cishu >= ilen)
        {
            return [0,0];
        }
        var dest_info = choujiang_info_config[curday_choujiang_cishu];

        if(!dest_info || !dest_info.sec)
        {
            return [0,0];
        }

        var ineedsec= dest_info.sec;


        if(this.m_update_eplse_last_choujiang_sec  >= ineedsec)
        {
            return [1,0];
        }

        var ileftsec=  Math.floor(ineedsec - this.m_update_eplse_last_choujiang_sec);
        return [1,ileftsec];
        
    }
    Get_Choujiang_Tip()
    {
        var choujiang_info_config = GlobalGameMng.GetInstance().Get_Choujiang_Config();
        if(!choujiang_info_config)
        {
            return "无抽奖";
        }

        if(choujiang_info_config.length == 0)
        {
            return "无抽奖";
        }

        var ilen = choujiang_info_config.length;

        if(this.m_last_choujiang_day != ComFunc.GetCurDayUnion())
        {
            this.m_last_choujiang_day = ComFunc.GetCurDayUnion();
            this.m_last_choujiang_day_choujiang_cihsu = 0;
        }

        var curday_choujiang_cishu = this.m_last_choujiang_day_choujiang_cihsu ;

        if(curday_choujiang_cishu >= ilen)
        {
            return "今日已抽完";
        }
        var dest_info = choujiang_info_config[curday_choujiang_cishu];

        if(!dest_info || !dest_info.sec)
        {
            return "无抽奖";
        }

        var ineedsec= dest_info.sec;


        if(this.m_update_eplse_last_choujiang_sec  >= ineedsec)
        {
            return "点击抽奖";
        }

        var ileftsec=  Math.floor(ineedsec - this.m_update_eplse_last_choujiang_sec);

        var strsec = ComFunc.FormatLeftSecStr(ileftsec);

        return strsec;

    }

}