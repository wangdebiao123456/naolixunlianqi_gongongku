 
import HttpUtil from "./MyHttpPostInfoUtil"; 
import MyLocalStorge from "../WDT/MyLocalStorge";
import PlatFormType from "../PlatForm/PlatFormType";
import PlatFormMng from "../PlatForm/PlatFormMng"; 
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";

 

export default class ClientLogUtils
{
    static _instance:ClientLogUtils = null;
    static GetInstance() 
    {
        if (!ClientLogUtils._instance) {
            // doSomething
            ClientLogUtils._instance = new ClientLogUtils();
             
        }
        return ClientLogUtils._instance;
    } 

    m_use_name = "";

    constructor() 
    {
    }
    newCreateGuid()
    {
        var guid = "";
        for (var i = 1; i <= 32; i++){
          var n = Math.floor(Math.random()*16.0).toString(16);
          guid +=   n;
          if((i==8)||(i==12)||(i==16)||(i==20))
            guid += "-";
        }
        return guid;    
    } 
    Get_PlatForm_Type()
    {
        return PlatFormMng.GetInstance().GetPlatFormType();
    }

    Get_Common_Saved_GUID()
    {
        var strguid = MyLocalStorge.getItem("shaonaomukuai_localguid");
        if(!strguid)
        {
            var newguid=  this.newCreateGuid();
            MyLocalStorge.setItem("shaonaomukuai_localguid",newguid);
            strguid = newguid;

        }  
        return strguid;
    }
    Get_Saved_GUID()
    {

        var strguid = PlatFormMng.GetInstance().Get_Saved_GUID();

        if(!strguid)
        {

            strguid = this.Get_Common_Saved_GUID()
        }
        
        return strguid;
         
    }
    Poset_Server_JS_Log( maintype,maintypeinfo,subtype, subtypeinfo,ivalue = 0,svalue="",ivalue2=0,svalue2="",callback = null)
    {
     
  
        try{
            var sguid=  this.Get_Saved_GUID();
            var iplatform = this.Get_PlatForm_Type();

            var sversion = PlatFormParaMng.GetInstance().m_version_str;
  
    
            var jsons = {sguid:sguid,iplatform:iplatform,maintype:maintype,maintypeinfo:maintypeinfo,subtype:subtype,
                subtypeinfo:subtypeinfo,ivalue:ivalue,svalue:svalue, ivalue2:ivalue2,svalue2:svalue2,sversion:sversion };
    
            var postdata = JSON.stringify(jsons);


            var irand = Math.floor(Math.random()*100);
    
            var urlp = "https://outercoms.zfgame123.com/Zhongzhuan_shaonaomukuai.aspx";

            // if(!cc.sys.isBrowser)
            {
                this.PostServerHTTPData(urlp,postdata,callback);
            }
          //  
        }catch(e)
        {}

  
    }

    PostServerHTTPData(urlp,postdata,callback)
    {
        
        
        HttpUtil.POSTData(urlp,postdata,callback)
    }

   

}