import PlatFormType from "../PlatForm/PlatFormType";  
import ClientLogUtils from "./ClientLogUtils";
 
import PlatFormMng from "../PlatForm/PlatFormMng";
import GlobalGameMng from "./GlobalGameMng";
import ComFunc from "./ComFunc";

 
 

export default class WatchVideoAdveseMng{

    static _instance:WatchVideoAdveseMng = null;
    static GetInstance() 
    {
        if (!WatchVideoAdveseMng._instance) {
            // doSomething
            WatchVideoAdveseMng._instance = new WatchVideoAdveseMng();
             
        }
        return WatchVideoAdveseMng._instance;
    }

    constructor()
    {

    }


    m_last_guangao_name=  "";
 
    m_b_playing_video = false;
    m_last_play_video_tick = 0;
    m_video = null;

    m_last_cb = null;
    m_last_arg = null;

    m_last_video_subtype = 0;

    m_b_reged_event = false;


    m_main_scence_node:cc.Node =  null;

    SetMainScenceNode(pnode:cc.Node)
    {
        this.m_main_scence_node = pnode;

    }

    InitRegWXEvent(calback)
    {
        if(this.m_b_reged_event)
        {
            this.m_b_reged_event = true;
        }
        
               
        /*
        wx.onShow(()=>
        {
            if(calback)
            {
                calback(1);
            }

        });

        wx.onHide(()=>
        {
            if(calback)
            {
                calback(0);
            }

        });
        */
    }
    OnVideoSuccessEnd()
    {
         

        if(this.m_last_cb)
        {
            this.m_last_cb(true, this.m_last_arg);

            this.m_last_cb = null;
            this.m_last_arg = null;
 
            ClientLogUtils.GetInstance().Poset_Server_JS_Log( 6144 ,"观看广告成功一次",
            this.m_last_video_subtype,
            this.m_last_guangao_name, 0, "",0,"");
 
        }
    }
    OnVideFailEnd(ierrorcode,errordesc)
    {



        if(this.m_last_cb)
        {
            this.m_last_cb(false, this.m_last_arg,ierrorcode,errordesc);

            this.m_last_cb = null;
            this.m_last_arg = null;


            if(ierrorcode == 0)
            {
                ClientLogUtils.GetInstance().Poset_Server_JS_Log( 6140 ,"观看广告退出",
                    this.m_last_video_subtype,
                    this.m_last_guangao_name, ierrorcode, "ierrorcode="+ierrorcode,0,""+errordesc);
            }else{
                ClientLogUtils.GetInstance().Poset_Server_JS_Log( 6141 ,"观看广告错误",
                    this.m_last_video_subtype,
                    this.m_last_guangao_name, ierrorcode, "ierrorcode="+ierrorcode,0,""+errordesc);
            }
           
        } 


    }
     

    GetSubTypeByName(sname,agv1)
    {
        var isubgametype=  agv1;

        if(sname == "超能力奖励")
        {
            return 1;
        }

        if(sname == "道具不足")
        {
            return 2;
        }


        if(sname == "游戏胜利双倍")
        {
            return 5000 + isubgametype;
        }


        if(sname == "钢材不足")
        {
            return 4;
        }

        if(sname == "金币不足")
        {
            return 5;
        }


        if(sname == "签到视频双倍")
        {
            return 6;
        }

        if(sname == "复活")
        {
            return 7;
        }

        if(sname == "卡牌不足")
        {
            return 8;
        }

        if(sname == "突破")
        {
            return 9;
        }
 

        if(sname == "钻石不足")
        {
            return 10;
        }


        if(sname == "增加解锁位置")
        {
            return 11;
        }

        if(sname == "商城购买礼包")
        {
            return 12;
        }

        if(sname == "商城购买钻石")
        {
            return 13;
        }


        if(sname == "商城购买钢材")
        {
            return 14;
        }

        if(sname == "商城购买金币")
        {
            return 15;
        }


        if(sname == "商城购买体力")
        {
            return 16;
        }


        if(sname == "获取游戏内金币")
        {
            return 17;
        }
        
        
        if(sname == "技能使用")
        {
            return 18;
        }
        if(sname == "体力不足购买体力")
        {
            return 19;
        }
        
        if(sname == "商城购买兵种技能卡牌")
        {
            return 20;
        }
          
        if(sname == "游戏技能使用")
        {
            return 21;
        }
        if(sname == "跳过本关")
        {
            return 22;
        }
        
        if(sname == "首看福利")
        {
            return 23;
        }
        if(sname == "购买技能仓库")
        {
            return 24;
        }
        if(sname == "视频解锁关卡")
        {
            return 25;
        }
        if(sname == "视频解锁华容道模式")
        {
            return 26;
        }
        

        if(sname == "购买继续游戏道具")
        {
            return 27;
        }
        
        if(sname == "普通购买体力")
        {
            return 28;
        }
        if(sname == "连续购买48小时体力")
        {
            return 29;
        }
        if(sname == "连续购买体力")
        {
            return 30;
        }
        
        if(sname == "签到双倍")
        {
            return 31;
        }
        if(sname == "视频解锁难度")
        {
            return 32;
        }


        if(sname == "领取首看礼包")
        {
            return 33;
        }

        if(sname == "购买道具")
        {
            return 34;
        }

        if(sname == "商城购买道具")
        {
            return 35;
        }

        if(sname == "三消消复活")
        {
            return 36;
        }

        if(sname == "购买三消消道具")
        {
            return 37;
        }
        if(sname == "三消消使用移除")
        {
            return 38;
        }
        
        if(sname == "弹出弹框购买道具")
        {
            return 41;
        }
        

        if(sname == "抽奖全要")
        {
            return 42;
        }
        
        
        
        return 0;
    }

    
    Get_Jiange_Sec_From_Last_Play_Video()
    {
        var ieplasetick = Date.now() - this.m_last_play_video_tick;
        var ierplasec= Math.floor(ieplasetick/1000)  ;
        return ierplasec;
    }
   



    Watch_Com_Guanggao_IF_Fail_Try_Self(pnode :cc.Node,show_watch_fail_dlg_callback :Function ,guanggaoname:string,cb:Function,agv = null,errorload_cb = null)
    {
       
        if(this.m_b_playing_video && Date.now() - this.m_last_play_video_tick < 3000)
        {

            PlatFormMng.GetInstance().showToast({
                title: "点击太频繁",
                icon: "error",
                duration: 1500
                });


                /*
            wx.showToast({
                title: "点击太频繁",
                icon: "error",
                duration: 1500
                });

                */


            return;
        }

        var self = this;
    
        var i_watch_type  = this.GetSubTypeByName(guanggaoname,agv);

        this.Watch_Com_Guanggao_ID(guanggaoname,
            (bsuc,ret_arg,ierrorcode,errordesc)=>
            {
                if(!bsuc)
                {

                    if(ierrorcode > 0)
                    {

                        var need_show_video_Fail_dlg = GlobalGameMng.GetInstance().IS_Watch_Video_Fail_Need_Show_Error_Lingqu_Dlg(i_watch_type);

                        if(need_show_video_Fail_dlg)
                        {
                            if(show_watch_fail_dlg_callback)
                            {
                                show_watch_fail_dlg_callback();
                            }

                            ComFunc.OpenNewDialog(pnode,"preab/common/watch_video_fail","watch_video_fail",
                                { 
                                    i_watch_type:i_watch_type,
                                    cb:(iret)=>
                                    {
                                        if(iret > 0)
                                        {
                                            cb(1,ret_arg,ierrorcode,errordesc);


                                            ClientLogUtils.GetInstance().Poset_Server_JS_Log( 6139 ,"视频失败处理领取",
                                                self.m_last_video_subtype,
                                                self.m_last_guangao_name, 0, "",0,"");

                                        }else{
                                            cb(bsuc,ret_arg,ierrorcode,errordesc);
                                        }
    
                                    }
    
                                }
                            );
                        }else{

                            cb(bsuc,ret_arg,ierrorcode,errordesc);
                        }

                        
                    }else
                    {
                        cb(bsuc,ret_arg,ierrorcode,errordesc);
                    }


                    return;
                } 


                cb(bsuc,ret_arg,ierrorcode,errordesc);
            },
            agv ,errorload_cb )

    }
    Watch_Com_Guanggao_ID(guanggaoname,cb,agv = null,errorload_cb = null)
    {
       
      
          
        this.m_last_guangao_name = guanggaoname;

      
        
        if(this.m_b_playing_video && Date.now() - this.m_last_play_video_tick < 3000)
        {
            /*
            wx.showToast({
                title: "点击太频繁",
                icon: "error",
                duration: 1500
                });


                */

                PlatFormMng.GetInstance().showToast({
                    title: "点击太频繁",
                    icon: "error",
                    duration: 1500
                    });
           // cb(false,agv,0,"");
            return;
        }
        var isubtype  = this.GetSubTypeByName(guanggaoname,agv);


        this.m_last_cb = cb;
        this.m_last_arg = agv;
        this.m_last_video_subtype = isubtype;


        this. m_b_playing_video = true;
        this.m_last_play_video_tick = Date.now();
        var self = this;

 

        PlatFormMng.GetInstance().Watch_Com_Guanggao_ID_B(guanggaoname,cb,errorload_cb,agv,
            (bsuc,ierrorcode,errordesc)=>
            {
                if(!bsuc)
                {
                    self.OnVideFailEnd(ierrorcode,errordesc);
                    return;
                }

                self.OnVideoSuccessEnd();
                
            });

       
             
    }
    
}