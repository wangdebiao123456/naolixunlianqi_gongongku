import MyLocalStorge from "../WDT/MyLocalStorge";
import BundleLoadUtils from "./BundleLoadUtils";
import ClientLogUtils from "./ClientLogUtils";

export default class PreLoadResMng
{
    static _instance:PreLoadResMng = null;
 
    static GetInstance() 
    {
        if (!PreLoadResMng._instance) {
            // doSomething
            PreLoadResMng._instance = new PreLoadResMng();
             
        }
        return PreLoadResMng._instance;
    }


    m_orianl_config_json = null;

    m_readed_preload_file_config_remote_json = null;
    m_last_save_valid_preload_file_config_remote_json = null;


    m_b_in_bk_loaded = false;

    m_init_load_call_bk = null;
    m_bk_all_need_loaded_res_count = 0;
    m_bk_all_has_loaded_res_count = 0;

    m_dating_scecnce_loaded = false;

    m_start_bk_load_tick = 0;

    constructor()
    {

        this.InitRead_Last_Save_Common_Server_Config();
    }


    Set_Origianl_Preload_File(psonobj)
    {
        this.m_orianl_config_json = psonobj;

        //console.log("orianljson = "+JSON.stringify(psonobj))

    }

    Get_Cur_Valid_Server_PreloadFile_Config()
    {
        
    }



    InitRead_Last_Save_Common_Server_Config()
    {
        
        
    }
    On_Loaded_Server_Remote_Common_Config(remoteobj)
    {
       
    }

    Load_Game_PreloadFile_Config(callback)
    {
       
    
      
    }
    On_All_Bk_Res_Load_Finished()
    {
       
        
    }

    Bk_Load_All_PreloadFile_Res_List(callback)
    {

   

        
    }
    Bunble_Load_Info_Perfile(bunblrnmae, bunlde:cc.AssetManager.Bundle, ff_filename_or_path,bdir,bwaitall)
    { 
    }
    Bunble_Load_Info(bunblrnmae, bunlde:cc.AssetManager.Bundle, file_list,bdir,bwaitall)
    {
         
    }

    
    Bunble_Pre_Load_Info_Perfile(bundlename, bunlde:cc.AssetManager.Bundle, ff_filename_or_path,bdir,bwaitall)
    {
        
    }
    Bunble_Pre_Load_Info(bundlename, bunlde:cc.AssetManager.Bundle, file_list,bdir,bwaitall)
    {

       
    }

    On_Bk_Loaded_Finish(ilen)
    {

  
 


    }

    Load_Info(ff_info)
    {
        
    }
    PreLoad_Info(ff_info)
    {
 

    }

    Dating_Check_Preload_File_Bk_Loaded()
    {
        

    }

    Dating_Check_Scence_PerLoaded()
    {
        
    }
}