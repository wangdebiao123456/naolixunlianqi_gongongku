

const { ccclass, property } = cc._decorator;

@ccclass
export default class linebuttom extends cc.Component {


    // onLoad () {}
    m_arry = null;
    m_index = null;
//    ran_arry = null;
  //  ran_heigh = null;
    heigh = 0;
    start() {
        this.getdata();
        this.fill();
    }
    fill() {
        var arry = this.m_arry;
        var a = this.m_index;
        var graphics = this.node.addComponent(cc.Graphics);
        graphics.strokeColor = cc.Color.GREEN;
        graphics.lineWidth = 15;
        var width = 90;
        var heigh = 40;
        graphics.clear(false);
        for (var ff = 0; ff < arry.length; ff++) {
            var is = false;
            var is_heigh = 0;
            if (ff == 0) {
                graphics.moveTo(-360 + ff * width, 640 - arry[ff] * heigh);
                this.heigh = arry[ff];
            } else {
                if (arry[ff] == this.heigh) {

                } else {
                    graphics.lineTo(-360 + ff * width, 640 - arry[ff] * heigh);
                }
                this.heigh = arry[ff];
            }
            graphics.lineTo(-360 + (ff + 1) * width, 640 - arry[ff] * heigh);
            graphics.stroke();
        }
    }
    getdata() {
        var pa = this.node.getParent();
        var parent = pa.getComponent("mishimask");
        this.m_arry = parent.inputm_arry();
        this.m_index = parent.inputm_index();
       // this.ran_arry = parent.inputran_arry();
      //  this.ran_heigh = parent.inputran_heigh();
    }
    update(dt) {
    }
}