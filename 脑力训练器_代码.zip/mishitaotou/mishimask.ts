

const { ccclass, property } = cc._decorator;

@ccclass
export default class mishimask extends cc.Component {
    @property(cc.Prefab)
    line: cc.Prefab = null;
    @property(cc.Prefab)
    linebut: cc.Prefab = null;
    // onLoad () {}
    m_arry = [];
    ran_arry = [];
    ran_heigh = [];
    m_index = 0;
    escape = 0;



    m_line_node:cc.Node = null;

    start() {

    }
    ClearAllPrev()
    {
        
        if(this.m_line_node)
        {
            this.m_line_node.destroy();
            this.m_line_node = null;
        }
        var mas = this.node.getComponent(cc.Mask);
        var graphics = mas['_graphics'];
 

        graphics.clear(true);
    }

    Move_Update()
    {
        var arry = this.m_arry;
        var a = this.m_index;
        var mas = this.node.getComponent(cc.Mask);
        var graphics = mas['_graphics'];
 

        graphics.clear(false);
        var width = 90;
        var heigh = 40;

        if (a == 0) {
            //上方 
            for (var ff = 0; ff < arry.length; ff++) {
                var is = false;
                var is_heigh = 0;
                for (var i = 0; i < this.ran_arry.length; i++) {
                    if (this.ran_arry[i] == ff) {
                        is = true;
                        is_heigh = this.ran_heigh[i];
                    }
                }
                if (is) {
                    graphics.rect(-360 + ff * width, -640, width, (arry[ff] + is_heigh) * heigh);
                } else {
                    graphics.rect(-360 + ff * width, -640, width, arry[ff] * heigh);
                }
                graphics.fill();
            }
        }
    }
    Refresh() {
        var arry = this.m_arry;
        var a = this.m_index;
        var mas = this.node.getComponent(cc.Mask);
        var graphics = mas['_graphics'];
        graphics.clear(false);
        var width = 90;
        var heigh = 40;

        if (a == 0) {
            //上方
            this.creatline(a);
            for (var ff = 0; ff < arry.length; ff++) {
                var is = false;
                var is_heigh = 0;
                for (var i = 0; i < this.ran_arry.length; i++) {
                    if (this.ran_arry[i] == ff) {
                        is = true;
                        is_heigh = this.ran_heigh[i];
                    }
                }
                if (is) {
                    graphics.rect(-360 + ff * width, -640, width, (arry[ff] + is_heigh) * heigh);
                } else {
                    graphics.rect(-360 + ff * width, -640, width, arry[ff] * heigh);
                }
                graphics.fill();
            }
        }
        if (a == 1) {
            //下方
            this.creatline(a);
            for (var ff = 0; ff < arry.length; ff++) {
                graphics.rect(-360 + ff * width, 640 - arry[ff] * heigh, width, arry[ff] * heigh);
                graphics.fill();
            }
        }
    }
    set_ran_arry(arry, heigh) {
        this.ran_arry = arry;
        this.ran_heigh = heigh;
    }
    set_mask(arry, a) {
        this.m_arry = arry;
        this.m_index = a;
        this.Refresh();
    }
    creatline(a) {
        

        if(this.m_line_node)
        {
            this.m_line_node.destroy();
            this.m_line_node = null;
        }


        if (a == 0) {
            let line = cc.instantiate(this.line);
            this.node.addChild(line);
            line.setPosition(0,0);
            this.m_line_node =  line;
            //line.y += 10;
            //line.x += 15;
        } else if(a==1) {
            let linee = cc.instantiate(this.linebut);
            this.node.addChild(linee);
            linee.setPosition(0,0);
            this.m_line_node =  linee;
            
        }else{

        }
        
    }
    get_arry() {
        return this.m_arry;
    }
    get_index() {
        return this.m_index;
    }
    inputm_arry() {
        return this.m_arry;
    }
    inputran_arry() {
        return this.ran_arry;
    }
    inputran_heigh() {
        return this.ran_heigh;
    }
    inputm_index() {
        return this.m_index;
    }
    //update (dt) {}
}