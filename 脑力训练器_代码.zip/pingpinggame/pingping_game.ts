import BaseUIUtils from "../comfuncs/BaseUIUtils";
import ComFunc from "../comfuncs/ComFunc";
import GlobalGameMng from "../comfuncs/GlobalGameMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";
import PlatFormType from "../PlatForm/PlatFormType";
import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
import NodeComPoolUtils from "../WDT/NodeComPoolUtils";
import { Utils } from "../WDT/Utils";
import WMap from "../WDT/WMap";
import huoqu_daoju_dlg from "./dlg/huoqu_daoju_dlg";
import GlobalConfig from "./GlobalConfig";
import pingping_game_date from "./pingping_game_date";

 
 

const {ccclass, property} = cc._decorator;

@ccclass
export default class pingping_game extends cc.Component {
 


    @property(cc.Prefab)
    shangcheng_dlg: cc.Prefab = null;


    @property(cc.Prefab)
    ping_desk: cc.Prefab = null;

    
    @property(cc.Prefab)
    ping_pengzi: cc.Prefab = null;

    
    @property(cc.Prefab)
    ping_dongwu: cc.Prefab = null;


    @property(cc.Prefab)
    move_star_node: cc.Prefab = null;

    
      
    @property(cc.Prefab)
    select_move_hua: cc.Prefab = null;

    
    @property(cc.Prefab)
    huaban_suikai: cc.Prefab = null;

 
    @property(cc.Prefab)
    gamefuhuo_dlg: cc.Prefab = null;

     


    @property(cc.Texture2D)
    huaduo_sprite_frame_list:cc.Texture2D[] = [];


    @property(cc.Texture2D)
    dongwu_sprite_frame_list:cc.Texture2D[] = [];



 
     
    @property(cc.Prefab)
    gamesuccess_new: cc.Prefab = null;

 
    @property(cc.Prefab)
    game_end_animate: cc.Prefab = null;

    

  
    @property(cc.Prefab)
    huoqu_daoju_dlg: cc.Prefab = null;


    
    @property(cc.Prefab)
    game_fail_new: cc.Prefab = null;
  
    @property(cc.Prefab)
    shouzhi: cc.Prefab = null;

    
    m_game_date:pingping_game_date = null;

    m_b_qiehuaned = 0;
    m_last_tishi_hua_v_list = [];

    m_last_effect_daojishi_sec = 0;
    m_panzi = null;
    
    m_game_ended = false;
    m_game_end_success = 0;

    m_fughuoed_count = 0;

    m_first_yd_shouzhi_node:cc.Node = null;
    m_first_yd_step = 1;


    m_last_skill_action_tick = 0;

    m_cur_gk_showed_jineng_qipao_tishi_jineng_map = new WMap();
    m_cur_gk_showed_jineng_qipao_type=  0;
    m_cur_jineng_show_eplaee_bushu_count = 0;

    m_last_show_jineng_qipao_tick = 0;


    m_last_user_do_action_tick = Date.now();
    m_game_start_tick = Date.now();


    m_cur_level  =1;
    m_enter_game_mdoe = 2;

    //10秒内消除另外一个算连击
    m_last_xiaochu_huaduo_tick = 0;
    m_xiaochu_huaduo_lianji_count = 0;


    m_game_banner_arr = [];
    
    onLoad () 
    {


        GlobalConfig.GetIns().m_pingping_dongwu_sprite_frame_list = this.dongwu_sprite_frame_list;

        
        GlobalConfig.GetIns().m_pingping_huaduo_sprite_frame_list = this.huaduo_sprite_frame_list;

 

        this.m_enter_game_mdoe = GlobalConfig.GetIns().m_enter_mode;
        this.m_cur_level = GlobalConfig.GetIns().m_enter_mode_gk;

        this.m_game_date = new pingping_game_date(this,this.node);
        this.m_game_date.Init_All_Info();

        var cool_col_progress_node = cc.find("menu/3/col_progress",this.node);
        cool_col_progress_node.getComponent(cc.Sprite).fillRange = 0;
        
        var movehua = cc.find("center/movehua",this.node);
        var move_hua_node = cc.instantiate(this.select_move_hua);
        movehua.addChild(move_hua_node,10);
        move_hua_node.active = false;
        this.m_game_date.Set_Select_Move_Hua_Node(move_hua_node);


        var sztn = cc.find("toptiao/sztn",this.node);
        sztn.on("click",this.OnBtnBackToHall.bind(this));
 
    
        var info_node = cc.find("qipaitishi/info",this.node);
        info_node.active = false;

        var lianjitishi_info_node = cc.find("lianjitishi/info",this.node);

        lianjitishi_info_node.active = false;

        var bk = cc.find("bk",this.node);
        this.m_panzi = bk;


     
        bk.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        bk.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        bk.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        bk.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
     

        for(var ff=1;ff<=4;ff++)
        {
            var ff_menu = cc.find("menu/"+ff,this.node);
            ff_menu.on("click",this.OnBtnMenu.bind(this,ff))

        }




        this.On_Game_Enter_Event();

        this.Refresh_Info();

        BackGroundSoundUtils.GetInstance().playBackgroundMusic("huaduoppingping/beijing",0.5);

        this.schedule(this.FD_Timer.bind(this),0.5);

        if((GlobalConfig.GetIns().m_enter_mode == 2  || GlobalConfig.GetIns().m_enter_mode == 4 )
             && GlobalConfig.GetIns().m_enter_mode_gk == 1)
        {
            this.Add_Move_Shouzhi_Zhiyiing();
        }
         
        BackGroundSoundUtils.GetInstance().Play_Effect("huaduoppingping/enter_rand_hua");


        var ibanner_mng_time = GlobalGameMng.GetInstance().Get_Game_Banner_Mng_Time_Config(this.Get_SubGameType());
  
        this.schedule(this.FD_Banner_Mng_Timer.bind(this),ibanner_mng_time);
 
        GlobalGameMng.GetInstance().m_dating_last_from_subgame_type =  this.Get_SubGameType();
        GlobalGameMng.GetInstance().m_dating_last_from_subgame_level =  this.Get_Level();
        var bchaogaoping=  ComFunc.ISChaoGaoPing();
 

        var in_subgame_jiaoti_gezi_arr = [];

         
        this.m_game_banner_arr = [];


        MiddleGamePlatformAction.GetInstance().Set_In_Subgame_Valid_Gezi_Guangao_Bannerindex_Arr_Info(true,
            this.Get_SubGameType(),this.m_game_banner_arr);
 
     
        
        
        this.Check_Show_Gezi_Guanggao();

    }
    Check_Show_Gezi_Guanggao()
    {

        
        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
 
        var banerid_map = new WMap();
         
       
   
        for(var ff=0;ff<this.m_game_banner_arr.length;ff++)
        {
            var ff_bannerid = this.m_game_banner_arr[ff];
 
            if(!banerid_map.hasKey(ff_bannerid))
            {

                continue;
            }

            var ibanenrtype = banerid_map.getData(ff_bannerid);


            console.log("Check_Show_Gezi_Guanggao ff_bannerid="+ff_bannerid+",itype="+ibanenrtype);
            MiddleGamePlatformAction.GetInstance().Check_Create_Show_Game_Banner_A(ff_bannerid,ibanenrtype);
     
 
        }
     
 
       
        this.FD_Banner_Mng_Timer();
    }
      
 
    Get_Level()
    {
        return this.m_cur_level;
    }
    
    FD_Banner_Mng_Timer()
    {

        MiddleGamePlatformAction.GetInstance().FD_Banner_Mng_Timer(this.node);

    
    }
     

    Get_Max_Wuping_TypeCpunt()
    {
        if(GlobalConfig.GetIns().m_enter_mode == 4)
        {
            return 55;
        }

        return 50;
    }
    On_Game_Enter_Event()
    {
        var entermode = GlobalConfig.GetIns().m_enter_mode ;
        var enter_mode_gk = GlobalConfig.GetIns().m_enter_mode_gk ;


        if(entermode == 2)
        {
            if(enter_mode_gk == 2)
            {
                if(this.m_cur_gk_showed_jineng_qipao_tishi_jineng_map.size() > 0)
                {
                    return;
                }
                 
                
                {
                    this.m_cur_gk_showed_jineng_qipao_tishi_jineng_map.putData(4,1);
                    this.Show_Jineng_Qipao_Tishi(4,true);
                }
            }

            if(enter_mode_gk == 3)
            {
                if(this.m_cur_gk_showed_jineng_qipao_tishi_jineng_map.size() > 0)
                {
                    return;
                }
                 
                
                {
                    this.m_cur_gk_showed_jineng_qipao_tishi_jineng_map.putData(1,1);
                    this.Show_Jineng_Qipao_Tishi(1,true);
                }
            }

            if(enter_mode_gk == 6)
            {
                if(this.m_cur_gk_showed_jineng_qipao_tishi_jineng_map.size() > 0)
                {
                    return;
                }
                 
                
                {
                    this.m_cur_gk_showed_jineng_qipao_tishi_jineng_map.putData(2,1);
                    this.Show_Jineng_Qipao_Tishi(2,true);
                }
            }

            if(enter_mode_gk == 8)
            {
                if(this.m_cur_gk_showed_jineng_qipao_tishi_jineng_map.size() > 0)
                {
                    return;
                }
                 
                
                {
                    this.m_cur_gk_showed_jineng_qipao_tishi_jineng_map.putData(3,1);
                    this.Show_Jineng_Qipao_Tishi(3,true);
                }
            }
        }

    }
     
    Get_SubGameType()
    {
        
        return 30+ GlobalConfig.GetIns().m_enter_mode;
    }
    Notify_Xiaochu_One_Success(find_same_peng_index)
    {




        var bnned = false;
        if((GlobalConfig.GetIns().m_enter_mode == 2  || GlobalConfig.GetIns().m_enter_mode == 4 ) && GlobalConfig.GetIns().m_enter_mode_gk == 1)
        {
            bnned = true;
        }

        if(this.m_game_date.m_bgame_end)
        {
            if(this.m_first_yd_shouzhi_node)
            {
                this.m_first_yd_shouzhi_node.active = false;
            }
            return;
        }

        if(!bnned)
        {
            this.Check_Show_Jineng_Tishi_On_Xiaochu_End();


            if(this.m_xiaochu_huaduo_lianji_count == 0)
            {
                this.m_last_xiaochu_huaduo_tick = Date.now();
                this.m_xiaochu_huaduo_lianji_count = 1;
    
            }else{

                if(Date.now() -this.m_last_xiaochu_huaduo_tick < 10000)
                {
                    this.m_last_xiaochu_huaduo_tick = Date.now();
                    this.m_xiaochu_huaduo_lianji_count += 1;
                }
            }
 


            this.Refresh_Lianji_Info();
          
            return;
        }
        if(this.m_first_yd_step == 1)
        {

            this.m_first_yd_step = 2;
        }


        if(this.m_game_ended)
        { 
        }else
        { 
            this.Add_Move_Shouzhi_Zhiyiing();
        }
    }
    Add_Move_Shouzhi_Zhiyiing()
    {
        var yingdao_ndoe = cc.find("center/yingdao",this.node)
         
        if(!this.m_first_yd_shouzhi_node)
        {
            this.m_first_yd_shouzhi_node = cc.instantiate(this.shouzhi);
            yingdao_ndoe.addChild(this.m_first_yd_shouzhi_node ,30);
    
        }

        if(this.m_first_yd_step == 1)
        {
            yingdao_ndoe.stopAllActions();
            var pz3_pos = this.m_game_date.Get_Pengzi_Pos(2);
            var pz2_pos = this.m_game_date.Get_Pengzi_Pos(3);
    
    
            var startpos = new cc.Vec2(pz3_pos.x-50,pz3_pos.y-50)
            var endpos = new cc.Vec2(pz2_pos.x+50,pz2_pos.y+50)
            this.m_first_yd_shouzhi_node .setPosition(startpos.x,startpos.y);
    
            var pseq =  cc.sequence(cc.show(), cc.moveTo(0.01,startpos),cc.delayTime(0.3) ,cc.moveTo(1,endpos),cc.hide(),cc.delayTime(1))
    
            var targactiob= cc.targetedAction(this.m_first_yd_shouzhi_node,pseq)
    
            yingdao_ndoe.runAction(cc.repeatForever(targactiob)  );
        }else{
            yingdao_ndoe.stopAllActions();
            var pz3_pos = this.m_game_date.Get_Pengzi_Pos(4);
            var pz2_pos = this.m_game_date.Get_Pengzi_Pos(1);
    
    
            var startpos = new cc.Vec2(pz3_pos.x-50,pz3_pos.y+50)
            var endpos = new cc.Vec2(pz2_pos.x+50,pz2_pos.y-50)
            this.m_first_yd_shouzhi_node .setPosition(startpos.x,startpos.y);
    
            var pseq =  cc.sequence(cc.show(), cc.moveTo(0.01,startpos),cc.delayTime(0.3) ,cc.moveTo(1,endpos),cc.hide(),cc.delayTime(1))
    
            var targactiob= cc.targetedAction(this.m_first_yd_shouzhi_node,pseq)
    
            yingdao_ndoe.runAction(cc.repeatForever(targactiob)  );
        }
       
       
        
    }
    FD_Real_Pop_GameSuccess_Dlg(ibeishu)
    {
        var igk = GlobalConfig.GetIns().m_enter_mode_gk;

        if(GlobalConfig.GetIns().m_enter_mode == 2 || GlobalConfig.GetIns().m_enter_mode == 4 
        || GlobalConfig.GetIns().m_enter_mode == 1)
        {
            GlobalConfig.GetIns().On_Guoguang_Gk(igk)
        }

        if(!ibeishu)
        {
            ibeishu = 1;
        }
        var showfenshu  =  ibeishu*this.m_game_date.m_all_jifen;

        GlobalConfig.GetIns().Set_Max_Jifen_Show(showfenshu);


        /*
        var pndoe  =  cc.instantiate(this.game_success);
        var game_success = pndoe.getComponent("huaduo_game_success");
        game_success.SetInfo(

            {
                fenshu:showfenshu,
                gk:igk
            }
        )

        this.node.addChild(pndoe,10);
        */


        


        var jinfenawrd =[
            {
                "t":1,
                "c":showfenshu
            }
        ]

        var self = this;
        ComFunc.Real_OpenNewDialog(this.gamesuccess_new, this.node,"preab/gamesuccess_new","gamesuccess_new",
         {
            hidechongwan:1,
            parentgame:this,star:3,
            isubgametype:this.Get_SubGameType(),
            ilevel:this.m_cur_level,

            cb:(iret)=>
            {

                 
               
 
                self.RestartNewGame()
                
                
            
        }});



    }
    On_Game_Success_Finished()
    {

        this.scheduleOnce(this.FD_Pop_GameEnd_Animate.bind(this),0.1)

        this.scheduleOnce(this.FD_Show_GameSuccess_Dlg.bind(this),2.5)
        
        if(GlobalConfig.GetIns().m_b_yingdao)
        {
            GlobalConfig.GetIns().m_b_yingdao = 0;
            GlobalConfig.GetIns().m_yingdao_finished = 1;


        }
    }


    FD_Pop_GameEnd_Animate()
    {
        var pnode = cc.instantiate(this.game_end_animate);
        this.node.addChild(pnode,70);
        
        BackGroundSoundUtils.GetInstance().Play_Effect("huaduoppingping/game_win_effect")
    }
    FD_Show_GameSuccess_Dlg()
    {
        this.FD_Real_Pop_GameSuccess_Dlg(1);

        /*
        if(this.m_game_date.m_all_jifen > 0 )
        {
            var self = this;
            var pndoe  =  cc.instantiate(this.guoguang_jiangli_dlg);
            var guoguang_jiangli_dlg = pndoe.getComponent("guoguang_jiangli_dlg");
            guoguang_jiangli_dlg.SetInfo(
    
                {
                    xingxing:this.m_game_date.m_all_jifen,
                    callback:(ibeishu)=>
                    {
                        self.FD_Real_Pop_GameSuccess_Dlg(ibeishu);
                    }
                }
            )
    
            this.node.addChild(pndoe,10);

        }else{
            this.FD_Real_Pop_GameSuccess_Dlg(1);
        }

        */
    }
    Real_Menu_Action(imenu)
    {
        if(this.m_game_date.m_b_in_animate)
        {
            return;
        }
        if(this.m_game_date.m_bgame_end)
        {
            return;
        }

        if(Date.now() - this.m_last_skill_action_tick < 1000)
        {
            return;
        }


        var daojutype =  20+imenu;

        var self = this;
        if(imenu == 1)
        {
            var find_hua_v_map = this.m_game_date.Find_Same_Tree_Color_Hua_Map();
            if(find_hua_v_map.size() == 0)
            {
                BaseUIUtils.ShowTipTxtDlg("没有可提示的消除信息",this.node)
                return;
            }


            var find_hua =  0;

            for(var ff=0;ff<find_hua_v_map.size();ff++)
            {
                var ff_v = find_hua_v_map.GetKeyByIndex(ff);

                if(!ComFunc.arrayShuzuContain(this.m_last_tishi_hua_v_list,ff_v))
                {
                    find_hua = ff_v;
                    break;
                }
            }

            if(find_hua == 0)
            {
                this.m_last_tishi_hua_v_list = [];
                find_hua = find_hua_v_map.GetKeyByIndex(0);
                
            }

            this.m_last_tishi_hua_v_list.push(find_hua)
 
            var tishi_xiaochu_arr_list = this.m_game_date.Skill_Tishi_Show_And_Xiaochu_3_Hua_Color(find_hua);

            this.m_game_date.m_b_in_animate = 1;

            var pseq = cc.sequence(cc.delayTime(2),
                cc.callFunc(()=>
                {
                    self.Move_Tishi_Hua_Arr_To_Center_And_Xiaochu(tishi_xiaochu_arr_list);
                }),
                cc.delayTime(0.3),
                cc.callFunc(()=>
                {

                    var v_pos = new  cc.Vec2(0,0);

                    self.Add_Xingxing_Move_Animate(v_pos, 1);
            
            
                    self.Add_Huaban_Animate(v_pos,cc.color(255,215,0))
                    
                    BackGroundSoundUtils.GetInstance().Play_Effect("huaduoppingping/xaiochuhua");
                }),
                cc.delayTime(0.3),
                cc.callFunc(()=>
                {
                    self.m_game_date.Skill_Tishi_End(tishi_xiaochu_arr_list);
                })
            );

            this.node.runAction(pseq);

         //   this.m_game_date.Tishi_Show_Hua_Color(find_hua);

        }
        else if(imenu == 4)
        {

            this.m_game_date.Rand_All_Hua_Digit();

            BackGroundSoundUtils.GetInstance().Play_Effect("huaduoppingping/enter_rand_hua");
        }
        else if(imenu == 3)
        {
            var eplase_tick = Date.now() - this.m_game_date.m_last_bingdong_skill_tick ;

            if(eplase_tick < 10*1000)
            {
                return;
            }

            this.m_game_date.Bingdong_Time();

            

            BackGroundSoundUtils.GetInstance().Play_Effect("huaduoppingping/bingdong");
        }
        else if(imenu == 2)
        {

            var balid = this.m_game_date.Skill_Shuazi_Change_Hua_Color();
            if(!balid)
            {
                return false;
            }

            BackGroundSoundUtils.GetInstance().Play_Effect("huaduoppingping/shuazi");
        }
        GlobalConfig.GetIns().Change_Self_DaojuType_Count(daojutype,-1);
        this.Refresh_Info();
        this.m_last_skill_action_tick = Date.now();
        this.Show_Jineng_Qipao_Tishi(0,false);
    
    }

    Add_Per_Tishi_Hua_Node_To_Center(ff_arr)
    {
        var ff_pengzi_index = ff_arr[0];
        var ff_subindex = ff_arr[1];

        var ff_hua_v = ff_arr[2];
        var ff_pos = this.m_game_date.Get_Pengzi_Sub_Hua_Pos(ff_pengzi_index,ff_subindex)
            
        var ff_ndoe:cc.Node = NodeComPoolUtils.GetInstance().GetPrabbNameNode("select_move_hua",this.select_move_hua);
        this.node.addChild(ff_ndoe,50);
        ff_ndoe.setPosition(ff_pos);
        var hua_node:cc.Node = cc.find("hua",ff_ndoe);
        hua_node.color = cc.color(255,255,255)
        if(GlobalConfig.GetIns().m_enter_mode == 4)
        {
            hua_node.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame( this.dongwu_sprite_frame_list[ff_hua_v])
            hua_node.width = 75;
            hua_node.height = 75;
        }
        else
        {
            hua_node.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame( this.huaduo_sprite_frame_list[ff_hua_v])
   
        }    

        var pmoveto = cc.moveTo(0.3,0,0);

        var pseq = cc.sequence(cc.targetedAction(ff_ndoe,pmoveto),cc.callFunc(()=>
        {
                NodeComPoolUtils.GetInstance().putANode("select_move_hua",ff_ndoe)
        }))

        this.node.runAction(pseq);
    }
   
    Move_Tishi_Hua_Arr_To_Center_And_Xiaochu(tishi_xiaochu_arr_list)
    {
        for(var ff=0;ff<tishi_xiaochu_arr_list.length;ff++)
        {
            var ff_arr = tishi_xiaochu_arr_list[ff];
            var ff_pengzi_index = ff_arr[0];
            var ff_subindex = ff_arr[1];

            var ff_hua_v = ff_arr[2];

            this.m_game_date.Hide_Pengzi_SubIndex_Hua_Show(ff_pengzi_index,ff_subindex);

            this.Add_Per_Tishi_Hua_Node_To_Center(ff_arr);

            

        }

    }
    Show_Jineng_Daoju_Buzu(idaojutype)
    {
        this.Set_Game_Paused(1);
        var self = this;
        var pndoe  =  cc.instantiate(this.huoqu_daoju_dlg);
        var huoqu_daoju_dlg:huoqu_daoju_dlg = pndoe.getComponent("huoqu_daoju_dlg");
        huoqu_daoju_dlg.SetInfo(

            {
                idaojutype:idaojutype,
                callback:()=>
                {
                    self.Set_Game_Paused(0);
                    self.Refresh_Info();
                }
            }
        )
        this.node.addChild(pndoe,10);
    }
    
     
    OnBtnMenu(imenu)
    {
      
        /*
        if(hualandaojuc <= 0)
        {
            var self = this; 
            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
                this.node,()=>{},
                
                "手动全军满血",(bsuc)=>
            {
               
                if(!bsuc)
         s       {
                    
                    return;
                } 


                var icc = 2;
                if(imenu == 1)
                {
                    icc = 6;
                }
                GlobalConfig.GetIns().Change_Self_DaojuType_Count(daojutype,icc);
                Util.ShowTipTxtDlg("获得道具成功",self.node)
               // self.Real_Menu_Action(imenu);
            });
        }else{
            this.Real_Menu_Action(imenu);
        }

*/



        var ff_daoju_lock_level = this.Get_Daoju_Unlock_Leve(imenu);
        var unlocked = 0;
        if(ff_daoju_lock_level <= GlobalConfig.GetIns().m_max_win_gk + 1)
        {
            unlocked = 1;
        }
   
        if(!unlocked)
        {
            BaseUIUtils.ShowTipTxtDlg("关卡"+ff_daoju_lock_level+"解锁道具",this.node)
            return;
        }

 

        var daojutype =  20+imenu;

        var hualandaojuc = GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(daojutype);

        if(hualandaojuc <= 0)
        {
            
            this.Show_Jineng_Daoju_Buzu(daojutype);

            /*
            var self = this; 
            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
                this.node,()=>{},
                
                "手动全军满血",(bsuc)=>
            {
               
                if(!bsuc)
                {
                    
                    return;
                } 
                self.Refresh_Info();
                self.Real_Add_Hualan();
            });
            */
        }else{
          //  GlobalConfig.GetIns().Change_Self_DaojuType_Count(daojutype,-1);
          //  this.Refresh_Info();
            this.Real_Menu_Action(imenu);

            
        }

    }

    Get_Per_Xiaochu_Add_Xingxing_Count()
    {
        if(this.m_xiaochu_huaduo_lianji_count <= 2)
        {

            return 1;
        }
        else if(this.m_xiaochu_huaduo_lianji_count <= 11)
        {
            var iaddc  = Math.floor(this.m_xiaochu_huaduo_lianji_count/3)


            return 1 + iaddc;
        }
        else if(this.m_xiaochu_huaduo_lianji_count <= 15)
        {

            return 4;
        }else  
        {

            return 5;
        } 

        return 1;
    }

    Refresh_Lianji_Info()
    {
        var lianjitishi_info_node = cc.find("lianjitishi/info",this.node);

        if(this.m_xiaochu_huaduo_lianji_count <= 0 )
        {
            lianjitishi_info_node.active = false;
            return;
        }
        lianjitishi_info_node.active = true;
        lianjitishi_info_node.getChildByName("beishu").getComponent(cc.Label).string = ""+this.m_xiaochu_huaduo_lianji_count;


        var eplase_tick = Date.now() - this.m_last_xiaochu_huaduo_tick;

        var lefttick = 10000 - eplase_tick;

        if(lefttick <= 0)
        {
            lefttick = 0;
            this.m_xiaochu_huaduo_lianji_count = 0;
            this.m_last_xiaochu_huaduo_tick = 0;
        }

        var iprogress = lefttick/10000;
        var jindu_bar = cc.find("lianjitishi/info/jindu/bar",this.node);
        jindu_bar.getComponent(cc.Sprite).fillRange = iprogress;
        

    }
    FD_Timer()
    {
        this.Refresh_Info();
        this.Refresh_Lianji_Info();
         

        if(Date.now() - this.m_last_user_do_action_tick > 20000)
        {
            this.m_last_user_do_action_tick = Date.now();

            var to_long_no_action_show_tip_type=  this.Find_Too_Long_Not_Action_Show_Jinengi();

            if(to_long_no_action_show_tip_type > 0)
            {
                this.Show_Jineng_Qipao_Tishi(to_long_no_action_show_tip_type,true);
            }
            
        }
    }

    Find_Too_Long_Not_Action_Show_Jinengi()
    {

        var unlocked_4 = this.Is_Skill_Jineng_Type_Unlocked(4);
        var unlocked_1 = this.Is_Skill_Jineng_Type_Unlocked(1);

        if(unlocked_4)
        {
            //没有可提示的并且空位小于等于2个了

            var empty_pos_count = this.m_game_date.Get_All_Pengzi_Empty_Pos_Count();
            var find_hua_v_map = this.m_game_date.Find_Same_Tree_Color_Hua_Map();
            if(find_hua_v_map.size() == 0 && empty_pos_count<= 2 )
            {
               return 4;   
            }

            if(empty_pos_count<= 1)
            {
                return 4;
            }
        }

        if(unlocked_1)
        {
            return 1;
        }

        return 0;
    }
    Check_Show_Jineng_Tishi_On_Xiaochu_End()
    {
        var bneedshuaxin = 0;
        var unlocked_4 = this.Is_Skill_Jineng_Type_Unlocked(4);
        if(unlocked_4)
        {
            //没有可提示的并且空位小于等于2个了

            var empty_pos_count = this.m_game_date.Get_All_Pengzi_Empty_Pos_Count();
            var find_hua_v_map = this.m_game_date.Find_Same_Tree_Color_Hua_Map();
            if(find_hua_v_map.size() == 0 && empty_pos_count<= 2 )
            {
                bneedshuaxin = 1;
            }
        }


        if(bneedshuaxin)
        {
            this.Show_Jineng_Qipao_Tishi(4,true);
        }

    }
    onTouchStart(event) 
    {
        var pos = this.m_panzi.convertToNodeSpaceAR(event.getLocation());

        this.m_game_date.onTouchStart(pos);

        this.m_last_user_do_action_tick = Date.now();

        if(Date.now() - this.m_game_start_tick > 15000)
        {
            this.Show_Jineng_Qipao_Tishi(0,false);
        }
        
    }

    onTouchMove(event)
    {
        var pos = this.m_panzi.convertToNodeSpaceAR(event.getLocation());

        this.m_game_date.onTouchMove(pos);
        this.m_last_user_do_action_tick = Date.now();
    }

    onTouchEnd(event)
    {
        var pos = this.m_panzi.convertToNodeSpaceAR(event.getLocation());

        this.m_game_date.onTouchEnd(pos);
        this.m_last_user_do_action_tick = Date.now();
    }

    onTouchCancel(event)
    {
        this.m_game_date.onTouchCancel();

    }



    Get_Pengzi_Preab()
    {
        if(GlobalConfig.GetIns().m_enter_mode == 4)
        {
            return this.ping_dongwu;
        }
        return this.ping_pengzi;
    }
    Get_Desk_Preab()
    {
        return this.ping_desk;
    }

    OnBtnShangcheng()
    {
        this.Set_Game_Paused(1)

        var self = this;
        var pndoe  =  cc.instantiate(this.shangcheng_dlg);
        var huaduo_shangcheng_dlg = pndoe.getComponent("huaduo_shangcheng_dlg");
        huaduo_shangcheng_dlg.SetInfo(

            {
                callback:(iret)=>
                {
                    self.Set_Game_Paused(0);
                    self.Refresh_Info()

                }
            }
        )
        this.node.addChild(pndoe,10);

 
    }

     
    Set_Game_Paused(bpause)
    {
        this.m_game_date.m_bgame_paused = bpause;
    }

    OnBtnBackToHall()
    {
        var isubgametype = this.Get_SubGameType();
       
        this.Set_Game_Paused(1)

         var self = this;
         ComFunc.OpenNewDialog(this.node,"preab/pausedlg","pausedlg", 
         { 
            parentgame:this,
            hidexuanguang:1,
            isubgametype:isubgametype, 
             cb:()=>
             {
                self.Set_Game_Paused(0)

             },
             close_cb:()=>
             {
                self.Set_Game_Paused(0)

             },
             paihangbang_cb:()=>
             {
                 //self.OnBtn_PaihangBang();
             },
             shangcheng_cb:()=>
             {
                //self.Set_Game_Paused(0)

                 self.OnBtnShangcheng();
             }
         
         
        });
 
    }
    OnBtn_Open_Shangcheng()
    {
       
    }
    OnBtnShezhi()
    {
     /*
        this.Set_Game_Paused(1)

        var self = this;
        var pndoe  =  cc.instantiate(this.shezhi_dlg);
        var shezhi_dlg:shezhi_dlg = pndoe.getComponent("shezhi_dlg");
        shezhi_dlg.SetInfo(

            {
                callback:(iret)=>
                {
                    self.Set_Game_Paused(0)

                    if(iret == 2)
                    {
                        self.OnBtnShangcheng();
                    }

                }
            }
        )
        this.node.addChild(pndoe,10);
       
 */
    }
    
    Get_Daoju_Unlock_Leve(iindex)
    {
        
        if(iindex == 1)
        {
            return 3;
        }
        if(iindex == 2)
        {
            return 6;
        }
        if(iindex == 3)
        {
            return 8;
        }
        if(iindex == 4)
        {
            return 2;
        }
        return 2;
    }

    Is_Skill_Jineng_Type_Unlocked(skilltype)
    {
        var ff_daoju_lock_level = this.Get_Daoju_Unlock_Leve(skilltype);
        var unlocked = 0;
        if(ff_daoju_lock_level<= GlobalConfig.GetIns().m_max_win_gk + 1)
        {
            unlocked = 1;
        }

        return unlocked;
    }
    Refresh_Info()
    { 



        var maxscore = cc.find("toptiao/wujininfo/maxinfo/maxscore",this.node)
        maxscore.getComponent(cc.Label).string = ""+GlobalConfig.GetIns().m_max_jifen;
     
        var left_t_label = cc.find("menu/3/left_t",this.node)
      
        var bd_left_sec  = this.m_game_date.m_bingdong_skill_left_sec
        if(bd_left_sec > 0)
        {
            bd_left_sec=  Math.floor(bd_left_sec);
            left_t_label.active = true;
            left_t_label.getComponent(cc.Label).string = ComFunc.FormatLeftSecStr(bd_left_sec);
        }else{
            left_t_label.active = false;
        }

 

        for(var ff=1;ff<=4;ff++)
        {
            var ff_count_node = cc.find("menu/"+ff+"/com/count",this.node)
            var ff_sp_node = cc.find("menu/"+ff+"/com/sp",this.node)
            var ff_lock_node = cc.find("menu/"+ff+"/lock",this.node);

            var ff_daoju_lock_level = this.Get_Daoju_Unlock_Leve(ff);
            var unlocked = 0;
            if(ff_daoju_lock_level<= GlobalConfig.GetIns().m_max_win_gk + 1)
            {
                unlocked = 1;
            }

            var ff_cc = GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(ff+20);

            if(!unlocked )
            {

                ff_lock_node.active = true;

                ff_sp_node.active = false;
                ff_count_node.active = false;

            }
            else{
                ff_lock_node.active = false;
                if(ff_cc > 0)
                {
                    ff_sp_node.active = false;
                    ff_count_node.active = true;
    
                    ff_count_node.getChildByName("c").getComponent(cc.Label).string = ""+ff_cc;
                }else{
                    ff_sp_node.active = true;
                    ff_count_node.active = false;
                }
            }

          

        }



        var xingxing_c_label = cc.find("toptiao/xx/c",this.node)
        xingxing_c_label.getComponent(cc.Label).string = ""+this.m_game_date.m_all_jifen
   
      
        

        var leftsec = this.m_game_date.Get_Curju_Left_Sec();

        var left_sec_label = cc.find("toptiao/daojishi/left_sec",this.node)
        left_sec_label.getComponent(cc.Label).string = ""+ComFunc.FormatLeftSecStr(leftsec);
   
        if(leftsec <= 60)
        {
            left_sec_label.color = cc.color(255,0,0);

            if(leftsec < 15  && leftsec > 0  && !this.m_game_date.m_bgame_end  && !this.m_game_date.m_bgame_paused)
            {
             //   BackGroundSoundUtils.GetInstance().Play_Effect_Check_Delay("huaduoppingping/daojishi",1000)
            }


            
            if(leftsec < 15  && leftsec > 0  && !this.m_game_date.m_bgame_end  && !this.m_game_date.m_bgame_paused
                && this.m_game_date.m_bingdong_skill_left_sec <= 0
                
                )
            {
                if(this.m_last_effect_daojishi_sec != leftsec)
                {
                    this.m_last_effect_daojishi_sec = leftsec;
                    BackGroundSoundUtils.GetInstance().Play_Effect("huaduoppingping/daojishi")
                }
                
            }
            
            
        }else{
            left_sec_label.color = cc.color(255,255,255)
        }

        if(leftsec <= 0  && !this.m_game_date.m_bgame_end)
        {
            this.m_game_date.OnGame_Fail_Time_Out();
            this.OnGame_Fail_Time_Out();
        }
        

        var enter_mode = GlobalConfig.GetIns().m_enter_mode;


        var gk_label = cc.find("toptiao/gkinfo/gk",this.node);

        if(enter_mode == 1)
        {
            gk_label.getComponent(cc.Label).string = "挑战关:"+GlobalConfig.GetIns().m_enter_mode_gk+""
   
        }else{
            gk_label.getComponent(cc.Label).string = "第"+GlobalConfig.GetIns().m_enter_mode_gk+"关"
   
        }
       

        
        var gk_xiaochu_jinbu = cc.find("toptiao/gkinfo/jindu/bar",this.node)
    
        var xiaochuedc = this.m_game_date.m_xiaochued_count;
        var allneedc = this.m_game_date.m_all_need_xiaochu_hua_count;


        gk_xiaochu_jinbu.getComponent(cc.Sprite).fillRange = xiaochuedc/allneedc;


        
        
    }

    Add_Xingxing_Move_Animate(v_pos:cc.Vec2, curlun_add_xingxing)
    {
      

        var star_node = cc.find("toptiao/xx/icon",this.node);
       
        var dest_pos = Utils.NodeWorldPos(star_node);


        var animate_node = cc.find("center/animate",this.node);

    
        var suipian_ndoe = NodeComPoolUtils.GetInstance().GetPrabbNameNode("move_star_node",this.move_star_node )
        suipian_ndoe.setPosition(v_pos);
        animate_node.addChild(suipian_ndoe,20);
 

        var pseq = cc.sequence(cc.delayTime(0.1),cc.targetedAction(suipian_ndoe,cc.moveTo(0.3,dest_pos)),cc.delayTime(0.05),cc.callFunc(()=>
        {
            NodeComPoolUtils.GetInstance().putANode("move_star_node",suipian_ndoe )
        }));

        this.node.runAction(pseq);

        
    }
    OnGame_Fail_Time_Out()
    {

        this.m_game_ended = true;
        this.m_game_end_success = 0;

       // var pndoe  =  cc.instantiate(this.gamefail);
        //this.node.addChild(pndoe,10);

          
        this.scheduleOnce(this.FD_Show_Fuhuo_Dlg.bind(this),1)

    }
    FD_Show_GameFail_Dlg()
    {
        /*
        var pndoe  =  cc.instantiate(this.gamefail);
        var gamefail = pndoe.getComponent("huaduo_gamefail");
        gamefail.SetInfo(

            {
                fenshu:this.m_game_date.m_all_jifen
            }
        )

        this.node.addChild(pndoe,10);

*/

        var isubgametype = this.Get_SubGameType();
        var icutgk = this.m_cur_level;

        var strtip = "挑战失败";
        
 
        BackGroundSoundUtils.GetInstance().Play_Effect("huaduoppingping/jbibianhua");
 

        var self = this;
      
        ComFunc.Real_OpenNewDialog(this.game_fail_new,this.node,"preab/game_fail_new","game_fail_new", {parentgame:this,
            isubgametype:isubgametype, igk:icutgk,strtip:strtip,
            cb:(val)=>
            {
                self.RestartNewGame();
           
            }});
    }
    RestartNewGame()
    {
        GlobalConfig.GetIns().Enter_Game_Mode(this.m_enter_game_mdoe)
        cc.director.loadScene("huaduo_xiaoxiao");

        
    }
    Real_Fuhuo()
    {
        this.m_game_date.Real_Fuhuo();
        BaseUIUtils.ShowTipTxtDlg("复活成功，增加消除时间成功",this.node)
    }
    FD_Show_Fuhuo_Dlg()
    {

        this.m_fughuoed_count++;

        var fuhuosec = this.m_game_date.Get_Fuhuo_Sec();
        var pndoe  =  cc.instantiate(this.gamefuhuo_dlg);
        var fuhuo_sel_dlg = pndoe.getComponent("fuhuo_sel_dlg");
        fuhuo_sel_dlg.SetInfo(

            {
                fuhuosec:fuhuosec,
                callback:(iret)=>
                {

                    if(iret > 0)
                    {

                        this.Real_Fuhuo();
                    }
                    else{

                        this.FD_Show_GameFail_Dlg();
                    }

                }
            }
        )
        this.node.addChild(pndoe,10);
    }
    Add_Huaban_Animate(huas_pos,wk_color)
    {
        var animate_node = cc.find("center/animate",this.node);

        var suipian_ndoe = NodeComPoolUtils.GetInstance().GetPrabbNameNode("huaban_suikai",this.huaban_suikai )

        suipian_ndoe.setPosition(huas_pos);

        var huaban_suikai = suipian_ndoe.getComponent("huaban_suikai");

        huaban_suikai.SetInfo(
            {
                wk_color_index:wk_color
            }
        )
        animate_node.addChild(suipian_ndoe,10);

        var pseq = cc.sequence(cc.delayTime(0.4),cc.callFunc(()=>
        {
            NodeComPoolUtils.GetInstance().putANode("huaban_suikai",suipian_ndoe )
        }));

        this.node.runAction(pseq);

    }

    update(dt)
    {
        this.m_game_date.Update_Tick(dt);



        var col_progress_node = cc.find("menu/3/col_progress",this.node)
        
        var daojishi_bingdong = cc.find("toptiao/daojishi/bingdong",this.node)
      

     
        
        var eplase_tick = Date.now() - this.m_game_date.m_last_bingdong_skill_tick ;

        if(eplase_tick < 10000)
        {
            var iprogress = 1- eplase_tick/10000;

            col_progress_node.getComponent(cc.Sprite).fillRange = iprogress;

            daojishi_bingdong.active = true;
        }else{
            col_progress_node.getComponent(cc.Sprite).fillRange = 0;

            daojishi_bingdong.active  =false;
 
        }

      
        if(this.m_last_show_jineng_qipao_tick > 0 && this.m_cur_gk_showed_jineng_qipao_type > 0)
        { 
            var eplase_qipao_show_tick = Date.now() - this.m_last_show_jineng_qipao_tick;
     
            if(eplase_qipao_show_tick > 15000)
            {
                this.Show_Jineng_Qipao_Tishi(0,false);
                
                this.m_last_user_do_action_tick = Date.now();

            }
     
        }  


        if(this.m_xiaochu_huaduo_lianji_count > 0)
        {
            this.Refresh_Lianji_Info();
        }
        
    }


    Show_Jineng_Qipao_Tishi(jinengtype,bshow)
    {
        this.m_cur_gk_showed_jineng_qipao_type=  0;
        this.m_cur_jineng_show_eplaee_bushu_count = 0;
      
        var qipaitishi_node = cc.find("qipaitishi",this.node);
      
        var info_node = cc.find("qipaitishi/info",this.node);
        if(!bshow)
        {
            qipaitishi_node.stopAllActions();
            info_node.active = false;
            return;
        }else{
          //  this.m_last_show_jineng_qiao_eplase_empty_pos_click_step = 0;
        }

        this.m_last_show_jineng_qipao_tick = Date.now();

        qipaitishi_node.stopAllActions();
        var info_bk_node = cc.find("bk",info_node);
        var stip_node = cc.find("stip",info_node);

        this.m_cur_gk_showed_jineng_qipao_type=  jinengtype;
       
        info_node.active = true;

        var destnode_pos=  new cc.Vec2(0,0);
        var scalex = 1;

        if(jinengtype == 2)
        {
            destnode_pos=  new cc.Vec2(-50,-425);
            scalex = 1;

            stip_node.getComponent(cc.Label).string = "变换9个花朵颜色";
        }
        else if(jinengtype == 1)
        {
            destnode_pos=  new cc.Vec2(-200,-425);
            scalex = 1;

            stip_node.getComponent(cc.Label).string = "消除3个花朵";
        } else if(jinengtype == 3)
        {
            destnode_pos=  new cc.Vec2(50,-425);
            scalex = -1;

            stip_node.getComponent(cc.Label).string = "冰冻冻结时间30秒";
        }else if(jinengtype == 4)
        {
            destnode_pos=  new cc.Vec2(200,-425);
            scalex = -1;

            stip_node.getComponent(cc.Label).string = "刷新重排剩余花朵";
        }

        info_bk_node.scaleX = scalex;

        
        info_node.setPosition(destnode_pos.x,destnode_pos.y-20);

        var pseq1 = cc.sequence(cc.targetedAction(info_node,cc.moveTo(0.3,destnode_pos)),
            cc.delayTime(0.1)
        );

      
        var pseqall = cc.sequence(pseq1,cc.callFunc(()=>
        {
            var pseq2 =  cc.sequence(cc.moveTo(0.3,destnode_pos.x,destnode_pos.y+5),cc.moveTo(0.3,destnode_pos.x,destnode_pos.y),cc.delayTime(1.5))
            var pseq3= cc.targetedAction(info_node,pseq2)
            qipaitishi_node.runAction(cc.repeatForever(pseq3))
        }))
  
        qipaitishi_node.runAction(pseqall)
    }
}
