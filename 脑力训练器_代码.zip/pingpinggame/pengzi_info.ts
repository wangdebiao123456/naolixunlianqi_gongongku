import ping_pengzi from "./ping_pengzi";


export default class pengzi_info
{

    m_pengzi_type = 1;
    m_pengzi_node:cc.Node = null;
    m_pengzi_index = 1;

    m_destk_count  = 2;

    m_pengzi_pos = new cc.Vec2(0,0)

    constructor(iindex)
    {
        this.m_pengzi_index = iindex;

    }
   
    Get_Pengzi_ComName()
    {
        if(this.m_pengzi_type == 1)
        {
            return "ping_pengzi";
        }
        return "ping_dongwu";
    }
    Tishi_Show_Sub_Index_Hua_Color(ff_sub_index)
    {
        var scomname = this.Get_Pengzi_ComName();
        var ping_pengzi = this.m_pengzi_node.getComponent(scomname);
        ping_pengzi.Tishi_Show_Sub_Index_Hua_Color(ff_sub_index);
    }
    Hide_SubIndex_Hua_Show( ff_subindex)
    {
        var scomname = this.Get_Pengzi_ComName();
        var ping_pengzi = this.m_pengzi_node.getComponent(scomname);
        ping_pengzi.Hide_SubIndex_Hua_Show(ff_subindex);
    }
    Tishi_Show_Hua_Color(find_hua)
    {
        var scomname = this.Get_Pengzi_ComName();
        var ping_pengzi = this.m_pengzi_node.getComponent(scomname);
        ping_pengzi.Tishi_Show_Hua_Color(find_hua);
    }
    ReShow_Hua_Arr(ff_hua_arr,ff_bk_hua_arr)
    {
        var scomname = this.Get_Pengzi_ComName();
        var ping_pengzi = this.m_pengzi_node.getComponent(scomname);
        ping_pengzi.ReShow_Hua_Arr(ff_hua_arr,ff_bk_hua_arr);
    }
    Get_Pengzi_Pos(prline_pz_c)
    {
        var iy = Math.floor( (this.m_pengzi_index-1) /prline_pz_c);
        var ix = this.m_pengzi_index -1 - iy*prline_pz_c;

        if(prline_pz_c == 2)
        {
            var x = -150 + 300*ix;
            var y =  100 - 300*iy + 46;

            return new cc.Vec2(x,y)
        }
        if(prline_pz_c == 3)
        {
            if(this.m_destk_count == 4)
            {
                
                var x4 =  -240 + 240*ix;
                var y4 =  330- 50 - 220*iy + 46;

                return new cc.Vec2(x4,y4)
            }
            var x2 = -240 + 240*ix;
            var y2 =  200 - 250*iy+ 46;
    
            return new cc.Vec2(x2,y2)
        }
        

        var x2 = -240 + 240*ix;
        var y2 =  200 - 250*iy+ 46;

        return new cc.Vec2(x2,y2)
    }

    Get_Pos()
    {
        return this.m_pengzi_pos;
    }


    Init( pengzitype,destk_count, desk_node:cc.Node,prline_pz_c,pengzi_preab)
    {
        this.m_pengzi_type = pengzitype;
        this.m_destk_count = destk_count;
        var pz_node:cc.Node = cc.instantiate(pengzi_preab)
        desk_node.addChild(pz_node,30);

        this.m_pengzi_node = pz_node;

        var pz_pos = this.Get_Pengzi_Pos(prline_pz_c);
        this.m_pengzi_pos = pz_pos;

        this.m_pengzi_node.setPosition(pz_pos);
    }

    Get_Pengzi_Sub_Hua_Pos(isubindex)
    {
        var pos = this.m_pengzi_pos;
        var scomname = this.Get_Pengzi_ComName();

        var ping_pengzi = this.m_pengzi_node.getComponent(scomname);
        var subhua_node:cc.Node = ping_pengzi.Get_Sub_Hua_Node(isubindex);
        var subpos = subhua_node.getPosition();

        var ix = pos.x + subpos.x;
        var iy = pos.y + subpos.y;

        return new cc.Vec2(ix,iy);
    }

    Show_Selected_Pengzi_Hua_Info( selected_pz_index, selected_pz_hua_index)
    {
        var scomname = this.Get_Pengzi_ComName();

        var ping_pengzi = this.m_pengzi_node.getComponent(scomname);
   
        if(selected_pz_index == this.m_pengzi_index)
        {
            ping_pengzi.Set_Selected_Status(selected_pz_hua_index);
        }else{
            ping_pengzi.Clear_All_Selected_Status();
        }

    }
    Clear_All_Selected_Status()
    {
        var scomname = this.Get_Pengzi_ComName();

        var ping_pengzi = this.m_pengzi_node.getComponent(scomname);
        ping_pengzi.Clear_All_Selected_Status();
    }
    Show_Selected_Pengzi_Hua_On_Moveing(selected_pz_index, selected_pz_hua_index)
    {
        var scomname = this.Get_Pengzi_ComName();

        if(selected_pz_index == this.m_pengzi_index)
        {
            var ping_pengzi = this.m_pengzi_node.getComponent(scomname);
   
            ping_pengzi.Show_Selected_Pengzi_Hua_On_Moveing(selected_pz_hua_index);
        }else{
            
        }
    }
    Run_Sub_Index_Hua_Scale(ff_subidnex)
    {
        var scomname = this.Get_Pengzi_ComName();

        var ping_pengzi = this.m_pengzi_node.getComponent(scomname);
        ping_pengzi.Run_Sub_Index_Hua_Scale(ff_subidnex)
    }
    Run_Start_Show_Scale()
    {
        var scomname = this.Get_Pengzi_ComName();

        var ping_pengzi = this.m_pengzi_node.getComponent(scomname);
        ping_pengzi.Run_Start_Show_Scale()
    }
    Show_Selected_Pengzi_Hua_On_Move_End(selected_pz_index, selected_pz_hua_index)
    {
        var scomname = this.Get_Pengzi_ComName();

        if(selected_pz_index == this.m_pengzi_index)
        {
            var ping_pengzi = this.m_pengzi_node.getComponent(scomname);
   
            ping_pengzi.Show_Selected_Pengzi_Hua_On_Move_End(selected_pz_hua_index);
        }else{
            
        }
    }
}