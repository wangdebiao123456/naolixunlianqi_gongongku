import GlobalConfig from "./GlobalConfig";

  


const {ccclass, property} = cc._decorator;

@ccclass
export default class ping_dongwu extends cc.Component {

  
    
    m_hua_arr = [];
    m_bk_hua_arr = [];
    
    
    onLoad () 
    {


    }

    Tishi_Show_Sub_Index_Hua_Color(subiindex)
    {
        var iindex = subiindex;
        var ff_node = cc.find("hua/"+iindex,this.node);
        
        ff_node.stopAllActions();
        ff_node.scale = 1;

        var psclae1 = cc.sequence(cc.scaleTo(0.2,1.2),cc.scaleTo(0.4,0.9),cc.scaleTo(0.2,1));
      
        var pseq =  cc.sequence(cc.repeat(psclae1,2),cc.delayTime(0.1) );
        ff_node.runAction(pseq)
    }
    Hide_SubIndex_Hua_Show(subiindex)
    {
        var iindex = subiindex;
        var ff_node = cc.find("hua/"+iindex,this.node);
        ff_node.stopAllActions();
        ff_node.scale = 1;
        ff_node.opacity = 0;
    }
    Tishi_Show_Hua_Color(tishi_hua_v)
    {

        for(var ff=1;ff<=3;ff++)
        {
            var ff_d = this.m_hua_arr[ff -1];
            if(!ff_d)
            {
                ff_d = 0;
            }

            if(ff_d != tishi_hua_v)
            {
                continue;
            }
            var ff_node = cc.find("hua/"+ff,this.node);
        
            ff_node.stopAllActions();
            ff_node.scale = 1;
    
            var psclae1 = cc.sequence(cc.scaleTo(0.2,1.2),cc.scaleTo(0.4,0.9),cc.scaleTo(0.2,1));
          
            var pseq =  cc.sequence(cc.repeat(psclae1,2),cc.delayTime(0.3),cc.repeat(psclae1,2));
            ff_node.runAction(pseq)
        }
    }
    ReShow_Hua_Arr( hua_arr, bk_hua_arr)
    {
        this.m_hua_arr =hua_arr;
        this.m_bk_hua_arr = bk_hua_arr;
        
        var hua_sprite_list:cc.Texture2D[] = GlobalConfig.GetIns().m_pingping_dongwu_sprite_frame_list ;

        if(!hua_arr)
        {
            hua_arr = [];
        }
        if(!bk_hua_arr)
        {
            bk_hua_arr = [];
        }

        for(var ff=1;ff<=3;ff++)
        {
            var ff_d = hua_arr[ff -1];
            if(!ff_d)
            {
                ff_d = 0;
            }

            var ff_node = cc.find("hua/"+ff,this.node);
            ff_node.active = false;


            ff_node.stopAllActions();
            ff_node.scale = 1;

            if(ff_d > 0)
            {  
                ff_node.active = true;

                ff_node.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(hua_sprite_list[ff_d])  

               // BaseUIUtils.ShowIconNodePicFilename(ff_node,"pinghua/"+ff_d);
            }
        }
        for(var ff=1;ff<=3;ff++)
        {
            var ff_d = bk_hua_arr[ff -1];
            if(!ff_d)
            {
                ff_d = 0;
            }

            var ff_node = cc.find("bk_hua/"+ff,this.node);
            ff_node.active = false;

            if(ff_d > 0)
            {
                ff_node.active = true;

               // BaseUIUtils.ShowIconNodePicFilename(ff_node,"pinghua/"+ff_d);

               ff_node.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(hua_sprite_list[ff_d])  

            }
        }
    }

    Set_Selected_Status(selected_pz_hua_index)
    {
        for(var ff=1;ff<=3;ff++)
        { 
            var ff_node = cc.find("hua/"+ff,this.node);
        
            if(selected_pz_hua_index == ff)
            {
                ff_node.color = cc.color(255,0,0)

            }else{
                ff_node.color = cc.color(255,255,255)

            }

        }
    }
    Clear_All_Selected_Status()
    {
        
        for(var ff=1;ff<=3;ff++)
        { 
            var ff_node = cc.find("hua/"+ff,this.node);
            ff_node.color = cc.color(255,255,255)
            ff_node.opacity = 255;
            ff_node.stopAllActions();
            ff_node.scale = 1;
        }
    }

    Show_Selected_Pengzi_Hua_On_Moveing(pz_hua_index)
    {

        var ff_node = cc.find("hua/"+pz_hua_index,this.node);
        ff_node.opacity = 0;
    }

    Show_Selected_Pengzi_Hua_On_Move_End(pz_hua_index)
    {
        var ff_node = cc.find("hua/"+pz_hua_index,this.node);
        ff_node.opacity = 255;
    }
    Get_Sub_Hua_Node(isubindex)
    {
        var iindex = isubindex;
        var ff_node = cc.find("hua/"+iindex,this.node);
      
        return ff_node;
    }
    Run_Sub_Index_Hua_Scale(subidnex)
    {

        var ff_node = cc.find("hua/"+subidnex,this.node);

        if(!ff_node.active)
        {
            return;
        }


        
        ff_node.stopAllActions();
        ff_node.scale = 0.3;


        var psalce =  cc.sequence(cc.scaleTo(0.3,1.1),cc.scaleTo(0.1,0.9),cc.scaleTo(0.1,1)) ;
        ff_node.runAction(psalce);

    }
    Run_Start_Show_Scale()
    {
        for(var ff=1;ff<=3;ff++)
        { 
            var ff_node = cc.find("hua/"+ff,this.node);

            if(!ff_node.active)
            {
                continue;
            }


            
            ff_node.scale = 0.3;


            var psalce =  cc.sequence(cc.scaleTo(0.3,1.1),cc.scaleTo(0.1,0.9),cc.scaleTo(0.1,1)) ;
            ff_node.runAction(psalce);
        }
    }
}
