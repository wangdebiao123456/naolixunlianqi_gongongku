import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import GlobalConfig from "../GlobalConfig";

 
 
const {ccclass, property} = cc._decorator;

@ccclass
export default class huaduo_gamefail extends cc.Component {

    
    
    m_fenshu = 0;

    m_start_tick = 0;

    m_start_sound_played = 0;

    m_animate_end = 0;
    onLoad () 
    {

        this.m_start_tick = Date.now();
        var okbtn = cc.find("okbtn",this.node)
        okbtn.on("click",this.OnBtnOk.bind(this));

        
        var exitbtn = cc.find("exitbtn",this.node)
        exitbtn.on("click",this.OnBtnExit.bind(this));



        BackGroundSoundUtils.GetInstance().Play_Effect("huaduoppingping/jbibianhua");
        this.Refresh_Info();
    }
    SetInfo(pinfo)
    {
        this.m_fenshu = pinfo.fenshu;

    }
    OnBtnExit()
    {
        cc.director.loadScene("dating");

        
        BackGroundSoundUtils.GetInstance().Play_Click_Btn_Effect();
    }
    OnBtnOk()
    {
        cc.director.loadScene("huaduo_xiaoxiao");

        
        BackGroundSoundUtils.GetInstance().Play_Click_Btn_Effect();
    }

    Refresh_Info()
    {
        var maxfen = cc.find("info/maxfen",this.node)
        maxfen.getComponent(cc.Label).string = ""+GlobalConfig.GetIns().m_max_jifen;
        
    }
    

    update(dt)
    {
        if(this.m_start_tick == 0)
        {
            return;
        }
        if(this.m_animate_end)
        {
            return;
        }

        var allneedtick = 800 ;
      

        var eplasetick = Date.now() - this.m_start_tick;


      
        var fenshu = cc.find("info/fenshu",this.node)
      
        if(eplasetick >= allneedtick)
        {
             fenshu.getComponent(cc.Label).string = ""+this.m_fenshu;
      
             this.m_animate_end = 1;


             BackGroundSoundUtils.GetInstance().Play_Effect("huaduoppingping/end_jb_change");

            return;
        }

        var change_c =   Math.floor( this.m_fenshu*(eplasetick/allneedtick) );
        var scinfo = change_c ;
        fenshu.getComponent(cc.Label).string = ""+scinfo;
     

    }
}
