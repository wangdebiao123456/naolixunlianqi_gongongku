 
import BaseUIUtils from "../../comfuncs/BaseUIUtils";
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import tankuang from "../../dlg/tankuang"; 
import MiddleGamePlatformAction from "../../PlatForm/MiddleGamePlatformAction";
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";
import GlobalConfig from "../GlobalConfig";
 

const {ccclass, property} = cc._decorator;

@ccclass
export default class fuhuo_sel_dlg extends cc.Component {

 
    m_callback = null;

    m_fuhuosec = 0;
    
    onLoad () 
    {

        var tankuang:tankuang = this.node.getComponent("tankuang");
        tankuang.Set_Close_Lisnter(this);
        var fuhuobtn = cc.find("panel/mianfeibtn",this.node);

        fuhuobtn.on("click",this.OnBtnFuhuo.bind(this));


        var jinbigoumai = cc.find("panel/jinbigoumai",this.node);

        jinbigoumai.on("click",this.OnBtnJinbiFuhuo.bind(this));

        
        BackGroundSoundUtils.GetInstance().Play_Effect("huaduoppingping/shibai");

        
        MiddleGamePlatformAction.GetInstance().Check_BK_Create_GameFail_Banners();
 
        BannerGuangaoMng.GetInstance().CheckShowChaiping(32);
    }

    SetInfo(pinfo)
    {
        this.m_callback = pinfo.callback;
        this.m_fuhuosec = pinfo.fuhuosec;

        this.Refresh_Info();


        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(4);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,true);

        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(6);

    }
    On_TK_Real_Exit()
    {
        this.OnBtnExit();
    }
    On_Tankuang_Real_Exit()
    {
        this.OnBtnExit();
    }
    OnBtnExit()
    {
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
     
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,false);


        this.node.destroy();

        if(this.m_callback)
        {
            this.m_callback(0);
        }


    }
    Real_Fuhuo()
    {
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
     
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,false);

        this.node.destroy();

        if(this.m_callback)
        {
            this.m_callback(1);
        }
    }
    OnBtnFuhuo()
    {
 
        var self = this; 
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,()=>{},
            
            "手动全军满血",(bsuc)=>
        {
            if(!bsuc)
            { 
                return;
            }
            self.Real_Fuhuo();

            BackGroundSoundUtils.GetInstance().ResumeBkMusic();
        }
        );
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
     
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,false);

    }

    Refresh_Info()
    {
        var cur_jinbi_c = GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(1);
        var addjinbi_c_node = cc.find("panel/top/addjinbi/c",this.node);
        addjinbi_c_node.getComponent(cc.Label).string = ""+cur_jinbi_c;
    

        var addsec_c_node = cc.find("panel/addsec",this.node);
        addsec_c_node.getComponent(cc.Label).string = "+"+this.m_fuhuosec+"s";
     
    }

    OnBtnJinbiFuhuo()
    {
        var cur_jinbi_c = GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(1);
        if(cur_jinbi_c < 500)
        {
            BaseUIUtils.ShowTipTxtDlg("金币不足",this.node)
            return;
        }
        GlobalConfig.GetIns().Change_Self_DaojuType_Count(1,-500);
        this.Real_Fuhuo();


    }
}
