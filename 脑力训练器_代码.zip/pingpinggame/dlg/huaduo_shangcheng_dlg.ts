import BaseUIUtils from "../../comfuncs/BaseUIUtils";
import ComFunc from "../../comfuncs/ComFunc";
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import tankuang from "../../dlg/tankuang";
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import { Utils } from "../../WDT/Utils";
import GlobalConfig from "../GlobalConfig";


const {ccclass, property} = cc._decorator;

@ccclass
export default class shangcheng_dlg extends cc.Component {

  
    
    m_callback = null;
    
    onLoad () 
    {


        for(var ff=1;ff<=5;ff++)
        {
            var ff_shipng_btn = cc.find("panel/sc/view/content/"+ff+"/shiping_btn",this.node);
            ff_shipng_btn.on("click",this.OnBtnShiping.bind(this,ff))
        }


        for(var ff=2;ff<=5;ff++)
        {
            var ff_jinbibtn = cc.find("panel/sc/view/content/"+ff+"/jinbibtn",this.node);
            ff_jinbibtn.on("click",this.OnBtnJinbi.bind(this,ff))
        }


        

        BackGroundSoundUtils.GetInstance().Play_Click_Btn_Effect();
        var tankuang:tankuang = this.node.getComponent("tankuang");
        tankuang.Set_Close_Lisnter(this);


        this.Refresh_Info();
 
    }
    Refresh_Info()
    {

        var jinib_c_label  = cc.find("panel/top/jinbi/c",this.node);

        jinib_c_label.getComponent(cc.Label).string = ""+GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(1);

    }
   
    
    Get_Award(iindex)
    {
        var awrad = [{"t":1,"c":200}];

        if(iindex == 2)
        {
            awrad = [{"t":21,"c":2}];
        } 
        else if(iindex == 3)
        {
            awrad = [{"t":22,"c":1}];
        }else if(iindex == 4)
        {
            awrad = [{"t":23,"c":2}];
        }else if(iindex == 5)
        {
            awrad = [{"t":24,"c":1}];
        }
        
        return awrad;
    }

    Real_Shiping_Get(iindex)
    {
        var awrad =  this.Get_Award(iindex);
        var self = this;
   

        GlobalConfig.GetIns().Common_Add_Award_List(awrad);
        this.Refresh_Info();
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrad, 1, ()=>
        {
            BaseUIUtils.ShowTipTxtDlg("视频获取道具成功",self.node)
        });
    }
    OnBtnJinbi(iindex)
    {
        var needc = 200;

        if(iindex == 5 || iindex == 3)
        {
            needc = 300;
        }
         

        if(GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(1) < needc)
        {

            BaseUIUtils.ShowTipTxtDlg("金币不足",this.node);
            return;
        }
        GlobalConfig.GetIns().Change_Self_DaojuType_Count(1,-1*needc);


        var awrad =  this.Get_Award(iindex);


        var self = this;
   

        GlobalConfig.GetIns().Common_Add_Award_List(awrad);
    
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrad, 1, ()=>
        {
            BaseUIUtils.ShowTipTxtDlg("金币购买道具成功",self.node)
        });
    }
    OnBtnShiping(iindex)
    {
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "签到双倍",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.Real_Shiping_Get(iindex)

        });
    }
    On_Tankuang_Real_Exit()
    {
         this.OnBtnExit();
    }

    OnBtnExit()
    {
         
         this.node.destroy();
        if(this.m_callback)
        {
            this.m_callback();
        } 
      
    }
    SetInfo(pinfo)
    {
         
        this.m_callback = pinfo.callback;

    }

}
