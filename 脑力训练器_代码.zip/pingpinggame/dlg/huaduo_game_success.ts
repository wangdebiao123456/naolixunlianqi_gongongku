import MiddleGamePlatformAction from "../../PlatForm/MiddleGamePlatformAction";
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";
import GlobalConfig from "../GlobalConfig";

 
 
 
const {ccclass, property} = cc._decorator;

@ccclass
export default class huaduo_game_success extends cc.Component {

    
    
    m_fenshu = 0;

    m_start_tick = 0;

    m_start_sound_played = 0;

    m_animate_end = 0;
    m_gk = 1;


    onLoad () 
    {

        this.m_start_tick = Date.now();

        var okbtn = cc.find("okbtn",this.node)
        okbtn.on("click",this.OnBtnOk.bind(this));


        var exitbtn = cc.find("exitbtn",this.node)
        exitbtn.on("click",this.OnBtnExit.bind(this));



        BackGroundSoundUtils.GetInstance().Play_Effect("huaduoppingping/jbibianhua");
        this.Refresh_Info();
    }
    OnBtnExit()
    {
        cc.director.loadScene("dating");

        
        BackGroundSoundUtils.GetInstance().Play_Click_Btn_Effect();
    }
    SetInfo(pinfo)
    {
        this.m_fenshu = pinfo.fenshu;
        this.m_gk = pinfo.gk;

        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(4);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,true);

        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(6);
    }

    OnBtnOk()
    {
        GlobalConfig.GetIns().Add_Cunqian_Guan_Money(20);
        GlobalConfig.GetIns().Enter_Game_Mode(GlobalConfig.GetIns().m_enter_mode)
        cc.director.loadScene("huaduo_xiaoxiao");

        
        BackGroundSoundUtils.GetInstance().Play_Click_Btn_Effect();
    }

    Refresh_Info()
    {
        var maxfen = cc.find("info/maxfen",this.node)
        maxfen.getComponent(cc.Label).string = GlobalConfig.GetIns().m_max_jifen+""
    }
    

    update(dt)
    {
        if(this.m_start_tick == 0)
        {
            return;
        }
        if(this.m_animate_end)
        {
            return;
        }

        var allneedtick = 800 ;
      

        var eplasetick = Date.now() - this.m_start_tick;


      
        var fenshu = cc.find("info/fenshu",this.node)
      
        if(eplasetick >= allneedtick)
        {
             fenshu.getComponent(cc.Label).string = ""+this.m_fenshu;
      
             this.m_animate_end = 1;


             BackGroundSoundUtils.GetInstance().Play_Effect("end_jb_change");

            return;
        }

        var change_c =   Math.floor( this.m_fenshu*(eplasetick/allneedtick) );
        var scinfo = change_c ;
        fenshu.getComponent(cc.Label).string = ""+scinfo;
     

    }
}
