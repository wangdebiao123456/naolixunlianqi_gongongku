import shouzhiZhiyingDlg from "./shouzhiZhiyingDlg";

 


export default class YDActionMng {
    private static _instance: YDActionMng = null;

    public static getInstance(): YDActionMng {
        if (!this._instance) {
            this._instance = new YDActionMng();
        }
        return this._instance;
    }


    constructor()
    {

    }
    Show_Shouzhi_Tip_Yingdao_RC(yingdao_shou_dianji,stip, parentnode,rc_info,callback = null ,addtion_pos_rect_arr = null,show_tip_pt = null,
        valid_click_pos_rect_arr = null,hide_shubiao = false,exit_sec = 0)
    {
        let pnode :cc.Node = cc.instantiate(yingdao_shou_dianji as cc.Prefab);
        parentnode.addChild(pnode,280);
       // pnode.setPosition(pos);
        var yingdao_shou_dianji = pnode.getComponent("yingdao_shou_dianji");
        yingdao_shou_dianji.Init_RC(rc_info,callback,stip,addtion_pos_rect_arr,show_tip_pt,valid_click_pos_rect_arr);

        if(hide_shubiao)
        {
            yingdao_shou_dianji.Hide_Shubiao();
        }

        if(exit_sec && exit_sec > 0)
        {
            yingdao_shou_dianji.Set_Delay_Exit_Sec(exit_sec)
        }
    }
    Show_Shouzhi_Tip_Yingdao_P( yingdao_shou_dianji,stip, parentnode,guideNode: any,callback = null ,
        addtion_pos_rect_arr = null,show_tip_pt = null,
        valid_click_pos_rect_arr = null,hide_shubiao = false,exit_sec = 0)
    {
        let world = guideNode.parent.convertToWorldSpaceAR(guideNode.position);
        let pos = parentnode.convertToNodeSpaceAR(world);

        let pnode :cc.Node = cc.instantiate(yingdao_shou_dianji as cc.Prefab);
        parentnode.addChild(pnode,280);
       // pnode.setPosition(pos);
        var yingdao_shou_dianji = pnode.getComponent("yingdao_shou_dianji");
        yingdao_shou_dianji.Init(pos,guideNode,callback,stip,addtion_pos_rect_arr,show_tip_pt,valid_click_pos_rect_arr)
        if(hide_shubiao)
        {
            yingdao_shou_dianji.Hide_Shubiao();
        }

        if(exit_sec && exit_sec > 0)
        {
            yingdao_shou_dianji.Set_Delay_Exit_Sec(exit_sec)
        }
    }
    Pop_Yingdao_TipInfo_Dlg_P(yindaotip_dlg_preab, parentnode,stip,callback)
    {
        let pnode :cc.Node = cc.instantiate(yindaotip_dlg_preab as cc.Prefab);
        parentnode.addChild(pnode,80);
        var yingdaotipdlg = pnode.getComponent("yingdaotipdlg");
        if(yingdaotipdlg &&  yingdaotipdlg.init)
        { 
            yingdaotipdlg.init(stip,callback);

        }
       
    }

    Pop_DelayTime_Dlg(parentnode,delaytime,callback)
    {
        cc.resources.load("yingdaoshou/DelayTimeShowDlg",   (err, prefab) =>{
            if (err) { 
                callback();
                return
             }

             let pnode :cc.Node = cc.instantiate(prefab as cc.Prefab);
             parentnode.addChild(pnode,80);
          
             var DelayTimeShowDlg = pnode.getComponent("DelayTimeShowDlg");
             DelayTimeShowDlg.Init(delaytime,callback)
            // FingerGuide.changeMiddleWidth(guideNode);

 
            
        }); 

    }
    /**
     * 戴手指的引导
     * @param guideNode
     */
     ShowShouzhiYingdao(parentnode,guideNode: any,callback = null,stip="") {

        let world = guideNode.parent.convertToWorldSpaceAR(guideNode.position);
        let pos = parentnode.convertToNodeSpaceAR(world);
        cc.resources.load("yingdaoshou/shouzhiZhiyingDlg",   (err, prefab) =>{
            if (err) { 
                callback();
                return
             }

             let pnode :cc.Node = cc.instantiate(prefab as cc.Prefab);
             parentnode.addChild(pnode,80);
            // pnode.setPosition(pos);
             var shouzhiZhiyingDlg = pnode.getComponent("shouzhiZhiyingDlg");
             shouzhiZhiyingDlg.Init(pos,guideNode,callback,stip)
       
 
            
        }); 
      
    }
    
    ShowShouzhiYingdao_P( shouzhiZhiyingDlg_preab, parentnode,guideNode: any,callback = null,stip="")
    {
        let world = guideNode.parent.convertToWorldSpaceAR(guideNode.position);
        let pos = parentnode.convertToNodeSpaceAR(world);

        let pnode :cc.Node = cc.instantiate(shouzhiZhiyingDlg_preab as cc.Prefab);
        parentnode.addChild(pnode,80);
       // pnode.setPosition(pos);
        var shouzhiZhiyingDlg = pnode.getComponent("shouzhiZhiyingDlg");
        shouzhiZhiyingDlg.Init(pos,guideNode,callback,stip)
 
    }
    Pop_DelayTime_Dlg_P(delayTime_dlg_preab:cc.Prefab, parentnode,delaytime,callback)
    {
        let pnode :cc.Node = cc.instantiate(delayTime_dlg_preab as cc.Prefab);
        parentnode.addChild(pnode,80);
     
        var DelayTimeShowDlg = pnode.getComponent("DelayTimeShowDlg");
        DelayTimeShowDlg.Init(delaytime,callback)

    }

    Pop_Yingdao_TipInfo_Dlg(parentnode,stip,callback)
    {
        cc.resources.load("yingdaoshou/yingdaotipdlg",   (err, prefab) =>{
            if (err) { 
                callback();
                return
             }
            let pnode :cc.Node = cc.instantiate(prefab as cc.Prefab);
            parentnode.addChild(pnode,80);
            var yingdaotipdlg = pnode.getComponent("yingdaotipdlg");
            if(yingdaotipdlg &&  yingdaotipdlg.init)
            { 
                yingdaotipdlg.init(stip,callback);

            }
            
        }); 
    }
    ShowShouzhiYingdao_Pos( shouzhiZhiyingDlg_preab, parentnode,guidpos: cc.Vec2,guide_size,callback = null,stip="")
    { 

        let pnode :cc.Node = cc.instantiate(shouzhiZhiyingDlg_preab as cc.Prefab);
        parentnode.addChild(pnode,280);
       // pnode.setPosition(pos);
        var shouzhiZhiyingDlg:shouzhiZhiyingDlg = pnode.getComponent("shouzhiZhiyingDlg");
        shouzhiZhiyingDlg.Init_2(guidpos,guide_size,callback,stip)
 
    }
}