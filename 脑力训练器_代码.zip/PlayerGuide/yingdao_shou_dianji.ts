 
const {ccclass, property} = cc._decorator;

@ccclass
export default class yingdao_shou_dianji extends cc.Component {
 
    m_call_func = null;
    graphics: cc.Graphics = null;

    m_valid_click_pos_rect_arr =  [];



     onLoad () {
        var btn = cc.find("btn",this.node);
        btn.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
    
        
       // var middle_node:cc.Node = cc.find("mask/middle/center",this.node);
       // middle_node.on("click",this.OnBtn_Tuichu.bind(this));

        var masknode = this.node.getChildByName("mask_zhezhao");
        var g_mask = masknode.getComponent(cc.Mask);
        let graphics:cc.Graphics = g_mask[ '_graphics'];

        this.graphics = graphics;
     }

     Set_Delay_Exit_Sec(isec)
     {
        this.scheduleOnce(this.FD_Exit.bind(this),isec)
     }
     FD_Exit()
     {
        if(this.m_call_func)
        {
            this.m_call_func();
        }

        this.node.destroy();
     }

     onTouchStart(event) 
    {
        var btn = cc.find("btn",this.node);
       
        var pos = btn.convertToNodeSpaceAR(event.getLocation());
       
        var bvalid = false;


        for(var ff=0;ff<this.m_valid_click_pos_rect_arr.length;ff++)
        {
            var ff_info   = this.m_valid_click_pos_rect_arr[ff];
            var ff_cneter_pos  = ff_info.pos;
            var ff_w = ff_info.width;
            var ff_h = ff_info.height;

            var minx = ff_cneter_pos.x - ff_w/2;
            var maxx = ff_cneter_pos.x + ff_w/2;
            

            var miny = ff_cneter_pos.y - ff_h/2;
            var maxy = ff_cneter_pos.y + ff_h/2;


            if(minx < pos.x && pos.x < maxx)
            {
                if(miny < pos.y && pos.y < maxy)
                {
                    bvalid = true;
                } 
            }
            
        }

        if(!bvalid)
        {
            return;
        }

        if(this.m_call_func)
        {
            this.m_call_func();
        }

        this.node.destroy();

    }
     OnBtn_Click_BK()
     {

     }
     OnBtn_Tuichu()
     {
         if(this.m_call_func)
         {
             this.m_call_func();
         }

         this.node.destroy();
     }
     
     ClarAll()
     {
         this.graphics.clear(true);
     }
     Draw_Per_RC(ff_rc)
     {
        var pos = ff_rc.pos;
        var iw = ff_rc.width;
        var ih = ff_rc.height;
        
        var let_top_pos = new cc.Vec2(pos.x - iw/2,pos.y- ih/2);
        var right_top_pos = new cc.Vec2(pos.x  + iw/2,pos.y- ih/2);
        var right_bottom_pos = new cc.Vec2(pos.x  + iw/2,pos.y+ ih/2);
        var left_bottom_pos = new cc.Vec2(pos.x  - iw/2,pos.y+ ih/2);

        var rc1 =  cc.Rect.fromMinMax(let_top_pos,right_bottom_pos)
        this.graphics.fillRect(let_top_pos.x,let_top_pos.y,iw,ih)
        /*
        this.graphics.moveTo(let_top_pos.x,let_top_pos.y);

        this.graphics.lineTo(right_top_pos.x,right_top_pos.y);
        this.graphics.lineTo(right_bottom_pos.x,right_bottom_pos.y);
        this.graphics.lineTo(left_bottom_pos.x,left_bottom_pos.y);
        this.graphics.lineTo(let_top_pos.x,let_top_pos.y);
*/

     }
     Draw_All_Mask_Rect(target_rc_info,addtion_pos_rect_arr  = null)
     {
        this.graphics.clear(true);


        this.Draw_Per_RC(target_rc_info);

        if(addtion_pos_rect_arr)
        {
            for(var ff=0;ff<addtion_pos_rect_arr.length;ff++)
            {
                var ff_rc = addtion_pos_rect_arr[ff];
                this.Draw_Per_RC(ff_rc);

            }
        }

     }

     Init_RC(rc_info,callback,stip,addtion_pos_rect_arr= null,show_tip_pt= null,valid_click_pos_rect_arr = null)
     {
        this.node.active = true;
        if (stip) {
          //  this.Tip.string = stip;
        }
        this.m_call_func = callback;
 
        var masknode = this.node.getChildByName("mask_zhezhao");
        var g_mask = masknode.getComponent(cc.Mask);
        let graphics:cc.Graphics = g_mask[ '_graphics'];

        this.graphics = graphics;

        var my_finger_node:cc.Node = cc.find("finger",this.node);

        var center_rc = rc_info

        this.Draw_All_Mask_Rect(center_rc,addtion_pos_rect_arr);

        if(valid_click_pos_rect_arr && valid_click_pos_rect_arr.length > 0)
        {
            this.m_valid_click_pos_rect_arr = valid_click_pos_rect_arr;
        }else{
            this.m_valid_click_pos_rect_arr = [];
            
            this.m_valid_click_pos_rect_arr.push(center_rc)
        }

      //  my_effect_node.setPosition(pos);

     
       var iw1 = center_rc.width;
       var ih1 = center_rc.height;

        my_finger_node.setPosition(center_rc.pos.x + iw1/2+8,center_rc.pos.y);
        this.handAction();



 

        var qipaotishi_node:cc.Node = cc.find("qipaotishi",this.node);
    




        if(stip)
        {
            

            var qipai_bk:cc.Node = cc.find("qipaotishi/info/bk",this.node);
            var qipai_bk2:cc.Node = cc.find("qipaotishi/info/bk2",this.node);
          


            var stip_node:cc.Node = cc.find("qipaotishi/info/stip",this.node);
            stip_node.getComponent(cc.Label).string = stip;
            qipaotishi_node.active = true;
            qipaotishi_node.x = center_rc.pos.x;

            if(center_rc.pos.y > 200)
            {
                qipaotishi_node.y = center_rc.pos.y-ih1/2 - 70;

                qipai_bk.active = false;
                qipai_bk2.active = true;
           
            }else{
                qipaotishi_node.y = center_rc.pos.y+ih1/2 + 52;
                qipai_bk.active = true;
                qipai_bk2.active = false;
            }

           

            if(show_tip_pt)
            {
                qipaotishi_node.x=  show_tip_pt.x;
                qipaotishi_node.y=  show_tip_pt.y;
            }

        }
        else{
            qipaotishi_node.active = false;
        }
     }
     Hide_Shubiao()
     {
        var my_finger_node:cc.Node = cc.find("finger",this.node);
        my_finger_node.active = false;
     }
     //:addtion_pos_rect_arr 数组  里面为  {pos:  width  height }
    Init(pos:cc.Vec2, guideNode:cc.Node,callback,stip,addtion_pos_rect_arr = null,show_tip_pt = null,
        valid_click_pos_rect_arr = null
        )
    {
        this.node.active = true;
        if (stip) {
          //  this.Tip.string = stip;
        }
        this.m_call_func = callback;

        
        var masknode = this.node.getChildByName("mask_zhezhao");
        var g_mask = masknode.getComponent(cc.Mask);
        let graphics:cc.Graphics = g_mask[ '_graphics'];

        this.graphics = graphics;
       // this.changeMiddleWidth(guideNode);

       
        

        var iw1 =  guideNode.width;
        var ih1 =  guideNode.height;


       // var my_effect_node:cc.Node = cc.find("effect",this.node);
        var my_finger_node:cc.Node = cc.find("finger",this.node);

        var center_rc = {pos:pos,width:iw1,height:ih1}

        this.Draw_All_Mask_Rect(center_rc,addtion_pos_rect_arr);

        if(valid_click_pos_rect_arr && valid_click_pos_rect_arr.length > 0)
        {
            this.m_valid_click_pos_rect_arr = valid_click_pos_rect_arr;
        }else{
            this.m_valid_click_pos_rect_arr = [];
            
            this.m_valid_click_pos_rect_arr.push(center_rc)
        }

      //  my_effect_node.setPosition(pos);

     
       

        my_finger_node.setPosition(pos.x + iw1/2+8,pos.y);
        this.handAction();



 

        var qipaotishi_node:cc.Node = cc.find("qipaotishi",this.node);
    



        if(stip)
        {
            var qipai_bk:cc.Node = cc.find("qipaotishi/info/bk",this.node);
            var qipai_bk2:cc.Node = cc.find("qipaotishi/info/bk2",this.node);
          


            var stip_node:cc.Node = cc.find("qipaotishi/info/stip",this.node);
            stip_node.getComponent(cc.Label).string = stip;
            qipaotishi_node.active = true;
            qipaotishi_node.x = center_rc.pos.x;

            if(center_rc.pos.y > 200)
            {
                qipaotishi_node.y = center_rc.pos.y-ih1/2 - 70;

                qipai_bk.active = false;
                qipai_bk2.active = true;
           
            }else{
                qipaotishi_node.y = center_rc.pos.y+ih1/2 + 52;
                qipai_bk.active = true;
                qipai_bk2.active = false;
            }

           

            if(show_tip_pt)
            {
                qipaotishi_node.x=  show_tip_pt.x;
                qipaotishi_node.y=  show_tip_pt.y;
            }

        }
        else{
            qipaotishi_node.active = false;
        }

        
        
    }
    changeMiddleWidth(guideNode)
    {

    }
    handAction() {
        var finger_node:cc.Node = cc.find("finger",this.node);

        let time = 0.6;
        cc.tween(finger_node)
            .repeatForever(
                cc.tween()
                    .to(time, {scale: 0.8})
                    .to(time, {scale: 1})
            )
            .start();
        /*
        var finger_node:cc.Node = cc.find("finger",this.node);

        let time = 0.6;
        cc.tween(finger_node)
            .repeatForever(
                cc.tween()
                    .to(time, {scale: 0.8 * 0.5})
                    .to(time, {scale: 0.5})
            )
            .start();

            */
    }



}
