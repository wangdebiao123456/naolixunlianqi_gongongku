 
const {ccclass, property} = cc._decorator;

@ccclass
export default class DelayTimeShowDlg extends cc.Component {

   m_delay_sec = 0;
   m_callback_func = null;
    
    onLoad () {}

    
    Init(delaysec,callback)
    {
        this.m_delay_sec = delaysec;
        this.m_callback_func = callback;
         
        this.scheduleOnce(this.FD_Dlg_End.bind(this),delaysec)
    }

    FD_Dlg_End()
    {
        this.node.destroy();

        if(this.m_callback_func)
        {
            this.m_callback_func();
        }
    }
}
