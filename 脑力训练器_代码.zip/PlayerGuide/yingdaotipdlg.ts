import XJS_GameInfoManager from "../manager/XJS_GameInfoManager";
 

import ClientLogUtils from "../comfuncs/ClientLogUtils"; 
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";
 

const {ccclass, property} = cc._decorator;

@ccclass
export class yingdaotipdlg extends cc.Component {

    @property({type: cc.Label, tooltip: '文字'})
    Tip: cc.Label = null;

    @property({type: cc.Node, tooltip: 'bg'})
    Bg: cc.Node = null;

    m_call_func = null;

    m_strinfo = "";

    onLoad()
    {
        var bk = this.node.getChildByName("bk");
        bk.on("click",this.OnBtnExit.bind(this));


        var dlg = this.node.getChildByName("dlg");
        dlg.on("click",this.OnBtnExit.bind(this));
 
    }

   
    init(str,callback) {
        this.node.active = true;

        var real_Str =  str;

        this.m_strinfo = real_Str;
        this.Tip.string = real_Str;
        this.m_call_func = callback;

   
    }
    OnBtnExit()
    {
        this.node.destroy();
       
        if(this.m_call_func)
        {
            this.m_call_func();
        }

       
        
    //    ClientLogUtils.GetInstance().Poset_Server_JS_Log( 1105 ,"指引对话",2,  this.m_strinfo,0,"",0,"");
    }
 

     

  
}
