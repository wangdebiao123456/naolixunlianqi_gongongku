import ComFunc from "../comfuncs/ComFunc";


const {ccclass, property} = cc._decorator;

@ccclass
export default class dianji_shou_tishi extends cc.Component {

   
    
    m_cb = null;
    m_delaydestroytime = 0;

    m_b_exited = 0;
    
    onLoad () 
    {

      
    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;
        this.m_delaydestroytime = paradata.delaydestroytime;
       
        this.Init();
    }

    FD_Check_Auto_Distroy()
    {
        if(this.m_b_exited)
        {
            return;
        }

        this.m_b_exited = 1;
   
        this.node.destroy();
       
        if(this.m_cb)
        {
            this.m_cb(0);
        }
    }
    OnBtnExit()
    {

        this.m_b_exited = 1;
   
        this.node.destroy();
       
        if(this.m_cb)
        {
            this.m_cb(1);
        }
 
       // ComFunc.Play_Click_Open_Dlg_Btn_Sound();
    }
    Init()
    {
        this.handAction();

        if(this.m_delaydestroytime > 0)
        {
            this.scheduleOnce(this.FD_Check_Auto_Distroy.bind(this),this.m_delaydestroytime)
        }
    }
    handAction() {

        var tip1_node:cc.Node = cc.find("panel/tip1",this.node);

        var pseq = cc.sequence(cc.scaleTo(0.2,1.02),cc.scaleTo(0.2,1));
        var pseq2 = cc.sequence(cc.targetedAction(tip1_node,pseq),cc.delayTime(0.1));

        tip1_node.runAction(cc.repeatForever(pseq))
        


        {
            var  quan_node:cc.Node = cc.find("panel/quan",this.node);


            var pseq3 = cc.sequence(cc.scaleTo(0.1,1.1),cc.scaleTo(0.1,1));
            //  var pseq4 = cc.sequence(cc.targetedAction(quan_node,pseq) );
        
            quan_node.runAction(cc.repeatForever(pseq3))
        }


        {

            var  guan_node:cc.Node = cc.find("panel/quan/shouzhi",this.node);


            var pseq3 = cc.sequence(cc.scaleTo(0.1,1.3),cc.scaleTo(0.1,1),cc.show(),cc.delayTime(0.1),cc.show());
            var pseq4 = cc.targetedAction(guan_node,pseq3)
        
            this.node.runAction(cc.repeatForever(pseq4))

        }
        
    
     
    }

}
