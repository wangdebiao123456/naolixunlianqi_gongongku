 
const {ccclass, property} = cc._decorator;

@ccclass
export default class contine_prev_luosihecheng_dlg extends cc.Component {

  
    m_cb = null;
    
    onLoad () 
    {
        var startnewgame = cc.find("startnewgame",this.node);
        startnewgame.on("click",this.OnBtnStartNewGame.bind(this))

        var jixuyouxi = cc.find("jixuyouxi",this.node);
        jixuyouxi.on("click",this.OnBtnJixuYouxi.bind(this))


      
      
        this.RefreshInfo();

    }

    RefreshInfo()
    {
        
    }
    SetInitData(paradata)
    {
        this.m_cb  = paradata.cb;
      

    }
    OnBtnStartNewGame()
    { 
        if(this.m_cb)
        {
            this.m_cb(2);
        }

        this.node.destroy();
    }

    Real_Jixu_Youxi()
    { 
        if(this.m_cb)
        {
            this.m_cb(1);
        }

        this.node.destroy();
    }
    OnBtnJixuYouxi()
    {
        this.Real_Jixu_Youxi();
         
       
    }


}
