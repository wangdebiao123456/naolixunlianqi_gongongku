import ComFunc from "../../comfuncs/ComFunc";
import XJS_GameInfoManager from "../../manager/XJS_GameInfoManager";
import BackGroundSoundUtils from "../../WDT/BackGroundSoundUtils";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class chuangong_success_dlg extends cc.Component {

    
    m_isubgametype = 0;
    m_guoguang_jl = [];

    m_b_lingqued = 0;

    @property(cc.Node)
    chuizi:cc.Node = null;

    @property(cc.Node)
    zuanshi:cc.Node = null;
 
    
    onLoad () 
    {
        var quedingbtn = cc.find("panel/quedingbtn",this.node)
        quedingbtn.on("click",this.OnBtnExit.bind(this))

        BackGroundSoundUtils.GetInstance().Play_Effect('com/victory');
    }

    SetInfo(paradata)
    {
        this.m_isubgametype = paradata.isubgametype;
        this.m_guoguang_jl = paradata.guoguang_jl;

        if(!this.m_guoguang_jl )
        {
            this.m_guoguang_jl  = [];
        }


        this.Refresh_Info();
    }

    OnBtnExit()
    {
        if(this.m_b_lingqued)
        {
            return;
        }
        this.m_b_lingqued = 1;
        var quedingbtn = cc.find("panel/quedingbtn",this.node);
        quedingbtn.active = false;
        XJS_GameInfoManager.GetInstance().Add_DaojuType_Count_List(this.m_guoguang_jl,1);

        this.Add_Move_Daoju_Anim();

        this.scheduleOnce(this.FD_Exit_To_Dating.bind(this),1);

        BackGroundSoundUtils.GetInstance().Play_Effect("com/huode_shengji")
    }
    FD_Exit_To_Dating()
    {
        this.Refresh_Info();
        cc.director.loadScene("dating")
    }

    Refresh_Info()
    {
           
        for(var ff=1;ff<=2;ff++)
        {
            var wuping_ff_node = cc.find("panel/wuping/"+ff,this.node);

            if(ff > this.m_guoguang_jl.length)
            {
                wuping_ff_node.active = false;
            }else{
                wuping_ff_node.active = true;

                var ff_jl = this.m_guoguang_jl[ff-1];
                var ff_t=  ff_jl.t;
                var ff_c=  ff_jl.c  ;
                
                wuping_ff_node.getChildByName("c").getComponent(cc.Label).string = "+"+ff_c;
                var icon_node = wuping_ff_node.getChildByName("icon");

               // var icon_sfilename = XJS_GameInfoManager.GetInstance().Get_Aawrd_Daoju_Icon(ff_t);
              //  BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",icon_node,icon_sfilename,{width:110,height:110})
            }
     
        }

        
        var addchuizi_c_label = cc.find("panel/top/addchuizi/c",this.node);
        addchuizi_c_label.getComponent(cc.Label).string = ""+XJS_GameInfoManager.GetInstance().Get_Self_DestType_Daoju_Count(6)


        var addzuanshi_label = cc.find("panel/top/addzuanshi/c",this.node);
        addzuanshi_label.getComponent(cc.Label).string = ""+XJS_GameInfoManager.GetInstance().Get_Self_DestType_Daoju_Count(5)

        var gamename_label = cc.find("panel/gamename",this.node);
     
        var sgamename =  "";

        gamename_label.getComponent(cc.Label).string = sgamename+"挑战成功";  

    }
    Add_Chuzi_Move_Anim()
    {
        var quedingbtn = cc.find("panel/quedingbtn",this.node);
        var from_pos = ComFunc.NodeWorldPos(quedingbtn);
     

        var addchuizi = cc.find("panel/top/addchuizi",this.node);
        var chuizi_dest_pos = ComFunc.NodeWorldPos(addchuizi);
     
        var ff_node  =cc.instantiate(this.chuizi);
        this.node.addChild(ff_node,10);

        var ix = Math.random() * 100 - 50 -50;
        var iy = Math.random() * 100 - 50;

        var fromx = from_pos.x + ix;
        var fromy = from_pos.y + iy;
        ff_node.setPosition(fromx,fromy);
       

        var pseq = cc.sequence(cc.delayTime(0.2),cc.targetedAction(ff_node,cc.moveTo(0.5,chuizi_dest_pos)) ,
            cc.callFunc(
                ()=>
                {
                    ff_node.destroy();
                }
            )
        );

        this.node.runAction(pseq);

    }
    Add_Zuanshi_Move_Anim()
    {
        var quedingbtn = cc.find("panel/quedingbtn",this.node);
        var from_pos = ComFunc.NodeWorldPos(quedingbtn);
     

        var addchuizi = cc.find("panel/top/addzuanshi",this.node);
        var chuizi_dest_pos = ComFunc.NodeWorldPos(addchuizi);
     
        var ff_node  =cc.instantiate(this.zuanshi);
        this.node.addChild(ff_node,10);

        var ix = Math.random() * 100 - 50+50;
        var iy = Math.random() * 100 - 50;

        var fromx = from_pos.x + ix;
        var fromy = from_pos.y + iy;
        ff_node.setPosition(fromx,fromy);
       

        var pseq = cc.sequence(cc.delayTime(0.2),cc.targetedAction(ff_node,cc.moveTo(0.5,chuizi_dest_pos)) ,
            cc.callFunc(
                ()=>
                {
                    ff_node.destroy();
                }
            )
        );

        this.node.runAction(pseq);
    }
    Add_Move_Daoju_Anim()
    {
       

        var all_del_node_list = [];
        
        for(var ff=1;ff<=5;ff++)
        {
            this.Add_Chuzi_Move_Anim();
          
        }

 
        for(var ff=1;ff<=5;ff++)
        {
            this.Add_Zuanshi_Move_Anim();
          
        }
    }
}
