import ComFunc from "../comfuncs/ComFunc";
import MyLocalStorge from "../WDT/MyLocalStorge";
import WMap from "../WDT/WMap";

 

export default class TiaozhanChang_Mng
{
    static _instance:TiaozhanChang_Mng = null;
    static GetInstance() 
    {
        if (!TiaozhanChang_Mng._instance) {
            // doSomething
            TiaozhanChang_Mng._instance = new TiaozhanChang_Mng();
             
        }
        return TiaozhanChang_Mng._instance;
    }


    //没有完成挑战场，直接退出的，下次进入后直接回到--目前只有subtype:9也就是三消消挑战用到
    m_last_unfinished_tiaozhanchang_subgametype = 0;
    m_first_start_from_dating_restor_subgametype =  0;

    //1:初级简单示意关，2：正式关卡,9:引导关
    m_cur_tiaozhanchang_gk_index = 0;

    m_cur_tiaozhanchang_failed_fuhuo_count = 0;
    m_subgametype_cur_skilltype_used_count_map = new WMap();


    m_last_tiaozhan_day_union = 0;

    //每个挑战场今日挑战次数
    m_subgametype_curday_tiaozhaned_count_map = new WMap();
    m_subgametype_curday_tiaozhan_successed_count_map = new WMap();
    m_subgametype_curday_tiaozhan_failed_count_map = new WMap();


   // m_luosi_paixu_tiaozhanchang_yingdaoed = 1;

  
    constructor()
    {

        this.InitRead_Game_Basic_Info();

    }



    InitRead_Game_Basic_Info()
    {   
        var str= MyLocalStorge.getItem("guaishouxiaochu_tiaozhanchang_info");
        if(!str)
        {
            return;
        }

        var basic_obj = JSON.parse(str);
        if(!basic_obj)
        {
            return;
        }


        this.m_last_tiaozhan_day_union = ComFunc.Check_Read_Number(basic_obj.m_last_tiaozhan_day_union)
        this.m_subgametype_curday_tiaozhaned_count_map = ComFunc.Serize_Saved_OBJ_Map(basic_obj.m_subgametype_curday_tiaozhaned_count_map)
        this.m_subgametype_curday_tiaozhan_successed_count_map = ComFunc.Serize_Saved_OBJ_Map(basic_obj.m_subgametype_curday_tiaozhan_successed_count_map)
        this.m_subgametype_curday_tiaozhan_failed_count_map = ComFunc.Serize_Saved_OBJ_Map(basic_obj.m_subgametype_curday_tiaozhan_failed_count_map)
          

    }
    Save_Game_Basic_Info()
    {
        var basicinfo = {  
             
            m_last_tiaozhan_day_union:this.m_last_tiaozhan_day_union, 
            m_subgametype_curday_tiaozhaned_count_map:ComFunc.Format_Save_OBJ_Map(this.m_subgametype_curday_tiaozhaned_count_map),
            m_subgametype_curday_tiaozhan_successed_count_map:ComFunc.Format_Save_OBJ_Map(this.m_subgametype_curday_tiaozhan_successed_count_map),
            m_subgametype_curday_tiaozhan_failed_count_map:ComFunc.Format_Save_OBJ_Map(this.m_subgametype_curday_tiaozhan_failed_count_map),
    
          
        };

       
        MyLocalStorge.setItem("guaishouxiaochu_tiaozhanchang_info",JSON.stringify(basicinfo));

    }
    Update_Tick(dt)
    {
        if(this.m_last_tiaozhan_day_union != ComFunc.GetCurDayUnion())
        {
            this.m_last_tiaozhan_day_union  = ComFunc.GetCurDayUnion();
            this.m_subgametype_curday_tiaozhaned_count_map.clear();
            this.m_subgametype_curday_tiaozhan_successed_count_map.clear();
            this.m_subgametype_curday_tiaozhan_failed_count_map.clear();


            this.Save_Game_Basic_Info();
        }

    }
  
    Get_TiaozhanChang_Curday_Success_Count(isubgametype)
    {
        var prevc=  0;
        if(this.m_subgametype_curday_tiaozhan_successed_count_map.hasKey(isubgametype))
        {
            prevc = this.m_subgametype_curday_tiaozhan_successed_count_map.getData(isubgametype);
        }

        return prevc;
    }


    Get_TiaozhanChang_Curday_Failed_Count(isubgametype)
    {
        var prevc=  0;
        if(this.m_subgametype_curday_tiaozhan_failed_count_map.hasKey(isubgametype))
        {
            prevc = this.m_subgametype_curday_tiaozhan_failed_count_map.getData(isubgametype);
        }

        return prevc;
    }
    On_Tiaozhanchang_Game_Faile(isubgametype)
    {
        var prevc=  0;
        if(this.m_subgametype_curday_tiaozhan_failed_count_map.hasKey(isubgametype))
        {
            prevc = this.m_subgametype_curday_tiaozhan_failed_count_map.getData(isubgametype);
        }
        this.m_subgametype_curday_tiaozhan_failed_count_map.putData(isubgametype,prevc + 1)

        this.m_last_unfinished_tiaozhanchang_subgametype = 0;
        this.m_first_start_from_dating_restor_subgametype =  0;

        this.m_cur_tiaozhanchang_failed_fuhuo_count = 0;
        this.m_subgametype_cur_skilltype_used_count_map.clear();

        var cur_tiaozhan_count = this.Get_SubgameType_CurDay_Tiaozhan_Count(isubgametype)

        this.Post_Server_Tiaozhan_Result(isubgametype,cur_tiaozhan_count,0);

        this.Save_Game_Basic_Info();
    }

    Post_Server_Tiaozhan_Result(isubgametype,cur_tiaozhan_count,bsuc)
    { 
    }
    On_Tiaozhanchang_Game_Success(isubgametype)
    {
        var prevc=  0;
        if(this.m_subgametype_curday_tiaozhan_successed_count_map.hasKey(isubgametype))
        {
            prevc = this.m_subgametype_curday_tiaozhan_successed_count_map.getData(isubgametype);
        }

        this.m_subgametype_curday_tiaozhan_successed_count_map.putData(isubgametype,prevc + 1);


    

        this.m_last_unfinished_tiaozhanchang_subgametype = 0;
        this.m_first_start_from_dating_restor_subgametype =  0;

        this.m_cur_tiaozhanchang_failed_fuhuo_count = 0;
        this.m_subgametype_cur_skilltype_used_count_map.clear();

        var cur_tiaozhan_count = this.Get_SubgameType_CurDay_Tiaozhan_Count(isubgametype)

         this.Save_Game_Basic_Info();
    }
    On_Tiaozhan_Fuhuoed()
    {
        this.m_cur_tiaozhanchang_failed_fuhuo_count++;
    }
    Get_Tiaozhanchang_Skill_Can_Max_Use_Count( isubgametype,iskilltype)
    {

        if(isubgametype == 9)
        {
            if(iskilltype == 2  )
            {
                return 2;
            }

            if(   iskilltype == 4)
            {
                return 2;
            }
            if(  iskilltype == 1)
            {
                return 9;
            } 

            if(iskilltype == 3  )
            {
                return 6;
            }

        }

        if(isubgametype == 31 || isubgametype == 35)
        {
            if(iskilltype == 21  )
            {
                return 10;
            }

            if(iskilltype == 23  )
            {
                return 4;
            }
            return 2;
        }


        if(isubgametype == 21)
        {
             
            return 2;
        }





        //无限制
        return 999;
    }
    Get_Cur_Tiaozhan_Skill_Use_Count(iskilltype)
    {

        var precv = 0;
        if(this.m_subgametype_cur_skilltype_used_count_map.hasKey(iskilltype))
        {
            precv = this.m_subgametype_cur_skilltype_used_count_map.getData(iskilltype);
        }

        return precv;
    }
    On_Tiaozhan_Use_Skill(isubgametype,iskilltype)
    {
        
        var precv = 0;
        if(this.m_subgametype_cur_skilltype_used_count_map.hasKey(iskilltype))
        {
            precv = this.m_subgametype_cur_skilltype_used_count_map.getData(iskilltype);
        }

        this.m_subgametype_cur_skilltype_used_count_map.putData(iskilltype,precv + 1);

        this.Save_Game_Basic_Info();
    }
    On_Enter_Tiaozhanchang(isubgametype)
    {
        this.m_last_unfinished_tiaozhanchang_subgametype = isubgametype;
        this.m_first_start_from_dating_restor_subgametype = 0;
        this.m_cur_tiaozhanchang_gk_index = 1;
        this.m_cur_tiaozhanchang_failed_fuhuo_count = 0;
        this.m_subgametype_cur_skilltype_used_count_map.clear();

        var prevc = 0;
        if(this.m_subgametype_curday_tiaozhaned_count_map.hasKey(isubgametype))
        {
            prevc = this.m_subgametype_curday_tiaozhaned_count_map.getData(isubgametype);
        }

        this.m_subgametype_curday_tiaozhaned_count_map.putData(isubgametype,prevc + 1);
        this.Save_Game_Basic_Info();
    }

    Get_SubgameType_CurDay_Tiaozhan_Count(isubgametype)
    {
        var prevc = 0;
        if(this.m_subgametype_curday_tiaozhaned_count_map.hasKey(isubgametype))
        {
            prevc = this.m_subgametype_curday_tiaozhaned_count_map.getData(isubgametype);
        }
        return prevc;
    }

}