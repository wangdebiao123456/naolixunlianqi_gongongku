import BackGroundSoundUtils from "../WDT/BackGroundSoundUtils";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class txz_jiesuan extends cc.Component {
    m_p_lisnter = null;
    
    onLoad ()
    {
        var guanbi = this.node.getChildByName("guanbi");
        guanbi.on("click",this.OnBtnExit.bind(this));

     
        var restartgame = this.node.getChildByName("restartgame");
        restartgame.on("click",this.OnBtnRestartGame.bind(this));
        
        
        var nextlevel = this.node.getChildByName("nextlevel");
        nextlevel.on("click",this.OnBtnNextLevel.bind(this));

       
        BackGroundSoundUtils.GetInstance().Play_Effect("com/win");

        BannerGuangaoMng.GetInstance(). CheckShowChaiping(17);

    }

    
    OnBtnNextLevel()
    {
        this.node.destroy();

        if(this.m_p_lisnter)
        {
           
            this.m_p_lisnter.Check_Jiesuan_End_From_Dlg(1);
            this.m_p_lisnter.OnBtnNextLevel();
        }
    }
    OnBtnRestartGame()
    {
        this.node.destroy();

        if(this.m_p_lisnter)
        {
           
            this.m_p_lisnter.Check_Jiesuan_End_From_Dlg(1);
            this.m_p_lisnter.ReStartGame();
        }
 
    }
    SetFinishUseStep(igkindex, moved_step,pp)
    {
        var tip = this.node.getChildByName("tip");
        tip.getComponent(cc.Label).string =  "步数:"+moved_step;


        var gkindex = this.node.getChildByName("gkindex");
        gkindex.getComponent(cc.Label).string =  "第"+igkindex+"关";

        
    
        this.m_p_lisnter = pp;
    }
    OnBtnExit()
    {
        this.node.destroy();
 

    }
}
