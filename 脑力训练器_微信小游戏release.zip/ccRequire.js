let moduleMap = {
'assets/internal/index.js' () { return require('assets/internal/index.js') },
'src/scripts/gameani/index.js' () { return require('src/scripts/gameani/index.js') },
'src/scripts/guaishou/index.js' () { return require('src/scripts/guaishou/index.js') },
'src/scripts/guaishouxiaoxiao/index.js' () { return require('src/scripts/guaishouxiaoxiao/index.js') },
'src/scripts/guimi/index.js' () { return require('src/scripts/guimi/index.js') },
'src/scripts/image/index.js' () { return require('src/scripts/image/index.js') },
'src/scripts/jiubei_xunlian/index.js' () { return require('src/scripts/jiubei_xunlian/index.js') },
'src/scripts/juba/index.js' () { return require('src/scripts/juba/index.js') },
'src/scripts/luosi/index.js' () { return require('src/scripts/luosi/index.js') },
'src/scripts/music/index.js' () { return require('src/scripts/music/index.js') },
'src/scripts/music_bj/index.js' () { return require('src/scripts/music_bj/index.js') },
'src/scripts/newimage/index.js' () { return require('src/scripts/newimage/index.js') },
'src/scripts/Prefabs/index.js' () { return require('src/scripts/Prefabs/index.js') },
'src/scripts/shuipaixu/index.js' () { return require('src/scripts/shuipaixu/index.js') },
'src/scripts/xjsimage/index.js' () { return require('src/scripts/xjsimage/index.js') },
'src/scripts/yiyiHurt/index.js' () { return require('src/scripts/yiyiHurt/index.js') },
'assets/start-scene/index.js' () { return require('assets/start-scene/index.js') },
// tail
};

window.__cocos_require__ = function (moduleName) {
    let func = moduleMap[moduleName];
    if (!func) {
        throw new Error(`cannot find module ${moduleName}`);
    }
    return func();
};